#!/usr/bin/env python3
# Copyright (C) 2026 Baptiste Bonnet
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""
forefst.py — ReFS forensic file lister.

Produces CSV and body file output from ReFS disk images with comprehensive
metadata for each file and directory:
  - Full path, OID, parent OID, filename, extension
  - 4 MACB timestamps (Created, Modified, Changed, Accessed) with sub-second precision
  - File attributes, file size, allocated size
  - SecurityId, Owner SID, USN
  - ADS (Alternate Data Streams) detection
  - Encryption, compression, integrity flags
  - Reparse point target (symlinks, junctions)
  - Deleted file detection: Trash Table + orphan objects + checkpoint comparison
  - Previous file versions via $SNAPSHOT embedded attributes
  - Hard link detection (names sharing one home-directory OID + file_id, size-matched)
  - ReFS version info

Supports ReFS 3.4 through 3.14+ and Windows Insider builds.

CSV output is designed to be comparable with common NTFS file-lister output
output for NTFS $MFT, enabling side-by-side forensic comparison.

Usage:
  python3 forefst.py <image>                     # CSV to stdout
  python3 forefst.py <image> -o output.csv       # CSV to file
  python3 forefst.py <image> --json               # JSON output (pretty-printed array)
  python3 forefst.py <image> --jsonl              # JSON Lines output (one object per line)
  python3 forefst.py <image> --body               # body file format
  python3 forefst.py <image> fastsummary          # quick volume summary (no directory walk)
  python3 forefst.py <image> summary              # full summary with file statistics
  python3 forefst.py <image> summary --json       # summary as JSON
  python3 forefst.py <image> deleted              # recover deleted files (deleted --full for the complete scan)
  python3 forefst.py <image> --partition-start 0  # override partition offset
  python3 forefst.py <image> --cow-before <earlier_image>  # forward CoW version recovery

Body file format (Sleuthkit/mactime compatible):
  MD5|name|inode|mode_as_string|UID|GID|size|atime|mtime|ctime|crtime
"""

from __future__ import annotations
import argparse, atexit, csv, datetime, errno, hashlib, json, os, struct, sys

# ─── Shared utilities (formerly in refs_common.py) ───────────────────
SECTOR = 512
SUPB_LCN = 0x1E
GPT_BASIC_DATA = bytes.fromhex("a2a0d0ebe5b9334487c068b6b72699c7")

def le16(b, off): return int.from_bytes(b[off:off+2], "little")
def le32(b, off): return int.from_bytes(b[off:off+4], "little")
def le64(b, off): return int.from_bytes(b[off:off+8], "little")

# GPT lives at LBA 1, so its byte offset depends on the disk's logical sector size: 512 on 512-native and
# 512e media, 4096 on 4Kn. Everything here tries 512 FIRST, so every image that parses today takes exactly
# the path it always did; 4096 is only reached when there is no GPT signature at 512.
_LBA_SIZES = (512, 4096)


def _read_gpt_header(f):
    """(header_bytes, lba_size) for the GPT at LBA 1, or (None, 512).

    NOTE: the 4096 branch is **untested** — this project has no 4Kn media. It is written so a 4Kn image is
    read rather than rejected outright, not because the behaviour has been observed. Treat a result obtained
    through it as unverified, and prefer `--partition-start` if the geometry looks wrong.
    """
    for lba in _LBA_SIZES:
        try:
            f.seek(lba)
            hdr = f.read(lba)
        except (OSError, OverflowError):
            continue
        if len(hdr) >= 92 and hdr[:8] == b"EFI PART":
            return hdr, lba
    return None, _LBA_SIZES[0]


def find_refs_partition(path):
    """Find the first ReFS partition in a GPT disk image.

    Returns (partition_start_bytes, description_string), or (None, error_message) if no GPT /
    no partition. Each Basic-Data partition's VBR is read and the first one whose signature is
    "ReFS" (VBR offset 3) is returned, so an NTFS/FAT partition that precedes the ReFS one is
    skipped. If NO Basic-Data partition carries a ReFS signature, falls back to the first
    Basic-Data partition (prior behaviour); the caller's parse_vbr then validates/aborts on it.
    """
    with open(path, "rb") as f:
        hdr, lba = _read_gpt_header(f)
        if hdr is None:
            return None, "no GPT partition table found (use --partition-start for raw partitions)"
        plba = le64(hdr, 72)
        np = min(le32(hdr, 80), 128)     # audit 2.2: cap entry count (a fuzzed 0xFFFFFFFF x es read = MemoryError)
        es = le32(hdr, 84)
        if not (128 <= es <= 4096):      # entry size outside the UEFI spec -> not a usable GPT
            return None, "GPT partition-entry array is out of spec (use --partition-start for raw partitions)"
        f.seek(plba * lba)
        entries = f.read(np * es)
        first_basic = None
        for i in range(np):
            e = entries[i*es:(i+1)*es]
            if len(e) >= 128 and e[:16] == GPT_BASIC_DATA:
                start = le64(e, 32) * lba
                if first_basic is None:
                    first_basic = (start, f"partition #{i+1}")
                try:
                    f.seek(start + 3)
                    if f.read(4) == b"ReFS":
                        return start, f"partition #{i+1}"
                except OSError:
                    pass
    if first_basic is not None:
        return first_basic
    return None, "no ReFS partition found in GPT (use --partition-start for raw partitions)"

def gpt_partition_detail(path):
    """GPT detail for the first ReFS partition, for informational -vv display.

    Returns {index (1-based), name, first_lba, last_lba, size_bytes, start_bytes}
    or None. Purely descriptive — parsing always uses find_refs_partition();
    never depend on this for the partition offset.
    """
    try:
        with open(path, "rb") as f:
            hdr, lba = _read_gpt_header(f)
            if hdr is None:
                return None
            plba = le64(hdr, 72); np = min(le32(hdr, 80), 128); es = le32(hdr, 84)
            if not (128 <= es <= 4096):     # audit 2.2: bound entries/size before the read (MemoryError guard)
                return None
            f.seek(plba * lba)
            entries = f.read(np * es)
        for i in range(np):
            e = entries[i*es:(i+1)*es]
            if len(e) >= 128 and e[:16] == GPT_BASIC_DATA:
                first, last = le64(e, 32), le64(e, 40)
                name = e[56:128].decode("utf-16-le", "replace").rstrip("\x00").strip()
                return {
                    "index": i + 1,
                    "name": name or "(unnamed)",
                    "first_lba": first,
                    "last_lba": last,
                    "size_bytes": (last - first + 1) * lba if last >= first else 0,
                    "start_bytes": first * lba,
                }
    except Exception:
        return None
    return None

def validate_image(path, die_fn=None):
    """Pre-flight check: path is a readable file with ReFS or GPT signature.

    If die_fn is provided, calls die_fn(msg) on error (should not return).
    Otherwise raises ValueError on error.
    Detects: missing files, directories, too-small files, NTFS, BitLocker,
    blank/unrecognized images.
    """
    def fail(msg):
        if die_fn:
            die_fn(msg)
        raise ValueError(msg)

    if not os.path.exists(path):
        fail(f"file not found: {path}")
    if not os.path.isfile(path):
        fail(f"not a regular file: {path}")
    if os.path.getsize(path) < 4096:
        fail(f"file too small to be a disk image: {path}")

    try:
        with open(path, "rb") as f:
            header = f.read(512)
            if len(header) < 512:
                fail(f"cannot read image header: {path}")

            # Direct ReFS VBR at sector 0 (raw partition image)
            if header[3:7] == b"ReFS":
                return
            if b"NTFS" in header[:16]:
                fail("image contains NTFS, not ReFS")
            if b"-FVE-FS-" in header[:16]:
                fail("image is BitLocker-encrypted")

            # Check for GPT at sector 0 or sector 1
            gpt_header = None
            gpt_lba = SECTOR
            if header[:8] == b"EFI PART":
                gpt_header = header
            else:
                gpt_header, gpt_lba = _read_gpt_header(f)

            if gpt_header is None:
                fail("no ReFS or GPT signature found "
                     "(use --partition-start for raw partitions)")

            # GPT found — scan EVERY Basic-Data partition's VBR to confirm ReFS
            plba = struct.unpack_from("<Q", gpt_header, 72)[0]
            nparts = min(struct.unpack_from("<I", gpt_header, 80)[0], 128)   # audit 2.2: cap the entry count
            esz = struct.unpack_from("<I", gpt_header, 84)[0]
            if not (128 <= esz <= 4096):                                     # audit 2.2: bound entry size (bomb)
                fail("GPT partition-entry array is out of spec "
                     "(use --partition-start for raw partitions)")
            f.seek(plba * gpt_lba)
            entries = f.read(nparts * esz)
            # audit 2.3: scan EVERY Basic-Data partition and accept if ANY is ReFS. Was `break` after the first,
            # so a ReFS partition BEHIND an NTFS one was rejected here while find_refs_partition accepted it —
            # two acceptance policies on one image (`files` worked, `usn` said "not ReFS"). Report NTFS/BitLocker
            # (preserving the exact prior message, so a single-partition image is byte-unchanged) only when NO
            # partition is ReFS.
            saw = None
            for i in range(nparts):
                e = entries[i*esz:(i+1)*esz]
                if len(e) >= 128 and e[:16] == GPT_BASIC_DATA:
                    part_lba = struct.unpack_from("<Q", e, 32)[0]
                    f.seek(part_lba * gpt_lba)
                    vbr = f.read(SECTOR)          # the VBR signature check only needs the first 512 bytes
                    if len(vbr) >= 16:
                        if vbr[3:7] == b"ReFS":
                            return  # confirmed ReFS partition (any position)
                        if saw is None and b"NTFS" in vbr[:16]:      saw = "NTFS"
                        if saw is None and b"-FVE-FS-" in vbr[:16]:  saw = "BitLocker"
            if saw == "NTFS":
                fail("partition contains NTFS, not ReFS")
            if saw == "BitLocker":
                fail("partition is BitLocker-encrypted")
            # GPT present but no Basic-Data partition confirmed ReFS — let tools try
    except PermissionError:
        fail(f"permission denied: {path}")
    except OSError as e:
        fail(f"cannot read image: {e}")

# ─── Constants ────────────────────────────────────────────────────────
PROG = "forefst"
VERSION = "1.11.2"
# Phase 3 (4.D): directory walks default to FULL depth (no artificial cap); `--depth N` overrides. The real
# recursion depth equals the actual directory nesting (ReFS trees are shallow — tens of levels), so this
# constant is never the binding limit; it just means "don't truncate". main() also raises the interpreter
# recursion limit as a safety margin for unusually deep trees.
DEFAULT_DEPTH = 1000000
# Non-resident directory entries have a short value (OID + timestamps + attrs + size).
# Resident entries (small files) embed full $SI + data inline and are longer.
NON_RESIDENT_MAX_VALUE = 84

# Canonical file-attribute flag table (TitleCase) — SINGLE source of truth; refsanalysis
# imports this and FILE_ATTR_SIMPLE (it deleted its own UPPERCASE copies). EA (0x40000) is
# LEFT EXACTLY AS-IS — do NOT touch the EA flag/handling (errata E22/E36). Virtual/Pinned/
# Unpinned (0x10000/0x80000/0x100000, winnt.h FILE_ATTRIBUTE_*) added 2026-06-29; proven
# DORMANT — 0 of 525,198 corpus files (112 images) carry them, and no on-disk attribute bit
# falls outside this table, so their addition changes no rendered output.
FILE_ATTR_FLAGS = {
    0x0001: "ReadOnly", 0x0002: "Hidden", 0x0004: "System",
    0x0010: "Directory", 0x0020: "Archive", 0x0040: "Device",
    0x0080: "Normal", 0x0100: "Temporary", 0x0200: "SparseFile",
    0x0400: "ReparsePoint", 0x0800: "Compressed", 0x1000: "Offline",
    0x2000: "NotContentIndexed", 0x4000: "Encrypted",
    0x8000: "IntegrityStream", 0x00010000: "Virtual",
    0x00020000: "NoScrubData", 0x00040000: "EA",
    0x00080000: "Pinned", 0x00100000: "Unpinned",
    0x10000000: "Directory_Internal",
}

# Short subset for compact listings (refsanalysis full=False uses this). TitleCase mirror of
# the legacy refsanalysis _FILE_ATTR_SIMPLE; 0x10000000 -> "Directory" (the user-facing
# directory marker), matching that table's intent.
FILE_ATTR_SIMPLE = {
    0x0001: "ReadOnly", 0x0002: "Hidden", 0x0004: "System",
    0x0020: "Archive", 0x0080: "Normal", 0x0400: "ReparsePoint",
    0x0800: "Compressed", 0x2000: "NotContentIndexed",
    0x10000000: "Directory",
}

# Canonical well-known SID name table (richer BUILTIN\ form) — refsanalysis imports this and
# deleted its own copy. Names are the authoritative BUILTIN\/mandatory-level/app-package
# strings (previously only in refsanalysis); surfacing them enriches forefst's OwnerSid.
WELL_KNOWN_SIDS = {
    "S-1-0-0": "Nobody", "S-1-1-0": "Everyone", "S-1-2-0": "LOCAL",
    "S-1-3-0": "CREATOR OWNER", "S-1-3-1": "CREATOR GROUP",
    "S-1-5-7": "ANONYMOUS LOGON", "S-1-5-11": "Authenticated Users",
    "S-1-5-18": "SYSTEM", "S-1-5-19": "LOCAL SERVICE",
    "S-1-5-20": "NETWORK SERVICE",
    "S-1-5-32-544": "BUILTIN\\Administrators", "S-1-5-32-545": "BUILTIN\\Users",
    "S-1-5-32-546": "BUILTIN\\Guests", "S-1-5-32-547": "BUILTIN\\Power Users",
    "S-1-5-32-551": "BUILTIN\\Backup Operators",
    "S-1-15-2-1": "ALL APPLICATION PACKAGES",
    "S-1-15-2-2": "ALL RESTRICTED APPLICATION PACKAGES",
    "S-1-16-0": "Untrusted Mandatory Level",
    "S-1-16-4096": "Low Mandatory Level",
    "S-1-16-8192": "Medium Mandatory Level",
    "S-1-16-8448": "Medium Plus Mandatory Level",
    "S-1-16-12288": "High Mandatory Level",
    "S-1-16-16384": "System Mandatory Level",
}

# Canonical Microsoft reparse-tag name table (ntifs.h / MS-FSCC, full IO_REPARSE_TAG_* names).
# SINGLE source of truth — refsanalysis imports this (it deleted its own _REPARSE_TAGS copy).
# Post-E41/#341: every tag that ACTUALLY occurs on disk in the corpus (MOUNT_POINT, SYMLINK,
# APPEXECLINK, AF_UNIX, LX_FIFO/CHR/BLK) was re-verified correct vs ntifs.h (0x80000024=LX_FIFO
# NOT ONEDRIVE; 0x80000017=WOF; 0x80000018=WCI). H3 verification (2026-06-29) flagged TWO latent
# entries that are ABSENT from the entire 113-image corpus (zero forensic impact, kept as-is to
# avoid an unverifiable change): 0x90001027 WCI_LINK_1 (MS-FSCC canonical value is 0xA0001027) and
# 0x80000016 WOF_DFM (MS-FSCC name is DFM). Both never appear on disk; see DOCS_UPDATE_CHECKLIST.
REPARSE_TAGS = {
    0xA0000003: "IO_REPARSE_TAG_MOUNT_POINT",
    0xC0000004: "IO_REPARSE_TAG_HSM",
    0x80000005: "IO_REPARSE_TAG_DRIVE_EXTENDER",
    0x80000006: "IO_REPARSE_TAG_HSM2",
    0x80000007: "IO_REPARSE_TAG_SIS",
    0x80000008: "IO_REPARSE_TAG_WIM",
    0x80000009: "IO_REPARSE_TAG_CSV",
    0x8000000A: "IO_REPARSE_TAG_DFS",
    0x8000000B: "IO_REPARSE_TAG_FILTER_MANAGER",
    0xA000000C: "IO_REPARSE_TAG_SYMLINK",
    0x80000012: "IO_REPARSE_TAG_DFSR",
    0x80000013: "IO_REPARSE_TAG_DEDUP",
    0x80000014: "IO_REPARSE_TAG_NFS",
    0x80000015: "IO_REPARSE_TAG_FILE_PLACEHOLDER",
    0x80000016: "IO_REPARSE_TAG_WOF_DFM",
    0x80000017: "IO_REPARSE_TAG_WOF",
    0x80000018: "IO_REPARSE_TAG_WCI",
    0x90001018: "IO_REPARSE_TAG_WCI_1",
    0xA0000019: "IO_REPARSE_TAG_GLOBAL_REPARSE",
    0x9000001A: "IO_REPARSE_TAG_CLOUD",
    0x8000001B: "IO_REPARSE_TAG_APPEXECLINK",
    0x9000001C: "IO_REPARSE_TAG_PROJFS",
    0xA000001D: "IO_REPARSE_TAG_LX_SYMLINK",
    0x8000001E: "IO_REPARSE_TAG_STORAGE_SYNC",
    0xA000001F: "IO_REPARSE_TAG_WCI_TOMBSTONE",
    0x80000020: "IO_REPARSE_TAG_UNHANDLED",
    0x80000021: "IO_REPARSE_TAG_ONEDRIVE",
    0xA0000022: "IO_REPARSE_TAG_PROJFS_TOMBSTONE",
    0x80000023: "IO_REPARSE_TAG_AF_UNIX",
    0x80000024: "IO_REPARSE_TAG_LX_FIFO",
    0x80000025: "IO_REPARSE_TAG_LX_CHR",
    0x80000026: "IO_REPARSE_TAG_LX_BLK",
    0xA0000027: "IO_REPARSE_TAG_WCI_LINK",
    0x90001027: "IO_REPARSE_TAG_WCI_LINK_1",
    0xA0000028: "IO_REPARSE_TAG_DATALESS_CIM",
}

def reparse_tag_str(tag):
    """Render a reparse tag as 'IO_REPARSE_TAG_NAME (0xXXXXXXXX)' (or bare hex if unknown)."""
    name = REPARSE_TAGS.get(tag)
    return f"{name} (0x{tag:08x})" if name else f"0x{tag:08x}"

# ─── Helpers ──────────────────────────────────────────────────────────
def filetime_to_iso(ft):
    """Convert FILETIME to ISO 8601 with 7-digit sub-second precision."""
    if ft == 0 or ft >= 0xFFFFFFFFFFFFFFFF:
        return ""
    try:
        epoch_diff = 116444736000000000
        total_100ns = ft - epoch_diff
        seconds = total_100ns // 10000000
        frac = total_100ns % 10000000
        dt = datetime.datetime.fromtimestamp(seconds, tz=datetime.timezone.utc)
        return dt.strftime("%Y-%m-%d %H:%M:%S") + f".{frac:07d}"
    except (OSError, ValueError, OverflowError) as _e:
        # The absent cases (0, all-ones) already returned above, so reaching here means the volume
        # HOLDS a value that will not render -- itself an anomaly worth seeing. Rendering "" keeps the
        # column shape, but the reader is told rather than shown a blank that looks like "no timestamp".
        _skip_note("FILETIME conversion", f"raw 0x{ft:x}", _e)
        return ""

def filetime_to_unix(ft):
    if ft == 0 or ft >= 0xFFFFFFFFFFFFFFFF:
        return 0
    try:
        # integer // (not float /) — float division rounds up at ~0.9999999 s, giving a Unix second
        # 1 too high; filetime_to_iso already uses //. (fix 2026-06-20)
        return (ft - 116444736000000000) // 10000000
    except (ValueError, OverflowError) as _e:
        _skip_note("FILETIME conversion", f"raw 0x{ft:x}", _e)
        return 0

# ── Timestamp-anomaly (timestomp) detection ────────────────────────────────
# A FILETIME tick is 100 ns; one day = 24*3600*1e7 ticks. The default margin
# tolerates normal close-in-time metadata ops while catching the year-scale
# back-dating that timestomping produces.
TS_MARGIN_100NS = 24 * 3600 * 10**7  # 1 day

def _ft_valid(ft):
    return 0 < ft < 0xFFFFFFFFFFFFFFFF

def timestomp_intrinsic_flags(create, modify, change, access,
                              vol_create=0, vol_modify=0, margin=TS_MARGIN_100NS):
    """Intrinsic ($SI-only) timestamp-anomaly indicators for one file.

    Returns a list of short flag strings. These are SUGGESTIVE, not proof. The
    metadata-change time ($SI+0x10) is an ordinary timestamp, but the high-level
    APIs timestomp tools usually use (Win32 SetFileTime, PowerShell, .NET) expose
    only Creation/Write/Access — NOT the change time — so after such a stomp the FS
    leaves the change time at the real write moment while B/M/A are back-dated:
    `change >> max(create, modify)` (CHANGE_LATE) is the tell. This is a heuristic
    against common tooling, NOT tamper-proof: the change time CAN be set via the
    native NtSetInformationFile(FILE_BASIC_INFORMATION.ChangeTime) or a raw-disk
    edit, which defeats CHANGE_LATE. Also trips on a creation-time-preserving copy
    (robocopy /COPY:T, restore) or a legitimate late rename/ACL change on an aged
    file. Corroborate with the USN journal (refsanalysis `timestomp`)."""
    flags = []
    if not _ft_valid(create):
        return flags
    base = max(create, modify) if _ft_valid(modify) else create
    if _ft_valid(change) and change > base + margin:
        flags.append("CHANGE_LATE")        # metadata-change time post-dates created/modified
    if _ft_valid(modify) and create > modify + margin:
        flags.append("CREATE_GT_MODIFY")   # created after last write
    if _ft_valid(vol_create) and create < vol_create - margin:
        flags.append("PRE_FORMAT")         # created before the volume existed
    if _ft_valid(vol_modify) and create > vol_modify + margin:
        flags.append("FUTURE")             # created after the volume's last metadata write
    return flags

# ─── timestomp verdict — ONE source for both surfaces ────────────────────────
# HISTORY, kept because it explains why this function exists at all. The `files` TimestompFlags column
# (removed in v1.11.0) and the `timestomp` command each computed their own tier. They disagreed on
# 40-55 % of flagged files (101/184, 62/151, 50/114 on three volumes): the column called
# CHANGE_LATE|PRE_FORMAT "MEDIUM", the command called it "HIGH — two independent intrinsic signals".
#
# Measured over the full corpus -- 96 images / 521,060 files -- the command's premise is false. The two are
# NOT independent:
#
#     PRE_FORMAT        22.67 % of all files   (created before the volume existed)
#     CHANGE_LATE       22.32 %                (change time post-dates create/modify)
#     CREATE_GT_MODIFY   1.04 %
#     HARDLINK_MACB_MISMATCH 0.04 %
#
#     CHANGE_LATE together with PRE_FORMAT : 115,936
#     CHANGE_LATE WITHOUT PRE_FORMAT       :     384  (0.33 %, all on one real Windows volume)
#
# A timestamp-preserving copy (robocopy /COPY:T, restore, archive extraction) sets create/modify to the
# original values -- before this volume existed -- and the change time to the copy moment. That fires BOTH
# signals, which is why they never appear apart. They are two halves of ONE event, not corroborating
# evidence, and tiering their co-occurrence HIGH marks 12 % of an ordinary volume as tampered.
#
# But the pair does NOT identify that event as a copy. Deliberately backdating a creation time produces the
# same two signals, and a lab volume whose generator log records 74 SetCreationTimeUtc calls carries exactly
# this signature -- so "INFO = a copy" asserts a cause the bytes cannot establish. INFO means AMBIGUOUS:
# one event that a copy and a backdated creation both produce, to be separated by the journal, not by the
# timestamps. It is a lowered tier, never an exoneration. What DOES survive as evidence is
# CHANGE_LATE *without* PRE_FORMAT -- born on this volume, metadata altered afterwards, which a copy cannot
# produce -- plus the ReFS-specific per-name HARDLINK_MACB_MISMATCH and journal corroboration. (A 27-image
# subset showed 0 of that residual and an earlier draft called the rule witness-less; the full corpus has
# 384, so measure on everything before describing a cohort as empty.)
TIMESTOMP_TIERS = ("HIGH", "MEDIUM", "LOW", "INFO", "NONE")
_TS_COPY_SIGNATURE = {"PRE_FORMAT", "CHANGE_LATE", "CREATE_GT_MODIFY", "ROUND_TIMESTAMPS"}


def timestomp_verdict(flags, usn_conf=False, hl_conf=False, round_ts=False):
    """(tier, signals) for one file. The ONLY place a timestomp tier is decided.

    `flags`    intrinsic signals from timestomp_intrinsic_flags(), plus any USN_* the caller established.
    `usn_conf` the change journal corroborates (authoritative, independent source).
    `hl_conf`  a hard-link sibling preserves the true birth (structural, journal-independent).
    `round_ts` whole-second Created AND Modified -- a weak hint that never lifts a tier on its own.

    A caller with less evidence gets a tier no HIGHER than one with more: the column passes usn_conf=False
    because the walk does not read the journal, so its verdict is the command's minus journal corroboration.
    """
    sig = list(flags)
    if round_ts and "ROUND_TIMESTAMPS" not in sig:
        sig.append("ROUND_TIMESTAMPS")
    if hl_conf and "HARDLINK_MACB_MISMATCH" not in sig:
        sig.append("HARDLINK_MACB_MISMATCH")
    has = set(sig)
    if not has:
        return "NONE", sig
    if hl_conf or "HARDLINK_MACB_MISMATCH" in has:
        return "HIGH", sig                      # ReFS-only, journal-independent (0.31 % base rate)
    if usn_conf:
        return "HIGH", sig                      # the journal is an independent source
    if "CHANGE_LATE" in has and "PRE_FORMAT" not in has:
        return "MEDIUM", sig                    # created on THIS volume, metadata altered later
    if "FUTURE" in has:
        return "MEDIUM", sig                    # created after the volume's last metadata write
    if has <= _TS_COPY_SIGNATURE:
        return "INFO", sig                      # ambiguous: a copy AND a backdate both produce this
    return "LOW", sig


def attrs_to_str(attrs, full=True, hex_if_empty=False):
    """Render file-attribute bits as 'Flag|Flag'. full=False uses the short subset.
    hex_if_empty=True renders no-flags as '0x..' (refsanalysis behaviour); the forefst
    default renders no-flags as '' (unchanged)."""
    table = FILE_ATTR_FLAGS if full else FILE_ATTR_SIMPLE
    flags = [name for bit, name in table.items() if attrs & bit]
    if flags:
        return "|".join(flags)
    return f"0x{attrs:x}" if hex_if_empty else ""

def attrs_to_mode(attrs, is_dir):
    if is_dir: return "d/drwxrwxrwx"
    if attrs & 0x400: return "l/lrwxrwxrwx"
    r = "-" if attrs & 0x01 else "r"
    return f"-/{r}rwxrwxrwx"

def parse_sid(data, offset):
    """Parse a SECURITY_DESCRIPTOR SID at offset -> (sid_string, sid_len). On a
    malformed/truncated SID returns the sentinel '(invalid)'/'(truncated)' (single
    canonical behaviour; refsanalysis imports this)."""
    if offset + 8 > len(data): return "(invalid)", 0
    revision = data[offset]
    sub_count = data[offset + 1]
    # A structurally valid SID has revision == 1 (SID_REVISION) and <= 15 sub-authorities
    # (SID_MAX_SUB_AUTHORITIES). Reject impossible values so a corrupt SD can't emit a fake
    # 'S-88-...' into the OwnerSid column (E13). reference_table FS_SECD_RA_001: all SDs revision=1.
    if revision != 1 or sub_count > 15: return "(invalid)", 0
    authority = int.from_bytes(data[offset+2:offset+8], "big")
    sid_len = 8 + sub_count * 4
    if offset + sid_len > len(data): return "(truncated)", sid_len
    subs = [le32(data, offset + 8 + i * 4) for i in range(sub_count)]
    return f"S-{revision}-{authority}" + "".join(f"-{s}" for s in subs), sid_len

def sid_name(sid_str):
    """Friendly NAME for a SID (name only; callers append ' (SID)'). '' = unknown
    (callers then show the raw SID). Domain RIDs keep the RID for non-builtin users."""
    if sid_str in WELL_KNOWN_SIDS:
        return WELL_KNOWN_SIDS[sid_str]
    if sid_str.startswith("S-1-5-21-"):
        rid = sid_str.rsplit("-", 1)[-1]
        try:
            rid_int = int(rid)
            if rid_int == 500: return "Administrator"
            if rid_int == 501: return "Guest"
            if rid_int == 512: return "Domain Admins"
            if rid_int == 513: return "Domain Users"
            if rid_int == 514: return "Domain Guests"
            return f"DomainUser (RID={rid_int})"
        except ValueError: pass
        return "DomainUser"
    return ""

def ext_from_name(name):
    if "." in name:
        e = name.rsplit(".", 1)[-1]
        if len(e) <= 10: return f".{e}"
    return ""

# ─── GPT + VBR + SUPB + CHKP ─────────────────────────────────────────
def parse_vbr(f, ps):
    f.seek(ps); bs = f.read(512)
    if bs[3:7] != b"ReFS":
        sig = bs[3:15].rstrip(b'\x00').decode('ascii', errors='replace')
        if b"NTFS" in bs[:16]:
            raise ValueError(f"partition contains NTFS, not ReFS (signature: '{sig}')")
        elif b"-FVE-FS-" in bs[:16]:
            raise ValueError("partition is BitLocker-encrypted (signature: -FVE-FS-)")
        raise ValueError(f"partition does not contain ReFS (VBR signature: '{sig}')")
    bps = le32(bs, 0x20)
    spc = le32(bs, 0x24)
    cs = bps * spc
    # Validate the cluster size before any caller divides by it (audit 2.1: cs==0 -> ZeroDivisionError in
    # bootstrap, which escapes main's `except (ValueError, OSError)` as a raw traceback). Real ReFS clusters
    # are a power of two (4096 or 65536 across the whole corpus); reject 0 / non-power-of-two / absurd so the
    # user gets a diagnosis instead of a crash. ValueError is already handled by main and every forensic handler.
    if cs <= 0 or cs > (2 << 20) or (cs & (cs - 1)):
        raise ValueError(
            f"implausible ReFS cluster size: {bps} B/sector x {spc} sectors/cluster = {cs} B "
            f"(expected a power of two such as 4096 or 65536). The VBR at offset 0x{ps:x} is damaged, or this "
            f"is not the partition start — check --partition-start, or run "
            f"`refsanalysis.py <image> bootedit repair --dry-run`.")
    vmaj = bs[0x28]
    vmin = bs[0x29]
    chk_algo = le16(bs, 0x2A)   # C6: VBR 0x2A is a u16 selector (vbr.md); low byte carries 0/2/4, 0x2B==0 on all corpus images
    bpc = le64(bs, 0x40) if le64(bs, 0x40) != 0 else 0x4000000
    return cs, vmaj, vmin, chk_algo, bpc

def parse_supb(f, ps, cs):
    f.seek(ps + SUPB_LCN * cs); data = f.read(cs)
    if data[:4] != b"SUPB":
        raise ValueError(
            f"superblock (SUPB) not found at LCN 0x{SUPB_LCN:x} (offset 0x{ps + SUPB_LCN * cs:x}): expected "
            f"'SUPB', got {data[:4]!r}. If this is a raw partition image, check --partition-start; to inspect "
            f"the bootstrap chain run `refsanalysis.py <image> supb -v`.")
    off = le32(data, 0x70); cnt = le32(data, 0x74)
    # E9: clamp the on-disk count (doc: always 2). A fuzzed/corrupt cnt (e.g. 0xFFFFFFFF) would build a
    # multi-billion-entry list and hang; also bound to the page so an out-of-range off can't over-read.
    if cnt > 8 or off + cnt * 8 > len(data):
        safe = max(0, min(cnt, 8, (len(data) - off) // 8 if off < len(data) else 0))
        print(f"[{PROG}] WARNING: SUPB checkpoint-ref count {cnt} implausible (doc=2); clamped to {safe}", file=sys.stderr)
        cnt = safe
    return [le64(data, off + i * 8) for i in range(cnt)]

def parse_chkp(f, ps, cs, lcn):
    f.seek(ps + lcn * cs); raw = f.read(4 * cs)
    if raw[:4] != b"CHKP":
        raise ValueError(
            f"checkpoint (CHKP) not found at LCN 0x{lcn:x} (offset 0x{ps + lcn * cs:x}): expected 'CHKP', got "
            f"{raw[:4]!r}. The superblock's checkpoint pointer may be corrupt — run "
            f"`refsanalysis.py <image> chkp -v` to inspect.")
    vclock = le64(raw, 0x10)
    flags = le32(raw, 0x78)
    desc_len = le32(raw, 0x5c)
    indirect = bool(flags & 0x200)
    root_count = le32(raw, 0x90)
    # E9: clamp (doc: always 13; capacity field 0x8C = 0x20 = 32). A fuzzed count would loop billions of times.
    if root_count > 32:
        print(f"[{PROG}] WARNING: CHKP root count {root_count} implausible (doc=13, cap=32); clamped to 32", file=sys.stderr)
        root_count = 32
    olb = le32(raw, 0x94) if indirect else 0x94
    roots = []
    for idx in range(root_count):
        oe = olb + idx * 4
        if oe + 4 > len(raw): roots.append([]); continue
        ro = le32(raw, oe)
        if ro == 0 or ro + desc_len > len(raw): roots.append([]); continue
        rec = raw[ro:ro+desc_len]
        slots = [le64(rec, i*8) for i in range(4)]
        roots.append([s for s in slots if s not in (0, 0xFFFFFFFFFFFFFFFF)])
    return vclock, flags, roots

# ─── Container Table + Translator ─────────────────────────────────────
# ─── Allocator (schema 0xe010) ─────────────────────────────────────────
# Reference: structure_reference.md B.2 / B.2a / B.2b, erratum E74. The row is NOT a fixed 2,072 bytes and
# three of its fields were previously mis-documented; the notes below record only what the driver actually
# does, because a capacity figure built on the wrong field is worse than none at all.
_ALLOC_TIERS = ((1, "Medium", 0x21), (2, "Container", 0x20), (12, "Small", 0x22))
_POPCOUNT = bytes(bin(i).count("1") for i in range(256))


def alloc_decode_row(vd):
    """Decode one allocator row. Returns None if it is not one.

    E74: `flags` bit 0 — not the row length — says whether a bitmap follows, the bitmap offset is the BYTE at
    +0x14 (the byte at +0x15 is a tier/format marker, not part of a u16 "header size"), and the bitmap runs
    for ceil(range_length/8) bytes, so the row is variable-length. The count at +0x16 is a driver hint that
    disagrees with the bitmap on ~14% of rows and is deliberately NOT used for arithmetic here.
    """
    if len(vd) < 0x18:
        return None
    start, length = struct.unpack_from("<QQ", vd, 0x00)
    free_u16, flags, hdr, alloc_hint = struct.unpack_from("<4H", vd, 0x10)
    bmoff, fmt = hdr & 0xFF, hdr >> 8
    r = {"start": start, "length": length, "flags": flags, "bitmap_offset": bmoff, "format": fmt,
         "free_u16": free_u16, "alloc_hint": alloc_hint, "bitmap": None}
    if flags & 1:
        need = ((int(length) + 7) // 8 + 7) & ~7
        if not bmoff or bmoff + need > len(vd):
            return None
        r["bitmap"] = vd[bmoff:bmoff + need]
    return r


def alloc_row_counts(r):
    """(allocated, free) clusters for one decoded row — never reads a saturating field as a number.

    Bitmap row: popcount over exactly `length` bits. Compact row: uniform, and the discriminator is
    `free_u16` (0 = fully allocated, non-zero = fully free) — NOT the +0x16 hint (E74).
    """
    L = int(r["length"])
    bm = r["bitmap"]
    if bm is None:
        return (L, 0) if r["free_u16"] == 0 else (0, L)
    whole, rem = divmod(L, 8)
    pc = sum(_POPCOUNT[b] for b in bm[:whole])
    if rem:
        pc += _POPCOUNT[bm[whole] & ((1 << rem) - 1)]
    return pc, L - pc


def alloc_read_summary(f, ps, cs, tr, roots, root_idx, table_id=None, volume_clusters=None):
    """The 384-byte summary ReFS keeps in an allocator table's ROOT page, as 48 u64s (or None).

    One page read — no tree walk — so a caller can report capacity for free. Slot 1 = clusters covered,
    slot 2 = free clusters (E74 / B.2b); the rest are undecoded. This is the volume's OWN accounting.

    `table_id` makes the read refuse a root page that does not claim this tier's own table: a root INDEX is
    not a tier (root 12 has been seen carrying the Container Table on a damaged volume), and reading 384
    bytes out of the wrong table's page yields confident nonsense. `volume_clusters` adds the obvious
    plausibility bound.
    """
    try:
        if root_idx >= len(roots) or not roots[root_idx]:
            return None
        lcn = roots[root_idx][0]
        p = lcn if root_idx in _CT_ROOT_INDICES else (tr.tr(lcn) if tr else lcn)
        f.seek(ps + p * cs); pg = f.read(cs)
        if pg[:4] != b"MSB+" or len(pg) < 0x58:
            return None
        if table_id is not None and le64(pg, 0x48) != table_id:
            return None
        base = 0x50 + le16(pg, 0x54)
        if base + 384 > len(pg):
            return None
        s = struct.unpack_from("<48Q", pg, base)
        if s[2] > s[1]:                                   # free can never exceed the span
            return None
        if volume_clusters is not None and s[1] > volume_clusters:
            return None
        return s
    except (OSError, OverflowError, struct.error):
        return None


def alloc_capacity(f, ps, cs, tr, roots):
    """Volume capacity from the Medium allocator's persisted summary (one page read).

    Returns None when the summary is unreadable. `covered` is the space the allocator accounts for — the
    Container-Table-mapped area; the physical tail beyond the last container belongs to no tier and is
    reported separately rather than counted as free (E74).
    """
    try:
        vol = (f.seek(0, 2) - ps) // cs
    except (OSError, OverflowError) as _e:
        _skip_note("allocator capacity", "image size", _e)
        return None
    s = alloc_read_summary(f, ps, cs, tr, roots, 1, table_id=0x21, volume_clusters=vol)
    if not s:
        return None
    covered, free = s[1], s[2]
    if not covered:
        return None
    return {"volume_clusters": vol, "covered_clusters": covered, "free_clusters": free,
            "used_clusters": covered - free, "outside_allocator_clusters": vol - covered,
            "cluster_size": cs, "format": s[0]}


def _select_ct_root(f, ps, cs, roots):
    """Pick the Container Table root by its on-disk Table-ID (0x0B), NOT by assuming root index 7.

    The Container-Table failover pair (roots 7 & 8) is not bound to a fixed index->id order (finding #337):
    on some volumes (e.g. a 2 TB volume) root 7 carries the duplicate (0x0C) and root 8 the primary (0x0B).
    Roots 7/8/12 use REAL physical LCNs, so the table-root page is read directly (no translation needed yet).
    Returns the vlcn-list for the primary CT (id 0x0B); falls back to the duplicate (0x0C), then to index 7.
    """
    def tid_of(ri):
        if ri >= len(roots) or not roots[ri]:
            return None
        try:
            f.seek(ps + roots[ri][0] * cs); pg = f.read(cs)
            return le64(pg, 0x48) if pg[:4] == b"MSB+" else None
        except Exception:
            return None
    ids = {ri: tid_of(ri) for ri in (7, 8)}
    for want in (0x0B, 0x0C):                       # prefer primary 0x0B, then duplicate 0x0C
        for ri in (7, 8):
            if ids.get(ri) == want and roots[ri]:
                return roots[ri]
    return roots[7] if len(roots) > 7 and roots[7] else []   # legacy fallback

def _select_ot_root(f, ps, cs, tr, roots):
    """Pick the Object Table root by its on-disk Table-ID (0x02), NOT by assuming root index 0.

    Same discipline as _select_ct_root: finding #337 proves a primary/duplicate root pair is not bound to a
    fixed index->id order, and the Object Table (0x02) + its duplicate (0x04) are such a pair. UNLIKE the CT /
    Small-Allocator roots (real physical LCNs), the Object Table root uses VIRTUAL LCNs, so its page is read
    THROUGH the container translator `tr`. Returns the vlcn-list of the root whose page+0x48 == 0x02; falls
    back to root index 0. Output-neutral on the corpus: root 0 == 0x02 on 116/116 ReFS images (2026-08-29),
    so this returns roots[0] on every current image — the ID check only matters if the pair ever swaps."""
    def tid_of(ri):
        if ri >= len(roots) or not roots[ri]:
            return None
        try:
            f.seek(ps + tr.tr(roots[ri][0]) * cs); pg = f.read(cs)
            return le64(pg, 0x48) if pg[:4] == b"MSB+" else None
        except Exception:
            return None
    for ri in range(len(roots)):                    # root 0 is the Object Table on every known volume
        if tid_of(ri) == 0x02 and roots[ri]:
            return roots[ri]
    return roots[0] if roots and roots[0] else []   # legacy fallback (index 0)

def _parse_ct_page(page, f, ps, cs, _depth=0, visited=None):
    # _depth guard: the Container Table is a shallow B+ tree; 64 bounds a circular/corrupt CT (never trips
    # on valid data) to prevent unbounded recursion. Defaulted kwargs — existing callers are unaffected.
    # E10 (mirrors _walk): `visited` is a per-walk set of head child-LCNs — a self-referential/cyclic inner
    # page would otherwise fan out ~4^depth and re-read identical pages forever (audit 2.4: hangs every
    # subcommand via bootstrap). On a well-formed CT every child page is referenced exactly once, so this
    # NEVER skips a legitimate page and the output is byte-identical; a cyclic child is skipped, not looped.
    if visited is None: visited = set()
    if page[:4] != b"MSB+" or _depth > 64: return {}
    thoff = 0x50 + le32(page, 0x50)
    if thoff + 40 > len(page): return {}
    tbl = struct.unpack_from("<10I", page, thoff)
    is_inner = bool(tbl[3] & 0x100)
    astart, aend = tbl[4], tbl[8]
    if astart >= aend: return {}
    result = {}
    for i in range((aend - astart) // 4):
        aa = thoff + astart + i * 4
        if aa + 4 > len(page): break
        ro = thoff + le16(page, aa)
        if ro + 16 > len(page): break
        rh = struct.unpack_from("<I6H", page, ro)
        _, ko, kl, _, vo, vl, _ = rh
        if (kl and ro + ko + kl > len(page)) or (vl and ro + vo + vl > len(page)):
            continue     # audit 2.5: skip a row whose key/value runs past the page (no silent truncation)
        kd = page[ro+ko:ro+ko+kl] if kl > 0 else b""
        vd = page[ro+vo:ro+vo+vl] if vl > 0 else b""
        key = le64(kd, 0) if len(kd) >= 8 else 0
        if is_inner:
            if len(vd) >= 32:
                cls = [le64(vd, j*8) for j in range(4)]
                valid = [x for x in cls if x not in (0, 0xFFFFFFFFFFFFFFFF)]
                if valid:
                    head = valid[0]                          # E10: key on the head child LCN (mirrors _walk)
                    if head in visited:
                        continue                             # already-read / cyclic child page — skip
                    visited.add(head)
                    cd = b""
                    for l in valid: f.seek(ps + l * cs); cd += f.read(cs)
                    result.update(_parse_ct_page(cd, f, ps, cs, _depth + 1, visited))
        else:
            if len(vd) >= 0x98:
                result[key] = (le64(vd, len(vd) - 16), le32(vd, 0x18))
    return result

class Translator:
    def __init__(self, m, cpc):
        self.map = m; self.cpc = cpc
        # Q9: the shift is bit_length() (= log2(cpc)+1), NOT log2(cpc), and this is CORRECT — not an off-by-one.
        # The driver does exactly this: GetContainerIdFromRealRange adds 1 to the log2 width, and
        # IsValidContainerLcn guarantees the container-boundary bit is 0, so the extra shifted bit is always
        # clear. cpc is a power of two, so mask = cpc-1 recovers the in-container offset. (docs/structures/
        # container_table.md.) Do not "fix" this to bit_length()-1.
        self.shift = cpc.bit_length() if cpc > 0 else 0
        self.mask = cpc - 1 if cpc > 0 else 0
        self.misses = 0   # E11: count VLCNs with no container mapping (unmapped => read as identity)
        self._first_cid = min(self.map) if self.map else None   # below this: not containerised
    def tr(self, vlcn):
        cid = vlcn >> self.shift
        if cid in self.map:
            return self.map[cid] + (vlcn & self.mask)
        # Below the first container id the volume is not containerised: ids start at 2 (E74), so
        # keys 0 and 1 are never in the table and an address there is ALREADY physical. Identity is
        # the correct answer, not a fallback, and counting it as a miss made every v3.4 volume warn
        # that its output "may be incomplete" because of three large files that read perfectly.
        if self._first_cid is not None and cid < self._first_cid:
            return vlcn
        # E11: an unmapped container (corrupt/truncated CT, or a wrong-mode read) falls back to identity
        # (VLCN read as PLCN). That silently loses evidence downstream; count it so callers can surface it.
        self.misses += 1
        return vlcn


_ALL_TRS = []   # audit 4.2: EVERY Translator built this run. Was a single _LAST_TR — but `--cow-before` builds a
                # SECOND Translator (the earlier image), and it silently overwrote the first, dropping that image's
                # unmapped-container caveat — the exact silent evidence-loss the 3.2 fix exists to prevent.

def _warn_translator(tr):
    """Surface unmapped-container misses (audit 3.2/4.2): 0 on a well-formed volume; non-zero => a corrupt/truncated
    container table forced identity-mapped (VLCN==PLCN) reads, so some rows may be missing or wrong. stderr ONLY
    — never alters stdout/JSON, so a valid volume is byte-unchanged — and at most once per translator (the
    `_warned` flag). Registered at-exit so EVERY command carries the caveat (not just fastsummary, 3.2), once per
    image (4.2: `--cow-before` builds a second Translator; the warning is labelled with which image it came from).
    Deliberately NOT suppressed by `-q/--quiet` — an evidence caveat is not progress output. NB: atexit does not
    fire on os._exit()/a signal, so the caveat is structurally slightly less reliable than the output it qualifies
    (neither path occurs in the current code)."""
    if tr is None or not getattr(tr, "misses", 0) or getattr(tr, "_warned", False):
        return
    tr._warned = True
    _img = getattr(tr, "_image", "")
    _where = f" [{_img}]" if _img else ""
    print(f"[{PROG}] WARNING:{_where} {tr.misses} VLCN(s) had no container mapping — output may be incomplete "
          f"(corrupt/truncated container table).", file=sys.stderr)

atexit.register(lambda: [_warn_translator(t) for t in _ALL_TRS])
# Skipped work is reported at exit whatever the command did, for the same reason as the
# translator caveat above: an incomplete answer must not look like a complete one.
def _defer_summary():
    """One line if any content path declined. Separate from the skip summary: a SKIP is work not done,
    a DEFERRAL is an answer deliberately withheld, and a reader needs to tell them apart."""
    if _DEFERRALS:
        print(f"[{PROG}] {len(_DEFERRALS)} stream(s) were DECLINED rather than reassembled; "
              f"no bytes were written for them.", file=sys.stderr)


atexit.register(lambda: _skip_summary())
atexit.register(lambda: _defer_summary())

# ─── B+ tree walker ──────────────────────────────────────────────────
def walk_bplus(f, ps, cs, tr, vlcns, max_depth=5):
    plcns = [tr.tr(v) for v in vlcns] if tr else vlcns
    page = b""
    for p in plcns: f.seek(ps + p * cs); page += f.read(cs)
    return _walk(page, f, ps, cs, tr, max_depth)

def _walk(page, f, ps, cs, tr, depth, visited=None):
    # E10: cycle/re-read protection. A corrupt inner node whose child pointers repeat an ancestor page
    # would otherwise fan out ~4^depth and re-read identical pages. `visited` is a per-walk set keyed on
    # (addressing-mode, head-PLCN) — the mode bit is essential so a translated VLCN and a physical LCN
    # sharing a numeric value are NOT merged (which would drop a real page). On a well-formed tree every
    # child page is referenced exactly once, so this NEVER skips a legitimate page (output unchanged).
    if visited is None: visited = set()
    if depth <= 0 or len(page) < 4 or page[:4] != b"MSB+": return []
    thoff = 0x50 + le32(page, 0x50)
    if thoff + 40 > len(page): return []
    tbl = struct.unpack_from("<10I", page, thoff)
    is_inner = bool(tbl[3] & 0x100)
    astart, aend = tbl[4], tbl[8]
    if astart >= aend: return []
    rows = []
    for i in range((aend - astart) // 4):
        aa = thoff + astart + i * 4
        if aa + 4 > len(page): break
        ro = thoff + le16(page, aa)
        if ro + 16 > len(page): break
        rh = struct.unpack_from("<I6H", page, ro)
        _, ko, kl, _, vo, vl, _ = rh
        if (kl and ro + ko + kl > len(page)) or (vl and ro + vo + vl > len(page)):
            continue     # audit 2.5: a row whose key/value runs past the page is corrupt — skip, don't let
                         # Python slicing return a SHORT buffer that becomes a plausible-but-wrong key
        kd = page[ro+ko:ro+ko+kl] if kl > 0 else b""
        vd = page[ro+vo:ro+vo+vl] if vl > 0 else b""
        if is_inner:
            if len(vd) >= 32:
                cvs = [le64(vd, j*8) for j in range(4)]
                cvld = [x for x in cvs if x not in (0, 0xFFFFFFFFFFFFFFFF)]
                cps = [tr.tr(v) for v in cvld] if tr else cvld
                head = (tr is not None, cps[0]) if cps else None
                if head is not None and head in visited:
                    continue                     # already-walked / cyclic child page — skip
                if head is not None:
                    visited.add(head)
                cp = b""
                for p in cps: f.seek(ps + p * cs); cp += f.read(cs)
                rows.extend(_walk(cp, f, ps, cs, tr, depth-1, visited))
        else:
            rows.append((kd, vd))
    return rows

# ─── Object Table ────────────────────────────────────────────────────
def build_object_map(f, ps, cs, tr, ot_vlcns):
    rows = walk_bplus(f, ps, cs, tr, ot_vlcns)
    objects = {}
    for kd, vd in rows:
        if len(kd) < 16 or len(vd) < 64: continue
        oid = le64(kd, 8)
        lcns = [le64(vd, 0x20 + j*8) for j in range(4)]
        valid = [s for s in lcns if s not in (0, 0xFFFFFFFFFFFFFFFF)]
        objects[oid] = valid
    return objects

# ─── Security Descriptor Table ────────────────────────────────────────
def build_security_map(f, ps, cs, tr, obj_map):
    """Build SecurityId → (Owner SID, Group SID) mapping from OID 0x530.

    SD table key (16 bytes): [val_size(4)] [pad(4)] [sid_high(4)] [sid_low(4)]
    SecurityId = (sid_high << 32) | sid_low
    SD table value: [hash(4)] [count(4)] [size(4)] [SECURITY_DESCRIPTOR_RELATIVE...]
    Within the SD (= value[12:]): owner_off u32 @SD+4, GROUP_OFF u32 @SD+8 (read
    identically to owner). Group verified on disk (H3, 2026-06-29): 2383/2383 SDs valid,
    distinct from owner ~56% of the time; group_off==0 (no group) handled but never occurs.
    Each value is (owner_sid_str, group_sid_str); '' = absent.
    """
    if 0x530 not in obj_map:
        return {}
    vlcns = obj_map[0x530]
    rows = walk_bplus(f, ps, cs, tr, vlcns)
    sd_map = {}
    for kd, vd in rows:
        # Extract SecurityId from key
        if len(kd) >= 16:
            sid_high = le32(kd, 8)
            sid_low = le32(kd, 12)
            sec_id = (sid_high << 32) | sid_low
        elif len(kd) >= 8:
            sec_id = le64(kd, 0)
        else:
            continue

        # SD value: 12-byte header then SECURITY_DESCRIPTOR_RELATIVE
        SD_HDR = 12
        if len(vd) < SD_HDR + 20:
            continue
        sd_data = vd[SD_HDR:]
        if sd_data[0] != 1:  # Revision must be 1
            continue
        off_owner = le32(sd_data, 4)
        owner_str = ""
        if 0 < off_owner < len(sd_data):
            owner_str, _ = parse_sid(sd_data, off_owner)
        off_group = le32(sd_data, 8)
        group_str = ""
        if 0 < off_group < len(sd_data):
            group_str, _ = parse_sid(sd_data, off_group)
        # DACLSummary (P6): a compact per-SecurityId ACE list — the DACL is at SD+0x10 when the control word
        # (SD+0x02) has SE_DACL_PRESENT (0x0004). Reuses the `security` command's _parse_acl; capped for width.
        dacl_sum = ""
        try:
            if le16(sd_data, 2) & 0x0004:
                aces = _parse_acl(sd_data, le32(sd_data, 0x10))
                parts = []
                for a in aces[:6]:
                    who = a.get("sid_name") or a.get("sid") or "?"
                    typ = a.get("type", "").replace("ACCESS_", "").replace("SYSTEM_", "")
                    rights = a.get("mask_str") or ""
                    parts.append(f"{typ}:{who}:{rights}" if rights else f"{typ}:{who}")
                if parts:
                    dacl_sum = f"{len(aces)} ACE(s): " + " | ".join(parts) + (" | …" if len(aces) > 6 else "")
        except Exception:
            dacl_sum = ""
        sd_map[sec_id] = (owner_str, group_str, dacl_sum)
    return sd_map

# ─── Forward CoW Version Recovery (cross-image comparison) ───────────
def cow_recovery(f_after, ps_a, cs_a, tr_a, obj_map_a,
                 before_image, partition_start_before, log_fn):
    """Recover previous file versions via forward CoW Object Table comparison.

    Compares the Object Table between a BEFORE image and the current (AFTER)
    image. Files whose per-object B+ tree page VLCNs differ were modified;
    files present only in BEFORE were deleted. For each, reads old metadata
    (name, timestamps, size) from the BEFORE image and checks whether old
    B+ tree pages survive on the AFTER image (MSB+ signature).

    This is the forward direction (file -> old clusters): only two Object
    Table walks are needed, no full disk scan.

    Returns list of entry dicts compatible with the main forefst output.
    """
    # Bootstrap BEFORE image
    try:
        f_b, ps_b, cs_b, tr_b, roots_b, obj_map_b, vmaj_b, vmin_b, _ = bootstrap(
            before_image, partition_start_before)
    except (ValueError, OSError) as e:
        log_fn(f"[{PROG}] CoW: cannot open BEFORE image: {e}")
        return []

    try:
        if cs_b != cs_a:
            log_fn(f"[{PROG}] CoW: cluster size mismatch "
                   f"(BEFORE={cs_b}, AFTER={cs_a}), skipping")
            return []

        # Compare object maps (user objects only, OID >= 0x600)
        modified = []
        deleted = []
        for oid in sorted(obj_map_b):
            if oid < 0x600:
                continue
            if oid not in obj_map_a:
                deleted.append(oid)
            elif tuple(obj_map_b[oid]) != tuple(obj_map_a[oid]):
                modified.append(oid)

        created_count = sum(1 for o in obj_map_a if o >= 0x600 and o not in obj_map_b)
        log_fn(f"[{PROG}] CoW: {len(modified)} modified, {len(deleted)} deleted, "
               f"{created_count} created (user objects)")

        if not modified and not deleted:
            log_fn(f"[{PROG}] CoW: no changes detected between images")
            return []

        # Extract old metadata for each modified/deleted object
        results = []
        pages_survived = 0
        pages_total = 0

        for oid in modified + deleted:
            vlcns = obj_map_b[oid]

            # Read per-object B+ tree from BEFORE image
            try:
                rows = walk_bplus(f_b, ps_b, cs_b, tr_b, vlcns)
            except Exception as _e:
                # Dropping this object silently would understate the recovery: the operator
                # would see fewer previous versions with nothing saying why.
                _skip_note("CoW recovery (before-image object)", "oid 0x%x" % oid, _e)
                continue

            name = None
            si = {}
            file_size = 0

            for kd, vd in rows:
                if len(kd) < 2:
                    continue
                at = le16(kd, 0)
                if at == 0x30 and len(kd) > 4 and name is None:
                    try:
                        name = kd[4:].decode("utf-16-le").rstrip("\x00")
                    except UnicodeDecodeError:
                        pass
                if at == 0x10 and len(vd) >= 0x60 and not si:
                    si = {
                        "create_time": le64(vd, 0x28),
                        "modify_time": le64(vd, 0x30),
                        "change_time": le64(vd, 0x38),
                        "access_time": le64(vd, 0x40),
                        "file_attrs": le32(vd, 0x48),
                        "internal_flags": le32(vd, 0x4C),
                        "security_id": le64(vd, 0x50),
                        # usn = LastUsn ($SI+0x40 / value+0x68); value+0x58 unpopulated. E30/E45.
                        "usn": le64(vd, 0x68) if len(vd) >= 0x70 else 0,
                    }
                if at == 0x40 and len(vd) >= 0x60:
                    file_size = le64(vd, 0x58)

            if not name and not si:
                continue

            # Check if the object's old B+ tree PAGE still has MSB+ on the AFTER image.
            # `vlcns` is the object's 4-cluster node reference — ONE page, not four. The MSB+ signature lives
            # only at the page's start, so testing every cluster counted 4 "pages" per page and could only ever
            # find 1 survivor: the ratio was pinned at 25% on every volume regardless of what actually survived.
            obj_survived = 0
            _head = next((v for v in vlcns if v), None)
            if _head is not None:
                pages_total += 1
                try:
                    plcn = tr_b.tr(_head)
                    f_after.seek(ps_a + plcn * cs_a)
                    if f_after.read(4) == b"MSB+":
                        obj_survived += 1
                        pages_survived += 1
                except Exception as _e:
                    # This counter drives the "N/M old pages still valid (X%)" figure; a
                    # swallowed failure quietly biases it downward.
                    _skip_note("CoW recovery (page survival probe)", "page", _e)

            fa = si.get("file_attrs", 0)
            status = "cow_modified" if oid in obj_map_a else "cow_deleted"

            entry = {
                # E7: Object Table OID => directory (#327); label by the dir OID, keep child as a note.
                "path": f"$COW_PREVIOUS/DIR_OID_0x{oid:x}",
                "parent_path": "$COW_PREVIOUS",
                "parent_oid": 0,
                "name": f"DIR_OID_0x{oid:x}",
                "recovered_child": name or "",
                "oid": oid,
                "is_resident": False,
                "is_dir": True,
                "is_deleted": True,
                "deletion_source": status,
                "create_time": si.get("create_time", 0),
                "modify_time": si.get("modify_time", 0),
                "change_time": si.get("change_time", 0),
                "access_time": si.get("access_time", 0),
                "file_attrs": fa,
                "internal_flags": si.get("internal_flags", 0),
                "security_id": si.get("security_id", 0),
                "usn": si.get("usn", 0),
                "file_size": file_size,
                "is_encrypted": bool(fa & 0x4000),
                "is_compressed": bool(fa & 0x0800),
                "has_integrity": bool(fa & 0x8000),
                "has_ea": bool(fa & 0x00040000),
                "has_reparse": bool(fa & 0x0400),
                "has_ads": False,
                "ads_names": "",
                "reparse_target": "",
                "snapshot_count": 0,
            }
            results.append(entry)

        if pages_total > 0:
            pct = 100 * pages_survived // pages_total
            log_fn(f"[{PROG}] CoW: {pages_survived}/{pages_total} old B+ tree pages "
                   f"still valid on AFTER image ({pct}%)")

        return results
    finally:
        f_b.close()


def _collect_dir_entries(f, ps, cs, tr, obj_map, oid, parent_path, out, visited, depth, max_depth):
    """Helper: collect directory entry names from a tree (for checkpoint comparison)."""
    if depth > max_depth or oid in visited or oid not in obj_map:
        return
    visited.add(oid)
    vlcns = obj_map[oid]
    try:
        rows = walk_bplus(f, ps, cs, tr, vlcns)
    except Exception:
        return
    for kd, vd in rows:
        if len(kd) < 4 or le16(kd, 0) != 0x30: continue
        try: name = kd[4:].decode("utf-16-le").rstrip("\x00")
        except UnicodeDecodeError: continue
        full_path = f"{parent_path}/{name}" if parent_path else name
        child_oid = 0
        if len(vd) <= NON_RESIDENT_MAX_VALUE and len(vd) >= 0x10:
            child_oid = le64(vd, 0x08)
        out[(oid, name)] = {"name": name, "path": full_path, "oid": child_oid}
        if child_oid and len(vd) <= NON_RESIDENT_MAX_VALUE and len(vd) >= 0x44:
            if le32(vd, 0x40) & 0x10000000:
                _collect_dir_entries(f, ps, cs, tr, obj_map, child_oid, full_path, out, visited, depth+1, max_depth)


# ─── Inline reparse target extraction (for resident entries) ──────────
def extract_inline_reparse(vd):
    """Extract reparse target from a resident entry's embedded attributes."""
    SYMLINK_TAG = b"\x0c\x00\x00\xa0"
    MOUNT_TAG = b"\x03\x00\x00\xa0"
    LX_SYM_TAG = b"\x1d\x00\x00\xa0"

    for tag_bytes, tag_val in [(SYMLINK_TAG, 0xA000000C), (MOUNT_TAG, 0xA0000003), (LX_SYM_TAG, 0xA000001D)]:
        search_start = 0xA8
        idx = vd.find(tag_bytes, search_start)
        if idx < 0 or idx + 20 > len(vd):
            continue
        data_len = le16(vd, idx + 4)
        if data_len < 4:
            continue

        if tag_val == 0xA000000C:  # SYMLINK
            sub_off = le16(vd, idx + 8)
            sub_len = le16(vd, idx + 10)
            print_off = le16(vd, idx + 12)
            print_len = le16(vd, idx + 14)
            buf_start = idx + 20
            if print_len > 0 and buf_start + print_off + print_len <= len(vd):
                try:
                    return vd[buf_start+print_off:buf_start+print_off+print_len].decode("utf-16-le")
                except UnicodeDecodeError:
                    pass
            if sub_len > 0 and buf_start + sub_off + sub_len <= len(vd):
                try:
                    target = vd[buf_start+sub_off:buf_start+sub_off+sub_len].decode("utf-16-le")
                    if target.startswith("\\??\\"):
                        target = target[4:]
                    return target
                except UnicodeDecodeError:
                    pass
        elif tag_val == 0xA0000003:  # MOUNT_POINT/JUNCTION
            sub_off = le16(vd, idx + 8)
            sub_len = le16(vd, idx + 10)
            print_off = le16(vd, idx + 12)
            print_len = le16(vd, idx + 14)
            buf_start = idx + 16
            if print_len > 0 and buf_start + print_off + print_len <= len(vd):
                try:
                    return vd[buf_start+print_off:buf_start+print_off+print_len].decode("utf-16-le")
                except UnicodeDecodeError:
                    pass
        elif tag_val == 0xA000001D:  # LX_SYMLINK
            # E5 fix: the LX_SYMLINK payload is u32 version(=2) + UTF-8 target; skip the 4-byte
            # version (idx+8 -> idx+12) so it does not prefix the target with "\x02\x00\x00\x00".
            try:
                return vd[idx+12:idx+8+data_len].decode("utf-8").rstrip("\x00")
            except UnicodeDecodeError:
                pass
        return REPARSE_TAGS.get(tag_val, f"0x{tag_val:08X}")
    return ""

def extract_reparse_from_backing(vd):
    """Validated REPARSE_DATA_BUFFER target path embedded in a NON-RESIDENT file's type-0x40
    backing record (v3.14). Scans for the symlink (0xA000000C) / junction (0xA0000003) buffer
    at its VARIABLE offset, decodes Print/Substitute name, and accepts only a real path; the
    +0x7C tag MIRROR (a bare tag dword, no valid buffer) is explicitly skipped so it is never
    mistaken for the buffer. Returns '' when no valid target embeds (e.g. v3.7-v3.10, whose
    live backing carries only the +0x7C mirror). H3-verified 2026-06-29: 100% on native v3.14,
    correctly empty on v3.7-v3.10. Caller selects the file's OWN backing via the verified
    hard-link resolution (home stream), which avoids the file_id-collision wrong-target bug."""
    for tag_bytes, has_flags in ((b"\x0c\x00\x00\xa0", True), (b"\x03\x00\x00\xa0", False)):
        pos = 0
        while True:
            idx = vd.find(tag_bytes, pos)
            if idx < 0:
                break
            pos = idx + 1
            if idx == 0x7C or idx + 0x10 > len(vd):   # 0x7C = the tag mirror, not the buffer
                continue
            sub_off = le16(vd, idx + 0x08); sub_len = le16(vd, idx + 0x0A)
            print_off = le16(vd, idx + 0x0C); print_len = le16(vd, idx + 0x0E)
            buf_start = idx + (0x14 if has_flags else 0x10)   # symlink has a 4-byte Flags field
            if print_len > 0 and buf_start + print_off + print_len <= len(vd):
                try:
                    t = vd[buf_start+print_off:buf_start+print_off+print_len].decode("utf-16-le")
                    if t and ("\\" in t or ":" in t):
                        return t
                except UnicodeDecodeError:
                    pass
            if sub_len > 0 and buf_start + sub_off + sub_len <= len(vd):
                try:
                    t = vd[buf_start+sub_off:buf_start+sub_off+sub_len].decode("utf-16-le")
                    if t.startswith("\\??\\"):
                        t = t[4:]
                    if t and ("\\" in t or ":" in t):
                        return t
                except UnicodeDecodeError:
                    pass
    return ""

# ─── Per-object $SI extraction ────────────────────────────────────────
def get_object_si(f, ps, cs, tr, vlcns):
    """Walk an object's B+ tree and extract $STANDARD_INFORMATION (type 0x10)."""
    try:
        rows = walk_bplus(f, ps, cs, tr, vlcns)
    except Exception as _e:
        # Indistinguishable from "this object has no $SI" unless the failure is recorded.
        _skip_note("$STANDARD_INFORMATION", "object tree", _e)
        return None
    for kd, vd in rows:
        if len(kd) >= 2 and le16(kd, 0) == 0x10:
            result = {}
            if len(vd) >= 0x60:
                result["create_time"] = le64(vd, 0x28)
                result["modify_time"] = le64(vd, 0x30)
                result["change_time"] = le64(vd, 0x38)
                result["access_time"] = le64(vd, 0x40)
                result["file_attrs"] = le32(vd, 0x48)
                result["internal_flags"] = le32(vd, 0x4C)
                result["security_id"] = le64(vd, 0x50)
                # CORRECTED 2026-06-17 (disk-proven, errata E30 retracted / E45): the file's
                # USN-journal pointer is LastUsn at $SI+0x40 (value+0x68), NOT $SI+0x30 (value+0x58).
                # value+0x58 ($SI+0x30) is 0 on 0/32,629 own-rows corpus-wide — never a populated USN.
                # LastUsn = virtual byte offset of the file's most recent $UsnJrnl:$J record (OID 0x520).
                result["usn"] = le64(vd, 0x68) if len(vd) >= 0x70 else 0
                result["usn_journal_id"] = le64(vd, 0x70) if len(vd) >= 0x78 else 0
            return result
    return None

# ─── ADS detection in per-object B+ tree ──────────────────────────────
def detect_ads(f, ps, cs, tr, vlcns):
    """Check if an object has Alternate Data Streams (type 0x80, marker 0x80000002)."""
    try:
        rows = walk_bplus(f, ps, cs, tr, vlcns)
    except Exception:
        return False, []
    ads_names = []
    for kd, vd in rows:
        if len(kd) >= 4:
            attr_type = le16(kd, 0)
            if attr_type == 0x80 and len(kd) > 4:
                try:
                    stream_name = kd[4:].decode("utf-16-le").rstrip("\x00")
                    if stream_name:
                        ads_names.append(stream_name)
                except UnicodeDecodeError:
                    pass
    return len(ads_names) > 0, ads_names

# ─── Embedded B+-tree row parser (shared by snapshot/ADS/file-size) ───
_B0_MARKER = b"\x02\x00\x00\x80"  # 0x80000002 little-endian (multi-instance)
_SI_MARKER = b"\x01\x00\x00\x80"  # 0x80000001 little-endian (single-instance)


def _descend_embedded_index(vd, base, ctx, _depth=0):
    """E73: the embedded attribute node is an INDEX node — its rows are child-page pointers, not attributes.

    A file whose attribute set outgrows one embedded node gets a real multi-level B+-tree: the node inside the
    type-0x30 value becomes an index node (descriptor+0x0C level != 0, +0x0D bit0 set) holding ONE row per child
    with an EMPTY separator key (key_offset 0x10 / key_size 0) whose value is a 48-byte node reference. The
    attributes ($DATA, ADS, $EA, $SNAPSHOT, $REPARSE ...) live in the child PAGE, not in the value. The driver
    does exactly this descent (`CmsEmbeddedComposite::FindIndexHeaderInPage` -> `CmsBPlusTable::BinarySearchIndex`).
    Returns the child rows in the same (key, value) shape as a leaf parse, so every caller is transparently fixed.
    """
    f, ps, cs, tr = ctx
    if _depth > 3:
        return []
    astart = le32(vd, base + 0x10); aend = le32(vd, base + 0x20)
    if not (0 < astart < aend) or base + aend > len(vd):
        return []
    rows = []; seen = set(); pos = base + astart
    while pos + 4 <= base + aend and pos + 4 <= len(vd):
        off = le16(vd, pos); pos += 4
        ab = base + off
        if ab + 16 > len(vd):
            continue
        _, ko, kl, _, vo, vl, _ = struct.unpack_from("<I6H", vd, ab)
        if vl < 32 or ab + vo + vl > len(vd):
            continue
        val = vd[ab + vo:ab + vo + vl]
        lcns = tuple(x for x in (le64(val, i * 8) for i in range(4))
                     if x not in (0, 0xFFFFFFFFFFFFFFFF))
        if not lcns or lcns in seen:
            continue
        seen.add(lcns)
        try:
            rows.extend(walk_bplus(f, ps, cs, tr, list(lcns)))
        except Exception:
            continue
    return rows


def parse_resident_btree_rows(vd, ctx=None):
    """Parse embedded B+-tree row offset table in a resident directory entry value.

    Returns list of (key_bytes, value_bytes) tuples for all rows found.
    Row offset table is at the end of vd (4-byte entries: u16 offset + 0xFFFF marker).
    Base offset for the data area is le32(vd, 0).

    `ctx` = (f, ps, cs, tr). When supplied AND the embedded node is an INDEX node, the real attribute rows are
    in a child page and are fetched by descending (E73). Without `ctx` the behaviour is exactly as before —
    an index node yields no rows — so every existing caller is unchanged until it opts in.
    """
    if len(vd) < 0xC0:
        return []
    base = le32(vd, 0)
    if base < 0x28 or base >= len(vd) - 0x28:
        return []
    if ctx is not None and base + 0x24 <= len(vd) and (vd[base + 0x0D] & 0x01):
        return _descend_embedded_index(vd, base, ctx)
    offsets = []
    pos = len(vd) - 4
    while pos >= base:
        if le16(vd, pos + 2) != 0xFFFF:
            break
        offsets.append(le16(vd, pos))
        pos -= 4
    rows = []
    for off in offsets:
        abs_off = base + off
        if abs_off + 16 > len(vd):
            continue
        rh = struct.unpack_from("<I6H", vd, abs_off)
        _, ko, kl, _, vo, vl, _ = rh
        if ko == 0 or kl == 0:
            continue
        key_abs = abs_off + ko
        val_abs = abs_off + vo
        if key_abs + kl > len(vd) or val_abs + vl > len(vd):
            continue
        rows.append((bytes(vd[key_abs:key_abs + kl]),
                      bytes(vd[val_abs:val_abs + vl])))
    return rows


def _b0_name_offset(kd):
    """Offset of the stream NAME in a 0xB0 embedded-attribute key, or None if this is not one.

    The key has TWO on-disk forms (E72). From v3.7 an instance marker sits at key+0x08, the attribute type
    at key+0x0C and the UTF-16 name from key+0x10. On v3.4 there is NO marker: the type is at key+0x08 and
    the name starts at key+0x0C. Matching only the marker form makes every v3.4 alternate data stream
    invisible — 176 live `hidden_*` streams on win10refs2tspecials alone, which the reader reported as
    "0 ADS" until this was fixed.
    """
    if len(kd) >= 14 and kd[8:12] in (_B0_MARKER, _SI_MARKER) and kd[12] == 0xB0 and kd[13] == 0x00:
        return 0x10
    if len(kd) >= 12 and kd[8] == 0xB0 and kd[9] == 0x00 and kd[10] == 0x00 and kd[11] == 0x00:
        return 0x0C          # v3.4, marker-less
    return None


def _b0_stream_name(kd):
    """UTF-16LE stream name from a 0xB0 key, whichever form it is in ("" if absent/undecodable)."""
    off = _b0_name_offset(kd)
    if off is None or len(kd) <= off:
        return ""
    try:
        return kd[off:].decode("utf-16-le").rstrip("\x00")
    except UnicodeDecodeError:
        return ""


def _is_b0_snapshot_key(kd):
    """True if the B+-tree key is a 0xB0 embedded attribute, in either the marker or the v3.4 form."""
    return _b0_name_offset(kd) is not None


def _is_snapshot_value(vd):
    """True if the StreamSummary flags at val+0x10 == 2 (snapshot, not ADS).
    C11: the field is a u16 at 0x10 (0=ADS, 2=snapshot; +0x12 reserved-zero). The old le32!=0 read
    worked only by coincidence (0x12==0); le16==2 matches the doc and recover_snapshot_streams."""
    return len(vd) >= 0x14 and le16(vd, 0x10) == 2


def _snapshot_meta(vd, ctx=None):
    """(name, sub_id, ts) for each true snapshot 0xB0 sub-record in a resident value — the single source for
    both the count and the names. Name = the snapshotted stream name (0xB0 key bytes @+0x10, UTF-16LE);
    sub_id = value+0x44 (the data sub-id); ctime = value+0x4C. Same predicate as before (le16@+0x10 == 2)."""
    out = []
    for kd, vd_row in parse_resident_btree_rows(vd, ctx):
        if not (_is_b0_snapshot_key(kd) and _is_snapshot_value(vd_row)):
            continue
        name = _b0_stream_name(kd)                    # handles both key forms (E72)
        if not name:
            _off = _b0_name_offset(kd) or 0x10
            name = kd[_off:].hex() if len(kd) > _off else ""
        sub_id = le32(vd_row, 0x44) if len(vd_row) >= 0x48 else 0
        ts = le64(vd_row, 0x4C) if len(vd_row) >= 0x54 else 0
        out.append((name, sub_id, ts))
    return out

def count_snapshots_in_resident(vd, ctx=None):
    """Count true snapshot entries within a resident directory entry value."""
    return len(_snapshot_meta(vd, ctx))


# ─── Resident file-size extraction ───────────────────────────────────
def get_resident_file_size(vd, ctx=None):
    """Extract file content size from the $DATA sub-record in a resident value.

    The $DATA row in the embedded B+-tree has key marker 0x80000001 + attr type 0x80.
    Stream size is at value offset 0x20.
    """
    for kd, vd_row in parse_resident_btree_rows(vd, ctx):
        if (len(kd) >= 14 and kd[8:12] == _SI_MARKER
                and kd[12] == 0x80 and kd[13] == 0x00):
            if len(vd_row) >= 0x28:
                return le64(vd_row, 0x20)
    # Fallback: a stream-snapshotted / CoW'd resident file has no live 0x80000001 $DATA row — its
    # live stream lives in the type-0x80 descriptor-0x10028 holder keyed by the CURRENT sub_id 0x1000
    # (older snapshots are 0x1001, 0x1002, ...). The current content byte size is at value+0x38.
    # (E2/RD: win11refs2tsnapshots — arg.txt=15, lasttest.txt=201, test.txt=5.)
    for kd, vd_row in parse_resident_btree_rows(vd, ctx):
        if (len(kd) >= 0x18 and kd[12] == 0x80 and kd[13] == 0x00
                and len(vd_row) >= 0x40 and le32(vd_row, 4) == SNAP_DATA_DESC
                and le64(kd, 0x10) == 0x1000):
            return le64(vd_row, 0x38)
    return 0


# ─── The two storage axes (E87) ───────────────────────────────────────
# "Resident" was one word for two independent properties, which is why this file used to
# decide `is_resident` twice: once from the name row's length (placement) and again from the
# $DATA descriptor (residency), overwriting the first with the second.
#
#   RECORD PLACEMENT  embedded in the name row, or split into a type-0x40 backing.
#                     key_flags at type-0x30 key+0x02: 0x01 embedded, 0x02 split.
#                     A move or a hard link forces the split -- and moves no data.
#   DATA RESIDENCY    where the bytes are. Read from the $DATA sub-record's own header.
#
# A 0-byte file is decided by descriptor form like any other: an inline-form record that
# happens to carry no bytes is `inline`; an extent-form one is `extents`.
# `unallocated`, not `sparse`: the residency state says the stream's range has NO allocation behind it.
# `sparse` already names something else here -- the FILE_ATTRIBUTE_SPARSE_FILE bit, which `--filter sparse`
# and `specials` report -- and one word meaning two things in the same output is how a reader is misled.
DATA_INLINE, DATA_EXTENTS, DATA_SNAPSHOT_SHARED, DATA_SPARSE, DATA_UNKNOWN = (
    "inline", "extents", "snapshot-shared", "unallocated", "unknown")


def _stream_data_form(rec, ctx=None):
    """DATA RESIDENCY of a file record's CURRENT stream. `rec` is the embedded name-row value
    or the type-0x40 backing -- the same test applies to both, which is the point.

    Returns one of DATA_*:
      inline           the descriptor is the resident form (summary_size@0x0C == 0x30,
                       StreamSummary flags@0x10 == 0); the bytes are at +0x3C, and there may be none.
      extents          the extent-bearing form (inner header 0x88 / descriptor 0x00010028),
                       with an allocation of its own.
      snapshot-shared  extent form owning NO allocation (disk_alloc@+0x48 == 0) while a
                       snapshot sub-record for the same stream exists -- the live bytes are
                       the snapshot's (E83).
      sparse           extent form owning no allocation and NO snapshot row: nothing was ever
                       written. Measured on `bigsparse.dat` / `sparse.dat`; without this the
                       two are indistinguishable from the snapshot case.
      unknown          no $DATA row, or a shape that matches none of the above.
    """
    try:
        rows = parse_resident_btree_rows(bytes(rec), ctx)
    except (ValueError, struct.error, IndexError):
        return DATA_UNKNOWN
    live = None
    snapshot_rows = False
    v34 = None
    for kd, vr in rows:
        if len(kd) < 0x0E:
            continue
        mk, ty = le32(kd, 8), le16(kd, 0x0C)
        if ty == 0x0080 and mk in (0x80000001, 0x80000002):
            sub = le32(kd, 0x10) if len(kd) >= 0x14 else None
            if mk == 0x80000001 and live is None:
                live, v34 = bytes(vr), False
            elif sub == 0x1000 and live is None:
                live, v34 = bytes(vr), False
            elif sub is not None and sub > 0x1000:
                snapshot_rows = True
        elif mk == 0x80 and ty == 0x0000 and live is None:
            live, v34 = bytes(vr), True          # v3.4 key: no marker, type u32 at +0x08
    if live is None:
        return DATA_UNKNOWN
    if len(live) >= 0x14 and le32(live, 0x0C) == 0x30 and le32(live, 0x10) == 0:
        return DATA_INLINE
    if len(live) >= 8 and le32(live, 0) == 0x88 and le32(live, 4) == 0x00010028:
        size = le64(live, 0x3C if v34 else 0x38) if len(live) >= 0x44 else 0
        if not v34 and size > 0 and len(live) >= 0x50 and le64(live, 0x48) == 0:
            return DATA_SNAPSHOT_SHARED if snapshot_rows else DATA_SPARSE
        return DATA_EXTENTS
    return DATA_UNKNOWN


# ─── Skipped work is reported, never swallowed (Phase 1.3) ────────────────
# A swallowed exception is indistinguishable from "nothing was there", which is how a reader
# returns a confident wrong answer: E73's outer-level-only parse returned [] and every consumer
# reported "no attributes". Anything that gives up on part of the volume says so, once per kind,
# with a count -- and anything that would otherwise emit BYTES raises instead (never invent data).
_SKIP_NOTES = {}



class IncompleteEvidence(Exception):
    """A decode failed on a path whose caller would otherwise fill the gap with a default.

    Raised instead of returning a partial answer, so the caller can DEFER rather than emit bytes,
    a size or a verdict that the volume does not support. Distinct from a parse error the caller is
    entitled to ignore: this one says "what I return would be wrong, not merely incomplete".
    """


_DEFERRALS = []


def _defer_note(where, reason):
    """Record that a CONTENT path declined to answer, and say so.

    Deferring is correct -- it is how the reassembler avoids emitting bytes the volume does not support.
    But a deferral that only shows up as a missing file is the silent-default class wearing another hat:
    the caller exits 0, no file appears, and nothing says which file or why. Callers that were ASKED for a
    specific file (extract / export) report these and exit 2.
    """
    _DEFERRALS.append((where, reason))
    print(f"[{PROG}] WARNING: declined to reassemble {where}: {reason} — no bytes written for it.",
          file=sys.stderr)
    return len(_DEFERRALS)


def _skip_note(stage, where, exc, limit=3):
    """Record and report a skipped unit of work. Returns the running count for this kind."""
    key = (stage, type(exc).__name__)
    n = _SKIP_NOTES.get(key, 0) + 1
    _SKIP_NOTES[key] = n
    if n <= limit:
        print(f"[{PROG}] WARNING: {stage} skipped {where}: {type(exc).__name__}: {exc}",
              file=sys.stderr)
    elif n == limit + 1:
        print(f"[{PROG}] WARNING: {stage}: further {type(exc).__name__} skips suppressed "
              f"(count reported at exit)", file=sys.stderr)
    return n


_SKIP_SUMMARY_DONE = []


def _skip_summary():
    """One line per kind of skipped work, for the end of a run. Silent when nothing was skipped.

    Idempotent: registered with atexit, so an explicit call must not double-report."""
    if not _SKIP_NOTES or _SKIP_SUMMARY_DONE:
        return
    _SKIP_SUMMARY_DONE.append(True)
    total = sum(_SKIP_NOTES.values())
    print(f"[{PROG}] WARNING: {total} unit(s) of work were skipped and are NOT reflected in the "
          f"output above:", file=sys.stderr)
    for (stage, exc), n in sorted(_SKIP_NOTES.items()):
        print(f"[{PROG}]          {stage}: {n} x {exc}", file=sys.stderr)


def _t40_record_tuple(vd, ctx=None):
    """The per-object facts carried by a type-0x40 backing record, as one tuple.

    Shared by the directory walk and by the on-demand home-tree lookup (E89) so the two cannot
    drift: the walk only sees backings in directories it traverses, and a file whose HOME object
    is never traversed would otherwise get none of this -- losing its residency, USN, SecurityId,
    EA bit and allocated size, and reporting it non-resident with the data sitting in the record.
    Layout: alloc @+0x60, size @+0x58, LastUsn @+0x68, journal @+0x70, SecurityId @+0x50,
    internal flags @+0x4C, reparse tag mirror @+0x7C (bit31), file attrs @+0x48.
    """
    _a = le64(vd, 0x60) if len(vd) >= 0x68 else 0
    _s = le64(vd, 0x58) if len(vd) >= 0x60 else 0
    _u = le64(vd, 0x68) if len(vd) >= 0x70 else 0
    _j = le64(vd, 0x70) if len(vd) >= 0x78 else 0
    _sid = le64(vd, 0x50) if len(vd) >= 0x58 else 0
    _if = le32(vd, 0x4C) if len(vd) >= 0x50 else 0
    _tag = le32(vd, 0x7C) if len(vd) >= 0x80 else 0
    if not (_tag >> 31) & 1:
        _tag = 0
    _tgt = extract_reparse_from_backing(vd) if _tag in (0xA000000C, 0xA0000003) else ""
    _bfa = le32(vd, 0x48) if len(vd) >= 0x4C else 0
    _inl = _backing_inline_data(vd, ctx) is not None
    _form = _stream_data_form(vd, ctx)
    # T9 / MD_ADS_RA_005: a named stream on a SPLIT record lives HERE, in the backing, not in the type-0x30
    # name row -- so the enumeration that reads only the name row never sees it. Appended last so every
    # existing rec[N] index is unchanged.
    _ads = detect_ads_in_resident(vd, ctx)[1]
    _adsst = _ads_storage_map(vd, ctx) if _ads else {}
    return (_a, _s, _u, _j, _sid, _if, _tag, _tgt, _bfa, _inl, _form, _ads, _adsst)


def _backing_inline_data(vd, ctx=None):
    """Inline `$DATA` bytes of a type-0x40 backing record, or None when the stream is extent-backed (E82).

    A file whose record was SPLIT OUT of its name row (`key_flags 0x02`) can still keep its data **inside that
    record**. Record placement and data residency are independent (E77): the split is what a move or a hard
    link forces, and it says nothing about where the bytes live. When the data stayed inline, the backing's
    main `$DATA` sub-record is the **resident** form — single-instance marker 0x80000001 + type 0x80, with
    `summary_size@0x0C == 0x30` and `StreamSummary flags@0x10 == 0` — carrying the byte count at `+0x20` and the
    bytes at `+0x3C`. (The extent-bearing form is the other one: `inner_hdr@0x00 = 0x88`, `summary_size` 0x200
    on v3.14+ / 0x1A0 on v3.4-v3.10, extents at `+0x88`.)

    Matching the single-instance marker matters: an ADS is a *multi-instance* 0x80 row, so accepting any 0x80
    row returns a stream that is not the file's data.

    Measured over the corpus: 16,191 of 83,176 index-entry files keep their data this way, on 26 images
    (14,580 on one real Windows volume); the two forms are mutually exclusive — no record carries both.
    Before this, such a file was reported non-resident and `extract` failed with "no extents decoded" while
    its bytes sat in the record already held."""
    try:
        rows = parse_resident_btree_rows(bytes(vd), ctx)
    except (ValueError, struct.error, IndexError):
        return None
    for kd, vr in rows:
        if len(kd) >= 14 and kd[8:12] == _SI_MARKER and kd[12] == 0x80 and kd[13] == 0x00:
            v = bytes(vr)
            if len(v) < 0x28 or le32(v, 0x0C) != 0x30 or le32(v, 0x10) != 0:
                return None                      # extent-bearing (or an unexpected shape) -> not inline
            sz = le64(v, 0x20)
            if sz == 0:
                # A genuinely EMPTY resident stream: the inline form is present (summary 0x30 /
                # storage 0) and simply carries no bytes. Returning None here made it look
                # extent-backed, so the file was reported non-resident and `extract` failed with
                # "file not found" for every empty hard-linked name (772 rows / 11 images).
                return b""
            if 0x3C + sz > len(v):
                return None
            return v[0x3C:0x3C + sz]
    return None


def get_resident_data_content(vd, ctx=None):
    """Q7: inline bytes of the main $DATA stream of a resident file, or None.

    The $DATA row (key marker 0x80000001 + attr type 0x80) carries the SAME stream descriptor as an ADS
    row (see _parse_ads_from_value): locate it by the 0x0C/0x30 signature (hdr=scan-4), read storage_type
    at hdr+0x0C, stream size at hdr+0x1C, and inline content at hdr+0x38. Only storage_type==0 is inline
    (verified on desktop.ini: content '[.ShellClassInfo]...' at hdr+0x38). Returns None for a non-inline
    ($DATA descriptor pointing to extents) or malformed row — the caller falls back to the extent path."""
    for kd, vrow in parse_resident_btree_rows(vd, ctx):
        if not (len(kd) >= 14 and kd[8:12] == _SI_MARKER and kd[12] == 0x80 and kd[13] == 0x00):
            continue
        hdr = None
        for scan in range(0, len(vrow) - 8):
            if le32(vrow, scan) == 0x0C and le32(vrow, scan + 4) == 0x30:
                hdr = scan - 4
                break
        if hdr is None or hdr < 0 or hdr + 0x24 > len(vrow):
            return None
        if le32(vrow, hdr + 0x0C) != 0:          # storage_type != 0 => non-inline (extent-backed)
            return None
        stream_size = le64(vrow, hdr + 0x1C)
        content_off = hdr + 0x38
        if content_off + stream_size <= len(vrow) and stream_size <= 0x100000:
            return bytes(vrow[content_off:content_off + stream_size])
        return None
    return None


def _current_stream_extent_backed(vd, ctx=None):
    """F5: True when a file's CURRENT $DATA stream lives in on-disk extents (so the file is NON-RESIDENT even
    though its type-0x30 value is 'long' > 84 B). The live stream is the sub_id-0x1000 holder whose descriptor
    is 0x00010028 (le32 @ holder value+0x04); its on-disk allocation is disk_alloc @ holder value+0x48. Older
    sub_ids (0x1001+) are CoW snapshots and are ignored. A genuine inline/resident file has no such holder
    (its $DATA is a single-instance 0x80000001 descriptor) or disk_alloc==0. (structure_reference §C.6;
    calibrated on win11refs8g.raw: bigsparse/rangefile/stomp_nonres disk_alloc>0 => non-resident,
    test.txt current-stream disk_alloc==0 => resident.)"""
    for kd, vrow in parse_resident_btree_rows(vd, ctx):
        if (len(kd) >= 0x18 and kd[12] == 0x80 and kd[13] == 0x00
                and le64(kd, 0x10) == 0x1000 and len(vrow) >= 8 and le32(vrow, 4) == 0x00010028):
            return len(vrow) >= 0x50 and le64(vrow, 0x48) > 0
    return False


def _multilevel_extent_backed_size(vd, cs, ctx=None):
    """B2: on v3.4/v3.9/upgraded framing a 'long' (>84 B) resident type-0x30 value can be a MULTI-LEVEL
    embedded B+-tree — parse_resident_btree_rows reaches only the OUTER level, so no inline $DATA row is
    found (get_resident_file_size == 0) even though the file has on-disk data. Such a file is actually
    NON-RESIDENT / extent-backed; its true FileSize is at value+0x58 and its allocated size at value+0x60.
    Returns the true file_size when the pattern holds, else None.
    Gate: no inline $DATA (get_resident_file_size==0) AND alloc (value+0x60) is a whole number of clusters
    (alloc>0 and alloc % cs == 0 — extents allocate whole clusters) AND 0<size<=alloc. The cluster-alignment
    check is what distinguishes a real extent-backed file (alloc = N*cluster, e.g. xbpt_delta 209311/212992)
    from a small resident file whose value is merely unparseable (e.g. multibig_*.bin 300/304, alloc NOT a
    cluster multiple — NOT extent-backed). A genuine resident file also has an inline $DATA
    (get_resident_file_size>0), so it never reaches this. (Confirmed v3.4/v3.7/v3.9/v3.10/upgraded, 653
    files, all cluster-aligned; excludes the win11refs8g multibig_* resident misfires.)"""
    if len(vd) < 0x68 or cs <= 0:
        return None
    alloc = le64(vd, 0x60)
    if alloc == 0 or alloc % cs != 0 or get_resident_file_size(vd, ctx) != 0:
        return None
    size = le64(vd, 0x58)
    if 0 < size <= alloc:
        return size
    return None


# ─── Resident ADS detection ─────────────────────────────────────────
def detect_ads_in_resident(vd, ctx=None):
    """Detect Alternate Data Streams in a resident directory entry value.

    ADS appear as 0xB0 entries (marker 0x80000002) with StreamSummary flags=0
    at val[0x10] in the embedded B+-tree. Stream name is in the key at offset 16+.
    Returns (has_ads, ads_names) matching detect_ads() signature.
    """
    ads_names = []
    for kd, vd_row in parse_resident_btree_rows(vd, ctx):
        if _is_b0_snapshot_key(kd) and not _is_snapshot_value(vd_row):
            if True:
                try:
                    name = _b0_stream_name(kd)
                    if name:
                        ads_names.append(name)
                except UnicodeDecodeError:
                    pass
    return len(ads_names) > 0, ads_names


# ─── Extended Attributes ($EA) + WSL/Linux metadata ──────────────────────────
# VERIFIED 2026-06-29 (E2 + RD, report wsl_ea_verification_2026-06-29.md). EAs live as TWO embedded
# single-instance sub-records (marker 0x80000001) in the resident value's B+-tree: $EA_INFORMATION
# (type 0xD0, val[0x0C]=PackedEaSize) + $EA (type 0xE0, FILE_FULL_EA_INFORMATION chain at val+0x0C).
# refs.sys (RefsQueryLxMetadataEa) recognises EXACTLY four $LX EAs; all other EA values are opaque
# (name+size+raw only). NEVER source PackedEaSize from the value+0x78 mirror (stale on upgraded vols)
# or read device numbers from the reparse buffer (it has none).
def parse_ea_chain(data):
    """Parse a FILE_FULL_EA_INFORMATION chain -> [{'name','value','flags'}].
    Entry: NextEntryOffset u32@0, Flags u8@4, EaNameLength u8@5, EaValueLength u16@6,
    Name(ASCII)@8 (+1 null), Value@(8+nameLen+1). 0 NextEntryOffset = last."""
    eas = []
    off = 0
    for _ in range(256):
        if off + 8 > len(data):
            break
        nxt = le32(data, off)
        flags = data[off + 4]
        nlen = data[off + 5]
        vlen = le16(data, off + 6)
        name_end = off + 8 + nlen
        if name_end > len(data):
            break
        try:
            name = bytes(data[off + 8:name_end]).decode("ascii")
        except UnicodeDecodeError:
            name = bytes(data[off + 8:name_end]).decode("ascii", "replace")
        vstart = name_end + 1
        vend = vstart + vlen
        if vend > len(data):
            break
        eas.append({"name": name, "value": bytes(data[vstart:vend]), "flags": flags})
        if nxt == 0:
            break
        off += nxt
    return eas

def fetch_t40_backing(f, ps, cs, tr, obj_map, dir_oid, file_id, file_size=None):
    """Raw value bytes of the type-0x40 backing record for (dir_oid, file_id), or None. A non-resident
    file's EAs live in this backing. The per-dir file_id can COLLIDE (hard-link ordinal reuse); when
    several records share it, disambiguate by the file's size (val+0x58) — the same collision-safe rule
    the directory walk uses (#340). (The PackedEaSize==Σ oracle in the caller is the final guard.)"""
    if dir_oid not in obj_map:
        return None
    cands = []
    try:
        for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[dir_oid]):
            if len(kd) >= 0x10 and le16(kd, 0) == 0x40 and le64(kd, 0x08) == file_id:
                cands.append(bytes(vd))
    except Exception as _e:
        # `None` below also means "no such backing", a legitimate answer. A walk FAILURE returning the
        # same value makes the two indistinguishable -- and this record feeds residency, USN, SecurityId
        # and the attribute flags for the file.
        _skip_note("type-0x40 backing", f"dir 0x{dir_oid:x} file_id {file_id}", _e)
        return None
    if not cands:
        return None
    if file_size is not None and len(cands) > 1:
        for vd in cands:
            if len(vd) >= 0x60 and le64(vd, 0x58) == file_size:
                return vd
    return cands[0]

def extract_eas_from_value(vd, ctx=None):
    """(ea_list, packed_ea_size) from a resident value's embedded $EA/$EA_INFORMATION sub-records,
    or (None, None) if the file has no EAs ($EA_INFORMATION 0xD0 absent = the gate). packed_ea_size
    is read from the 0xD0 sub-record val[0x0C] (authoritative; never the +0x78 mirror)."""
    ea_info = None
    ea_chain = None
    for kd, vr in parse_resident_btree_rows(vd, ctx):
        if len(kd) >= 14 and kd[8:12] == _SI_MARKER and kd[13] == 0x00:
            if kd[12] == 0xD0 and len(vr) >= 0x10:
                ea_info = vr
            elif kd[12] == 0xE0 and len(vr) >= 0x0C:
                ea_chain = vr
    if ea_info is None:
        return None, None
    packed = le32(ea_info, 0x0C)
    eas = parse_ea_chain(ea_chain[0x0C:]) if ea_chain is not None else []
    return eas, packed

# Linux S_IFMT file types (mode & 0o170000) — verified vs lab mknod/chmod ground truth.
_LX_IFMT = {0o140000: "socket", 0o120000: "symlink", 0o100000: "regular", 0o060000: "block",
            0o040000: "directory", 0o020000: "char", 0o010000: "fifo"}

def decode_lx_mode(mode):
    """Decode a Linux mode_t (from $LXMOD) -> 'regular rwxr-xr-x (0o755)' with setuid/setgid/sticky."""
    ft = _LX_IFMT.get(mode & 0o170000, "unknown(0o%o)" % (mode & 0o170000))
    perms = "".join(("r" if (mode >> s) & 4 else "-") + ("w" if (mode >> s) & 2 else "-")
                    + ("x" if (mode >> s) & 1 else "-") for s in (6, 3, 0))
    extra = "".join(t for b, t in ((0o4000, " setuid"), (0o2000, " setgid"), (0o1000, " sticky")) if mode & b)
    return f"{ft} {perms} (0o{mode & 0o7777:04o}){extra}"

def decode_wsl_eas(eas):
    """Decode the FOUR driver-recognised $LX EAs (gated on the exact value lengths refs.sys requires:
    4 for UID/GID/MOD, 8 for DEV). Returns {uid,gid,mode,dev=(major,minor)} for those present."""
    wsl = {}
    for ea in eas:
        n, v = ea["name"], ea["value"]
        if n == "$LXUID" and len(v) == 4: wsl["uid"] = le32(v, 0)
        elif n == "$LXGID" and len(v) == 4: wsl["gid"] = le32(v, 0)
        elif n == "$LXMOD" and len(v) == 4: wsl["mode"] = le32(v, 0)
        elif n == "$LXDEV" and len(v) == 8: wsl["dev"] = (le32(v, 0), le32(v, 4))
    return wsl

# $SI+0x24 internal-flags labels — ONLY the bits with verified semantics (E25/E29/E43). Bits 0x04/0x08
# have a known FCB source (bit 11 / bit 31) but no confident semantic name, so they are left UNLABELLED
# (shown only in the raw hex) rather than guessed.
_INTERNAL_FLAG_LABELS = {0x01: "DeleteDisposition", 0x02: "Dedup/CoW", 0x20: "RedirectionTrust"}

# Checkpoint (CHKP+0x78) flag bits — meanings for the summary decode (Q4). Any bit NOT here is labelled
# 'unknown (uncatalogued)' so a new/unexpected flag is never silently dropped. (structure_reference §A.4a.)
_CHKP_FLAG_BITS = {
    0x002: "always-set",
    0x010: "dedup-bit4",
    0x020: "dedup-bit5",
    0x080: "native-Win11-format (v3.10+)",
    0x100: "dedup-bit8",
    0x200: "indirect-root-list",
    0x400: "metadata-checksum (CRC64/SHA-256)",
    0x2000: "insider-build flag (29574+)",
}

def chkp_flags_decoded(flags):
    """List of 'bit = meaning' strings for a CHKP flags value, incl. any uncatalogued residual bit."""
    out = [f"0x{b:03x} = {name}" for b, name in sorted(_CHKP_FLAG_BITS.items()) if flags & b]
    # OR-fold the catalogued bits into one mask (D7). `sum()` would over-count if any two flags ever
    # shared a bit or a flag became multi-bit; `|` is correct for any bit layout.
    catalogued = 0
    for _b in _CHKP_FLAG_BITS:
        catalogued |= _b
    residual = flags & ~catalogued
    if residual:
        out.append(f"0x{residual:x} = unknown (uncatalogued bit)")
    return out

def internal_flags_str(flags):
    """'0x28 (RedirectionTrust)' — shown ONLY when a confidently-verified bit is set. The common
    value 0x08 (FCB bit 31, no confident semantic) and other un-named bits are NOT surfaced (avoid
    displaying a field whose meaning is unproven)."""
    if not flags:
        return ""
    labels = [n for b, n in _INTERNAL_FLAG_LABELS.items() if flags & b]
    if not labels:
        return ""
    return f"0x{flags:x} ({'|'.join(labels)})"


def resolve_path(f, ps, cs, tr, obj_map, path):
    """Resolve a '/dir/sub/file' path to (parent_oid, key, value) of its type-0x30 row.
    Case-insensitive (ReFS default), but an EXACT spelling always wins: a directory carrying the per-directory
    case-sensitivity flag (`fsutil file setCaseSensitiveInfo`) can hold two names that differ only by case, and
    taking the first case-insensitive hit served one file's bytes under the other's name. Files have no OID —
    they are found by name in the parent directory's tree. Returns (None, None, None) if not found."""
    parts = [p for p in path.replace("\\", "/").split("/") if p and p != "."]
    if not parts:
        return (None, None, None)
    oid = 0x600
    for i, part in enumerate(parts):
        if oid not in obj_map:
            return (None, None, None)
        found = None
        try:
            rows = walk_bplus(f, ps, cs, tr, obj_map[oid])
        except Exception as _e:
            # "Unreadable" is not "absent". Returning the not-found tuple silently turns a
            # damaged directory into a confident wrong answer for every caller.
            _skip_note("path resolution (directory unreadable)", "oid 0x%x" % oid, _e)
            return (None, None, None)
        for kd, vd in rows:
            if len(kd) < 4 or le16(kd, 0) != 0x30:
                continue
            try:
                nm = kd[4:].decode("utf-16-le").rstrip("\x00")
            except UnicodeDecodeError:
                continue          # a name that will not decode cannot be the one asked for
            if nm == part:
                found = (kd, vd)      # exact spelling wins outright
                break
            if found is None and nm.lower() == part.lower():
                found = (kd, vd)      # remember the first case-insensitive hit, keep looking for an exact one
        if found is None:
            return (None, None, None)
        kd, vd = found
        if i == len(parts) - 1:
            return (oid, kd, vd)
        # descend into a child directory: val+0x08 is the child's own OID only when the directory bit is
        # set. A non-resident FILE has the home-dir backref there (a different object), not an OID, so an
        # intermediate path component that is a file (not a directory) is not descendable -> no such path.
        if len(vd) <= NON_RESIDENT_MAX_VALUE and len(vd) >= 0x44 and (le32(vd, 0x40) & 0x10000000):
            oid = le64(vd, 0x08)
        else:
            return (None, None, None)
    return (None, None, None)


def count_snapshots_from_btree(f, ps, cs, tr, vlcns):
    """Count true snapshot entries in an object's B+-tree."""
    try:
        rows = walk_bplus(f, ps, cs, tr, vlcns)
    except Exception as _e:
        # "0 snapshots" is a statement about the object, not about the walk. Callers print it as a count.
        _skip_note("snapshot count", "object tree", _e)
        return 0
    count = 0
    for kd, vd in rows:
        if _is_b0_snapshot_key(kd) and _is_snapshot_value(vd):
            count += 1
    return count


# ── Snapshot content recovery (CoW prior-content) ───────────────────────
# Chain (E2: SetResidentStreamSummary/RefsCreateStreamSnapshot; RD-verified):
#   snapshot 0xB0 sub-record  val[0x44] = data_sub_id, val[0x20] = stream size
#     -> DATA 0x80 sub-record whose key+0x10 == data_sub_id  (descriptor 0x10028)
#         val[0x00] = inner-header offset (0x88); val[0x48] = on-disk alloc (0 = inline)
#         extent_count = val[ihdr+0x14]; 24-byte extents at val[ihdr+0x28]:
#           +0x00 VLCN(u64)  +0x0C file_vcn(u32)  +0x14 run_length(u32)
#     -> translate VLCN->PLCN (Container Table) -> read run_length clusters -> trim.
# The CURRENT version is data_sub_id 0x1000. Same 24-byte extent format as type-0x40.
SNAP_DATA_DESC = 0x10028

# Inline per-cluster integrity checksum (structure_reference §C.6 / MD_DATA_RA_007; Phase-2 spec 2026-08-06,
# static+disk confirmed). On a v3.14 4K-cluster CRC32-C integrity stream, a checksummed cluster is its own
# run==1 extent carrying flag 0x1C00D0, immediately followed by an 8-byte element = [CRC32-C(cluster):le32@+0]
# [reserved:le32@+4] (32-byte stride). CRC32-C = Castagnoli, reflected poly 0x82F63B78; unit = one 4096-byte
# cluster. SHA-256 / 64K-cluster / v3.4 volumes carry NO inline element (checksums are out-of-line or absent).
INTEGRITY_EXTENT_FLAG = 0x1C00D0
_INTEGRITY_UNSET = 0xABBAFFFE          # driver's unset / match-all placeholder — an unwritten checksum, not a mismatch
_CRC32C_TABLE = None


def _crc32c(data):
    """CRC32-C (Castagnoli), reflected poly 0x82F63B78, init/final 0xFFFFFFFF. Canonical check:
    _crc32c(b'123456789') == 0xE3069283. (NOT zlib.crc32, which is CRC-32/ISO-HDLC.)"""
    global _CRC32C_TABLE
    if _CRC32C_TABLE is None:
        t = []
        for n in range(256):
            c = n
            for _ in range(8):
                c = (c >> 1) ^ (0x82F63B78 & -(c & 1))
            t.append(c & 0xFFFFFFFF)
        _CRC32C_TABLE = t
    crc = 0xFFFFFFFF
    for b in data:
        crc = (crc >> 8) ^ _CRC32C_TABLE[(crc ^ b) & 0xFF]
    return crc ^ 0xFFFFFFFF


def _volume_ncl(f, ps_off, cs):
    """Volume cluster count (clusters after the partition offset) — the plausibility bound for a decoded VLCN."""
    _p = f.tell(); f.seek(0, 2); n = (f.tell() - ps_off) // cs; f.seek(_p)
    return n


def _decode_inline_extents(v, ncl, max_fvcn=None, tr=None):
    """Single source of truth for decoding the inline 24-byte extent records inside a 0x10028 holder.
    VALIDATED-GREEDY: after each real extent the next one sits at +24, OR at +32 when an 8-byte integrity
    CRC32-C element is interleaved (integrity streams) — pick whichever validates. Returns
    [(file_vcn, vlcn, run_length)] sorted by file_vcn; stops at the first record that cannot be validated
    (the caller applies any coverage gate). `ncl` (volume cluster count) bounds plausibility; `max_fvcn`
    optionally tightens the file_vcn bound (recover path passes size_cl). A record with `vlcn == 0` is a SPARSE
    HOLE (VLCN 0 -> PLCN 0 = the boot region on every volume, so cluster 0 is never real file data; the flags
    carry bit 0x20) — it is KEPT in the list and reassembly zero-fills it; it is never disk-read. Byte-identical
    to the legacy fixed-24-stride decode when NO checksums are interleaved (proven on all corpus holders) but
    correct when they are. (structure_reference §C.6; Phase-0 SPEC 2026-08-02, disk-verified.)"""
    if len(v) < 0x50:
        return []
    ihdr = le32(v, 0)
    if ihdr + 0x18 > len(v):
        return []
    ecount = le32(v, ihdr + 0x14)
    fvcn_bound = max_fvcn if max_fvcn is not None else ncl

    def _plausible_vlcn(vlcn):
        """A VLCN is VIRTUAL: the container table maps it to a physical cluster, and the virtual address
        space is wider than the physical one (it starts at `first_container_id << shift` and runs roughly
        twice as far — E74). Bounding it by the PHYSICAL cluster count therefore rejects every extent that
        lives in the upper half of the virtual space: on win11bidule that is 583 of 629 files, each failing
        `extract` with "inline-holder-overflow" although the extents are intact and translate cleanly.
        When a translator is available, the authoritative test is whether the container table can map it."""
        if vlcn == 0:
            return True                 # sparse hole (zero-filled by reassembly; never disk-read)
        if tr is not None:
            # Ask the container table whether it MAPS this address, and ask without translating:
            # `tr.tr()` does not raise on a miss -- it falls back to identity and increments the
            # miss counter -- so probing with it both accepted unmappable addresses (identity can
            # land inside the physical range) and produced spurious "unmapped VLCN" warnings from
            # a test that was never a real read. Translation happens only once a cover is accepted.
            return _vlcn_mappable(tr, vlcn)
        return 0 < vlcn < ncl           # no translator: physical range is all we have

    def _ext(off):
        if off < 0 or off + 24 > len(v):
            return None
        vlcn = le64(v, off); run = le32(v, off + 0x14); fvcn = le32(v, off + 0x0C)
        if 0 < run <= ncl and fvcn < fvcn_bound and _plausible_vlcn(vlcn):
            return (fvcn, vlcn, run)
        return None

    exts = []; pos = ihdr + 0x28
    for i in range(ecount):
        rec = _ext(pos)
        if rec is None:
            break
        exts.append(rec)
        if i == ecount - 1:
            break
        if _ext(pos + 24) is not None:
            pos += 24
        elif _ext(pos + 32) is not None:
            pos += 32                       # skip the interleaved 8-byte integrity CRC32-C element
        else:
            pos += 24
    exts.sort(key=lambda e: e[0])
    return exts


def parse_snapshot_data_entry(v, ncl=None, tr=None):
    """Parse an embedded type-0x80 DATA entry -> (stream_size, disk_alloc, extents)
    where extents = [(file_vcn, vlcn, run_length), ...] sorted by file_vcn.
    When `ncl` (volume cluster count) is given, the extent list is decoded integrity-robustly via
    `_decode_inline_extents` (skips interleaved CRC32-C checksums). When ncl is None the LEGACY fixed-24-stride
    decode is used (100% back-compatible for any caller that lacks a volume cluster count — e.g. the no-`f`
    predicate `_extent_backed_carveable`)."""
    if len(v) < 0x50:
        return (0, 0, [])
    stream_size = le64(v, 0x38)
    disk_alloc = le64(v, 0x48)
    if ncl is not None:
        return (stream_size, disk_alloc, _decode_inline_extents(v, ncl, tr=tr))
    ihdr = le32(v, 0)
    exts = []
    if ihdr + 0x18 <= len(v):
        ecount = le32(v, ihdr + 0x14)
        eo = ihdr + 0x28
        for i in range(ecount):
            base = eo + i * 24
            if base + 24 > len(v):
                break
            exts.append((le32(v, base + 0x0C), le64(v, base), le32(v, base + 0x14)))
        exts.sort(key=lambda e: e[0])
    return (stream_size, disk_alloc, exts)


def recover_cow_current_content(f, ps_off, cs, tr, vd, _content_what=None):
    """Q7/CoW: recover the LIVE content of a resident file whose current stream (sub_id 0x1000) is a 0x10028
    holder with disk_alloc==0 and no own extents — i.e. UNMODIFIED since the last snapshot, so its bytes are
    shared with the newest snapshot. Returns bytes (trimmed to size) or None. STRICTLY the safe case only:
    if the current stream has its OWN allocation (disk_alloc>0 / own extents) this returns None (that is the
    F5 large-non-resident / possibly-sparse case, deferred to `dataruns`). Verified on win11refs2tsnapshots
    (test.txt current 5B == snapshot 0x1004; lasttest.txt 201B == 0x1002)."""
    ncl = _volume_ncl(f, ps_off, cs)       # integrity-robust extent decode (skip interleaved CRC32-C)
    holders = {}   # sub_id -> (stream_size, disk_alloc, extents)
    for k, v in parse_resident_btree_rows(vd, (f, ps_off, cs, tr)):
        if (len(k) >= 0x18 and k[12] == 0x80 and k[13] == 0x00
                and len(v) >= 0x50 and le32(v, 4) == SNAP_DATA_DESC):
            holders[le64(k, 0x10)] = parse_snapshot_data_entry(v, ncl, tr)
    cur = holders.get(0x1000)
    if cur is None:
        return None
    cur_size, cur_alloc, cur_exts = cur
    if cur_alloc != 0 or cur_exts:
        return None   # own allocation => not the safe CoW case (F5 / sparse) — leave to dataruns
    if cur_size == 0:
        return b""
    # the current bytes are the newest snapshot with real extents AND the SAME size (don't guess otherwise).
    candidates = [sid for sid, d in holders.items()
                  if sid > 0x1000 and d[2] and d[0] == cur_size]
    if not candidates:
        return None
    _ssz, _salloc, exts = holders[max(candidates)]
    alloc = max((fv + run) for fv, _vl, run in exts) * cs
    if alloc > 64 * 1024 * 1024:   # CoW resident streams are small; guard anyway
        return None
    # NB on `bytes(memoryview(buf)[:N])` here and in the other reassemblers: the slice is LOAD-BEARING
    # (buf is allocated at `alloc`, the cluster-rounded size, and N is the logical size), so it cannot be
    # dropped the way `_recover_inline_extent_content`'s could -- that one allocated at exactly its slice
    # bound. Taking the slice through a memoryview avoids the intermediate bytearray copy, so the peak is
    # one copy of the file instead of two: measured 400 -> 200 MiB on a 200 MiB buffer.
    buf = bytearray(alloc)
    _runs = []
    for fvcn, vlcn, run in sorted(exts, key=lambda e: e[0]):
        for j in range(run):
            try:
                plcn = tr.tr(vlcn + j)
            except Exception:
                plcn = vlcn + j
            off = (fvcn + j) * cs
            _runs.append((plcn, 1, off))
            f.seek(ps_off + plcn * cs)
            chunk = f.read(cs)
            buf[off:off + cs] = chunk
    # These bytes become OUTPUT (cmd_extract emits them as "snapshot-shared with the latest snapshot"),
    # so the clusters behind them must be present in the image. A punched cluster here produced five
    # zero bytes under that label with rc=0 -- see analysis/reports/d13_gap_2026-09-09/.
    if _content_what:
        # Only when the caller says these bytes will be EMITTED. The directory walk precomputes
        # cow_content for every file to fill a column; running a hole scan there would cost a syscall
        # sweep per file for a check nobody reads. Extract asks again, by name, for the one file.
        content_holes(f, ps_off, cs, _runs, _content_what, stream_size=cur_size)
    return bytes(memoryview(buf)[:cur_size])


def _snapshot_shared_blocks(vd, ctx, ncl, exclude=0x1000, older_than=None):
    """Map file-VCN -> VLCN for the blocks a stream does not own itself but SHARES with stream snapshots.

    ReFS stream snapshots are copy-on-write: a block is duplicated only when it is about to be overwritten, so
    every block not yet modified since a snapshot stays **shared** — physically present once, listed in the
    snapshot's extent table and absent from the current stream's. That is why a snapshotted file's current
    stream can report `total_alloc` for the whole file while its own `disk_alloc` covers only the few clusters
    written since the last snapshot (E83).

    This resolves those blocks to the real clusters that hold them. Nothing is reconstructed or synthesised —
    every VCN is answered with an actual on-disk cluster; the alternative (what the reader did before) was to
    leave them zero-filled, which invents bytes that exist nowhere on the volume.

    `exclude` is the stream being assembled. `older_than` restricts the search to snapshots strictly older than
    a given sub_id, which is what reconstructing a PRIOR version needs: a newer snapshot may hold content
    written *after* the version being recovered. For the current stream (`older_than=None`) the newest snapshot
    holding a VCN wins, since a block only leaves the current stream's table when it has not changed since.
    """
    streams = {}
    tr = ctx[3] if ctx and len(ctx) > 3 else None      # the translator, for virtual-LCN plausibility (E85)
    try:
        rows = parse_resident_btree_rows(vd, ctx)
    except (ValueError, struct.error, IndexError) as _e:
        # `return {}` here is indistinguishable from "this file shares no blocks", and the callers
        # reassemble content from the result: every shared VCN would silently come back zero. Same
        # defect as the per-stream failure below, reached one level earlier.
        _skip_note("snapshot shared blocks", "row decode", _e)
        raise IncompleteEvidence("snapshot rows did not decode") from _e
    for k, v in rows:
        if len(k) < 0x18 or le16(k, 0x0C) != 0x80:
            continue
        v = bytes(v)
        if len(v) < 0x50 or le32(v, 4) != SNAP_DATA_DESC:
            continue
        sub = le64(k, 0x10)
        if sub == exclude or not (0x1000 <= sub <= 0xFFFF):
            continue
        if older_than is not None and sub >= older_than:
            continue
        try:
            streams[sub] = parse_snapshot_data_entry(v, ncl, tr)
        except (ValueError, struct.error, IndexError) as _e:
            # Dropping this stream would SHRINK the shared-block map, and both callers reassemble file
            # content from it: every VCN this stream would have supplied then stays zero in the output.
            # That is E83's defect (snapshot CoW blocks read as holes) arriving through an exception
            # path. The map is all-or-nothing, so say so and let the caller defer.
            _skip_note("snapshot shared blocks", f"sub-stream 0x{sub:x}", _e)
            raise IncompleteEvidence(f"snapshot sub-stream 0x{sub:x} did not parse") from _e
    shared = {}
    for sub in sorted(streams, reverse=True):        # newest first; an older snapshot never overrides it
        for fv, vlcn, run in (streams[sub][2] or []):
            if not vlcn:
                continue
            for j in range(run):
                shared.setdefault(fv + j, vlcn + j)
    return shared


def _recover_inline_extent_content(f, ps, cs, tr, vd, _defer_ctx=None):
    """Reassemble the LIVE content of a NON-RESIDENT file whose CURRENT $DATA stream (sub_id 0x1000) holds its
    extent map INLINE in a 0x10028 holder — the F5 'extent-backed' case (disk_alloc>0) that
    `recover_cow_current_content` deliberately defers. Returns the bytes (trimmed to stream_size), or None to
    DEFER (never wrong output). SAFE by a coverage gate: reassemble only when the decoded extents account for
    EVERY allocated cluster exactly once and start within the file — otherwise defer (large/overflow holders with
    a different extent-table format, or any decode anomaly). Sparse-aware: holes (alloc < size) are zero-filled.
    Integrity-stream CRC32-C checksums interleaved BETWEEN extents (8-byte element) are skipped by validated
    decode (the next real extent sits at +24 or +32). SEPARATE from the snapshot path (`parse_snapshot_data_entry`)
    which is left byte-identical. (structure_reference §C.6; Phase-0 SPEC 2026-08-02, disk-verified.)"""
    v = None
    for k, hv in parse_resident_btree_rows(vd, (f, ps, cs, tr)):
        if (len(k) >= 0x18 and k[12] == 0x80 and k[13] == 0x00
                and len(hv) >= 0x50 and le32(hv, 4) == SNAP_DATA_DESC and le64(k, 0x10) == 0x1000):
            v = hv; break
    if v is None:
        return None
    ihdr = le32(v, 0)
    if ihdr + 0x18 > len(v):
        return None
    ecount = le32(v, ihdr + 0x14)
    stream_size = le64(v, 0x38)
    alloc_cl = le64(v, 0x48) // cs
    if stream_size == 0:
        return b""
    if alloc_cl <= 0 or ecount <= 0:
        return None
    if stream_size > 4 * 1024 * 1024 * 1024:        # 4 GiB safety cap (matches the extent-extract path)
        return None
    size_cl = (stream_size + cs - 1) // cs
    ncl = _volume_ncl(f, ps, cs)            # volume cluster count (plausibility bound)

    # validated-greedy decode (shared with the snapshot/carve paths); size_cl tightens the file_vcn bound.
    exts = _decode_inline_extents(v, ncl, max_fvcn=size_cl, tr=tr)

    # COVERAGE GATE (the safety guarantee): every allocated cluster accounted for, exactly once, within the file.
    covered = set()
    for fv, _vl, run in exts:
        for j in range(run):
            covered.add(fv + j)
    if sum(run for _fv, _vl, run in exts) != alloc_cl or len(covered) != alloc_cl:
        return None
    if any(fv + run > size_cl for fv, _vl, run in exts):
        return None

    # E83: blocks this stream does not own may be SHARED with a stream snapshot rather than being sparse
    # holes. Resolve those to the clusters that actually hold them; a VCN no stream owns stays zero-filled,
    # which is the genuine sparse case. Empty (and therefore a no-op) for a file without snapshots.
    _runs = []                          # every PHYSICAL cluster whose bytes end up in `buf`
    try:
        shared = _snapshot_shared_blocks(vd, (f, ps, cs, tr), ncl)
    except IncompleteEvidence as _e:
        _defer_note(_defer_ctx or "a stream", f"snapshot shared-block map incomplete ({_e})")
        return None                     # defer: a truncated shared map would be emitted as zero blocks
    if shared:
        for fv in range(size_cl):
            if fv in covered or fv not in shared:
                continue
            off = fv * cs
            try:
                plcn = tr.tr(shared[fv]) if tr else shared[fv]
                _runs.append((plcn, 1, off))
            except Exception as _e:
                # This VCN never reaches `exts`, so the buffer below leaves it ZERO and the file is
                # emitted anyway -- fabricated content, in a function that promises to defer instead.
                _skip_note("shared block translate", f"vcn {fv}", _e)
                _defer_note(_defer_ctx or "a stream",
                            f"shared block at VCN {fv} could not be translated ({type(_e).__name__})")
                return None
            f.seek(ps + plcn * cs)
            chunk = f.read(cs)
            if len(chunk) < min(cs, stream_size - off):
                _skip_note("shared block read", f"vcn {fv}", IOError("short read"))
                _defer_note(_defer_ctx or "a stream", f"short read on the shared block at VCN {fv}")
                return None
            exts = exts + [(fv, shared[fv], 1)]

    buf = bytearray(stream_size)            # holes stay zero (sparse)
    for fv, vlcn, run in exts:
        if vlcn == 0:
            continue                        # sparse hole -> leave zero-filled (never read PLCN 0 / boot region)
        for j in range(run):
            off = (fv + j) * cs
            if off >= stream_size:
                continue
            try:
                plcn = tr.tr(vlcn + j) if tr else (vlcn + j)
            except Exception:
                return None
            _runs.append((plcn, 1, off))
            f.seek(ps + plcn * cs)
            chunk = f.read(cs)
            n = min(cs, stream_size - off)
            if len(chunk) < n:
                return None
            buf[off:off + n] = chunk[:n]
    if _defer_ctx:
        # Only when these bytes are destined for OUTPUT. `files` calls this for residency classification
        # on every record; a hole sweep there would cost syscalls for an answer nobody reads.
        content_holes(f, ps, cs, _runs, _defer_ctx, stream_size=stream_size)
    # `bytes(buf)`, not `bytes(buf[:stream_size])`: buf is allocated at exactly stream_size and every
    # write above is bounded by it (`off >= stream_size` skipped, `n = min(cs, stream_size - off)`), so
    # the slice can only ever copy the whole buffer. It made a large reassembly hold THREE copies of the
    # file at once -- on a 2,556 MiB stream that is ~7.6 GiB, which is what took a verification worker
    # over the limit on a 7 GiB host. Same bytes, one copy fewer.
    return bytes(buf)


def _verify_inline_integrity(f, ps, cs, tr, vd):
    """Verify a NON-RESIDENT file's INLINE per-cluster CRC32-C integrity checksums (the 0x1000 / 0x10028 holder).
    Each checksummed cluster is a run==1 extent with flag 0x1C00D0, immediately followed by an 8-byte element
    whose le32@+0 == CRC32-C(that 4096-byte cluster). Reads each checksummed cluster and recomputes CRC32-C.

    Returns None when the file carries NO inline element (SHA-256 / 64K-cluster / non-integrity / v3.4 / the
    large-overflow or complex holder formats) — i.e. nothing inline to verify. Otherwise returns
    {'checked': int, 'ok': int, 'unset': int, 'bad': [(file_vcn, vlcn, plcn, stored_crc, actual_crc), ...],
     'bad_count': int}. Never raises: a read error on a cluster is skipped (not counted). Purely on-disk read-only
    (the stored checksum is the ground truth; a mismatch is genuine corruption/tampering, surfaced non-fatally).
    (structure_reference §C.6; Phase-2 spec 2026-08-06, poly 0x82F63B78, static+disk confirmed on 391/391 clusters.)"""
    v = None
    for k, hv in parse_resident_btree_rows(vd, (f, ps, cs, tr)):
        if (len(k) >= 0x18 and k[12] == 0x80 and k[13] == 0x00
                and len(hv) >= 0x50 and le32(hv, 4) == SNAP_DATA_DESC and le64(k, 0x10) == 0x1000):
            v = hv; break
    if v is None:
        return None
    ihdr = le32(v, 0)
    if ihdr + 0x18 > len(v):
        return None
    ecount = le32(v, ihdr + 0x14)
    ncl = _volume_ncl(f, ps, cs)
    res = {"checked": 0, "ok": 0, "unset": 0, "bad": [], "bad_count": 0}
    inline = False
    pos = ihdr + 0x28
    for _i in range(ecount):
        if pos + 24 > len(v):
            break
        vlcn = le64(v, pos); run = le32(v, pos + 0x14); fvcn = le32(v, pos + 0x0C); flag = le32(v, pos + 8)
        if not (0 < run <= ncl and (vlcn == 0 or 0 < vlcn < ncl)):
            break
        checksummed = (flag == INTEGRITY_EXTENT_FLAG and run == 1)
        if checksummed and vlcn > 0 and pos + 32 <= len(v):
            inline = True
            stored = le32(v, pos + 24)                 # element[+0] = CRC32-C(cluster); element[+4] reserved (ignore)
            if stored == _INTEGRITY_UNSET:
                res["unset"] += 1
            else:
                try:
                    plcn = tr.tr(vlcn) if tr else vlcn
                    f.seek(ps + plcn * cs); data = f.read(cs)
                except Exception:
                    data = b""
                if len(data) == cs:
                    res["checked"] += 1
                    actual = _crc32c(data)
                    if actual == stored:
                        res["ok"] += 1
                    else:
                        res["bad_count"] += 1
                        if len(res["bad"]) < 64:
                            res["bad"].append((fvcn, vlcn, plcn, stored, actual))
        pos += 32 if checksummed else 24               # checksummed extent has a 32-byte stride (24 + 8-byte element)
    return res if inline else None


def recover_snapshot_streams(f, ps_off, cs, tr, vd):
    """Recover snapshot + current stream content from a resident type-0x30 row.
    Returns a list of {name, sub_id, stream_size, ts, content|None, inline, n_extents}.
    content is None when inline (disk_alloc==0; bytes live in the main 0x30 body) or
    when the referenced DATA entry is absent. The current file version is sub_id 0x1000."""
    ncl = _volume_ncl(f, ps_off, cs)       # integrity-robust extent decode (skip interleaved CRC32-C)
    snaps = []   # (name, sub_id, stream_size, ts)
    data = {}    # sub_id -> (stream_size, disk_alloc, extents)
    for k, v in parse_resident_btree_rows(vd, (f, ps_off, cs, tr)):
        if len(k) < 0x10:
            continue
        typ = le16(k, 0x0C)
        if typ == 0xB0 and len(v) >= 0x50:
            sub_id = le32(v, 0x44)
            is_snap = (le16(v, 0x10) == 2) or (0x1000 <= sub_id <= 0xFFFF)
            if not is_snap:
                continue
            name = ""
            if len(k) > 0x10:
                try:
                    name = k[0x10:].decode("utf-16-le").rstrip("\x00")
                except Exception:
                    name = k[0x10:].hex()
            snaps.append((name, sub_id, le64(v, 0x20), le64(v, 0x4C)))
        elif typ == 0x80 and len(v) >= 0x50 and le32(v, 4) == SNAP_DATA_DESC:
            data[le64(k, 0x10)] = parse_snapshot_data_entry(v, ncl, tr)

    def _read_extents(stream_size, exts, sub_id=None, name_for_msg=None):
        """Assemble one version, placing every block at its own file VCN.

        E83: a version owns only the blocks that were copied out for it; the rest it SHARES with OLDER
        snapshots, which is why concatenating its own extents produced a short, offset-shifted file. Missing
        VCNs are resolved from snapshots strictly older than this one — never newer, which could hold content
        written after the version being recovered. A VCN no stream owns stays zero (a genuine sparse hole)."""
        try:
            shared = (_snapshot_shared_blocks(vd, (f, ps_off, cs, tr), ncl, exclude=sub_id, older_than=sub_id)
                      if sub_id else {})
        except IncompleteEvidence:
            return None                 # defer: same reason as the live-stream path
        nblocks = (stream_size + cs - 1) // cs
        blocks = {}
        for fvcn, vlcn, run in exts:
            for j in range(run):
                if vlcn:
                    blocks.setdefault(fvcn + j, vlcn + j)
        for fvcn in range(nblocks):
            if fvcn not in blocks and fvcn in shared:
                blocks[fvcn] = shared[fvcn]
        # Only hand back content when EVERY block position resolves to a real cluster. A partially resolved
        # version would have to be zero-padded, and inventing bytes that are not on the volume is exactly the
        # failure this change exists to remove — so an incomplete version is reported as not recovered
        # instead. (A stream with no extents at all is the inline/CoW-resident case, handled elsewhere.)
        if len(blocks) < nblocks:
            return b""
        buf = bytearray(stream_size)
        _runs = []
        for fvcn in range(nblocks):
            vlcn = blocks.get(fvcn)
            if not vlcn:
                continue
            try:
                plcn = tr.tr(vlcn)
            except Exception:
                plcn = vlcn
            off = fvcn * cs
            _runs.append((plcn, 1, off))
            f.seek(ps_off + plcn * cs)
            chunk = f.read(cs)
            n = min(cs, stream_size - off)
            if len(chunk) < n:
                return b""
            buf[off:off + n] = chunk[:n]
        # Snapshot VERSIONS are output too. Punching one cluster behind a version produced a 5-byte
        # all-zero `test.txt__last` sitting beside five correct versions -- which reads as "the file was
        # zeroed in its last version", a forensic conclusion invented by the reader.
        content_holes(f, ps_off, cs, _runs,
                      f"snapshot version '{name_for_msg}' (0x{sub_id or 0:x})" if name_for_msg
                      else f"snapshot version 0x{sub_id or 0:x}", stream_size=stream_size)
        return bytes(buf)

    out = []
    for name, sub_id, ssize, ts in sorted(snaps, key=lambda s: s[1]):
        d = data.get(sub_id)
        if d is None:
            out.append({"name": name, "sub_id": sub_id, "stream_size": ssize,
                        "ts": ts, "content": None, "inline": False, "n_extents": 0})
            continue
        _ds, disk_alloc, exts = d
        if disk_alloc == 0:
            out.append({"name": name, "sub_id": sub_id, "stream_size": ssize,
                        "ts": ts, "content": None, "inline": True, "n_extents": 0})
        else:
            # _holes_mark is taken BEFORE this version is assembled, so the writer can tell which
            # version drew from holes: every version is produced here, long before any is written.
            _hm = len(_CONTENT_HOLES)
            out.append({"name": name, "sub_id": sub_id, "stream_size": ssize, "ts": ts,
                        "content": _read_extents(ssize, exts, sub_id, name), "inline": False,
                        "n_extents": len(exts), "_holes_mark": _hm})
    return out

# ═══════════════════════════════════════════════════════════════════════
# MLog (durable log) parsing — E2 opcode tables from PerformRedo
# ═══════════════════════════════════════════════════════════════════════

# v3.14 redo dispatch — corrected verbatim from CmsLogRedoQueue::PerformRedo (win11 26100,
# refs_win11.decomp.c; per-function copy analysis/static/decompiled_functions/redo_dispatch/
# PerformRedo_win11.c). Opcodes 0x00–0x2B are a CONTIGUOUS dispatched range; the ONLY in-range
# value that returns NTSTATUS 0xC0000427 (generic unhandled-opcode) is 0x17. The earlier table mislabelled six handled
# ops (0x04,0x10,0x14,0x1B,0x20,0x26) as "gaps" and was off-by-one across 0x1A/0x1B and
# 0x1E/0x1F/0x20 and 0x28/0x29; all corrected here (finding #328, all E2).
REDO_OPS_V314 = {
    0x00: "OpenTableFromTablePath",
    0x01: "RedoInsertRow",
    0x02: "RedoDeleteRow",
    0x03: "RedoUpdateRow",
    0x04: "RedoUpdateDataWithRoot",                  # PerformRedo_win11.c:144 (was tagged gap)
    0x05: "RedoReparentTable",
    0x06: "RedoAllocate",
    0x07: "RedoFree",
    0x08: "RedoSetRangeState",                       # shared 0x08/0x09
    0x09: "RedoSetRangeState",
    0x0A: "RedoDuplicateExtents",
    0x0B: "RedoModifyStreamExtent",
    0x0C: "CmsStream::StripAllChecksums",
    0x0D: "CmsBPlusTable::SetIntegrityInformation",
    0x0E: "RedoSetParentId",
    0x0F: "RedoDeleteTable",
    0x10: "CmsBPlusTable::SetObjectRecordPayload",   # :207 (was tagged gap)
    0x11: "RedoAddSchema",
    0x12: "RedoMoveContainer",                       # shared 0x12/0x14/0x15 (LAB_14012eebf)
    0x13: "RedoAddContainer",
    0x14: "RedoMoveContainer",                       # :224 (was gap:unknown_0x14)
    0x15: "RedoMoveContainer",                       # :222 (was "(dispatch flag)")
    0x16: "RedoSetRangeState",                       # :114 range-parse variant (E3, name unconfirmed)
    0x17: "ERROR:0xC0000427",             # :239 explicit error — the only in-range gap
    0x18: "RedoContainerCompaction",
    0x19: "RedoDeleteCompressionUnitOffsets",
    0x1A: "RedoAddCompressionUnitOffsets",           # :256 InsertRow(0x32) (was RedoGhostExtents)
    0x1B: "RedoGhostExtents",                        # :266 (was gap:unknown_0x1b)
    0x1C: "RedoCompactionUnreserve",
    0x1D: "CmsBPlusTable::UnlinkParentObjectId",
    0x1E: "CmsTableSetBase::PrepareEntryForMerge",   # :293 (was RedoUpdateStreamSummary)
    0x1F: "RedoUpdateStreamSummary",                 # :297 (was UpdateStreamUserPayload)
    0x20: "CmsStream::UpdateStreamUserPayload",      # :310 (was gap:unknown_0x20) — handled
    0x21: "RedoStreamPersistFastRunInsertion",
    0x22: "RedoTableSetSummaryUpdate",
    0x23: "RedoTableSetShadowTreeUpdate",
    0x24: "RedoTableSetCommitMerge",
    0x25: "RedoTableSetCallback(+0x08)",             # :340 indirect CmsTableSetBase vtbl call
    0x26: "RedoTableSetStrongRefMerge",              # :348 (was gap:unknown_0x26)
    0x27: "RedoSetDefaultCompressionParameters",
    0x28: "CmsBlockRefcount::BreakWeakReferences",   # :358 (was RedoDuplicateCluster)
    0x29: "RedoDuplicateCluster",                    # :365
    0x2A: "RedoChangeRangeEncryptedState",
    0x2B: "RedoTableSetCallback(+0x18)",             # :381 indirect CmsTableSetBase vtbl call
}

REDO_OPS_V34 = {
    0x00: "OpenTable",
    0x01: "RedoInsertRow",
    0x02: "RedoDeleteRow",
    0x03: "RedoUpdateRow",
    0x04: "RedoUpdateDataWithRoot",
    0x05: "RedoReparentTable",
    0x06: "RedoAllocate",
    0x07: "RedoFree",
    0x08: "RedoSetRangeState",                       # PerformRedo_win10.c:114 (was tagged gap)
    0x09: "RedoSetRangeState",                       # shared 0x08/0x09 (uVar2 < 10 branch)
    0x0A: "RedoDuplicateExtents",
    0x0B: "RedoModifyStreamExtent",
    0x0C: "RedoStripMetadataStreamExtent",
    0x0D: "RedoSetIntegrity",
    0x0E: "RedoSetParentId",
    0x0F: "RedoDeleteTable",
    0x10: "CmsBPlusTable::SetObjectRecordPayload",
    0x11: "RedoAddSchema",
    0x12: "RedoMoveContainer",
    0x13: "RedoAddContainer",
    0x14: "RedoMoveContainer",
    0x15: "RedoMoveContainer",
    0x16: "RedoReadCacheInvalidation",
    0x17: "RedoGenerateChecksum",
    0x18: "RedoContainerCompression",
    0x19: "RedoDeleteCompressionUnitOffsets",
    0x1A: "RedoAddCompressionUnitOffsets",
    0x1B: "RedoGhostExtents",
    0x1C: "RedoCompactionUnreserve",
}

OPCODE_CATEGORIES = {
    "OpenTableFromTablePath": "table", "OpenTable": "table",
    "RedoInsertRow": "btree", "RedoDeleteRow": "btree",
    "RedoUpdateRow": "btree", "RedoUpdateDataWithRoot": "btree",
    "RedoReparentTable": "table", "RedoDeleteTable": "table",
    "RedoAllocate": "alloc", "RedoFree": "alloc",
    "RedoSetRangeState": "alloc",
    "RedoDuplicateExtents": "dedup", "RedoDuplicateCluster": "dedup",
    "RedoGhostExtents": "dedup",
    "RedoModifyStreamExtent": "stream",
    "RedoUpdateStreamSummary": "stream",
    "CmsStream::UpdateStreamUserPayload": "stream",
    "RedoStreamPersistFastRunInsertion": "stream",
    "CmsStream::StripAllChecksums": "integrity",
    "CmsBPlusTable::SetIntegrityInformation": "integrity",
    "RedoSetIntegrity": "integrity",
    "RedoStripMetadataStreamExtent": "integrity",
    "RedoSetParentId": "namespace",
    "CmsBPlusTable::UnlinkParentObjectId": "namespace",
    "RedoAddSchema": "schema",
    "RedoMoveContainer": "container", "RedoAddContainer": "container",
    "RedoContainerCompaction": "container", "RedoContainerCompression": "container",
    "RedoCompactionUnreserve": "container",
    "RedoDeleteCompressionUnitOffsets": "compress",
    "RedoAddCompressionUnitOffsets": "compress",
    "RedoSetDefaultCompressionParameters": "compress",
    "RedoTableSetSummaryUpdate": "tableset",
    "RedoTableSetShadowTreeUpdate": "tableset",
    "RedoTableSetCommitMerge": "tableset",
    "RedoTableSetStrongRefMerge": "tableset",
    "CmsTableSetBase::PrepareEntryForMerge": "tableset",
    "RedoTableSetCallback(+0x08)": "tableset",
    "RedoTableSetCallback(+0x18)": "tableset",
    "RedoReadCacheInvalidation": "cache",
    "RedoGenerateChecksum": "checksum",
    "RedoChangeRangeEncryptedState": "encrypt",
    "CmsBPlusTable::SetObjectRecordPayload": "btree",
    "CmsBlockRefcount::BreakWeakReferences": "dedup",
    "ERROR:0xC0000427": "error",
}

MLOG_SCHEMA_NAMES = {
    0xe010: "Allocator", 0xe030: "ObjectTable", 0xe040: "ParentChild",
    0xe050: "ObjectData", 0xe060: "SchemaTable", 0xe080: "IntegrityState",
    0xe090: "Upcase/Logfile", 0xe0b0: "BlockRefcount",
    0xe0c0: "ContainerTable", 0xe0d0: "TrashTable", 0xe100: "ContainerIndex",
    0xe110: "ReadCache", 0xe120: "DirtyRange", 0xe130: "HeatEngine",
    0x0110: "DirEntryList", 0x0120: "FileStream", 0x0130: "$FILE_NAME",
    0x0140: "$FILE_NAME_long", 0x0150: "$VOLUME_INFO", 0x0160: "ReparseIndex",
    0x0170: "$REPARSE", 0x0180: "$DATA", 0x0190: "$SI",
    0x01A0: "$INDEX_ROOT", 0x01B0: "$SNAPSHOT", 0x01C0: "$REPARSE_v2",
    0x01D0: "$EA_INFO", 0x01E0: "$EA", 0x01F0: "$LOGGED_UTILITY",
    0x0200: "$LOGGED_UTILITY_V2",
}

KNOWN_SYSTEM_OIDS = {
    0x07: "Upcase(pri)", 0x08: "Upcase(dup)", 0x09: "Logfile(pri)",
    0x0A: "Logfile(dup)", 0x0D: "TrashTable", 0x30: "SessionActivity",
    0x500: "VolumeInfo(pri)", 0x501: "VolumeInfo(dup)",
    0x520: "FS Metadata", 0x530: "SecurityDesc",
    0x540: "ReparseIdx(pri)", 0x541: "ReparseIdx(dup)",
    0x600: "/",
}

# R3 (2026-07-03): the old hand-maintained MLOG_OP_SHORT opcode→mnemonic dict was removed — it was dead code
# (no readers) carrying the pre-C4 version-independent short names. op_short is now DERIVED from the
# version-selected long table via _redo_short(), so it can never drift from op_name.

PAGE_TYPE_ZERO = "zero"
PAGE_TYPE_MSBP = "MSB+"
PAGE_TYPE_MLOG = "MLog"
PAGE_TYPE_DATA = "data"

MIN_REDO_SIZE = 0x38

# ── ReFS metadata checksum (page references, cktype 2 = CRC64) ──────────
# REFLECTED CRC64, polynomial 0x9A6C9329AC4BC9B5 (driver global `ClMulCsCrc64`),
# init = xorout = ~0, computed over the FULL metadata page (all page-ref LCN
# slots concatenated, 16 KiB for 4K clusters). E2: ?GenerateChecksum…Crc64_ClMul@
# + RD: matches stored page-reference checksums, 0 mismatches across CRC64/SHA-256/64K.
_REFS_CRC64_POLY = 0x9A6C9329AC4BC9B5
_REFS_CRC64_TBL = []
for _ci in range(256):
    _cc = _ci
    for _ in range(8):
        _cc = (_cc >> 1) ^ _REFS_CRC64_POLY if (_cc & 1) else _cc >> 1
    _REFS_CRC64_TBL.append(_cc & 0xFFFFFFFFFFFFFFFF)
# Collision sentinel the driver remaps (GenerateChecksum: 0x…fffe → 0x…ffff).
REFS_CRC64_SENTINEL = 0xABBAFFFFABBAFFFF


def refs_crc64(data):
    """ReFS metadata CRC64 (cktype 2) over a full metadata page."""
    crc = 0xFFFFFFFFFFFFFFFF
    for b in data:
        crc = _REFS_CRC64_TBL[(crc ^ b) & 0xFF] ^ (crc >> 8)
    return (crc ^ 0xFFFFFFFFFFFFFFFF) & 0xFFFFFFFFFFFFFFFF

_CKNAME = {0: "none", 1: "CRC32-C", 2: "CRC64", 4: "SHA-256"}
def _verify_self_checksum(blk, cluster_size):
    """B3: RECOMPUTE and match a SUPB/CHKP self-checksum (not just the signature). Returns
    (ok: bool|None, ckname). None => no self-descriptor / cktype 0 (nothing to verify). The self-descriptor
    (LcnWithChecksum) sits within the first cluster: byte@+0x23==8, cktype@+0x22, digest_len@+0x24, stored
    digest@+0x28; the descriptor region is zeroed and the checksum covers exactly one cluster (algorithm from
    CmsVolume::ComputeOrVerifySelfChecksumBlock; proven on the corpus by verify_self_checksum.py)."""
    import hashlib as _h, struct as _st
    desc = ck = dl = None
    for off in range(0x40, min(len(blk), 0x400) - 0x30):
        if blk[off + 0x23] != 0x08:            continue
        c = blk[off + 0x22]
        if c not in (0, 1, 2, 4):              continue
        d = le32(blk, off + 0x24)
        if d not in (0, 4, 8, 32):             continue
        if off + 0x28 + d > len(blk):          continue
        desc, ck, dl = off, c, d
        break
    if desc is None:            return (None, "-")
    if ck == 0 or dl == 0:      return (None, "none")
    stored = bytes(blk[desc + 0x28: desc + 0x28 + dl])
    for dz in (0x2c, 0x30, 0x48, 0x68, 0x80):  # descriptor-zeroing window candidates
        if desc + dz > cluster_size:           continue
        b = bytearray(blk[:cluster_size])
        b[desc:desc + dz] = b"\x00" * dz
        if   ck == 1: calc = _st.pack("<I", _crc32c(bytes(b)))
        elif ck == 2: calc = _st.pack("<Q", refs_crc64(bytes(b)))
        elif ck == 4: calc = _h.sha256(bytes(b)).digest()
        else:         calc = b""
        if calc == stored:
            return (True, _CKNAME.get(ck, "?"))
    return (False, _CKNAME.get(ck, "?"))


def _self_checksum_recipe(blk, cluster_size):
    """Write-side companion of _verify_self_checksum: return (desc_off, cktype, digest_len, zero_window) for the
    self-descriptor window that VERIFIES on `blk`, or None. `_recompute_self_checksum` uses it to reproduce the
    exact digest ReFS accepts after a location-specific field is edited (e.g. a repaired SUPB's self-LCN)."""
    import hashlib as _h, struct as _st
    for off in range(0x40, min(len(blk), 0x400) - 0x30):
        if blk[off + 0x23] != 0x08:                 continue
        ck = blk[off + 0x22]
        if ck not in (1, 2, 4):                     continue
        dl = le32(blk, off + 0x24)
        if dl not in (4, 8, 32) or off + 0x28 + dl > len(blk):   continue
        stored = bytes(blk[off + 0x28: off + 0x28 + dl])
        for dz in (0x2c, 0x30, 0x48, 0x68, 0x80):
            if off + dz > cluster_size:             continue
            b = bytearray(blk[:cluster_size]); b[off:off + dz] = b"\x00" * dz
            calc = (_st.pack("<I", _crc32c(bytes(b))) if ck == 1 else
                    _st.pack("<Q", refs_crc64(bytes(b))) if ck == 2 else _h.sha256(bytes(b)).digest())
            if calc == stored:
                return (off, ck, dl, dz)
        return None
    return None


def _recompute_self_checksum(blk, cluster_size, recipe):
    """Return a NEW bytearray = `blk` with the self-checksum digest recomputed per `recipe`
    (from _self_checksum_recipe) and written at desc+0x28 — used after editing a self-LCN during repair."""
    import hashlib as _h, struct as _st
    off, ck, dl, dz = recipe
    out = bytearray(blk)
    b = bytearray(out[:cluster_size]); b[off:off + dz] = b"\x00" * dz
    dig = (_st.pack("<I", _crc32c(bytes(b))) if ck == 1 else
           _st.pack("<Q", refs_crc64(bytes(b))) if ck == 2 else _h.sha256(bytes(b)).digest())
    out[off + 0x28: off + 0x28 + dl] = dig[:dl]
    return out
# The MLog log block (one LogCore record) is ALWAYS 4 KiB, independent of the
# volume cluster size. On a 64 KiB-cluster volume each data-area cluster holds
# 16 of these 4 KiB log blocks (verified RD; see docs/structures/mlog.md).
MLOG_BLOCK = 0x1000

_FT_EPOCH = datetime.datetime(1601, 1, 1)
# Plausible-FILETIME band, used to (a) render a timestamp only if it is a real date and (b) discriminate a
# paired $SI-update block from redo/random bytes in _mlog_pair_si_timestamp. Widened (audit 3.1) from the old
# 2013–2044 band to ~1968–2108: a real or timestomped/backdated date outside 2013–2044 (e.g. a 1970 Unix-epoch
# or year-2000 timestomp) must be shown as it is on disk, not suppressed. Still a tight ~0.2%-of-u64 band, so
# requiring all three $SI stamps in-band keeps the pairing discriminator effectively false-positive-free.
_FT_MIN = 116000000000000000   # ~1968
_FT_MAX = 160000000000000000   # ~2108


def _filetime_dt(val):
    if _FT_MIN < val < _FT_MAX:
        return _FT_EPOCH + datetime.timedelta(microseconds=val // 10)
    return None


def _filetime_str(val):
    dt = _filetime_dt(val)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z" if dt else ""


def format_uuid(b):
    if len(b) < 16:
        return b.hex()
    import uuid as _uuid
    return str(_uuid.UUID(bytes_le=bytes(b[:16])))


def _as_vlcn_list(val):
    return val if isinstance(val, (list, tuple)) else [val]


def get_mlog_info(f, ps_off, cs, tr, obj_map):
    """Extract MLog location from OID 0x9 (Logfile Information Table)."""
    for oid in [0x9, 0xA]:
        if oid not in obj_map:
            continue
        rows = list(walk_bplus(f, ps_off, cs, tr, _as_vlcn_list(obj_map[oid])))
        info = {"oid": oid, "rows": len(rows)}
        for kd, vd in rows:
            key = le32(kd, 0) if len(kd) >= 4 else -1
            if key == 0:
                try:
                    info["table_name"] = kd[4:].decode("utf-16-le").rstrip("\x00") \
                        if len(kd) > 4 else vd.decode("ascii", errors="replace").rstrip("\x00")
                except Exception:
                    info["table_name"] = vd[:25].hex()
            elif key == 1 and len(vd) >= 40:
                info["data_start_lcn"] = le64(vd, 0)
                info["data_end_lcn"] = le64(vd, 8)
                info["data_size_clusters"] = le64(vd, 16)
                info["ctrl_plcn_0"] = le64(vd, 24)
                info["ctrl_plcn_1"] = le64(vd, 32)
        if "ctrl_plcn_0" in info:
            return info
    return None


def parse_mlog_control_page(page):
    """Parse a raw MLog control page (4096+ bytes with 'MLog' signature)."""
    if len(page) < 256 or page[:4] != b"MLog":
        return None
    info = {
        "signature": "MLog",
        "format_magic": le32(page, 0x04),  # per-volume constant, NOT a CRC32 (errata E42)
        "version": le32(page, 0x08),
        "sector_size": le32(page, 0x0C),
        "uuid": format_uuid(page[0x10:0x20]),
        "sequence_raw": le64(page, 0x20),
    }
    eh_off = le32(page, 0x54)
    if eh_off == 0 or eh_off + 0x30 > len(page):
        return info
    info["entry_header_offset"] = eh_off
    payload_size = le32(page, eh_off + 0x20)
    payload_off = le32(page, eh_off + 0x28)
    info["payload_size"] = payload_size
    info["payload_offset"] = payload_off
    if payload_size != 0xe48:
        return info
    data_off = eh_off + payload_off
    if data_off + 0xe48 > len(page):
        return info
    d = page[data_off:]
    info["sequence"] = le64(d, 0x00)
    info["data_start_lcn"] = le64(d, 0x08)
    info["data_end_lcn"] = le64(d, 0x10)
    info["lsn_oldest"] = le64(d, 0x18)
    info["generation"] = le32(d, 0x20)
    info["write_counter"] = le32(d, 0x38)
    info["flags"] = le32(d, 0x3C)
    info["total_entries"] = le64(d, 0x48)
    info["ctrl_uuid"] = format_uuid(d[0x50:0x60])
    return info


def read_mlog_control(f, ps_off, cs, mlog_info):
    """Read both MLog control pages and return the more recent one."""
    ctrls = []
    for key in ["ctrl_plcn_0", "ctrl_plcn_1"]:
        plcn = mlog_info.get(key, 0)
        if plcn == 0:
            continue
        f.seek(ps_off + plcn * cs)
        page = f.read(max(cs, 4096))
        parsed = parse_mlog_control_page(page)
        if parsed:
            parsed["plcn"] = plcn
            ctrls.append(parsed)
    if not ctrls:
        return None
    if len(ctrls) == 2:
        s0 = ctrls[0].get("sequence", 0)
        s1 = ctrls[1].get("sequence", 0)
        return ctrls[1] if s1 > s0 else ctrls[0]
    return ctrls[0]


def classify_mlog_page(page):
    if all(b == 0 for b in page[:64]):
        return PAGE_TYPE_ZERO
    sig = page[:4]
    if sig == b"MSB+":
        return PAGE_TYPE_MSBP
    if sig == b"MLog":
        return PAGE_TYPE_MLOG
    return PAGE_TYPE_DATA


def scan_mlog_data_area(f, ps_off, cs, tr, mlog_info, ctrl):
    """Scan the MLog data area and classify each 4 KiB log block.

    The data area is addressed in volume clusters (from OID 0x9), but each MLog
    record is a 4 KiB log block. On a 64 KiB-cluster volume every cluster packs
    16 log blocks, so we iterate 4 KiB blocks within each cluster — otherwise a
    64K-cluster log would expose only 1/16 of its records. On 4K-cluster volumes
    blocks_per_cluster == 1 and the behaviour is identical to a cluster scan."""
    start_plcn = mlog_info.get("data_start_lcn", 0)
    end_plcn = mlog_info.get("data_end_lcn", 0)
    if start_plcn == 0 or end_plcn == 0 or end_plcn <= start_plcn:
        if ctrl:
            start_plcn = ctrl.get("data_start_lcn", 0)
            end_plcn = ctrl.get("data_end_lcn", 0)
    if start_plcn == 0 or end_plcn == 0:
        return
    blocks_per_cluster = max(1, cs // MLOG_BLOCK)
    # Generator: yield one page dict per 4 KiB log block instead of building a list. A 1 GiB log
    # (262k blocks × 4 KiB) would otherwise hold ~1 GB of block bytes resident at once. Single-pass
    # consumers (extract_redo_records / extract_mlog_transactions, timeline) stream this directly;
    # multi-pass callers (mlog --json / default / --raw-scan) wrap it with list().
    for plcn in range(start_plcn, end_plcn):
        f.seek(ps_off + plcn * cs)
        cluster = f.read(cs)
        for bi in range(blocks_per_cluster):
            block = cluster[bi * MLOG_BLOCK:(bi + 1) * MLOG_BLOCK]
            if len(block) < 4:
                break
            ptype = classify_mlog_page(block)
            yield {
                "vlcn": plcn, "plcn": plcn, "block": bi,
                "block_lcn": plcn * blocks_per_cluster + bi,
                "type": ptype,
                "page": block if ptype != PAGE_TYPE_ZERO else None,
            }


def try_parse_redo_block(data, redo_ops):
    """Parse data as _SmsRedoHeader with inner _SmsRedoRecord entries."""
    if len(data) < 8:
        return []
    total_size = le32(data, 0)
    first_off = le32(data, 4)
    if total_size < MIN_REDO_SIZE or total_size > len(data):
        return []
    if first_off < 8 or first_off >= total_size:
        return []
    records = []
    remaining = total_size - first_off
    pos = first_off
    while remaining >= MIN_REDO_SIZE and pos + MIN_REDO_SIZE <= len(data):
        rec_size = le32(data, pos)
        if rec_size < MIN_REDO_SIZE or rec_size > remaining or rec_size == 0:
            break
        opcode = le32(data, pos + 4)
        table_path_len = le32(data, pos + 8) if pos + 12 <= len(data) else 0
        obj_id = le64(data, pos + 0x20) if pos + 0x28 <= len(data) else 0
        flags = le32(data, pos + 0x2C) if pos + 0x30 <= len(data) else 0
        op_name = redo_ops.get(opcode, "UNKNOWN_0x%02x" % opcode)
        records.append({
            "offset": pos, "size": rec_size,
            "opcode": opcode, "op_name": op_name,
            "table_path_len": table_path_len,
            "object_id": obj_id, "flags": flags,
            "txn_start": bool(flags & 1),
            "txn_commit": bool(flags & 2),
        })
        remaining -= rec_size
        pos += rec_size
    return records


def extract_payload_from_mlog_page(page):
    """Extract redo block payload from an MLog-signature data page."""
    if len(page) < 0x60:
        return None
    eh_off = le32(page, 0x54)
    if eh_off == 0 or eh_off + 0x30 > len(page):
        return None
    payload_size = le32(page, eh_off + 0x20)
    payload_off = le32(page, eh_off + 0x28)
    if payload_size == 0 or payload_off == 0:
        return None
    data_start = eh_off + payload_off
    if data_start + payload_size > len(page):
        return None
    return page[data_start:data_start + payload_size]


def mlog_verify_record(page):
    """Recompute an MLog data record's own integrity value and compare it with the stored one.

    Returns (ok, stored, computed) — or None when `page` is not an MLog LogCore record, so a caller can
    tell "did not apply" from "failed". Both record types carry the field: type 1 (control page) and
    type 2 (data record), at entry_header+0x30.

    The driver's scheme (`LogVerifyChecksumEntryHeader` -> `LogChecksumBlock`, E78): the checksum is an
    8-byte field at `page + le32(page, 0x54) + 8`; it is **zeroed** and the whole log block is folded:

        per block of `le32(page, 0x0C)` bytes (0x1000 on every volume measured):
            acc[0..3] = 0, with acc[0] seeded from the previous block's result as (r << 1) | (r >> 31 & 1)
            acc[i mod 4] ^= each little-endian u64 of the block
            v      = acc0 ^ acc1 ^ acc2 ^ acc3
            result = (v >> 32) ^ (v & 0xFFFFFFFF)

    i.e. a four-way interleaved u64 XOR folded to 32 bits, chained across blocks. A record is one block, so
    the chaining seed is 0 in practice. Verified byte-exact on 599,039 data records and 95 control pages
    across the whole image corpus (ReFS 3.4 -> 3.15 + Insider, 4K and 64K clusters), 0 mismatches, and it
    detects 2,000/2,000 random single-bit flips. Being an XOR fold it is blind to a REORDERING of 8-byte
    words that keeps each word in its own lane (i mod 4) -- it is an integrity check, not a signature.
    """
    if len(page) < 0xB0 or page[:4] != b"MLog":
        return None
    eh_off = le32(page, 0x54)
    if eh_off == 0 or eh_off + 0x34 > len(page):
        return None
    if le32(page, eh_off + 0x30) not in (1, 2):     # 1 = control record, 2 = data record; nothing else exists
        return None
    if eh_off + 16 > len(page):
        return None
    block = le32(page, 0x0C) or 0x1000
    if block < 8 or block > len(page):
        block = len(page)
    stored = le64(page, eh_off + 8)
    buf = bytearray(page)
    struct.pack_into("<Q", buf, eh_off + 8, 0)      # the field is excluded by zeroing it, as the driver does
    res = 0
    for base in range(0, len(buf), block):
        blk = bytes(buf[base:base + block])
        if len(blk) < block:
            blk += bytes(block - len(blk))
        acc = [((res << 1) | ((res >> 31) & 1)) & 0xFFFFFFFFFFFFFFFF, 0, 0, 0]
        for i in range(len(blk) // 8):
            acc[i & 3] ^= struct.unpack_from("<Q", blk, i * 8)[0]
        v = acc[0] ^ acc[1] ^ acc[2] ^ acc[3]
        res = ((v >> 32) ^ (v & 0xFFFFFFFF)) & 0xFFFFFFFFFFFFFFFF
    return (res == stored, stored, res)


def mlog_verify_pages(pages, max_failures=100):
    """Run mlog_verify_record() over an iterable of scan_mlog_data_area() blocks.

    Returns {checked, verified, failed, failures, failures_truncated}; `failures` holds
    (block_lcn, stored, computed) triples, capped at `max_failures`."""
    checked = verified = 0
    failures = []
    truncated = False
    for p in pages:
        page = p.get("page")
        if not page:
            continue
        r = mlog_verify_record(page)
        if r is None:
            continue
        checked += 1
        if r[0]:
            verified += 1
        elif len(failures) < max_failures:
            failures.append((p.get("block_lcn", 0), r[1], r[2]))
        else:
            truncated = True
    return {"checked": checked, "verified": verified, "failed": checked - verified,
            "failures": failures, "failures_truncated": truncated}


def parse_mlog_record_header(page):
    """Decode the LogCore data-record header (Layer 1, 0x78 bytes) and entry
    header (Layer 2) of an MLog data page. Returns None for control/other pages.
    Offsets verified static (v3.4/v3.14/Insider) + RD on 10 images; see
    docs/structures/mlog.md. payload_offset is 0x38 on v3.4-v3.14, 0x40 on Insider."""
    if len(page) < 0xB0 or page[:4] != b"MLog":
        return None
    eh_off = le32(page, 0x54)
    if eh_off == 0 or eh_off + 0x34 > len(page):
        return None
    rec_type = le32(page, eh_off + 0x30)        # u32: 2 = data, 1 = control
    if rec_type != 2:
        return None
    return {
        "signature": page[:4].decode("ascii", "replace"),
        "format_magic": le32(page, 0x04),       # per-volume constant, NOT a CRC (E42)
        "version": le32(page, 0x08),
        "log_block_size": le32(page, 0x0C),     # 0x1000 (4K) always
        "uuid": format_uuid(page[0x10:0x20]),
        "counter": le32(page, 0x20),
        "lsn": le64(page, 0x28),                # (generation<<32) | block offset
        "prev_lsn": le64(page, 0x30),
        "total_blocks": le32(page, 0x38),       # 4K log-block units
        "header_blocks": le32(page, 0x3C),
        "entry_header_offset": eh_off,
        "checksum": le64(page, eh_off + 0x08),  # XOR-fold at page+0x80
        "payload_len": le32(page, eh_off + 0x20),
        "payload_offset": le32(page, eh_off + 0x28),
        "record_type": rec_type,
        "redo_block_offset": eh_off + le32(page, eh_off + 0x28),
    }


def extract_redo_records(pages, redo_ops):
    """Extract redo records from MLog data area pages."""
    all_records = []
    for pinfo in pages:
        page = pinfo.get("page")
        if page is None:
            continue
        if pinfo["type"] != PAGE_TYPE_MLOG:
            continue
        payload = extract_payload_from_mlog_page(page)
        if payload is None:
            continue
        recs = try_parse_redo_block(payload, redo_ops)
        if recs:
            for r in recs:
                r["vlcn"] = pinfo["vlcn"]
                r["plcn"] = pinfo["plcn"]
                r["block"] = pinfo.get("block", 0)
                r["block_lcn"] = pinfo.get("block_lcn", pinfo["plcn"])
                r["page_type"] = pinfo["type"]
            all_records.extend(recs)
    return all_records


def _mlog_decode_utf16(raw):
    try:
        txt = raw.decode("utf-16-le").split("\x00")[0]
        if len(txt) >= 1 and all(c.isprintable() or c in "\t" for c in txt):
            return txt[:255]
    except (UnicodeDecodeError, ValueError):
        pass
    return ""


def _mlog_scan_utf16(vdata, start_off):
    for s in range(start_off, min(len(vdata) - 3, 200), 2):
        b0, b1 = vdata[s], vdata[s + 1]
        if 0x20 <= b0 < 0x7F and b1 == 0:
            txt = _mlog_decode_utf16(vdata[s:s + 520])
            if len(txt) >= 2 and txt != "$I30":
                return txt
    return ""


def _mlog_extract_timestamp(rec, rs, opcode, tpl, vc, vbase):
    if opcode == 0x01 and vc >= 2:
        v1p = vbase + 8
        if v1p + 8 <= rs:
            v1_off = le32(rec, v1p)
            v1_len = le32(rec, v1p + 4)
            if v1_off + v1_len <= rs and v1_len >= 0x48:
                for off in (0x30, 0x28, 0x38, 0x40):
                    val = le64(rec, v1_off + off)
                    if _FT_MIN < val < _FT_MAX:
                        return val
    if opcode == 0x04 and vc >= 1:
        if vbase + 8 <= rs:
            v0_off = le32(rec, vbase)
            v0_len = le32(rec, vbase + 4)
            if v0_off + v0_len <= rs and v0_len >= 8:
                for off in range(0, min(v0_len - 7, 0x20), 8):
                    val = le64(rec, v0_off + off)
                    if _FT_MIN < val < _FT_MAX:
                        return val
    if opcode == 0x03 and vc >= 2:
        v1p = vbase + 8
        if v1p + 8 <= rs:
            v1_off = le32(rec, v1p)
            v1_len = le32(rec, v1p + 4)
            if v1_off + v1_len <= rs and v1_len >= 0x20:
                for off in (0x90, 0xa0, 0x30, 0x28, 0x08, 0x00):
                    if off + 8 <= v1_len:
                        val = le64(rec, v1_off + off)
                        if _FT_MIN < val < _FT_MAX:
                            return val
    return 0


def _redo_short(name):
    """C4: compact mnemonic DERIVED from the (version-selected) long redo-op name, so op_short can never
    drift from op_name / the long table. Opcode->name is decompiler-verified for v3.4 (REDO_OPS_V34) and
    v3.14 (REDO_OPS_V314); v3.7-v3.10 have no decompiled driver and reuse the v3.14 table (best-effort —
    surfaced in the mlog caveat). This replaces the old hand-maintained, version-independent MLOG_OP_SHORT."""
    if not name:
        return ""
    if name.startswith("ERROR"):        # R1: the one ERROR:0x… entry — don't mangle it to "E_R"
        return "ERROR"
    n = name.split("::")[-1]            # R1: drop a Namespace:: qualifier (CmsStream::StripAllChecksums -> Strip…)
    if n.startswith("Redo"):
        n = n[4:]
    parts, cur = [], ""                # split CamelCase manually (forefst.py does not import `re`)
    for ch in n:
        if ch.isupper() and cur:
            parts.append(cur); cur = ch
        else:
            cur += ch
    if cur:
        parts.append(cur)
    if not parts:
        return n.upper()[:12]
    # R1: keep WHOLE words (no mid-word truncation), joined with _, within a ~16-char budget so the mnemonic
    # stays readable and compact (RedoInsertRow -> INSERT_ROW, UpdateDataWithRoot -> UPDATE_DATA).
    out = ""
    for w in parts:
        wu = w.upper()
        if out and len(out) + 1 + len(wu) > 16:
            break
        out = wu if not out else out + "_" + wu
    return out or parts[0].upper()[:12]


def parse_mlog_deep_record(rec_bytes, redo_ops):
    """Deep-parse a redo record with key path and value extraction."""
    rs = le32(rec_bytes, 0)
    opcode = le32(rec_bytes, 4)
    tpl = le32(rec_bytes, 8)
    val_count = le32(rec_bytes, 0x10)
    handle = le64(rec_bytes, 0x20)
    flags = le32(rec_bytes, 0x2C)
    r = {
        "size": rs, "opcode": opcode,
        "op_name": redo_ops.get(opcode, "UNK_0x%02x" % opcode),
        # C4: derive from the version-selected long table (not the stale version-independent MLOG_OP_SHORT).
        "op_short": _redo_short(redo_ops.get(opcode)) if opcode in redo_ops else "0x%02x" % opcode,
        "tpl": tpl, "val_count": val_count,
        "handle": handle, "flags": flags,
        "txn_start": bool(flags & 1), "txn_commit": bool(flags & 2),
        "target_oid": 0, "table_schema": 0, "attr_schema": 0,
        "attr_schema2": 0, "filename": "", "timestamp": 0,
    }
    if tpl >= 1:
        if len(rec_bytes) < 0x3C:
            return r
        kc0_off = le32(rec_bytes, 0x38)
        kc0_len = le32(rec_bytes, 0x3C)
        if kc0_off + 28 <= rs and kc0_len >= 28:
            r["table_schema"] = le32(rec_bytes, kc0_off)
            r["attr_schema"] = le32(rec_bytes, kc0_off + 4)
            r["target_oid"] = le64(rec_bytes, kc0_off + 20)
    if tpl >= 2:
        kc1_off = le32(rec_bytes, 0x40)
        kc1_len = le32(rec_bytes, 0x44)
        if kc1_off + 4 <= rs and kc1_len >= 4:
            r["attr_schema2"] = le32(rec_bytes, kc1_off)
    vbase = 0x38 + tpl * 8
    if opcode in (0x01, 0x02):
        if vbase + 8 <= rs:
            v0_off = le32(rec_bytes, vbase)
            v0_len = le32(rec_bytes, vbase + 4)
            if v0_off + v0_len <= rs and 4 < v0_len < 4096:
                vdata = rec_bytes[v0_off:v0_off + v0_len]
                if tpl == 1 and r["attr_schema"] == 0x0130 and v0_len > 6:
                    r["filename"] = _mlog_decode_utf16(vdata[4:])
                elif tpl == 0 and v0_len > 34:
                    r["filename"] = _mlog_scan_utf16(vdata, 16)
        # The NEW-name InsertRow of a rename is `tpl=0, val_count>=2`: v0 is short, and the name lives in a
        # LATER value as an embedded type-0x30 filename row (type16=0x30, key_flags@2 in {1,2}, name UTF-16 @+4).
        # Without this the new name is lost and classify_mlog_transaction can't see the rename (falls to UPDATE).
        if not r["filename"] and val_count >= 2:
            for i in range(val_count):
                do = vbase + i * 8
                if do + 8 > rs:
                    break
                voff = le32(rec_bytes, do); vlen = le32(rec_bytes, do + 4)
                if voff + vlen > rs or vlen < 8:
                    continue
                vd = rec_bytes[voff:voff + vlen]
                for k in range(0, len(vd) - 6, 2):
                    if le16(vd, k) == 0x0030 and le16(vd, k + 2) in (0x0001, 0x0002):
                        nm = _mlog_decode_utf16(vd[k + 4:k + 4 + 520])
                        if len(nm) >= 2 and nm != "$I30":
                            r["filename"] = nm
                            break
                if r["filename"]:
                    break
    r["timestamp"] = _mlog_extract_timestamp(rec_bytes, rs, opcode, tpl,
                                              val_count, vbase)
    return r


def extract_mlog_transactions(pages, redo_ops):
    """Extract per-page transactions with deep-parsed records."""
    txns = []
    for pinfo in pages:
        page = pinfo.get("page")
        if page is None or pinfo["type"] != PAGE_TYPE_MLOG:
            continue
        payload = extract_payload_from_mlog_page(page)
        if payload is None or len(payload) < 8:
            continue
        _eh = le32(page, 0x54); _dstart = _eh + le32(page, _eh + 0x28)  # payload start within the MLog block
        total_sz = le32(payload, 0)
        first_rec = le32(payload, 4)
        if total_sz < MIN_REDO_SIZE or first_rec < 8 or first_rec >= total_sz:
            continue
        recs = []
        remaining = total_sz - first_rec
        pos = first_rec
        while remaining >= MIN_REDO_SIZE and pos + MIN_REDO_SIZE <= len(payload):
            rec_size = le32(payload, pos)
            if rec_size < MIN_REDO_SIZE or rec_size > remaining or rec_size == 0:
                break
            rec_bytes = payload[pos:pos + rec_size]
            r = parse_mlog_deep_record(rec_bytes, redo_ops)
            r["plcn"] = pinfo["plcn"]
            r["rec_off"] = _dstart + pos  # B3: byte offset within the MLog block; disk = ps + plcn*cs + block*MLOG_BLOCK + rec_off
            r["block"] = pinfo.get("block", 0)
            recs.append(r)
            remaining -= rec_size
            pos += rec_size
        if recs:
            txns.append({"plcn": pinfo["plcn"], "block": pinfo.get("block", 0),
                         "records": recs})
    return txns


#  MLog concrete-action groups. FILE_OPS are user-visible file operations; LOW_LEVEL are B+-tree/metadata
#  redo records that accompany them (kept as facts, not folded away). See docs/structures/mlog.md.
MLOG_FILE_OPS = ("CREATE", "WRITE", "RENAME", "MOVE", "DELETE")
MLOG_LOW_LEVEL = ("MODIFY", "STREAM_UPD", "REPARENT", "ENTRY_REMOVE", "ALLOCATE", "CONTAINER",
                  "DEDUP", "EXTENT_MOD", "UPDATE", "INSERT", "OP")

def _mlog_handle_oid_map(recs):
    """handle -> table OID for a transaction. A record's key-context gives target_oid directly; records that
    only reference an open-table by HANDLE (e.g. the new-name InsertRow of a rename, target_oid==0) resolve
    through this map. Built from every record that DOES carry a target_oid (OpenTable and the old-name row)."""
    m = {}
    for r in recs:
        if r.get("target_oid"):
            m.setdefault(r["handle"], r["target_oid"])
    return m

def _mlog_name_entry_parents(recs, opcode, handle_oids=None):
    """The set of TARGET OIDs (parent-directory tables) of the name-entry rows of `opcode` in a
    transaction — non-zero only. For a rename/move this is the OLD parent (opcode 0x02 DeleteRow) vs the
    NEW parent (opcode 0x01 InsertRow); comparing the two tells RENAME (same parent) from MOVE (reparent).
    A name row with no inline target_oid (the new-name InsertRow, keyed only by table HANDLE) is resolved via
    `handle_oids` so a same-parent rename is recognised instead of falling through to UPDATE."""
    direct, resolved = set(), set()
    for r in recs:
        if r["opcode"] == opcode and r["filename"] and r["filename"] != "$I30":
            if r["target_oid"]:
                direct.add(r["target_oid"])
            else:
                h = (handle_oids or {}).get(r["handle"], 0)
                if h:
                    resolved.add(h)
    # Prefer a name row's OWN parent OID; only fall back to the handle-resolved table when NO name row of this
    # opcode carried a direct target (the pure-rename InsertRow). A MOVE's new-name row DOES carry its direct
    # destination OID, so it is never masked by the source table the shared handle resolves to.
    return direct if direct else resolved

def classify_mlog_transaction(recs):
    """Classify a redo transaction into a concrete action.

    Uses the redo opcode SET, and — for name-entry changes — the TARGET OID (parent-directory table) of the
    old vs new entry, so RENAME (same parent) and MOVE (reparented to another directory) are told apart by
    fact, not guessed from opcode presence. Rules that matter forensically:
      * DELETE is returned ONLY when the object's own table is destroyed (RedoDeleteTable, 0x0F). A bare
        DeleteRow (0x02) is the OLD-name removal of a rename/move, or a hard-link unlink — labelled
        ENTRY_REMOVE, never DELETE.
      * CREATE = a new table opened + its name row + parent id set. HARDLINK = a new name row for an
        EXISTING object (insert name, no new table, no delete)."""
    ops = [r["opcode"] for r in recs]
    op_set = set(ops)
    has_open = 0x00 in op_set
    has_insert = 0x01 in op_set
    has_delete = 0x02 in op_set
    has_set_parent = 0x0E in op_set
    has_del_table = 0x0F in op_set
    has_reparent = 0x05 in op_set
    has_alloc = 0x06 in op_set
    has_upd_data = 0x04 in op_set
    has_set_objrec = 0x10 in op_set
    handle_oids = _mlog_handle_oid_map(recs)
    named_ins = bool(_mlog_name_entry_parents(recs, 0x01, handle_oids))
    named_del = bool(_mlog_name_entry_parents(recs, 0x02, handle_oids))

    # Real deletion: the object's own B+-tree table is destroyed.
    if has_del_table:
        return "DELETE"
    # Name-entry change WITH a matching removal: RENAME (same parent OID) vs MOVE (parent OID changed).
    if named_del and named_ins:
        old_par = _mlog_name_entry_parents(recs, 0x02, handle_oids)
        new_par = _mlog_name_entry_parents(recs, 0x01, handle_oids)
        if old_par and new_par:
            if old_par == new_par:
                return "RENAME"
            if not (old_par & new_par):
                return "MOVE"
        return "MOVE" if has_reparent else "RENAME"   # OID inconclusive → reparent opcode decides
    # A NEW name row with no removal = a newly created directory entry (create / copy / hard-link — the
    # last is not reliably separable per-transaction, and is a name-creation regardless; the redo records
    # under -v, e.g. OpenTable vs a pointer to an existing OID, distinguish them for an analyst).
    if named_ins and not has_delete:
        return "CREATE"
    # A create whose name row is in another transaction: this fragment opens the table + sets its parent.
    if has_open and has_set_parent and not has_delete:
        return "CREATE"
    # A reparent record WITHOUT both name entries: it belongs to a move or a rename, but which one cannot be
    # decided from one transaction (the reparent's own target_oid is not reliably the new parent), so it is
    # labelled REPARENT rather than guessed — MOVE/RENAME above are only claimed on the parent-OID evidence.
    if has_reparent:
        return "REPARENT"
    if any(o in (0x1F, 0x20) for o in ops):
        return "STREAM_UPD"
    if any(o in (0x12, 0x13, 0x14, 0x15) for o in ops):
        return "CONTAINER"
    # Write: a data-record change on an EXISTING object (no new name entry — those became CREATE above).
    if has_insert and (has_set_objrec or has_upd_data):
        return "WRITE"
    if has_alloc and not has_insert:
        return "ALLOCATE"
    # Bare DeleteRow with no table destroyed = old-name removal of a rename/move (its InsertRow is in a
    # different transaction) or a hard-link unlink — NOT a file deletion.
    if has_delete and not has_insert:
        return "ENTRY_REMOVE"
    if has_delete and has_insert:
        return "UPDATE"
    if all(o in (0x03, 0x04, 0x08, 0x09, 0x10, 0x0D, 0x16, 0x20) for o in ops):
        return "MODIFY"
    if any(o in (0x28, 0x29) for o in ops):
        return "DEDUP"
    if any(o in (0x0A, 0x0B, 0x21) for o in ops):
        return "EXTENT_MOD"
    if any(o == 0x07 for o in ops):
        return "MODIFY"
    if has_insert and not has_delete and len(ops) <= 2:
        return "INSERT"
    return "OP"


def build_oid_path_map(f, ps_off, cs, tr, obj_map):
    """Build OID -> full path map by walking the directory tree from root."""
    paths = dict(KNOWN_SYSTEM_OIDS)
    paths[0x600] = "/"
    visited = set()

    def _walk(oid, parent_path, depth):
        if depth > 50 or oid in visited or oid not in obj_map:
            return
        visited.add(oid)
        try:
            rows = walk_bplus(f, ps_off, cs, tr,
                              _as_vlcn_list(obj_map[oid]))
        except Exception:
            return
        for kd, vd in rows:
            if len(kd) < 6 or le16(kd, 0) != 0x30:
                continue
            try:
                name = kd[4:].decode("utf-16-le").rstrip("\x00")
            except UnicodeDecodeError:
                continue
            if not name:
                continue
            # value+0x08 is the child's OID for a DIRECTORY entry, but the home-dir BACKREF for a FILE
            # entry (#327) — for root-created files that backref is 0x600, which would overwrite
            # paths[0x600]="/" (corrupting the path of every record whose parent is root). This OID->path
            # map is only meaningful for directory objects (USN/MLog resolve a record's PARENT, always a
            # directory), so index/recurse on directories only. Directory marker = attribute bit
            # 0x10000000 at value+0x40 (errata E32), NOT key_flags 0x04.
            if not (le32(vd, 0x40) & 0x10000000 if len(vd) >= 0x44 else False):
                continue
            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
            full = "%s/%s" % (parent_path.rstrip("/"), name)
            if child_oid:
                paths[child_oid] = full
                if child_oid in obj_map:
                    _walk(child_oid, full, depth + 1)

    _walk(0x600, "", 0)
    return paths


# ═══════════════════════════════════════════════════════════════════════
# USN (Change) Journal parsing
# ═══════════════════════════════════════════════════════════════════════

USN_REASON_FLAGS = {
    0x00000001: "DATA_OVERWRITE",
    0x00000002: "DATA_EXTEND",
    0x00000004: "DATA_TRUNCATION",
    0x00000010: "NAMED_DATA_OVERWRITE",
    0x00000020: "NAMED_DATA_EXTEND",
    0x00000040: "NAMED_DATA_TRUNCATION",
    0x00000100: "FILE_CREATE",
    0x00000200: "FILE_DELETE",
    0x00000400: "EA_CHANGE",
    0x00000800: "SECURITY_CHANGE",
    0x00001000: "RENAME_OLD_NAME",
    0x00002000: "RENAME_NEW_NAME",
    0x00004000: "INDEXABLE_CHANGE",
    0x00008000: "BASIC_INFO_CHANGE",
    0x00010000: "HARD_LINK_CHANGE",
    0x00020000: "COMPRESSION_CHANGE",
    0x00040000: "ENCRYPTION_CHANGE",
    0x00080000: "OBJECT_ID_CHANGE",
    0x00100000: "REPARSE_POINT_CHANGE",
    0x00200000: "STREAM_CHANGE",
    0x00400000: "TRANSACTED_CHANGE",
    0x00800000: "INTEGRITY_CHANGE",
    0x80000000: "CLOSE",
}

USN_SOURCE_FLAGS = {
    0x00000001: "DATA_MANAGEMENT",
    0x00000002: "AUXILIARY_DATA",
    0x00000004: "REPLICATION_MANAGEMENT",
    0x00000008: "CLIENT_REPLICATION_MANAGEMENT",
}

USN_MIN_RECORD = 0x50
USN_MAX_RECORD = 65536
OID_FS_METADATA = 0x520


def usn_reason_to_str(reason):
    parts = []
    for bit, name in sorted(USN_REASON_FLAGS.items()):
        if reason & bit:
            parts.append(name)
    return " | ".join(parts) if parts else "0x%08x" % reason


def usn_reason_to_short(reason):
    core = reason & ~0x80000000
    parts = []
    for bit, name in sorted(USN_REASON_FLAGS.items()):
        if bit == 0x80000000:
            continue
        if core & bit:
            parts.append(name)
    close = " + CLOSE" if reason & 0x80000000 else ""
    return ("|".join(parts) + close) if parts else "0x%08x" % reason


class UsnRecord:
    __slots__ = (
        "record_length", "major_version", "minor_version",
        "file_oid", "file_idx", "parent_oid", "parent_idx",
        "usn", "timestamp", "reason", "source_info",
        "security_id", "file_attrs", "filename", "offset",
    )

    def __init__(self, data, off):
        self.offset = off
        self.record_length = le32(data, off)
        self.major_version = le16(data, off + 0x04)
        self.minor_version = le16(data, off + 0x06)
        fid_lo = le64(data, off + 0x08)
        fid_hi = le64(data, off + 0x10)
        self.file_idx = fid_lo
        self.file_oid = fid_hi
        pid_lo = le64(data, off + 0x18)
        pid_hi = le64(data, off + 0x20)
        self.parent_idx = pid_lo
        self.parent_oid = pid_hi
        self.usn = le64(data, off + 0x28)
        self.timestamp = le64(data, off + 0x30)
        self.reason = le32(data, off + 0x38)
        self.source_info = le32(data, off + 0x3C)
        self.security_id = le32(data, off + 0x40)
        self.file_attrs = le32(data, off + 0x44)
        name_len = le16(data, off + 0x48)
        name_off = le16(data, off + 0x4A)
        try:
            self.filename = data[off + name_off:off + name_off + name_len].decode("utf-16-le")
        except (UnicodeDecodeError, IndexError):
            self.filename = "<decode error at 0x%x>" % off


_usn_nonv3_warned = False

def _warn_usn_nonv3(versions):
    """One-time light warning when a non-V3 USN record is accepted (N1). ReFS on-disk records are V3;
    the decoder only knows the V3 field layout, so V2/V4 records are parsed with V3 offsets and NOT
    validated. We do not refuse them (per user request) — we flag them once."""
    global _usn_nonv3_warned
    if _usn_nonv3_warned:
        return
    _usn_nonv3_warned = True
    vs = "/".join("V%d" % v for v in sorted(versions))
    print("[%s] NOTE: USN record version(s) %s encountered. ReFS journals are normally V3; the decoder uses "
          "the V3 field layout, so %s records are parsed with V3 offsets and their fields are NOT validated "
          "for that version (V2 is NTFS's 64-bit form, V4 is NTFS-only range tracking — see erratum E58)."
          % (PROG, vs, vs), file=sys.stderr)


def parse_usn_records(j_data, alloc=None):
    """Parse the `$J` ring buffer into records.

    `alloc` (the journal's allocated size) enables a structural check: a record's USN **is** its
    byte offset in the journal, so `usn % alloc == offset` holds for every genuine record.
    Measured: 217,892 of 217,892 on `winsider`, 9,371 of 9,378 on `win11refstestmftecmd`,
    33,379 of 33,381 on `win11refs8gtestmove_aftermove` -- the handful of failures are zero-filled
    slack that happens to parse as a record (`usn == 0` at a non-zero offset), plus one genuine
    outlier. Violations are REPORTED, never dropped: a torn or overwritten record is evidence, and
    discarding it silently is what this whole pass exists to stop.

    Bytes stepped over as unparseable are counted too. The loop advances 8 bytes at a time through
    anything it cannot read, which on a wrapped journal is exactly where the torn record at the
    write head lives -- previously skipped without a word.
    """
    records = []
    off = 0
    end = len(j_data)
    nonv3 = set()
    slack_bytes = 0        # zero-filled: the ring has not reached here yet -- normal
    torn_bytes = 0         # NON-zero bytes that parse as no record -- a real anomaly
    usn_violations = 0
    while off < end - USN_MIN_RECORD:
        rec_len = le32(j_data, off)
        if rec_len == 0:
            # A zero record length is unwritten ring space, not damage: a journal that has never
            # wrapped is mostly zeros (132 MB of 134 MB on one corpus volume). Counted separately
            # so the caveat fires for torn data and stays silent for an empty journal.
            off += 8; slack_bytes += 8; continue
        if rec_len < USN_MIN_RECORD or rec_len > USN_MAX_RECORD or (rec_len & 7) != 0:
            off += 8; torn_bytes += 8; continue
        if off + rec_len > end:
            break
        major = le16(j_data, off + 0x04)
        # Accept USN record versions 2, 3 and 4. On a ReFS journal every on-disk record is V3 (128-bit
        # file IDs); V2 (NTFS's 64-bit form) and V4 (USN_RECORD_V4, the NTFS-only range-tracking / extent
        # record — `fsutil usn enablerangetracking` refuses ReFS with "A local NTFS volume is required for
        # this operation", erratum E58) do not occur on ReFS. We still PARSE a V2/V4 record if one appears
        # (a non-ReFS journal, or crafted/corrupt input) rather than refuse it, but we only have the V3
        # field layout — so those records are decoded with V3 offsets and flagged once via _warn_usn_nonv3.
        if major < 2 or major > 4:
            off += 8; torn_bytes += 8; continue
        name_off_field = le16(j_data, off + 0x4A)
        name_len_field = le16(j_data, off + 0x48)
        if name_off_field < 0x4C or name_off_field + name_len_field > rec_len:
            off += 8; torn_bytes += 8; continue
        _r = UsnRecord(j_data, off)
        if alloc and _r.usn % alloc != off:
            usn_violations += 1
        records.append(_r)
        if major != 3:
            nonv3.add(major)
        off += (rec_len + 7) & ~7
    if nonv3:
        _warn_usn_nonv3(nonv3)
    if usn_violations:
        _skip_note("USN journal", "%d record(s) whose USN is not their journal offset"
                   % usn_violations, ValueError("usn %% alloc != offset"))
    if torn_bytes:
        # Non-zero and not a record. On the corpus these regions hold PRIOR CLUSTER CONTENTS --
        # `GFSAREPLAY` marker text and BitLocker signatures -- i.e. ring space the journal was
        # allocated over but has not yet written. That is recoverable prior data, not damage; the
        # other cause is a genuinely torn record at the write head. Reported either way so the
        # analyst knows the journal is not fully accounted for.
        _skip_note("USN journal", "%d non-zero byte(s) that parse as no record (unwritten ring space "
                   "still holding prior cluster contents, or a torn record at the write head)"
                   % torn_bytes, ValueError("unparseable journal bytes"))
    return records


def locate_change_journal(f, ps, cs, tr, obj_map):
    """Find Change Journal entry in OID 0x520 (FS Metadata directory)."""
    if OID_FS_METADATA not in obj_map:
        return None, None
    vlcns = obj_map[OID_FS_METADATA]
    try:
        rows = walk_bplus(f, ps, cs, tr, vlcns)
    except Exception:
        return None, None
    for kd, vd in rows:
        if len(kd) < 4 or le16(kd, 0) != 0x30:
            continue
        try:
            name = kd[4:].decode("utf-16-le").rstrip("\x00")
        except UnicodeDecodeError:
            continue
        if name == "Change Journal":
            meta = {}
            if len(vd) >= 0x48:
                meta["stream_count"] = le64(vd, 0x20)
                meta["create_time"] = le64(vd, 0x28)
                meta["modify_time"] = le64(vd, 0x30)
                meta["change_time"] = le64(vd, 0x38)
                meta["access_time"] = le64(vd, 0x40)
            if len(vd) >= 0x60:
                meta["file_attrs"] = le32(vd, 0x48)
                meta["security_id"] = le64(vd, 0x50)
            meta["value_len"] = len(vd)
            return bytes(vd), meta
    return None, None


def _usn_find_subrecord_markers(vd):
    subs = []
    off = 0xA8
    while off < len(vd) - 8:
        marker = le32(vd, off)
        if marker in (0x80000002, 0x80000001):
            stream_size = le32(vd, off + 4) if off + 8 <= len(vd) else 0
            subs.append((off, marker, stream_size))
        off += 4
    return subs


def _usn_scan_extent_tables(vd, tr):
    results = []
    for scan_off in range(0xA8, len(vd) - 24, 4):
        start = le32(vd, scan_off)
        end = le32(vd, scan_off + 4)
        if not (0x10 <= start <= 0x200 and end > start):
            continue
        cap = le32(vd, scan_off + 12)
        count = le32(vd, scan_off + 20)
        if not (count > 0 and count <= 1000 and cap >= 0x100):
            continue
        entry_area = end - start
        if entry_area < count * 24 or entry_area > count * 32 + 16:
            continue
        entries_off = scan_off + start
        extents = []
        for i in range(count):
            eoff = entries_off + i * 24
            if eoff + 24 > len(vd):
                break
            vlcn_lo = le32(vd, eoff)
            vlcn_hi = le32(vd, eoff + 4)
            full_vlcn = vlcn_lo | (vlcn_hi << 32)
            ext_flags = le32(vd, eoff + 8)
            file_vcn = le32(vd, eoff + 12)
            run_len = le32(vd, eoff + 20)
            if run_len > 0 and full_vlcn > 0:
                plcn = tr.tr(full_vlcn) if tr else full_vlcn
                extents.append({
                    "vlcn": full_vlcn, "plcn": plcn,
                    "file_vcn": file_vcn, "clusters": run_len,
                    "flags": ext_flags,
                })
        if extents:
            extents.sort(key=lambda e: e["file_vcn"])
            results.append((scan_off, extents))
    return results


def _usn_parse_single_subrecord(vd, sub_off):
    data_start = sub_off + 8
    next_marker = len(vd)
    for off in range(data_start, len(vd) - 4, 4):
        m = le32(vd, off)
        if m in (0x80000002, 0x80000001):
            next_marker = off
            break
    data_len = next_marker - data_start
    if data_len <= 0:
        return None
    return bytes(vd[data_start:data_start + data_len])


def parse_usn_journal_streams(vd, cs, tr):
    """Parse sub-records and extent tables from the Change Journal value."""
    markers = _usn_find_subrecord_markers(vd)
    extent_tables = _usn_scan_extent_tables(vd, tr)
    multi_markers = [(off, sz) for off, m, sz in markers if m == 0x80000002]
    single_markers = [off for off, m, sz in markers if m == 0x80000001]
    j_extents = []
    j_stream_size = 0
    max_extents = []
    max_stream_size = 0
    if extent_tables:
        best = max(extent_tables, key=lambda t: sum(e["clusters"] for e in t[1]))
        j_extents = best[1]
    if len(multi_markers) >= 1:
        j_stream_size = multi_markers[0][1]
    if len(multi_markers) >= 2:
        max_stream_size = multi_markers[1][1]
        if len(extent_tables) >= 2:
            others = [t for t in extent_tables if t[1] is not j_extents]
            if others:
                max_extents = others[0][1]
    metadata_raw = None
    if single_markers:
        metadata_raw = _usn_parse_single_subrecord(vd, single_markers[0])
    return {
        "j_extents": j_extents, "j_stream_size": j_stream_size,
        "max_extents": max_extents, "max_stream_size": max_stream_size,
        "metadata_raw": metadata_raw, "subrecord_count": len(markers),
    }


def read_usn_j_stream(f_handle, ps, cs, extents, stream_size=0, _content_what=None):
    """Read the USN $J data stream from disk following its extent descriptors.

    The read length is the **allocated size** (Σ of the extents' clusters). The `$J` journal fills its
    allocation — a bounded rolling log whose old records are overwritten in place — so the whole allocation
    must be read. `stream_size` is NOT a real length: it comes from the value's $DATA sub-record **descriptor
    `0x000E0080`** (= 917632), and capping the read at it truncated every journal larger than ~896 KB to its
    first ~896 KB (fixed 2026-08-21 — it dropped ~97 % of a busy volume's records). The parameter is kept for
    call-site compatibility but ignored. `parse_usn_records` validates each record, so the zero/slack tail of a
    partially-filled journal is skipped and reading the full allocation is complete (corpus-verified: 0 duplicate
    USNs, ~100 % of records carry a name)."""
    if not extents:
        return b""
    alloc_size = sum(e["clusters"] for e in extents) * cs
    buf = bytearray(alloc_size)
    _runs = []
    for ext in extents:
        file_off = ext["file_vcn"] * cs
        if file_off >= alloc_size:
            continue
        nbytes = min(ext["clusters"] * cs, alloc_size - file_off)
        _runs.append((ext["plcn"], ext["clusters"], file_off))
        f_handle.seek(ps + ext["plcn"] * cs)
        data = f_handle.read(nbytes)
        buf[file_off:file_off + len(data)] = data
    # `export metadata` writes these bytes to disk as usn_J.bin, a forensic artifact. A punched cluster
    # there is a zero-filled stretch of journal presented as the volume's own record, so it goes through
    # the same check as every other producer. Clipped to the ALLOCATION, which for $J is the real length
    # (the journal fills its allocation; see the docstring) -- not to `stream_size`, which is a descriptor
    # constant and not a length at all.
    if _content_what:
        content_holes(f_handle, ps, cs, _runs, _content_what, stream_size=alloc_size)
    return bytes(buf)


def parse_usn_journal_metadata(streams, f_handle, ps, cs):
    """Parse $Max stream and single-instance metadata."""
    meta = {}
    if streams["metadata_raw"] and len(streams["metadata_raw"]) >= 16:
        raw = streams["metadata_raw"]
        if len(raw) >= 8:
            meta["meta_field_0x00"] = le64(raw, 0)
        if len(raw) >= 16:
            meta["meta_field_0x08"] = le64(raw, 8)
        if len(raw) >= 24:
            meta["meta_field_0x10"] = le64(raw, 16)
        if len(raw) >= 32:
            meta["meta_field_0x18"] = le64(raw, 24)
        meta["metadata_size"] = len(raw)
    if streams["max_extents"]:
        max_data = read_usn_j_stream(f_handle, ps, cs, streams["max_extents"],
                                      streams["max_stream_size"])
        if len(max_data) >= 32:
            meta["max_size"] = le64(max_data, 0)
            meta["allocation_delta"] = le64(max_data, 8)
            meta["journal_id"] = le64(max_data, 16)
            if len(max_data) >= 40:
                meta["lowest_valid_usn"] = le64(max_data, 24)
        meta["max_raw"] = max_data[:64].hex() if max_data else ""
    return meta


# ─── Reparse target extraction ────────────────────────────────────────
def _reparse_buffer_target(vd):
    """Decode a REPARSE_DATA_BUFFER and return its target string ("" if it carries none).

    `vd` starts at the buffer itself: tag u32@0x00, ReparseDataLength u16@0x04, Reserved u16@0x06, then for
    SYMLINK / MOUNT_POINT the SubstituteName and PrintName offset+length pairs, and the path buffer at 0x14
    (SYMLINK, which has a 4-byte Flags field) or 0x10 (MOUNT_POINT). The PrintName is preferred because it is
    the display form; a junction usually carries only the SubstituteName, so that is the fallback."""
    if len(vd) < 8:
        return ""
    tag = le32(vd, 0)
    data_len = le16(vd, 4)
    if tag == 0xA000000C and len(vd) >= 0x14:  # SYMLINK
        sub_off = le16(vd, 0x08)
        sub_len = le16(vd, 0x0A)
        print_off = le16(vd, 0x0C)
        print_len = le16(vd, 0x0E)
        buf_start = 0x14
        if print_len > 0 and buf_start + print_off + print_len <= len(vd):
            try:
                return vd[buf_start+print_off:buf_start+print_off+print_len].decode("utf-16-le")
            except UnicodeDecodeError:
                pass
        if sub_len > 0 and buf_start + sub_off + sub_len <= len(vd):
            try:
                return vd[buf_start+sub_off:buf_start+sub_off+sub_len].decode("utf-16-le")
            except UnicodeDecodeError:
                pass
    elif tag == 0xA0000003 and len(vd) >= 0x10:  # MOUNT_POINT/JUNCTION
        sub_off = le16(vd, 0x08)
        sub_len = le16(vd, 0x0A)
        print_off = le16(vd, 0x0C)
        print_len = le16(vd, 0x0E)
        buf_start = 0x10
        if print_len > 0 and buf_start + print_off + print_len <= len(vd):
            try:
                return vd[buf_start+print_off:buf_start+print_off+print_len].decode("utf-16-le")
            except UnicodeDecodeError:
                pass
        if sub_len > 0 and buf_start + sub_off + sub_len <= len(vd):
            try:
                return vd[buf_start+sub_off:buf_start+sub_off+sub_len].decode("utf-16-le")
            except UnicodeDecodeError:
                pass
    elif tag == 0xA000001D and len(vd) > 8:  # LX_SYMLINK
        # E5 fix: skip the 4-byte version (8 -> 12) so it does not prefix the target.
        try:
            return vd[12:8+data_len].decode("utf-8").rstrip("\x00")
        except UnicodeDecodeError:
            pass
    return REPARSE_TAGS.get(tag, f"0x{tag:08X}")


def _embedded_reparse_target(vd, ctx=None):
    """Target of a 0xC0 reparse attribute held INSIDE an object record's embedded attribute tree.

    An object whose record is resident keeps its attributes in a small B+-tree embedded in a single row
    (keyed 0x10). For a DIRECTORY reparse point — a junction or a directory symlink — that is the ONLY place
    the reparse buffer exists: the object's table has no top-level 0xC0 row, and the name row in the parent is
    an 84-byte index entry with no room for it. Scanning only top-level rows therefore returned "" and the
    target was reported as absent though it is on disk (P4-2: 98 of 341 reparse-bearing objects corpus-wide,
    78 of 81 on a real Windows volume).

    The embedded 0xC0 value carries a 12-byte header whose u32 at +0x08 is the offset of the standard
    REPARSE_DATA_BUFFER within the value.

    `ctx` = (f, ps, cs, tr) and must be passed: without it an embedded INDEX node yields no rows, which is
    exactly the E73 blind spot — an object with a large attribute set keeps its attributes in a CHILD page,
    and a target there would be missed the same way."""
    if len(vd) < 0x20:
        return ""
    try:
        rows = parse_resident_btree_rows(bytes(vd), ctx)
    except Exception as _e:
        # "" is how a file with NO reparse target renders. A decode failure must not be reported as
        # the absence of a target -- that is the fact E81 exists to establish.
        _skip_note("reparse target (embedded)", "attribute rows", _e)
        return ""
    for k, v in rows:
        if len(k) < 0x0E or le16(k, 0x0C) != 0xC0 or len(v) < 0x18:
            continue
        off = le32(v, 0x08)
        if off < 0x0C or off + 8 > len(v):
            continue
        t = _reparse_buffer_target(bytes(v)[off:])
        if t:
            return t
    return ""


def get_reparse_target(f, ps, cs, tr, vlcns):
    """Extract a reparse point's target from an object's B+ tree (type 0xC0).

    The attribute sits at the TOP LEVEL on most objects, but on a directory reparse point it lives inside the
    object record's embedded attribute tree instead, so both levels are searched (P4-2)."""
    try:
        rows = walk_bplus(f, ps, cs, tr, vlcns)
    except Exception as _e:
        _skip_note("reparse target", "object tree", _e)
        return ""
    for kd, vd in rows:
        if len(kd) >= 2 and le16(kd, 0) == 0xC0 and len(vd) >= 8:
            t = _reparse_buffer_target(bytes(vd))
            if t:
                return t
    for kd, vd in rows:                      # not at the top level -> look inside the object record
        if len(kd) >= 4 and le16(kd, 0) == 0x10:
            t = _embedded_reparse_target(vd, (f, ps, cs, tr))
            if t:
                return t
    return ""

# ─── Directory tree walk ─────────────────────────────────────────────
def walk_directory_tree(f, ps, cs, tr, obj_map, start_oid, max_depth, enrich, trash_set):
    """Walk the directory tree and collect file metadata."""
    results = []
    visited = set()
    t40_content = {}     # (owner_dir_oid, file_id) -> has_real_content (alloc>0 or size>0); alloc=0 stubs map to False
    t40_links = {}       # F-1 hardening: (owner_dir_oid, file_id) -> set of (parent_oid, name.lower()) from the
                         # backing's embedded type-0x39 hard-link back-pointers = the object's AUTHORITATIVE name
                         # list; used only as a fallback when a name's cached size (value+0x38) is stale and
                         # defeats the size-match grouping below.
    nonres_files = []    # non-resident file entries, grouped into hard-link sets in post-processing

    # Reparse existence-index (OID 0x540): {(owner_oid, file_id): tag}. Key = marker(0x80000001)@0,
    # tag@4, file_id@8, owner@0x10 (H3-verified). Used as the ReparseTag source for directory
    # junctions and as the fallback when a non-resident file's backing +0x7C tag is 0.
    reparse_idx = {}
    if enrich and 0x540 in obj_map:
        try:
            for _kd, _vd in walk_bplus(f, ps, cs, tr, obj_map[0x540]):
                if len(_kd) >= 0x18 and le32(_kd, 0) == 0x80000001:
                    reparse_idx[(le64(_kd, 0x10), le64(_kd, 0x08))] = le32(_kd, 0x04)
        except Exception:
            pass

    def _walk_dir(oid, parent_path, parent_oid, depth):
        if depth > max_depth or oid in visited:
            return
        visited.add(oid)
        if oid not in obj_map:
            return

        vlcns = obj_map[oid]
        try:
            rows = walk_bplus(f, ps, cs, tr, vlcns)
        except Exception:
            return

        for kd, vd in rows:
            if len(kd) < 4: continue
            attr_type = le16(kd, 0)
            if attr_type == 0x40:
                # Record this file's backing type-0x40 stream as (alloc, size) under (this dir, file_id).
                # The hard-link grouping below resolves each name to the candidate stream (local or home)
                # whose SIZE matches the name's own size (val+0x38): the per-directory ordinal (file_id
                # @key+0x08) collides across files home'd in the same dir, so size is the disambiguator.
                # alloc @val+0x60, size @val+0x58. (#340 / over-merge fix 2026-06-20.)
                if len(kd) >= 0x10:
                    # One definition of what a backing record says, shared with the on-demand
                    # home-tree lookup below (E89) so the walked and unwalked paths cannot drift.
                    t40_content[(oid, le64(kd, 0x08))] = _t40_record_tuple(vd, (f, ps, cs, tr))
                    # F-1 hardening: decode the backing's embedded type-0x39 hard-link back-pointers — one
                    # per name, each `(parent-dir OID @sub-value+0x08, name UTF-16LE @sub-value+0x18)`. This
                    # is the object's own authoritative list of its names (what the driver counts links from);
                    # it lets the grouping below reattach a hard-link name whose cached size is stale. Only
                    # parse when the value is large enough to hold sub-records (skips the common single-stream
                    # backing). Layout verified on winsider (0x9d84,2): parents 0x9da4/0x9d84.
                    if len(vd) > 0x88:
                        _lset = None
                        try:
                            _subrows = parse_resident_btree_rows(vd, (f, ps, cs, tr))
                        except Exception:
                            _subrows = ()
                        for _sk, _sv in _subrows:
                            if len(_sk) > 12 and _sk[12] == 0x39 and len(_sv) >= 0x1A:
                                try:
                                    _lp = le64(_sv, 0x08)
                                    _ln = _sv[0x18:].decode("utf-16-le", "ignore").rstrip("\x00")
                                except Exception:
                                    continue
                                if _ln:
                                    if _lset is None:
                                        _lset = set()
                                    _lset.add((_lp, _ln.lower()))
                        if _lset:
                            t40_links[(oid, le64(kd, 0x08))] = _lset
                continue
            if attr_type != 0x30: continue

            try:
                name = kd[4:].decode("utf-16-le").rstrip("\x00")
            except UnicodeDecodeError:
                name = kd[4:].hex()

            full_path = f"{parent_path}/{name}" if parent_path else name
            entry = {"path": full_path, "parent_path": parent_path if parent_path else ".", "parent_oid": oid, "name": name}

            if len(vd) <= NON_RESIDENT_MAX_VALUE:
                # Non-resident entry (directory or large file)
                file_id = le64(vd, 0x00) if len(vd) >= 8 else 0      # FileId / per-directory child ordinal
                backref = le64(vd, 0x08) if len(vd) >= 0x10 else 0   # val+0x08 (see oid gating below)
                entry["file_id"] = file_id
                entry["create_time"] = le64(vd, 0x10) if len(vd) >= 0x18 else 0
                entry["modify_time"] = le64(vd, 0x18) if len(vd) >= 0x20 else 0
                entry["change_time"] = le64(vd, 0x20) if len(vd) >= 0x28 else 0
                entry["access_time"] = le64(vd, 0x28) if len(vd) >= 0x30 else 0
                entry["file_attrs"] = le32(vd, 0x40) if len(vd) >= 0x44 else 0
                entry["file_size"] = le64(vd, 0x38) if len(vd) >= 0x40 else 0
                entry["is_dir"] = bool(entry["file_attrs"] & 0x10000000)
                entry["is_resident"] = False
                # RECORD PLACEMENT (E87), set once from the row's own form and never refined.
                # `is_resident` below is refined by F5 into a residency statement; this is not.
                entry["record_embedded"] = False
                entry["security_id"] = 0
                entry["usn"] = 0
                entry["internal_flags"] = 0
                entry["allocated_size"] = None   # filled from the resolved type-0x40 backing (files) in
                                                 # post-processing; stays None (=> blank) when unresolved,
                                                 # consistent with USN/SecurityId on the same entries.

                # val+0x08 is the object's OWN OID only for a SUBDIRECTORY (dir-bit set). For a
                # non-resident FILE it is the home-dir backref (the OID of the directory the file was
                # first created in) -- a DIFFERENT object's OID, shared by the file's hard-link names.
                # A non-resident file has NO Object-Table OID of its own, so reporting the backref as
                # the file's oid made files collide with real directories (--oid bug, fixed 2026-06-27;
                # master 0x08 home-dir backref / #327 / #335 / #340 / FN_LINK_002).
                if entry["is_dir"]:
                    entry["oid"] = backref          # subdirectory's own OID
                    entry["home_oid"] = 0
                else:
                    entry["oid"] = 0                 # files have no own OID (matches resident files)
                    entry["home_oid"] = backref      # home-dir backref, used only for hard-link grouping

                # Hard-link detection (finding #340): a file's multiple names all resolve to the SAME backing
                # type-0x40 record. Collect the non-resident file entries now; the actual grouping (which uses
                # home_oid + file_id) happens in post-processing once every dir's type-0x40 records have been
                # seen, so each name can be resolved to its true physical object. Files only; directories
                # cannot be hard-linked.
                if backref and file_id and not entry["is_dir"]:
                    nonres_files.append(entry)

                # Enrichment: a non-resident DIRECTORY has its own $SI in its own B+ tree (backref is its own
                # OID). A non-resident FILE does NOT -- backref points at the HOME DIRECTORY, not the file, so
                # reading get_object_si(backref) would attribute the home dir's security_id/internal_flags to
                # the file. The file's usn comes from its own type-0x40 backing record in post-processing; its
                # security_id is not on-disk recoverable from its records (left 0). RD-proven 2026-06-27.
                if enrich and entry["is_dir"] and backref and backref in obj_map:
                    si = get_object_si(f, ps, cs, tr, obj_map[backref])
                    if si:
                        entry["security_id"] = si.get("security_id", 0)
                        entry["usn"] = si.get("usn", 0)
                        entry["internal_flags"] = si.get("internal_flags", 0)
            else:
                # Resident entry (small file)
                entry["oid"] = 0  # No separate OID for resident files
                entry["is_resident"] = True
                entry["record_embedded"] = True      # RECORD PLACEMENT (E87), never refined
                entry["is_dir"] = False
                # A resident file has a FileRef too: home == parent (a resident file can never have been
                # relocated — a cross-directory move forces non-residency, E70 / FS_MOVE_RA_001), and its
                # ordinal is at value+0x80 ($SI+0x58 NextFileId). This fills HomeOID/FileID/FileRef for
                # resident files, which were previously left blank.
                entry["home_oid"] = oid
                entry["file_id"] = le64(vd, 0x80) if len(vd) >= 0x88 else 0
                if len(vd) >= 0x60:
                    entry["create_time"] = le64(vd, 0x28)
                    entry["modify_time"] = le64(vd, 0x30)
                    entry["change_time"] = le64(vd, 0x38)
                    entry["access_time"] = le64(vd, 0x40)
                    entry["file_attrs"] = le32(vd, 0x48)
                    entry["internal_flags"] = le32(vd, 0x4C)
                    entry["security_id"] = le64(vd, 0x50)
                    # RE-VERIFIED 2026-06-17 at corpus scale (errata E30 retracted / E45):
                    # the type-0x30 resident value is an INDEX ENTRY (not a verbatim $SI). At value+0x58
                    # it carries FileSize (== embedded-$DATA size on 409,514/409,514 v3.14 files; nonzero
                    # even on USN-inactive images), and value+0x60 = AllocatedSize. There is NO embedded
                    # $SI sub-record (a prior comment claimed so -- wrong). The file's USN-journal pointer
                    # is LastUsn at value+0x68 ($SI+0x40) and UsnJournalId at value+0x70 ($SI+0x48):
                    # LastUsn = virtual byte offset of the file's most recent $UsnJrnl:$J record (OID 0x520),
                    # disk-proven (14/14 then 480/480 LastUsn->$J-record name matches). 0 if journal inactive.
                    entry["usn"] = le64(vd, 0x68) if len(vd) >= 0x70 else 0
                    entry["usn_journal_id"] = le64(vd, 0x70) if len(vd) >= 0x78 else 0
                    entry["allocated_size"] = le64(vd, 0x60)
                else:
                    entry["create_time"] = 0
                    entry["modify_time"] = 0
                    entry["change_time"] = 0
                    entry["access_time"] = 0
                    entry["file_attrs"] = 0
                    entry["internal_flags"] = 0
                    entry["security_id"] = 0
                    entry["usn"] = 0
                    entry["allocated_size"] = 0
                entry["file_size"] = get_resident_file_size(vd, (f, ps, cs, tr))

            # Derived flags
            fa = entry.get("file_attrs", 0)
            entry["is_encrypted"] = bool(fa & 0x4000)
            entry["is_compressed"] = bool(fa & 0x0800)
            entry["has_integrity"] = bool(fa & 0x8000)
            entry["has_ea"] = bool(fa & 0x00040000)
            entry["has_reparse"] = bool(fa & 0x0400)
            entry["is_deleted"] = entry["oid"] in trash_set if entry["oid"] else False
            entry["deletion_source"] = "trash" if entry["is_deleted"] else ""
            entry["snapshot_count"] = 0

            # ADS, reparse, and snapshot enrichment
            entry["has_ads"] = False
            entry["ads_names"] = ""
            entry["reparse_target"] = ""
            if enrich:
                if entry["has_reparse"]:
                    if entry["is_resident"]:
                        entry["reparse_target"] = extract_inline_reparse(vd)
                        # resident reparse tag = the $SI mirror at type-0x30 value+0x7C (H3-verified
                        # 2905/2905 across v3.4..v3.14); validate bit31 (Microsoft reparse tag).
                        if len(vd) >= 0x80:
                            _rt = le32(vd, 0x7C)
                            if (_rt >> 31) & 1:
                                entry["reparse_tag_value"] = _rt
                    elif entry["oid"] and entry["oid"] in obj_map:
                        # non-resident DIRECTORY junction: target via its own 0xC0 attribute; tag via
                        # the reparse index (keyed by parent dir OID + file_id).
                        entry["reparse_target"] = get_reparse_target(f, ps, cs, tr, obj_map[entry["oid"]])
                        _rt = (reparse_idx.get((oid, entry.get("file_id", 0)), 0)
                               or reparse_idx.get((entry["oid"], entry.get("file_id", 0)), 0))
                        if (_rt >> 31) & 1:
                            entry["reparse_tag_value"] = _rt
                    # non-resident FILE reparse: tag + target are set from the resolved backing record
                    # in post-processing (the home stream), which avoids the file_id-collision bug.

                # ADS are embedded 0xB0 sub-records inside the resident (value > 84 B) type-0x30 entry, so a
                # file that HAS an ADS is always is_resident here -- this resident path is complete. Verified
                # corpus-wide 2026-06-28: forefst has_ads == an independent embedded-ADS recount (678 == 678,
                # 0 divergent images) and 0 standalone 0x80/0xB0 stream rows exist on disk. A non-resident
                # file's value is the <=84 B index pointer (no embedded chain) and it has no own OID, so it
                # carries no ADS; the former oid-gated non-resident branch was therefore dead (removed).
                if entry["is_resident"] and not entry["is_dir"]:
                    has_ads, ads_list = detect_ads_in_resident(vd, (f, ps, cs, tr))
                    if has_ads:
                        entry["has_ads"] = True
                        entry["ads_names"] = ";".join(ads_list)
                        entry["ads_storage"] = _ads_storage_map(vd, (f, ps, cs, tr))

            # Snapshot count -- snapshots are likewise embedded 0xB0 sub-records in the resident (value > 84 B)
            # entry, so this resident path is complete (same corpus proof as ADS above). A non-resident file
            # carries no embedded snapshot record; the former oid-gated non-resident branch was dead (removed).
            if entry["is_resident"] and len(vd) > 0x60:
                _snaps = _snapshot_meta(vd, (f, ps, cs, tr))
                entry["snapshot_count"] = len(_snaps)
                if _snaps:   # SnapshotNames: the ;-joined snapshotted stream names (blank name → its sub-id)
                    entry["snapshot_names"] = ";".join(n or f"0x{sid:x}" for n, sid, _ts in _snaps)

            # F5: a "long value" file we parsed + enriched via the inline path above is actually NON-RESIDENT
            # when its CURRENT $DATA stream is extent-backed (on disk, not inline). ADS/reparse/snapshot were
            # already read from the inline value (correct); only the reported residency must reflect the
            # on-disk truth. Fixes ~209 large files/win11refs8g mislabeled resident (blanked HardLinkCount).
            if entry["is_resident"] and not entry["is_dir"]:
                if _current_stream_extent_backed(vd, (f, ps, cs, tr)):
                    entry["is_resident"] = False
                else:
                    # B2: multi-level embedded-tree resident value (v3.4/v3.9/upgraded framing). Its $DATA
                    # lives in a NESTED subtree, so file_size read 0 and residency was mislabeled resident.
                    # The true size (value+0x58) + alloc (value+0x60) are directly readable; when alloc>0
                    # with no inline $DATA the file is extent-backed (NON-resident).
                    _ml_size = _multilevel_extent_backed_size(vd, cs, (f, ps, cs, tr))
                    if _ml_size is not None:
                        entry["file_size"] = _ml_size
                        entry["is_resident"] = False

            # DATA RESIDENCY (E87) for an embedded record, straight from the $DATA descriptor.
            # A split record's form is filled in post-processing from its resolved backing.
            if entry.get("record_embedded") and not entry.get("is_dir"):
                entry["data_form"] = _stream_data_form(vd, (f, ps, cs, tr))

            results.append(entry)

            # Recurse into directories
            if entry["is_dir"] and entry["oid"] and entry["oid"] in obj_map:
                _walk_dir(entry["oid"], full_path, oid, depth + 1)

    try:
        _walk_dir(start_oid, "", start_oid, 0)
    except RecursionError:   # audit 5.3: a crafted/corrupt tree deeper than the (C-stack-safe) limit is now a
        die("directory tree deeper than the walker supports — the volume may be corrupt or crafted; "   # clean
            "bound the walk with --depth")                                                              # error

    # Post-process: group a file's names by their TRUE physical stream record (owner-dir, file_id).
    # file_id is the per-directory child ordinal (type-0x30 value+0x00), which COLLIDES — a directory
    # can hold the stream of a DIFFERENT file that was home'd there with the same ordinal. The on-disk
    # disambiguator is the name's own size (type-0x30 value+0x38): a name's real content is the candidate
    # stream — local (parent,file_id) or home (home,file_id) — whose 0x40 size EQUALS the name's size.
    # STRICT size-match => 0 over-merge (distinct-size files colliding on the ordinal stay apart); names
    # matching no candidate are not merged (solo, count 1). A hard LINK with an alloc=0 STUB (MD_DATA_RA_006)
    # resolves to its home stream (the stub's size 0 != the name's real size, the home stream's size matches).
    # Validated all-disk 2026-06-20: 0 over-merge / fsutil control [4,2] / genuine groups preserved
    # (winsider 33,104). Replaces the (home,ordinal,size,ctime,mtime) tuple and the presence-based
    # content-aware key, BOTH of which over-merged on the colliding ordinal (the size guard was dropped).
    hl_groups = {}

    # E89: `t40_content` only holds backings found in directories the walk TRAVERSED. A split name
    # whose HOME object is never traversed therefore resolved to nothing, fell to the `solo` branch,
    # and lost every fact the backing carries -- residency, USN, SecurityId, the EA bit, allocated
    # size. Measured: 548 names (446 distinct) on a real Windows volume reported IsResident=False
    # while their backing's $DATA was the inline form; `extract` got it right because it resolves the
    # home tree on demand, so `files` and `extract` disagreed about the same file.
    #
    # The home tree is reachable from obj_map whether or not the walk visited it, so look it up on
    # demand and cache it.
    _home_t40_cache = {}

    def _home_t40(oid):
        """{stream_idx: backing tuple} for one owner object, walked at most once."""
        if oid not in _home_t40_cache:
            got = {}
            if oid and oid in obj_map:
                try:
                    _rows = walk_bplus(f, ps, cs, tr, obj_map[oid])
                except Exception as _e:
                    _rows = ()
                    _skip_note("home-tree walk", "oid 0x%x" % oid, _e)
                for _k, _v in _rows:
                    if len(_k) >= 24 and le16(_k, 0) == 0x40 and len(_v) >= 0x68:
                        got.setdefault(le64(_k, 8), _t40_record_tuple(_v, (f, ps, cs, tr)))
            _home_t40_cache[oid] = got
        return _home_t40_cache[oid]

    for i, e in enumerate(nonres_files):
        P = e["parent_oid"]; fid = e["file_id"]; home = e.get("home_oid", 0); S = e.get("file_size", 0)
        rem = t40_content.get((home, fid))
        if rem is None and home:
            rem = _home_t40(home).get(fid)   # E89: the home object was not traversed by the walk
        # C1.4 -- ONE resolution path: the object's HOME. `file_id` is a PER-DIRECTORY ordinal, so a lookup
        # keyed on (parent_oid, file_id) can land on a different object that merely holds that ordinal in the
        # same directory. The home key cannot: it names the object itself.
        #
        # This is a SIMPLIFICATION, not a correction. Removing the local branches leaves the release golden
        # byte-identical over the whole corpus -- they were reachable but never decisive, because an earlier
        # branch had already won every time.
        #
        # An earlier checker reported that the local branch disagreed on 1,582 names. It re-implemented these
        # branch conditions to predict this ladder's choice and OR-ed them, losing the elif precedence, so it
        # counted branches that were reachable but never reached. The empirical diff is 0. Do not restore
        # that figure, and note there is no erratum or register row for it: it never happened. See
        # analysis/reports/d12_1/README.md, "a checker that modelled the tool instead of exercising it".
        #
        # What IS measured, by asking the driver instead of a second implementation of ours: every split name
        # this walk resolves is listed by its resolved backing's own type-0x39 link set -- 83,521 names on
        # the 64 corpus images that contain one (124 in scope), 0 exceptions (verify_claim.py,
        # assert_resolved_backing_lists_the_name).
        if rem and rem[1] == S:
            # The pre-1.11 ladder's branch-2 predicate, unchanged. Its separate `S == 0 and rem[1] == 0`
            # branch was unreachable -- this one already matches when both are zero -- so "restoring" it
            # would CHANGE behaviour rather than preserve it: an `or S == 0` here regrouped two winsider
            # names whose home backing has a non-zero size, moving the hard-link census by 2.
            sig = ("obj", home, fid); rec = rem
        else:                                              # no size-matching home stream: 0x39 fallback
            # F-1 hardening: a STALE `value+0x38` (e.g. 0 on a non-primary hard-link name — the SplashScreen
            # case) defeats the size-match above. Fall back to the object's authoritative name list: if the
            # home- (or local-) owned (owner, file_id) backing's embedded type-0x39 back-pointers name THIS
            # (parent_oid, name), it is a genuine name of that one object, so group it with that backing's
            # (owner, file_id). The 0x39 set is on-disk ground truth (the driver's own link list), so this can
            # only reattach a backing-confirmed name — it CANNOT over-merge distinct files.
            _lk = (P, (e.get("name", "") or "").lower())
            if rem is not None and _lk in t40_links.get((home, fid), ()):
                sig = ("obj", home, fid); rec = rem
            else:                                          # not a confident member -> solo, count 1
                sig = ("solo", e["path"], i); rec = None
        # Per-file USN (#327): the file's LastUsn is in its OWN resolved backing record (val+0x68 =
        # $SI+0x40), NOT the home directory's $SI. RD-proven 245/245 vs fsutil + 593/0 five-image;
        # static RefsComputeStandardInformationFromFcb maps $SI+0x40 <- FCB+0xe0 (per-file cursor).
        if rec is not None and len(rec) >= 4:
            e["usn"] = rec[2]; e["usn_journal_id"] = rec[3]
            # Per-file SecurityId / internal-flags (#327, problem.md #3): from the file's OWN resolved
            # backing record (val+0x50 / val+0x4C in the same $SI layout), NOT the home directory's $SI.
            # Disk-proven 2026-06-28: backing +0x50 is the file's real SID (e.g. 7973161277 on
            # win11refs2gtargeted, a member of the resident-file SID set; matches problem.md #3's
            # 295/295 + 448/449 on the 4 GB images). Replaces the honest-but-incomplete 0.
            if len(rec) >= 6:
                if rec[4]: e["security_id"] = rec[4]
                if rec[5]: e["internal_flags"] = rec[5]
            # H3: AllocatedSize = the resolved stream's alloc (val+0x60), read verbatim.
            e["allocated_size"] = rec[0]
            # F-1 hardening: report the OBJECT's size for a resolved member. This is a strict NO-OP for a
            # size-matched name (its value+0x38 already equals the backing size == rec[1]); it fires ONLY for
            # a hard-link name reattached via the 0x39 fallback whose cached value+0x38 was STALE (e.g. the
            # size-0 SplashScreen case), correcting it to the object's real size so the row is internally
            # consistent (FileSize == AllocatedSize) and the per-name summary total counts it like every other
            # hard-link name rather than under-counting the stale one.
            if len(rec) >= 2 and rec[1] != e.get("file_size", 0):
                e["file_size"] = rec[1]
            # Fix: the EA bit (0x40000) is in the backing's file_attrs (+0x48), NOT the type-0x30
            # pointer (+0x40) this entry was parsed from. OR it in so HasEA / FileAttributes / --filter
            # ea are correct for non-resident files. (Only the EA bit — the rare Archive-bit diff is left.)
            if len(rec) >= 9 and (rec[8] & 0x40000):
                e["file_attrs"] = e.get("file_attrs", 0) | 0x40000
                e["has_ea"] = True
            # T9: the same reasoning for named streams. The walk's ADS branch is gated on the type-0x30 value
            # being the long embedded form, so a split record's 0xB0 sub-records were never inspected -- 655
            # backing records on 28 of 102 corpus images carried streams no command could see (MD_ADS_RA_005 /
            # E93). The backing is resolved here, so enumerate from it.
            if len(rec) >= 12 and rec[11] and not e.get("ads_names"):
                e["has_ads"] = True
                e["ads_names"] = ";".join(rec[11])
                if len(rec) >= 13 and rec[12]:
                    e["ads_storage"] = rec[12]
            # E82: the resolved backing keeps this file's data INLINE, so the current $DATA stream is
            # resident even though the record was split out of the name row.
            if len(rec) >= 10 and rec[9]:
                e["data_inline"] = True
            if len(rec) >= 11 and rec[10]:
                e["data_form"] = rec[10]
        # H3: non-resident reparse tag + target. The reparse buffer lives in the file's OWN (home)
        # backing; source from `rem` (home stream) to dodge the file_id-collision wrong-target bug,
        # falling back to the resolved rec, then the 0x540 index for the tag. v3.14: target recovered;
        # v3.7-v3.10: backing is mirror-only so target stays empty (correct).
        if e.get("has_reparse"):
            rsrc = None
            if rem is not None and len(rem) >= 8 and (rem[6] or rem[7]):
                rsrc = rem
            elif rec is not None and len(rec) >= 8:
                rsrc = rec
            if rsrc is not None:
                if rsrc[6]:
                    e["reparse_tag_value"] = rsrc[6]
                if rsrc[7]:
                    e["reparse_target"] = rsrc[7]
            if not e.get("reparse_tag_value"):
                _ft = reparse_idx.get((home, fid), 0) or reparse_idx.get((P, fid), 0)
                if (_ft >> 31) & 1:
                    e["reparse_tag_value"] = _ft
        hl_groups.setdefault(sig, []).append(e)
    for _sig, entries_list in hl_groups.items():
        count = len(entries_list)
        # F1: when a file has >1 name, record the full set of sibling paths so a
        # consumer can enumerate every name of the object (like `fsutil hardlink list`).
        names = sorted(e["path"] for e in entries_list) if count > 1 else None
        for e in entries_list:
            e["hard_link_count"] = count
            if names:
                e["hard_link_names"] = names

    return results


def fs_content_summary(f, ps, cs, tr, obj_map, plus=True, depth=DEFAULT_DEPTH):
    """Single source of truth for the file-system-content counts shown by `summary` in BOTH forefst and
    refsanalysis (refsanalysis calls this, it does NOT re-implement the walk). Walks the tree ONCE from
    root (enriched) and returns (counts, results). `counts` holds RAW values (each caller formats):
    directories, files, resident_files (correct F5+B2 is_resident), total_file_size_bytes, oldest_ft,
    newest_ft, and — when plus — encrypted_files, integrity_files, compressed_files, reparse_files,
    hardlink_extra, snapshots, ads_entries."""
    results = walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, depth, True, set())
    counts = {
        "directories": sum(1 for r in results if r["is_dir"]),
        "files": sum(1 for r in results if not r["is_dir"]),
        "resident_files": sum(1 for r in results if _data_residency(r) == DATA_INLINE),
        "total_file_size_bytes": sum(r.get("file_size", 0) for r in results),
    }
    counts["non_resident_files"] = counts["files"] - counts["resident_files"]   # D1: resident + non-resident = files
    times = [t for r in results for t in (r.get("create_time", 0), r.get("modify_time", 0)) if t and t > 0]
    counts["oldest_ft"] = min(times) if times else 0
    counts["newest_ft"] = max(times) if times else 0
    if plus:
        counts["encrypted_files"] = sum(1 for r in results if r.get("is_encrypted"))
        counts["integrity_files"] = sum(1 for r in results if r.get("has_integrity"))
        counts["compressed_files"] = sum(1 for r in results if r.get("is_compressed"))
        counts["reparse_files"] = sum(1 for r in results if r.get("has_reparse"))
        _hl = [r for r in results if r.get("hard_link_count", 1) > 1]
        _hl_groups = {tuple(sorted(r.get("hard_link_names") or [f"oid:{r.get('oid')}"])) for r in _hl}
        # B7/D2: three distinct, self-describing hard-link metrics (names = rows with >1 name; groups =
        # distinct files; extra = names - groups). Printed together so they never look contradictory.
        counts["hardlink_names"] = len(_hl)
        counts["hardlink_groups"] = len(_hl_groups)
        counts["hardlink_extra"] = len(_hl) - len(_hl_groups)
        counts["snapshots"] = sum(r.get("snapshot_count", 0) for r in results)          # prior-version rows
        counts["snapshot_files"] = sum(1 for r in results if r.get("snapshot_count", 0) > 0)  # objects
        counts["ads_entries"] = sum(1 for r in results if r.get("has_ads"))             # host objects
    return counts, results


def _volume_times(f, ps, cs, tr, obj_map):
    """(vol_create, vol_modify) FILETIMEs from the volume-info object (OID 0x500,
    key 0x0520, +0x90/+0xA0). Returns (0, 0) if unavailable. Used by --timestomp
    for the PRE_FORMAT / FUTURE intrinsic signals."""
    if 0x500 not in obj_map:
        return (0, 0)
    try:
        for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[0x500]):
            if le16(kd, 0) == 0x0520 and len(vd) >= 0xA8:
                return (le64(vd, 0x90), le64(vd, 0xA0))
    except Exception:
        pass
    return (0, 0)

# `annotate_timestomp` lived here. It computed a per-row tier for the `files` TimestompFlags column,
# using the SAME verdict function as the `timestomp` subcommand but without the change journal --
# so the column could only ever carry the weaker half of the answer, and a reader who saw it in a
# listing had no way to know that. v1.11.0 removes the column and the flag; timestamp-anomaly
# information comes from `timestomp` alone, which reads the journal and states its corroboration.

def _record_placement(r):
    """RECORD PLACEMENT (E87): is the object's record embedded in this name row, or split out
    into a type-0x40 backing? A move or a hard link forces the split -- and moves no data.
    Blank for directories, where the distinction does not apply."""
    if r.get("is_dir"):
        return ""
    return "embedded" if r.get("record_embedded") else "split"


def _data_residency(r):
    """DATA RESIDENCY (E87): where the current $DATA stream's bytes are, read from the
    descriptor's own form -- `inline`, `extents`, `snapshot-shared` or `unallocated`.

    Independent of placement. A 0-byte file is decided by descriptor form like any other:
    an inline-form record carrying no bytes is `inline`; an extent-form one is `extents`.
    Blank for directories."""
    if r.get("is_dir"):
        return ""
    return r.get("data_form") or ""




# FullPath (now a standard column). The remaining columns keep their prior order.
CSV_COLUMNS = [
    # Phase C: identity first. OID and FileRef were two columns of which exactly one was ever populated —
    # OID for a directory, FileRef for a file — so they are merged into ONE identity column. This is
    # consistent with the change journal, where a directory's own reference IS `OID:0x0` (its OID in the
    # home slot, FileId 0) — verified on 589 directories with no counterexample.
    "ObjectRef",
    "FullPath", "FileName", "Extension", "FileSize",
    "Created", "Modified", "Changed", "Accessed",
    "ParentPath", "ParentOID",
    "CreationDir", "HomeOID", "FileID", "USN",
    "FileAttributes", "SecurityId", "OwnerSid", "GroupSid", "DACLSummary",
    "HasADS", "ADSNames", "RecordPlacement", "DataResidency", "IsResident", "IsDirectory",
    "IsEncrypted", "IsCompressed", "HasIntegrity", "HasEA",
    "HardLinkCount", "HardLinkNames", "SnapshotCount", "SnapshotNames",
    "ReparseTag", "ReparseTarget", "IsSparse", "AllocatedSize",
    "InternalFlags", "IsMoved",
    # P6 (2026-08-16): reordered + renamed (HomeOid→HomeOID, FileId→FileID, HasAds→HasADS, AdsNames→ADSNames);
    # NEW CreationDir (resolved HomeOID path), DACLSummary, IsMoved; the 3 recovery columns (IsDeleted/
    # DeletionSource/RecoveredChild) were dropped from `files` (always blank without deleted-recovery — that
    # lives in the `deleted` command). SnapshotNames deferred to a follow-up. RefsVersion removed 2026-08-09.
]

def _file_ref(r):
    """Stable 128-bit file reference HomeOid:FileId (== the USN FileReferenceNumber). Empty when the row
    has no file identity (e.g. a directory, which is addressed by its own OID instead)."""
    if r.get("file_id") and r.get("home_oid"):
        return f"0x{r['home_oid']:x}:0x{r['file_id']:x}"
    return ""

def _sid_display(sid):
    """Render a SID as 'Name (SID)', or the bare SID if no friendly name, or '' if empty.
    Matches the long-standing OwnerSid rendering; reused for GroupSid."""
    if not sid:
        return ""
    nm = sid_name(sid)
    return f"{nm} ({sid})" if nm else sid

def _full_path(r):
    """ParentPath/FileName as one column (F11). '.' or empty parent → just the name."""
    pp = r.get("parent_path", "")
    return f"{pp}/{r['name']}" if pp and pp != "." else r["name"]

def _is_moved(r):
    """IsMoved: the file currently sits in a directory other than the one it was created in —
    `home_oid != parent_oid`, and not a hard link (hlc > 1), whose extra names live outside the
    creation directory by design rather than by a move. Directories excluded.

    Placement-independent (E87). It used to be gated on `is_resident` because E70 was read as
    "a moved file is always non-resident"; what a move actually forces is the record SPLIT, and
    the home back-reference this test needs exists only on a split row anyway — so the gate was
    doing nothing except tying the column to a residency flag it has no relation to. A moved
    file can perfectly well still hold its bytes inline."""
    if r.get("is_dir"):
        return False
    home, par = r.get("home_oid") or 0, r.get("parent_oid") or 0
    return bool(home and par and home != par and (r.get("hard_link_count", 1) or 1) <= 1)

def _csv_fields(r, sd_map, version_str, oid2path=None):
    """Build the CSV cell values keyed by column name, so the row can be emitted in CSV_COLUMNS order
    without header/row drift (F11+2.C). `oid2path` (OID→FullPath, built from the walk) resolves CreationDir."""
    oid = r["oid"]
    sec_id = r.get("security_id", 0)
    _sd = (sd_map.get(sec_id) or ("", "", "")) if sec_id else ("", "", "")
    owner_sid, group_sid, dacl_summary = _sd[0], _sd[1], _sd[2]
    rtag = r.get("reparse_tag_value", 0)
    _file = not r.get("is_resident") and not r.get("is_dir")   # hard-link/name gate (non-resident files)
    _home = r.get("home_oid") or 0
    creation_dir = (oid2path.get(_home, "") if (oid2path and _home) else "")
    return {
        # ONE identity column, in ONE format: `<home>:<ordinal>`. A directory is its own home with ordinal
        # 0 -- which is exactly what the change journal writes for a directory's self-reference -- so it
        # renders `0x600:0x0`, not a bare `0x600`. Before this, a directory row and a file row carried
        # different shapes in the same column and a consumer had to branch on which it was looking at.
        "ObjectRef": (f"0x{oid:x}:0x0" if oid else _file_ref(r)),
        "FullPath": _full_path(r),
        "FileName": r["name"],
        "Extension": ext_from_name(r["name"]),
        "FileSize": r.get("file_size", 0),
        "Created": filetime_to_iso(r.get("create_time", 0)),
        "Modified": filetime_to_iso(r.get("modify_time", 0)),
        "Changed": filetime_to_iso(r.get("change_time", 0)),
        "Accessed": filetime_to_iso(r.get("access_time", 0)),
        "ParentPath": r.get("parent_path", ""),
        "ParentOID": f"0x{r['parent_oid']:x}" if r.get("parent_oid") else "",
        "CreationDir": creation_dir,
        "HomeOID": f"0x{r['home_oid']:x}" if r.get("home_oid") else "",
        "FileID": f"0x{r['file_id']:x}" if r.get("file_id") else "",
        "USN": r.get("usn", 0) if r.get("usn", 0) else "",
        "FileAttributes": attrs_to_str(r.get("file_attrs", 0)),
        "SecurityId": sec_id if sec_id else "",
        "OwnerSid": _sid_display(owner_sid),
        "GroupSid": _sid_display(group_sid),
        "DACLSummary": dacl_summary,
        "HasADS": r.get("has_ads", False),
        "ADSNames": r.get("ads_names", ""),
        "RecordPlacement": _record_placement(r),
        "DataResidency": _data_residency(r),
        "IsResident": (_data_residency(r) == DATA_INLINE),
        "IsDirectory": r["is_dir"],
        "IsEncrypted": r.get("is_encrypted", False),
        "IsCompressed": r.get("is_compressed", False),
        "HasIntegrity": r.get("has_integrity", False),
        "HasEA": r.get("has_ea", False),
        # F7: every FILE has at least one name, so report 1 rather than blank. The count is derived by
        # grouping names that share a type-0x40 backing, and only a record split out of its name row has one —
        # but a file WITHOUT one provably has exactly one name (creating a hard link forces the record out,
        # E70), so 1 is the true value, not a guess. Blank here meant "not computed" and made `files`
        # disagree with `summary`, which counts only groups of 2 or more. Directories keep "" (not applicable).
        "HardLinkCount": (r.get("hard_link_count", 1) if _file else (1 if not r.get("is_dir") else "")),
        # Q5: hard-link names (;-joined), same gate as HardLinkCount (non-resident files only).
        "HardLinkNames": ";".join(r.get("hard_link_names") or []) if _file else "",
        "SnapshotCount": r.get("snapshot_count", 0) if r.get("snapshot_count", 0) > 0 else "",
        "SnapshotNames": r.get("snapshot_names", "") if r.get("snapshot_count", 0) > 0 else "",
        "ReparseTag": reparse_tag_str(rtag) if rtag else "",
        "ReparseTarget": r.get("reparse_target", ""),
        # F5: sparse from $SI FileAttributes bit FILE_ATTRIBUTE_SPARSE_FILE (0x200) — the definitive signal.
        "IsSparse": bool(r.get("file_attrs", 0) & 0x200),
        "AllocatedSize": "" if r.get("allocated_size") is None else r.get("allocated_size"),
        # Q3: $SI InternalFlags (only confidently-named bits, e.g. 0x01 DeleteDisposition) — blank otherwise.
        "InternalFlags": internal_flags_str(r.get("internal_flags", 0)),
        "IsMoved": _is_moved(r),
        # Named "informational" in the header itself: the intrinsic $SI signals fire on ordinary
        # creation-time-preserving copies as often as on tampering, so the column is a lead, not a finding.
    }

def _build_oid2path(results):
    """OID → FullPath for directories, to resolve CreationDir from a row's HomeOID.

    Root (OID 0x600) maps to "." — the same way ParentPath renders the root. It used to map to "", which is
    falsy, so every file created in the volume root showed an EMPTY CreationDir, indistinguishable from
    "unknown". Any other directory that resolves to an empty path is normalised the same way."""
    m = {r["oid"]: (_full_path(r) or ".") for r in results if r.get("is_dir") and r.get("oid")}
    m.setdefault(0x600, ".")
    return m

_CSV_FORMULA_LEAD = ("=", "+", "-", "@", "\t", "\r")
_CSV_GUARD = False   # default: byte-FAITHFUL CSV (names written exactly as on the volume). `--csv-safe` opts IN.
_CSV_FORMULA_SEEN = 0   # audit 5.2: count formula-lead cells emitted UNGUARDED, to surface the hazard once at exit.

def _csv_safe(v):
    """Neutralise spreadsheet formula injection (audit 2.10): a cell whose first character is a formula lead
    (= + - @ TAB CR) is prefixed with a single quote so Excel/LibreOffice treat it as text, never as a formula.
    Because that single quote ALTERS the reported name, it is OPT-IN via `--csv-safe`, not the default — the tool
    outputs filenames byte-faithfully unless the examiner explicitly asks for the spreadsheet-safe rendering."""
    s = "" if v is None else str(v)
    return "'" + s if s[:1] in _CSV_FORMULA_LEAD else s

def _csv_cell(v):
    """One CSV cell under the fidelity-first policy: byte-faithful by default (the name exactly as on the volume);
    only with `--csv-safe` is the formula-injection guard applied. The tool never silently rewrites a name. When
    the guard is OFF, a cell that begins with a formula lead is COUNTED (not altered) so the hazard is surfaced on
    stderr at exit (audit 5.2) — the examiner is told to re-run with --csv-safe before Excel, stdout unchanged."""
    if _CSV_GUARD:
        return _csv_safe(v)
    if ("" if v is None else str(v))[:1] in _CSV_FORMULA_LEAD:
        global _CSV_FORMULA_SEEN
        _CSV_FORMULA_SEEN += 1
    return v

def _csv_row(cells):
    """Apply the per-cell policy (_csv_cell) across a CSV data row, so every subject-controlled column follows the
    same faithful-by-default / `--csv-safe` rule in the standalone writers (usn/timeline/timestomp/mlog/deleted),
    matching `files`."""
    return [_csv_cell(c) for c in cells]

def _warn_csv_formula():
    """audit 5.2: at exit, if any CSV cell was emitted UNGUARDED with a leading formula character (= + - @), tell
    the examiner — the default is byte-faithful, so the Excel-injection hazard would otherwise be invisible. Same
    shape as the 3.2 translator caveat: stderr only, never touches stdout, so valid output is byte-unchanged."""
    if _CSV_FORMULA_SEEN:
        print(f"[{PROG}] WARNING: {_CSV_FORMULA_SEEN} CSV cell(s) begin with a spreadsheet formula character "
              f"(= + - @). Output is byte-faithful; re-run with --csv-safe before opening the file in "
              f"Excel or LibreOffice.", file=sys.stderr)

atexit.register(_warn_csv_formula)

def emit_csv(results, sd_map, version_str, out, full_path=False):
    # `full_path` is accepted for back-compat (the old --full-path-column flag) but is now a no-op: FullPath
    # is a standard column. Building a dict keyed by column name guarantees header/row stay aligned.
    writer = csv.writer(out)
    writer.writerow(CSV_COLUMNS)
    oid2path = _build_oid2path(results)                  # P6: for CreationDir (resolve HomeOID → path)
    _cell = _csv_cell                                    # faithful by default; formula-guard only under --csv-safe
    for r in results:
        d = _csv_fields(r, sd_map, version_str, oid2path)
        writer.writerow([_cell(d[c]) for c in CSV_COLUMNS])

def emit_body(results, out):
    for r in results:
        md5 = "0"
        # Q10: Sleuthkit convention — mark deleted entries so mactime users can filter on " (deleted)".
        name = r["path"] + (" (deleted)" if r.get("is_deleted") else "")
        # Q10: a non-resident file has no own OID; use its file_id as the inode so mactime groups the file's
        # hard-link names (which share one file_id) as a single object instead of many inode-0 rows.
        if r["oid"]:
            inode = f"0x{r['oid']:x}"
        elif r.get("file_id"):
            inode = f"0x{r['file_id']:x}"
        else:
            inode = "0"
        mode = attrs_to_mode(r.get("file_attrs", 0), r["is_dir"])
        size = str(r.get("file_size", 0))
        atime = str(filetime_to_unix(r.get("access_time", 0)))
        mtime = str(filetime_to_unix(r.get("modify_time", 0)))
        ctime = str(filetime_to_unix(r.get("change_time", 0)))
        crtime = str(filetime_to_unix(r.get("create_time", 0)))
        out.write(f"{md5}|{name}|{inode}|{mode}|0|0|{size}|{atime}|{mtime}|{ctime}|{crtime}\n")

def _sid_display_or_none(sid):
    """Like _sid_display but returns None (not '') for an empty SID — JSON convention."""
    if not sid:
        return None
    nm = sid_name(sid)
    return f"{nm} ({sid})" if nm else sid

def _build_record(r, sd_map, version_str, oid2path=None):
    oid = r["oid"]
    sec_id = r.get("security_id", 0)
    _sd = (sd_map.get(sec_id) or ("", "", "")) if sec_id else ("", "", "")
    owner_sid, group_sid, dacl_summary = _sd[0], _sd[1], _sd[2]
    rtag = r.get("reparse_tag_value", 0)
    _fr = _file_ref(r)
    _home = r.get("home_oid") or 0
    creation_dir = (oid2path.get(_home, "") if (oid2path and _home) else "") or None
    return {
        # Identity (lead), ordered like the CSV. `id` is the single identity the CSV shows in its first column
        # (a directory's OID, or a file's FileRef); `oid` and `file_ref` are KEPT separate as well, because a
        # JSON consumer reads by name and losing the distinction would cost more than the key saves.
        "id": (f"0x{oid:x}" if oid else (_fr or None)),
        "oid": f"0x{oid:x}" if oid else None,
        "file_ref": _fr or None,
        "full_path": _full_path(r),
        "file_name": r["name"],
        "extension": ext_from_name(r["name"]),
        "file_size": r.get("file_size", 0),
        "parent_path": r.get("parent_path", ""),
        "parent_oid": f"0x{r['parent_oid']:x}" if r.get("parent_oid") else None,
        "creation_dir": creation_dir,
        "creation_dir_oid": f"0x{r['home_oid']:x}" if r.get("home_oid") else None,
        "file_id": f"0x{r['file_id']:x}" if r.get("file_id") else None,
        "is_directory": r["is_dir"],
        "is_moved": _is_moved(r),
        "is_resident": (_data_residency(r) == DATA_INLINE),
        "created": filetime_to_iso(r.get("create_time", 0)),
        "modified": filetime_to_iso(r.get("modify_time", 0)),
        "changed": filetime_to_iso(r.get("change_time", 0)),
        "accessed": filetime_to_iso(r.get("access_time", 0)),
        "file_attributes": attrs_to_str(r.get("file_attrs", 0)),
        "security_id": sec_id if sec_id else None,
        "owner_sid": _sid_display_or_none(owner_sid),
        "usn": r.get("usn", 0) or None,
        "has_ads": r.get("has_ads", False),
        "ads_names": r.get("ads_names", "") or None,
        "is_encrypted": r.get("is_encrypted", False),
        "is_compressed": r.get("is_compressed", False),
        "has_integrity": r.get("has_integrity", False),
        "has_ea": r.get("has_ea", False),
        "reparse_target": r.get("reparse_target", "") or None,
        "hard_link_count": (None if r.get("is_dir")
                            else (r.get("hard_link_count", 1) if not r.get("is_resident") else 1)),   # F7
        "hard_link_names": r.get("hard_link_names") or None,
        "snapshot_count": r.get("snapshot_count", 0) if r.get("snapshot_count", 0) > 0 else None,
        "snapshot_names": (r.get("snapshot_names") or None) if r.get("snapshot_count", 0) > 0 else None,
        "group_sid": _sid_display_or_none(group_sid),
        "dacl_summary": dacl_summary or None,
        "allocated_size": r.get("allocated_size"),
        "reparse_tag": reparse_tag_str(rtag) if rtag else None,
        # F5: FILE_ATTRIBUTE_SPARSE_FILE (0x200) from $SI FileAttributes.
        "is_sparse": bool(r.get("file_attrs", 0) & 0x200),
        # Q3: $SI InternalFlags (confidently-named bits only, e.g. DeleteDisposition).
        "internal_flags": internal_flags_str(r.get("internal_flags", 0)) or None,
        # refs_version removed 2026-08-09 (per-row constant) — volume version is in summary/details/usn --info.
    }

def emit_json(results, sd_map, version_str, out):
    oid2path = _build_oid2path(results)                  # for creation_dir (resolve home_oid → path)
    records = [_build_record(r, sd_map, version_str, oid2path) for r in results]
    json.dump(records, out, indent=2, ensure_ascii=False)
    out.write("\n")

def emit_jsonl(results, sd_map, version_str, out):
    oid2path = _build_oid2path(results)
    for r in results:
        out.write(json.dumps(_build_record(r, sd_map, version_str, oid2path), ensure_ascii=False))
        out.write("\n")

# ─── Summary helpers ──────────────────────────────────────────────────
_ROOT_LABELS = [
    "Object ID Table", "Medium Allocator", "Container Allocator",
    "Schema Table", "Parent-Child Table", "Object ID Table dup",
    "Block RefCount", "Container Table", "Container Table dup",
    "Schema Table dup", "Container Index", "Integrity State",
    "Small Allocator",
]

def _human_size(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024
    return f"{n:.1f} PB"

def _guid_str(b):
    if len(b) < 16: return b.hex()
    return f"{le32(b,0):08x}-{le16(b,4):04x}-{le16(b,6):04x}-{b[8:10].hex()}-{b[10:16].hex()}"

def _hash_page(f, offset, size):
    f.seek(offset); return hashlib.sha256(f.read(size)).hexdigest()

def _hash_image(path, log_fn=None):
    size = os.path.getsize(path)
    if size > 50 * 1024**3 and log_fn:
        est_min = size / (1.5 * 1024**3)
        log_fn(f"  Warning: image is {_human_size(size)}, hash will take ~{est_min:.0f} minutes")
    h = hashlib.sha256()
    done = 0
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(64 * 1024 * 1024)
            if not chunk: break
            h.update(chunk)
            done += len(chunk)
            if log_fn and size > 0:
                pct = 100.0 * done / size
                log_fn(f"\r  Hashing: {pct:.0f}%")
    return h.hexdigest()

def cmd_fastsummary(f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns,
                    image_path, plus_mode=False, json_mode=False, hash_image=False, log_fn=None,
                    verify_page_refs=False):
    hs = _human_size

    # VBR fields + hash
    f.seek(ps); bs = f.read(512)
    chk_type = le16(bs, 0x2A)
    vol_serial = le64(bs, 0x38)   # F11: volume serial number (VBR 0x38); boot shows it, triage summary didn't
    total_sectors = le64(bs, 0x18)
    bpc = le64(bs, 0x40) if le64(bs, 0x40) != 0 else 0x4000000
    vbr_sha = hashlib.sha256(bs).hexdigest()

    # SUPB + hash
    supb_off = ps + SUPB_LCN * cs
    f.seek(supb_off); supb_data = f.read(cs)
    vol_guid = supb_data[0x50:0x60] if supb_data[:4] == b"SUPB" else b"\x00" * 16
    supb_sha = hashlib.sha256(supb_data).hexdigest()

    # Checkpoint info + hash
    best_vc = 0; best_flags = 0; chkp_sha = ""
    for cl in chkp_lcns:
        try:
            vc, flags, _ = parse_chkp(f, ps, cs, cl)
            if vc >= best_vc:
                best_vc = vc; best_flags = flags
                chkp_sha = _hash_page(f, ps + cl * cs, cs)
        except Exception as _e: _skip_note("fastsummary: checkpoint", f"lcn {cl}", _e)

    # Root table row counts
    root_counts = {}
    # E3 fix: the real-addressed roots are {7,8,12} (module-level _CT_ROOT_INDICES) — NOT {7,8,10,11}.
    # The old local set read roots 10/11 without translation and root 12 WITH translation, i.e. 3 of
    # 13 root counts from wrong locations. (chkp.md / container_table.md / FS_CHKP_016/017/021, RD.)
    for idx in range(min(13, len(roots))):
        vlcns = roots[idx]
        if not vlcns: root_counts[idx] = 0; continue
        use_tr = None if idx in _CT_ROOT_INDICES else tr
        try: root_counts[idx] = len(list(walk_bplus(f, ps, cs, use_tr, vlcns)))
        except Exception: root_counts[idx] = 0

    # Volume metadata from OID 0x500
    vol_label = ""; vol_detail = {}
    if 0x500 in obj_map:
        try:
            for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[0x500]):
                kt = le16(kd, 0) if len(kd) >= 2 else 0
                if kt == 0x0510 and len(vd) >= 2:
                    vol_label = vd.decode("utf-16-le", errors="replace").rstrip("\x00")
                elif kt == 0x0520 and len(vd) >= 0xA8:
                    vol_detail["vol_major"] = vd[0x80]
                    vol_detail["vol_minor"] = vd[0x81]
                    vol_detail["drv_major"] = vd[0x82]
                    vol_detail["drv_minor"] = vd[0x83]
                    vol_detail["vol_create_time"] = le64(vd, 0x90)
                    vol_detail["vol_modify_time"] = le64(vd, 0xA0)
        except Exception as _e: _skip_note("fastsummary: volume info", "table 0x520", _e)

    checksum_types = {0: "None", 2: "CRC64", 4: "SHA-256"}
    volume_bytes = total_sectors * 512

    summary = {
        "tool": PROG, "summary_mode": "fastsummary-plus" if plus_mode else "fastsummary",
        "image": os.path.basename(image_path),
        "image_size": os.path.getsize(image_path),
        "refs_version": f"{vmaj}.{vmin}",
        "volume_guid": _guid_str(vol_guid),
        "volume_serial": f"0x{vol_serial:016x}",
        "volume_label": vol_label or "(none)",
        "volume_size": hs(volume_bytes), "volume_size_bytes": volume_bytes,
        "cluster_size": cs, "container_size": bpc,
        "checksum": checksum_types.get(chk_type, f"Unknown({chk_type})"),
        "checkpoint_vc": best_vc, "checkpoint_flags": f"0x{best_flags:x}",
        "containers_mapped": root_counts.get(7, 0),
        "objects": len(obj_map),
        "vbr_sha256": vbr_sha, "supb_sha256": supb_sha, "chkp_sha256": chkp_sha,
        # Bootstrap redundancy inventory (VBR primary+backup, checkpoint pair, SUPB copies) with addresses +
        # validity — the same scan `integrity` uses, surfaced so `summary` shows where the backups are.
        "bootstrap_backups": _scan_backup_copies(f, ps, cs, chkp_lcns),
        "root_table_rows": {_ROOT_LABELS[i]: root_counts.get(i, 0)
                            for i in range(min(13, len(roots)))},
    }

    # GN_PREF_RA_004 lives in `integrity`, NOT here. Verifying every Object-Table page reference means one
    # 4-cluster read per object, and a real Windows volume has 26,681 of them -- 427 MB and ~38 s, which took
    # `summary` from 4.7 s to 42.2 s and `fastsummary` from 0.36 s to 36.7 s. The ~385-reference corpus
    # average that made it look free came from small lab volumes. Doing it for free needs the lazy design
    # (verify each root page at the first walk that reads it anyway), which is more than a point release
    # should carry; until then it belongs to the diagnostic command, where the reader is asking for depth.
    if verify_page_refs:
        summary["page_refs"] = verify_page_references(f, ps, cs, tr, roots)

    if plus_mode:
        if vol_detail:
            summary["volume_version"] = f"{vol_detail.get('vol_major','?')}.{vol_detail.get('vol_minor','?')}"
            summary["driver_version"] = f"{vol_detail.get('drv_major','?')}.{vol_detail.get('drv_minor','?')}"
            summary["volume_create_time"] = filetime_to_iso(vol_detail.get("vol_create_time", 0))
            summary["volume_modify_time"] = filetime_to_iso(vol_detail.get("vol_modify_time", 0))

        # Feature E — upgrade detection. A volume was UPGRADED across versions iff it runs v3.10+
        # without the native-format bit (CHKP+0x78 & 0x080), OR the format-time version (immutable
        # VBR/$VolInfo) differs from the current driver version. (Verified: native v3.14=0x682 bit set;
        # upgraded v3.4→v3.14=0x602 bit clear; native v3.4=0x002 bit clear but minor<10.)
        native_bit = bool(best_flags & 0x080)
        vol_mn = vol_detail.get("vol_minor") if vol_detail else None
        drv_mn = vol_detail.get("drv_minor") if vol_detail else None
        reasons = []
        from_ver = None
        driver_note = None
        if vmin >= 10 and not native_bit:
            # native bit is set only on natively-formatted v3.10+, so its absence ⇒ formatted pre-v3.10.
            reasons.append("CHKP native-format bit 0x080 is clear on a v3.10+ volume")
            from_ver = "pre-v3.10 (v3.4–v3.9)"
        if isinstance(vol_mn, int) and isinstance(drv_mn, int) and vol_mn != drv_mn:
            if native_bit:
                # B10: a natively-formatted volume (native-format marker 0x080 set) whose driver stamp is newer
                # than its format-time version — e.g. an Insider v3.15 driver on a v3.14 volume. The CHKP
                # native marker is authoritative; this is NOT an upgrade, so it is an informational note, not
                # upgrade evidence. (RD: winsider/wininsider flags 0x2682, 0x080 set, GUID@0x48 populated.)
                driver_note = ("driver v3.%d is newer than the format-time v3.%d "
                               "(natively formatted — not an upgrade)" % (drv_mn, vol_mn))
            else:
                # native bit clear AND versions differ ⇒ corroborates a genuine cross-version upgrade; the
                # $VolInfo stamp usually tracks the current driver after upgrade, but if it lags it gives the
                # exact original minor.
                reasons.append("format-time v3.%d ≠ driver v3.%d ($VOLUME_INFORMATION stamp)" % (vol_mn, drv_mn))
                # P4-1: do NOT overwrite a from_ver already set above. The CHKP native-format bit is a
                # STRUCTURAL fact (clear on a v3.10+ volume => formatted pre-v3.10); the $VolInfo stamp is the
                # weaker signal because it usually tracks the CURRENT driver after an upgrade (see the comment
                # above). When both fire, the stamp's min() answer is wrong: win1122h2test_afteropenedwithinsider
                # reported "formatted v3.14" while the volume is provably v3.9 (its pre-upgrade image
                # win1122h2test), contradicting the evidence line printed directly beneath it.
                from_ver = from_ver or "v3.%d" % min(vol_mn, drv_mn)
        if reasons:
            summary["volume_state"] = "UPGRADED"
            summary["upgrade_evidence"] = reasons
            summary["upgraded_from"] = from_ver or "an earlier version"
        else:
            summary["volume_state"] = "NATIVE v%s" % summary["refs_version"]
            if driver_note:
                summary["driver_note"] = driver_note

        # Security descriptor count
        sec_count = 0
        if 0x530 in obj_map:
            try: sec_count = len(list(walk_bplus(f, ps, cs, tr, obj_map[0x530])))
            except Exception as _e: _skip_note("fastsummary: security descriptors", "table 0x530", _e)
        summary["security_descriptors"] = sec_count

        # Reparse index
        reparse_count = 0
        if 0x540 in obj_map:
            try: reparse_count = len(list(walk_bplus(f, ps, cs, tr, obj_map[0x540])))
            except Exception as _e: _skip_note("fastsummary: reparse index", "table 0x540", _e)
        summary["reparse_index_entries"] = reparse_count

        # Trash table
        trash_count = 0
        if 0xD in obj_map:
            try: trash_count = len(list(walk_bplus(f, ps, cs, tr, obj_map[0xD])))
            except Exception as _e: _skip_note("fastsummary: trash table", "table 0xD", _e)
        summary["trash_table_entries"] = trash_count

        # Container utilization
        ct_size = root_counts.get(7, 0)
        if tr and ct_size > 0:
            used = sum(1 for c in tr.map.values() if c > 0)
            summary["containers_used"] = used
            summary["containers_free"] = ct_size - used
            summary["utilization_pct"] = round(100.0 * used / ct_size, 1)
            # E74: the old `free_space_est` here was a CONTAINER-level figure — it counted unmapped
            # containers as free, and the Container Table maps ~100% of every volume, so it reported ~64 MB
            # free on any volume. Replaced by the allocator's own accounting below, at cluster granularity.

        # Capacity, from the allocator's persisted summary (one page read — see B.2b / E74). `covered` is the
        # Container-Table-mapped space; the physical tail past the last container belongs to no allocator tier
        # and is reported separately rather than counted as free.
        _cap = alloc_capacity(f, ps, cs, tr, roots)
        if _cap:
            summary["capacity"] = {
                "used_bytes": _cap["used_clusters"] * cs,
                "free_bytes": _cap["free_clusters"] * cs,
                "allocator_covered_bytes": _cap["covered_clusters"] * cs,
                "outside_allocator_bytes": _cap["outside_allocator_clusters"] * cs,
                "volume_bytes": _cap["volume_clusters"] * cs,
                "used_pct": round(100.0 * _cap["used_clusters"] / _cap["covered_clusters"], 1),
                "used": hs(_cap["used_clusters"] * cs),
                "free": hs(_cap["free_clusters"] * cs),
                "source": "allocator summary (Medium tier root page)",
            }

        # FS Metadata directory (OID 0x520)
        fs_meta = {"rows": 0, "children": [], "usn_journal": False}
        if 0x520 in obj_map:
            try:
                for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[0x520]):
                    fs_meta["rows"] += 1
                    if len(kd) >= 4 and le16(kd, 0) == 0x30:
                        try: name = kd[4:].decode("utf-16-le").rstrip("\x00")
                        except Exception: name = "(decode error)"
                        if name == "Change Journal": fs_meta["usn_journal"] = True
                        fs_meta["children"].append(name)
            except Exception as _e: _skip_note("fastsummary: system metadata", "object tree", _e)
        summary["fs_metadata"] = fs_meta
        # UsnJournalId (volume-constant journal epoch) is injected by the full `summary` path from the
        # walk (each file's $SI val+0x70 carries it; the $Max stream is unreliable — often no extents).

    if hash_image:
        summary["image_sha256"] = _hash_image(image_path, log_fn)

    # E11/3.2: surface unmapped-container misses (0 on well-formed volumes; non-zero => corrupt/truncated
    # container table, so some rows were read as identity and may be missing). stderr, not the summary. The
    # shared helper is also registered at-exit, so every OTHER command surfaces it too; the _warned flag keeps
    # it to one line per run.
    _warn_translator(tr)
    return summary

def _print_fastsummary(summary, plus_mode=False, is_summary=False):
    hs = _human_size
    w = 78
    print("=" * w)
    print(f"ReFS Volume {'Fast ' if not plus_mode else 'Fast Extended '}Summary")
    print("-" * w)   # 3summary: '=' above the title, '-' below
    print(f"  Image:              {summary['image']}")
    print(f"  Image size:         {hs(summary['image_size'])}")
    print(f"  ReFS version:       {summary['refs_version']}")
    print(f"  Volume GUID:        {summary['volume_guid']}")
    print(f"  Volume serial:      {summary.get('volume_serial', '')}")
    print(f"  Volume label:       {summary['volume_label']}")
    print(f"  Volume size:        {summary['volume_size']}")
    print(f"  Cluster size:       0x{summary['cluster_size']:x} ({hs(summary['cluster_size'])})")
    print(f"  Container size:     0x{summary['container_size']:x} ({hs(summary['container_size'])})")
    print(f"  Checksum:           {summary['checksum']}")
    print()
    print("-" * w)
    print("Bootstrap structures")
    print("-" * w)
    # Every redundant copy (VBR primary+backup, both checkpoints, primary+backup SUPB) with its address,
    # validity/identical check, AND its own SHA-256 — so all six-plus hashes are shown (1summary-2a) and no
    # line exceeds the report width (1summary-1: the 64-hex hash sits on its own indented line).
    bk = summary.get("bootstrap_backups") or {}
    _cs = summary.get("cluster_size", 0) or 0
    def _bs(label, addr, status, sha):
        print(f"  {label:<16} {addr}" + (f"  — {status}" if status else ""))
        if sha:
            print(f"      {sha}")
    v = bk.get("vbr") or {}
    _supb = bk.get("supb", [])
    _chkps = bk.get("checkpoints", [])
    def _self_ref_flag(rec):
        # The page stores its own LCN at +0x20; a mismatch = a tampered/corrupt bootstrap copy (e.g. a zeroed
        # self-reference — the classic hand-corrupted-superblock case). Surfaced here because the tool still
        # bootstraps from a good copy, so the corruption is otherwise invisible in `summary`.
        if rec.get("self_lcn_ok") is False:
            return f"  !! CORRUPT self-reference: stored {rec.get('self_lcn', 0):#x}, expected own LCN {rec.get('lcn', 0):#x}"
        return ""
    def _supb_line(s):
        _sha = summary.get("supb_sha256") if s.get("role") == "PRIMARY" else s.get("sha256")
        _st = "checksum OK" if s.get("cksum_ok") else ("signature OK" if s.get("ok") else "BAD")
        _bs(f"SUPB {s.get('role','?').lower()}", f"LCN {s.get('lcn',0):#x} (offset {s.get('lcn',0)*_cs:#x})",
            _st + _self_ref_flag(s), _sha)
    def _chkp_line(rec):
        _sha = summary.get("chkp_sha256") if rec.get("role") == "PRIMARY" else rec.get("sha256")
        _cok = "checksum OK" if rec.get("cksum_ok") else ("signature OK" if rec.get("sig_ok") else "BAD")
        _st = _cok + (f", vclock={rec['vc']}" if rec.get("vc") is not None else "") \
              + ("" if rec.get("roots_ok") else " (roots unreadable)") + _self_ref_flag(rec)
        _bs(f"CHKP {rec.get('role','?').lower()}", f"LCN {rec['lcn']:#x} (offset {rec['lcn']*_cs:#x})", _st, _sha)

    # 2summary: primary copies first, then a separator, then the backup copies (grouped by role, not by
    # structure type). VBR primary is always at LBA 0.
    _bs("VBR primary", "LBA 0 (offset 0x0)",
        "checksum OK" if v.get("primary_cksum_ok") else ("sig OK" if v.get("primary_ok") else "BAD"),
        summary.get("vbr_sha256"))
    for s in _supb:
        if s.get("role") == "PRIMARY": _supb_line(s)
    for rec in _chkps:
        if rec.get("role") == "PRIMARY": _chkp_line(rec)
    print("-" * w)
    vb = v.get("backup")
    if vb and vb.get("present"):
        _bs("VBR backup", f"LBA {vb['lba']} (off {vb['lba']*512:#x})",
            ("= primary" if vb.get("matches_primary") else "DIFFERS")
            + (", checksum OK" if vb.get("cksum_ok") else ""), vb.get("sha256"))
    elif vb is not None:
        _bs("VBR backup", f"LBA {vb.get('lba','?')}", "MISSING/unreadable", None)
    for s in _supb:
        if s.get("role") != "PRIMARY": _supb_line(s)
    for rec in _chkps:
        if rec.get("role") != "PRIMARY": _chkp_line(rec)
    _corrupt_self = [x for x in (_supb + _chkps) if x.get("self_lcn_ok") is False]
    if _corrupt_self:
        print()
        print(f"  ** BOOTSTRAP TAMPERING: {len(_corrupt_self)} structure(s) above carry a CORRUPT self-reference")
        print("     (the page's stored own-LCN was overwritten, typically zeroed). The volume still parses —")
        print("     the self-reference is not needed to bootstrap from a checkpoint — but a zeroed self-LCN does")
        print("     not occur normally, so treat it as deliberate tampering / a hand-corrupted bootstrap.")
    if len([s for s in _supb if s.get("ok")]) >= 2:
        # B1: the SUPB copies hash differently by design — each stores its own LCN (page header +
        # self-descriptor) and its own self-checksum; the payload (GUID, checkpoint refs, generation) is
        # identical. 4summary: re-wrapped so no line exceeds the report width; placed after the backups.
        print()
        print("note: the SUPB copies hash differently by design (each carries its own LCN +")
        print("self-checksum); their payload is identical — redundancy, not divergence.")
    elif len(_supb) < 2:
        print()
        print("  (warning: fewer than 2 SUPB copies located)")
    if "image_sha256" in summary:
        _bs("Image", "(full disk)", "", summary["image_sha256"])
    print()
    print("-" * w)
    print("Checkpoint")
    print("-" * w)
    print(f"  Virtual clock:      {summary['checkpoint_vc']}")
    print(f"  Flags:              {summary['checkpoint_flags']}")
    try:
        for _line in chkp_flags_decoded(int(str(summary['checkpoint_flags']), 16)):
            print(f"                        · {_line}")
    except (ValueError, TypeError) as _e:
        # Printing nothing here reads as "this checkpoint has no flags set".
        _skip_note("fastsummary: checkpoint flag decode", "flags field", _e)
    # 7summary: "Containers mapped" removed here — it duplicated the container count now shown once in
    # Volume Detail (below).
    print()
    print("-" * w)
    print("Global Root Tables")
    print("-" * w)
    for name, count in summary["root_table_rows"].items():
        print(f"  {name:<28} {count:>6} rows")

    if plus_mode:
        print()
        print("-" * w)
        print("Volume Detail")
        print("-" * w)
        if "volume_version" in summary:
            print(f"  Volume version:     {summary['volume_version']}")
            print(f"  Driver version:     {summary['driver_version']}")
            print(f"  Volume created:     {summary['volume_create_time']}")
            print(f"  Volume modified:    {summary['volume_modify_time']}")
        vstate = summary.get("volume_state", "")
        if vstate == "UPGRADED":
            print(f"  Volume state:       ⚠ APPEARS UPGRADED (formatted {summary.get('upgraded_from','?')}, now running v{summary['refs_version']})")
            for r in summary.get("upgrade_evidence", []):
                print(f"      • {r}")   # 6-space indent keeps the evidence bullets within the 78-col width
        elif vstate:
            print(f"  Volume state:       {vstate}")
            if summary.get("driver_note"):
                # S1: printed over two lines — as one it ran well past the width used everywhere else.
                _dn = summary["driver_note"]
                if " (" in _dn:
                    _head, _tail = _dn.split(" (", 1)
                    print(f"      • {_head}")
                    print(f"        ({_tail}")
                else:
                    print(f"      • {_dn}")
        print(f"  Security descs:     {summary.get('security_descriptors', 0)}")
        print(f"  Reparse index:      {summary.get('reparse_index_entries', 0)} entries")
        print(f"  Trash table:        {summary.get('trash_table_entries', 0)} entries")
        # 7summary: every 64 MB container is mapped by the Container Table; exactly one — the first
        # (VLCN 0x8000) — has base PLCN 0, which is the boot region (physical cluster 0 = the VBR), not free
        # space. So report the container count and name that one, instead of a misleading "used/%" (all
        # containers are mapped). Disk-verified: cid 2 -> PLCN 0 -> ReFS VBR on every corpus image.
        if "containers_used" in summary:
            _bootnote = ("  (first maps to PLCN 0 = boot region)"
                         if summary.get("containers_free") == 1 else "")
            print(f"  Containers used:    {summary['containers_used']} / {summary['containers_mapped']}{_bootnote}")
        # Capacity comes from the volume's OWN allocator accounting, not from counting containers (E74).
        if summary.get("capacity"):
            _c = summary["capacity"]
            print(f"  Space used:         {_c['used']} of {hs(_c['allocator_covered_bytes'])} "
                  f"({_c['used_pct']}%) — {_c['free']} free")
            if _c["outside_allocator_bytes"]:
                # S3: the old wording said where the space was but not what it meant, on a 106-column line.
                print(f"      • {hs(_c['outside_allocator_bytes'])} lies beyond the last container,")
                print("        so no allocator tracks it — it is neither used nor free")
        # 8summary: FS Metadata = OID 0x520 (ReFS's $Extend analogue; holds the USN "Change Journal" when
        # active). Show its named child entries, not the raw B+-tree row count — the lone row on an empty one
        # is the directory's own record, which read as a confusing "[1 rows]".
        fm = summary.get("fs_metadata", {})
        _kids = fm.get("children", [])
        if _kids:
            _lbl = f"{len(_kids)} child{'ren' if len(_kids) != 1 else ''}"
            _line = f"  FS Metadata:        {_lbl} ({', '.join(_kids)})"
            if len(_line) > 78:          # names would overflow the report width — show the count only
                _line = f"  FS Metadata:        {_lbl}"
            print(_line)
        else:
            print("  FS Metadata:        no child entries")
        print(f"  USN Journal:        {'Active' if fm.get('usn_journal') else 'Inactive'}")
        if "usn_journal_id" in summary:
            print(f"  USN Journal ID:     0x{summary['usn_journal_id']:016x}")

    print()
    if plus_mode and not is_summary:
        print("For complete file statistics, use the `summary` subcommand (full directory walk)")

def _print_summary(summary, fast_data, plus_mode=False):
    _print_fastsummary(fast_data, plus_mode=plus_mode, is_summary=True)
    w = 78
    # 4summary: _print_fastsummary already emits one trailing blank after Volume Detail — no second blank here.
    print("-" * w)
    print("File System Content (from directory walk)")
    print("-" * w)
    print(f"  Directories:        {summary['directories']}")
    print(f"  Files:              {summary['files']} ({summary['resident_files']} inline + {summary.get('non_resident_files', 0)} extent-backed)")
    print(f"  Total file size:    {summary['total_file_size']}")
    print(f"  Oldest timestamp:   {summary['oldest_timestamp']}")
    print(f"  Newest timestamp:   {summary['newest_timestamp']}")
    if plus_mode:
        print(f"  Encrypted files:    {summary.get('encrypted_files', 0)}")
        print(f"  Integrity objects:  {summary.get('integrity_files', 0)}")
        print(f"  Compressed files:   {summary.get('compressed_files', 0)}")
        print(f"  Hard-linked:        {summary.get('hardlink_groups', 0)} files sharing {summary.get('hardlink_names', 0)} names")
        print(f"  Snapshot versions:  {summary.get('snapshots', 0)} (across {summary.get('snapshot_files', 0)} files)")
        print(f"  ADS host files:     {summary.get('ads_entries', 0)}")
    print()
    # 1summary: the `fastsummary` tip is emitted at the TOP now (right after the "Walking directory tree" log).

# ─── OID detail + search ─────────────────────────────────────────────
_ATTR_NAMES = {
    0x10: "$STANDARD_INFORMATION", 0x20: "Reverse Index", 0x30: "Directory Entry",
    0x40: "Extent Descriptor", 0x50: "$VOLUME_INFORMATION", 0x60: "Reparse Index",
    0x70: "$REPARSE_POINT (v1)", 0x80: "$DATA",
    # type 0x90 is OVERLOADED by owning-object schema: $I30_INDEX when embedded in dir entries (#278),
    # but a table payload at the top level of system objects (e.g. the Upcase table on OID 0x7). NOT $SI.
    0x90: "$I30_INDEX / table payload (schema-dependent)",
    0xA0: "$INDEX_ROOT", 0xB0: "$SNAPSHOT/ADS", 0xC0: "$REPARSE_POINT (v2)",
    0xD0: "$EA_INFORMATION", 0xE0: "$EA/WSL", 0xF0: "$LOGGED_UTILITY_STREAM",
    0x100: "$EFS",  # embedded EFS-metadata sub-record ("$CBW4" in prior work is a fabrication — CBW4.md/E35)
}

def _parse_si_full(vd, vmaj, vmin):
    """Parse full $SI from a type 0x10 attribute value. vd starts at the SI base. (Only type 0x10 is $SI —
    type 0x90 is $I30_INDEX / a table payload, never a $SI; see #426.)"""
    si = {}
    if len(vd) < 0x28:
        return si
    # SI base is at vd+0x28 for type 0x10 in an OID's own B+-tree
    # The value starts with 0x28 bytes of attribute header, then SI fields
    base = 0x28
    if len(vd) < base + 0x58:
        return si
    si["create_time"] = filetime_to_iso(le64(vd, base + 0x00))
    si["modify_time"] = filetime_to_iso(le64(vd, base + 0x08))
    si["change_time"] = filetime_to_iso(le64(vd, base + 0x10))
    si["access_time"] = filetime_to_iso(le64(vd, base + 0x18))
    si["file_attrs"] = f"0x{le32(vd, base + 0x20):08x} ({attrs_to_str(le32(vd, base + 0x20))})"
    si["internal_flags"] = f"0x{le32(vd, base + 0x24):02x}"
    si["security_id"] = f"0x{le64(vd, base + 0x28):x}"
    si["si_field_0x30"] = f"0x{le64(vd, base + 0x30):x}"     # raw $SI+0x30: UNPOPULATED (0 on 0/32,629 own-rows) — NOT a USN. The file's USN is last_usn below. E30 retracted / E45.
    si["datasize"] = le64(vd, base + 0x38)   # raw $SI+0x38: 0 on own-rows; the type-0x30 index entry carries FileSize@value+0x58 / AllocSize@value+0x60 instead (E26/E30/E45)
    # 0x40/0x48: USN change-journal fields — the real per-file → journal link (E27)
    si["last_usn"] = f"0x{le64(vd, base + 0x40):x}"          # file's last USN = virtual $UsnJrnl:$J byte offset (proven 14/14, 480/480 record-name matches)
    si["usn_journal_id"] = le64(vd, base + 0x48)             # USN journal instance id (one per volume)
    if len(vd) >= base + 0x58:
        si["packed_ea_size_or_reparse_low"] = le32(vd, base + 0x50)
        si["reparse_tag"] = f"0x{le32(vd, base + 0x54):08x}"
        rt = le32(vd, base + 0x54)
        if rt in REPARSE_TAGS:
            si["reparse_tag"] += f" ({REPARSE_TAGS[rt]})"
    is_win11 = vmin >= 7
    if is_win11 and len(vd) >= base + 0x7C:
        si["next_file_id"] = le64(vd, base + 0x58)            # directory child-creation ordinal (was "VersionRefCount")
        si["external_file_id_2"] = f"0x{le64(vd, base + 0x60):x}"
        si["external_file_id_3"] = f"0x{le64(vd, base + 0x68):x}"
        si["hard_link_count"] = le32(vd, base + 0x70)
        si["next_stream_set_id"] = f"0x{le64(vd, base + 0x74):x}"   # base 0xF000 (was "ExternalFileObjectId")
    elif not is_win11 and len(vd) >= base + 0x74:
        si["next_file_id"] = f"0x{le64(vd, base + 0x58):x}"   # v3.4 "ExternalFileId_1" = same NextFileId ordinal
        si["external_file_id_2"] = f"0x{le64(vd, base + 0x60):x}"
        si["external_file_id_3"] = f"0x{le64(vd, base + 0x68):x}"
        si["hard_link_count"] = le32(vd, base + 0x70)
    return si

def cmd_oid_detail(f, ps, cs, tr, obj_map, vmaj, vmin, target_oid, json_mode=False, log_fn=None):
    """Dump all attributes for a specific OID."""
    if target_oid not in obj_map:
        return None

    vlcns = obj_map[target_oid]
    try:
        rows = walk_bplus(f, ps, cs, tr, vlcns)
    except Exception as e:
        return {"error": str(e)}

    # Group rows by attribute type
    attrs = {}
    for kd, vd in rows:
        if len(kd) < 2:
            continue
        attr_type = le16(kd, 0)
        key_extra = kd[2:] if len(kd) > 2 else b""
        attrs.setdefault(attr_type, []).append({"key": kd, "key_extra": key_extra, "value": vd})

    result = {
        "oid": f"0x{target_oid:x}",
        "vlcns": [f"0x{v:x}" for v in vlcns],
        "attribute_count": len(rows),
        "attribute_types": sorted(attrs.keys()),
        "attributes": {},
    }

    for at in sorted(attrs.keys()):
        type_name = _ATTR_NAMES.get(at, f"Unknown(0x{at:x})")
        # C7: schema = definition code + 0x100 for EVERY type EXCEPT $SI (def 0x10 / embedded 0x90 ->
        # schema 0x190 — the one def!=embedded case). The old (at<<4)+0x100 was wrong for all types incl $DATA.
        schema_id = f"0x{(0x190 if at == 0x10 else at + 0x100):x}" if at <= 0x100 else f"0x{at:x}"
        entries = attrs[at]
        attr_info = {"type": f"0x{at:02x}", "name": type_name, "schema": schema_id, "count": len(entries), "entries": []}

        for ent in entries:
            kd, vd = ent["key"], ent["value"]
            entry_data = {"key_len": len(kd), "value_len": len(vd)}

            if at == 0x10 and len(vd) >= 0x80:   # $SI is type 0x10 only — type 0x90 is $I30_INDEX / a table payload (Upcase on OID 0x7), NOT $SI (#426; 0/215 type-0x90 rows parse as a valid $SI corpus-wide)
                entry_data["si"] = _parse_si_full(vd, vmaj, vmin)
                # Directory/object EAs live in this type-0x10 record (same embedded $EA sub-records).
                _eas, _packed = extract_eas_from_value(vd)
                if _eas is not None and sum(5 + len(e["name"]) + len(e["value"]) for e in _eas) == _packed:
                    entry_data["packed_ea_size"] = _packed
                    entry_data["extended_attributes"] = [{"name": e["name"], "length": len(e["value"]),
                                                          "value_hex": e["value"].hex()} for e in _eas]
                    _w = decode_wsl_eas(_eas)
                    if _w:
                        _wj = dict(_w)
                        if "mode" in _w: _wj["mode_decoded"] = decode_lx_mode(_w["mode"])
                        entry_data["wsl"] = _wj
            elif at == 0x30:
                try:
                    name = kd[4:].decode("utf-16-le").rstrip("\x00")
                except UnicodeDecodeError:
                    name = kd[4:].hex()
                entry_data["filename"] = name
                if len(vd) <= NON_RESIDENT_MAX_VALUE:
                    entry_data["storage"] = "non-resident"
                    entry_data["file_size"] = le64(vd, 0x38) if len(vd) >= 0x40 else 0
                    entry_data["file_attrs"] = f"0x{le32(vd, 0x40):08x}" if len(vd) >= 0x44 else "0x0"
                    # val+0x08 is the child's own OID only for a SUBDIRECTORY (dir-bit set). For a
                    # non-resident FILE it is the home-dir backref (a different object), not the file's
                    # OID -- files have no own OID -- so label it accordingly rather than as "child_oid".
                    if len(vd) >= 0x10:
                        if len(vd) >= 0x44 and (le32(vd, 0x40) & 0x10000000):
                            entry_data["child_oid"] = f"0x{le64(vd, 0x08):x}"
                        else:
                            entry_data["home_backref"] = f"0x{le64(vd, 0x08):x}"
                else:
                    entry_data["storage"] = "resident"
                    entry_data["value_size"] = len(vd)
            elif at == 0x40:
                # A type-0x40 row is a non-resident child's backing/stream record (same layout as the
                # resident type-0x30 value): file_size@0x58, alloc_size@0x60; the data runs live in
                # embedded sub-records at 0xA8+. The low bytes at 0x00/0x08 are descriptor/sentinel
                # header, NOT a vlcn / cluster_count (corrected 2026-06-27; cf. _parse_extents_from_type40).
                entry_data["extent_key"] = kd.hex() if len(kd) > 2 else ""
                if len(vd) >= 0x68:
                    entry_data["backing_size"] = le64(vd, 0x58)
                    entry_data["backing_alloc"] = le64(vd, 0x60)
                    entry_data["cluster_count"] = (le64(vd, 0x60) + cs - 1) // cs if le64(vd, 0x60) else 0
            elif at == 0x80:
                # $DATA sub-records
                if len(kd) > 4:
                    try:
                        stream_name = kd[4:].decode("utf-16-le").rstrip("\x00")
                        entry_data["stream_name"] = stream_name if stream_name else "(default)"
                    except UnicodeDecodeError:
                        entry_data["stream_name"] = kd[4:].hex()
                else:
                    entry_data["stream_name"] = "(default)"
                entry_data["data_size"] = len(vd)
            elif at == 0xC0:
                if len(vd) >= 4:
                    tag = le32(vd, 0)
                    entry_data["reparse_tag"] = f"0x{tag:08x}"
                    if tag in REPARSE_TAGS:
                        entry_data["reparse_tag"] += f" ({REPARSE_TAGS[tag]})"
                    entry_data["target"] = extract_inline_reparse(vd) if len(vd) > 8 else ""
            else:
                entry_data["raw_hex"] = vd[:64].hex() + ("..." if len(vd) > 64 else "")

            attr_info["entries"].append(entry_data)
        result["attributes"][f"0x{at:02x}"] = attr_info

    return result

def _print_oid_detail(detail, path=None, sd_map=None):
    """Detail for a DIRECTORY / system object.

    It used to open straight into the raw structural dump — VLCNs, attribute types, field names like
    `si_field_0x30` — which is a different thing from the labelled summary a FILE gets, for no good reason:
    a directory has the same identity, timestamps, ownership and attributes a file does. It now leads with
    that summary, using the same labels and order as `details <file>` and the `files` columns, and the
    structural dump follows unchanged so nothing is lost."""
    w = 78
    si = (detail.get("attributes", {}).get("0x10", {}).get("entries") or [{}])[0].get("si", {}) or {}
    def _si(k, default=""):
        v = si.get(k, default)
        return "" if v is None else v
    print("=" * w)
    print(f"Directory Detail: {path or detail['oid']}")
    print("=" * w)
    print(f"  ObjectRef:          {detail['oid']}:0x0   (a directory is its own home, ordinal 0)")
    if path:
        print(f"  Path:               {path}")
    print(f"  Created:            {_si('create_time')}")
    print(f"  Modified:           {_si('modify_time')}")
    print(f"  Changed:            {_si('change_time')}")
    print(f"  Accessed:           {_si('access_time')}")
    # Child count — what a reader actually wants from a directory, and it is simply the number of name rows.
    _kids = detail.get("attributes", {}).get("0x30", {}).get("count")
    if _kids is not None:
        print(f"  Child entries:      {_kids}   (type-0x30 name rows in this directory)")
    print("  Is directory:       True")
    print(f"  File attributes:    {_si('file_attrs')}")
    _sec = _si("security_id")
    print(f"  Security ID:        {_sec}")
    if sd_map and _sec:
        try:
            _key = int(str(_sec), 16) if str(_sec).startswith("0x") else int(_sec)
        except (TypeError, ValueError):
            _key = None
        _sd = (sd_map.get(_key) or ("", "", "")) if _key is not None else ("", "", "")
        if _sd[0]:
            print(f"  Owner SID:          {_sid_display(_sd[0])}")
            print(f"  Group SID:          {_sid_display(_sd[1])}")
            if _sd[2]:
                print(f"  DACL:               {_sd[2]}")
    if _si("last_usn"):
        print(f"  USN:                {_si('last_usn')}")
    if _si("internal_flags"):
        print(f"  Internal flags:     {_si('internal_flags')}")
    if str(_si("reparse_tag")) not in ("", "0x00000000"):
        print(f"  Reparse tag:        {_si('reparse_tag')}")
    print()
    print("-" * w)
    print("  On-disk structure")
    print("-" * w)
    print(f"  VLCNs:              {', '.join(detail['vlcns'])}")
    print(f"  Total rows:         {detail['attribute_count']}")
    print(f"  Attribute types:    {', '.join(f'0x{t:02x}' for t in detail['attribute_types'])}")

    for at_key, attr_info in detail["attributes"].items():
        print()
        print("-" * w)
        print(f"  Type {attr_info['type']} ({attr_info['name']}) — Schema {attr_info['schema']} — {attr_info['count']} entries")
        print("-" * w)
        for ent in attr_info["entries"]:
            if "si" in ent:
                for k, v in ent["si"].items():
                    print(f"    {k:<30} {v}")
                if "extended_attributes" in ent:
                    print(f"    {'PackedEaSize':<30} {ent['packed_ea_size']}")
                    wsl = ent.get("wsl")
                    if wsl:
                        if "mode_decoded" in wsl: print(f"    {'WSL Mode':<30} {wsl['mode_decoded']}")
                        if "uid" in wsl: print(f"    {'WSL UID':<30} {wsl['uid']}")
                        if "gid" in wsl: print(f"    {'WSL GID':<30} {wsl['gid']}")
                        if "dev" in wsl: print(f"    {'WSL Device':<30} {wsl['dev'][0]},{wsl['dev'][1]} (major,minor)")
                    for ea in ent["extended_attributes"]:
                        hexs = ea["value_hex"][:32] + ("…" if len(ea["value_hex"]) > 32 else "")
                        print(f"    EA {ea['name']:<27} {ea['length']:>4}B  {hexs}")
            elif "filename" in ent:
                print(f"    Filename:         {ent['filename']}")
                print(f"    Storage:          {ent['storage']}")
                if ent.get("child_oid"):
                    print(f"    Child OID:        {ent['child_oid']}")
                if ent.get("home_backref"):
                    print(f"    Home-dir backref: {ent['home_backref']}")
                if "file_size" in ent:
                    print(f"    File size:        {ent['file_size']} ({_human_size(ent['file_size'])})")
                if "file_attrs" in ent:
                    print(f"    File attrs:       {ent['file_attrs']}")
            elif "extent_key" in ent:
                if "backing_size" in ent:
                    print(f"    Backing record:   size {ent['backing_size']} ({_human_size(ent['backing_size'])}), "
                          f"alloc {ent['backing_alloc']} ({ent.get('cluster_count', 0)} clusters); runs in sub-records")
                else:
                    print(f"    Backing record:   value {ent['value_len']}B (no size header)")
            elif "stream_name" in ent:
                print(f"    Stream:           {ent['stream_name']}")
                print(f"    Data size:        {ent['data_size']} bytes")
            elif "reparse_tag" in ent:
                print(f"    Reparse tag:      {ent['reparse_tag']}")
                if ent.get("target"):
                    print(f"    Target:           {ent['target']}")
            else:
                print(f"    Key: {ent['key_len']}B  Value: {ent['value_len']}B")
                if ent.get("raw_hex"):
                    print(f"    Hex:              {ent['raw_hex']}")


def _print_file_detail(r, sd_map, version_str, raw_value=None, oid2path=None):
    """Labeled detail view for one FILE resolved by path (F6). A strict superset of the `files` field set
    (so `details` never shows less than a `files` row), plus (from raw_value, when resident) Extended
    Attributes / WSL Linux metadata / internal flags. `oid2path` (OID→path from the walk) resolves the
    creation directory (HomeOID), matching the `files` CreationDir column."""
    w = 78
    print("=" * w)
    print(f"File Detail: {r.get('path', '')}")
    print("=" * w)
    oid = r.get("oid", 0)
    sec = r.get("security_id", 0)
    _sd = (sd_map.get(sec) or ("", "", "")) if sec else ("", "", "")
    owner, group = _sd[0], _sd[1]
    fa = r.get("file_attrs", 0)
    al = r.get("allocated_size")
    rtag = r.get("reparse_tag_value", 0)
    # EAs (resident value or non-resident backing). Extract once: drives both the "EA" flag (authoritative
    # via the $EA_INFORMATION sub-record — the file_attrs 0x40000 bit is NOT set on the non-resident
    # type-0x30 pointer) and the detail block below.
    _eas, _packed = extract_eas_from_value(raw_value) if raw_value is not None else (None, None)
    _has_ea = _eas is not None
    # Phase C: ONE identity line, matching the `files` ObjectRef column — a directory has an OID, a file has
    # a FileRef; they were never both populated.
    _fref = _file_ref(r)
    if oid:
        print(f"  ObjectRef:          0x{oid:x}:0x0   (a directory is its own home, ordinal 0)")
    elif _fref:
        print(f"  ObjectRef:          {_fref}   (FileRef = HomeOID:FileID, the directory the file was CREATED in)")
    else:
        print("  ObjectRef:          (none resolved)")
    # Relocation signal (F-1): a file whose HOME (creation dir, value+0x08) differs from its current parent
    # was either moved out of its creation directory (single name) or hard-linked into another directory
    # (>1 name) — told apart by the hard-link count. HomeOid is frozen at creation; the parent is the
    # current namespace.
    _home = r.get("home_oid") or 0
    _par = r.get("parent_oid") or 0
    if not r.get("is_dir") and _home and _par and _home != _par:
        if (r.get("hard_link_count", 1) or 1) > 1:
            print(f"  Home directory:     0x{_home:x}   hard-link name — created here, not in 0x{_par:x}")
        else:
            print(f"  Home directory:     0x{_home:x}   ⚠ moved: created here, now under parent 0x{_par:x}")
    # Field order mirrors the `files` columns, so the two views read the same way.
    print(f"  Name:               {r.get('name', '')}")
    print(f"  Extension:          {ext_from_name(r.get('name', ''))}")
    print(f"  File size:          {r.get('file_size', 0)} ({_human_size(r.get('file_size', 0))})")
    print(f"  Created:            {filetime_to_iso(r.get('create_time', 0))}")
    print(f"  Modified:           {filetime_to_iso(r.get('modify_time', 0))}")
    print(f"  Changed:            {filetime_to_iso(r.get('change_time', 0))}")
    print(f"  Accessed:           {filetime_to_iso(r.get('access_time', 0))}")
    print(f"  Parent path:        {r.get('parent_path', '')}")
    print(f"  Parent OID:         {('0x%x' % _par) if _par else ''}")
    if oid2path is not None and _home:
        _cdir = oid2path.get(_home, "")
        if _cdir:
            print(f"  Creation dir:       {_cdir}")
    if _home:
        print(f"  HomeOID:            0x{_home:x}   (the directory this file was CREATED in; unchanged by move/rename)")
    if r.get("file_id"):
        print(f"  FileID:             0x{r['file_id']:x}")
    print(f"  Is directory:       {r.get('is_dir', False)}")
    print(f"  Data residency:     {_data_residency(r) or '(directory)'}")
    print(f"  Is moved:           {_is_moved(r)}")
    if r.get("is_deleted"):
        print(f"  Is deleted:         True ({r.get('deletion_source', '')})")
    print(f"  Allocated size:     {'' if al is None else f'{al} ({_human_size(al)})'}")
    print(f"  File attributes:    0x{fa:08x} ({attrs_to_str(fa)})")
    if r.get("internal_flags"):
        print(f"  Internal flags:     0x{r['internal_flags']:02x}")
    print(f"  Security ID:        {sec if sec else ''}")
    print(f"  Owner SID:          {_sid_display(owner)}")
    print(f"  Group SID:          {_sid_display(group)}")
    if _sd[2]:
        print(f"  DACL:               {_sd[2]}")
    print(f"  USN:                {r.get('usn', 0) or ''}")
    if r.get("has_ads"):
        _adsn = [n for n in str(r.get("ads_names", "")).split(";") if n]
        _pp = r.get("path") or r.get("name")
        _adsst = r.get("ads_storage") or {}
        print(f"  Alternate streams:  {'; '.join(_adsn)}")
        for _nm in _adsn:
            # Say where each stream's bytes are. An ADS at or above 2 KiB is extent-backed, and a name on
            # its own reads as though the content were in the record.
            print(f"                        {_nm} — {_adsst.get(_nm, 'unknown')}"
                  f"   ·  read it:  export ads \"{_pp}:{_nm}\"")
    flags = [n for n, k in (("Encrypted", "is_encrypted"), ("Compressed", "is_compressed"),
                            ("IntegrityStream", "has_integrity")) if r.get(k)]
    if r.get("file_attrs", 0) & 0x200:            # FILE_ATTRIBUTE_SPARSE_FILE — matches files.IsSparse
        flags.append("Sparse")
    if _has_ea or r.get("has_ea"):
        flags.append("EA")
    if flags:
        print(f"  Flags:              {', '.join(flags)}")
    if r.get("reparse_target"):
        print(f"  Reparse target:     {r['reparse_target']}")
    if rtag:
        print(f"  Reparse tag:        {reparse_tag_str(rtag)}")
    if not r.get("is_resident") and not r.get("is_dir"):
        print(f"  Hard-link count:    {r.get('hard_link_count', 1)}")
        if r.get("hard_link_names"):
            for nm in r["hard_link_names"]:
                print(f"                        {nm}")
    if r.get("snapshot_count", 0) > 0:
        print(f"  Snapshot count:     {r['snapshot_count']}   (preview: snapshots --file {r['name']} --show · extract: export snapshots DIR --file {r['name']})")
        if r.get("snapshot_names"):
            print(f"  Snapshot names:     {r['snapshot_names']}")
    ifl = internal_flags_str(r.get("internal_flags", 0))
    if ifl:
        print(f"  Internal flags:     {ifl}")
    # Extended Attributes + WSL/Linux metadata. PackedEaSize from the $EA_INFORMATION sub-record
    # (authoritative). Only the four driver-recognised $LX EAs are decoded; all other EA values are
    # shown name+size+raw-hex only. (_eas/_packed extracted near the top.)
    if raw_value is not None:
        eas, packed = _eas, _packed
        if eas is not None:
            print(f"  PackedEaSize:       {packed}")
            # Oracle gate: only surface the parsed list/WSL when PackedEaSize == Σ(5+nameLen+valLen).
            # A mismatch means the backing was mis-resolved (file_id collision) — show nothing rather
            # than a wrong EA list (never display an unproven value).
            if sum(5 + len(e["name"]) + len(e["value"]) for e in eas) != packed:
                print("    (EA content could not be resolved reliably — not shown)")
            else:
                wsl = decode_wsl_eas(eas)
                if wsl:
                    print("  WSL/Linux metadata:")
                    if "mode" in wsl:
                        print(f"    Mode:             {decode_lx_mode(wsl['mode'])}")
                    if "uid" in wsl:
                        print(f"    UID:              {wsl['uid']}")
                    if "gid" in wsl:
                        print(f"    GID:              {wsl['gid']}")
                    if "dev" in wsl:
                        print(f"    Device:           {wsl['dev'][0]},{wsl['dev'][1]} (major,minor)")
                if eas:
                    print(f"  Extended Attributes ({len(eas)}):")
                    for ea in eas:
                        v = ea["value"]
                        hexs = v[:16].hex() + ("…" if len(v) > 16 else "")
                        print(f"    {ea['name']:<22} {len(v):>4}B  {hexs}")
    print(f"  ReFS version:       {version_str}")

def cmd_search(f, ps, cs, tr, obj_map, vmaj, vmin, pattern, regex_mode=False, max_results=0, filter_cat=None):
    """Search for files/directories by name pattern (live tree only; deleted objects → the `deleted` command).
    `filter_cat` (§5) restricts matches to one attribute category (same as `files --filter`); it enriches the
    walk (slower) so the category predicates have the fields they need."""
    import re
    if regex_mode:
        try:
            pat = re.compile(pattern, re.IGNORECASE)
        except re.error as e:
            return {"error": f"Invalid regex: {e}"}
        match_fn = lambda name: pat.search(name)
    else:
        pat_lower = pattern.lower()
        match_fn = lambda name: pat_lower in name.lower()

    # Enrich only when a category filter is requested (the category predicates need has_ads/reparse/… ) —
    # a plain name search stays fast (enrich=False). Full depth by default (4.D).
    _pred = FILE_FILTERS[filter_cat] if filter_cat else None
    results = walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, DEFAULT_DEPTH, bool(filter_cat), set())
    matches = []
    for r in results:
        if not match_fn(r["name"]):
            continue
        if _pred is not None and not _pred(r):
            continue
        matches.append({
            # E87 vocabulary: `is_resident` is the DATA axis (it is refined by F5 from the $DATA
            # descriptor), so the words here are the data-residency words. They were "(resident)" and
            # "(non-res)", which named the axis ambiguously and did not match any value `files` prints.
            "oid": f"0x{r['oid']:x}" if r["oid"] else ("(inline)" if r.get("is_resident") else "(extents)"),
            # Phase C: the single identity a reader can act on — a directory's OID, or a file's FileRef.
            "id": (f"0x{r['oid']:x}" if r["oid"] else (_file_ref(r) or "")),
            "parent_oid": f"0x{r['parent_oid']:x}" if r.get("parent_oid") else "",
            "type": "Dir" if r["is_dir"] else "File",
            "file_size": r.get("file_size", 0),
            "is_resident": (_data_residency(r) == DATA_INLINE),
            # E87: the listing says WHICH form, not a yes/no -- collapsing four states into one
            # boolean is the conflation this release removes from the CSV, so the human view
            # must not reintroduce it.
            "data": _data_residency(r),
            "path": r["path"],
            "name": r["name"],
            "is_deleted": r.get("is_deleted", False),
            # F11: the walk already carries MACB — surface Modified/Created so a name hit is time-contextualised.
            "modified": filetime_to_iso(r.get("modify_time", 0)),
            "created": filetime_to_iso(r.get("create_time", 0)),
        })
        if max_results and len(matches) >= max_results:
            break
    return matches

def _print_search(matches, pattern):
    if not matches:
        print(f"No matches for \"{pattern}\"")
        return
    # Phase C: one identity column (a directory's OID, a file's FileRef) — the old OID column carried
    # "(non-res)"/"(resident)" placeholders for files, which said nothing about identity and duplicated the
    # Res column. `Parent` is dropped: the parent directory is already visible in Path.
    # The value set here is EXACTLY the CSV's DataResidency set -- one vocabulary, not an abbreviation
    # for the human view and a longer token for the machine one. That divergence is what E87 corrects.
    print(f"{'ObjectRef':<14} {'Type':<5} {'Size':>12}  {'Data':<15}  {'Modified':<19}  Path")
    print(f"{'─'*13}  {'─'*4}  {'─'*12}  {'─'*15}  {'─'*19}  {'─'*40}")
    for m in matches:
        size_str = _human_size(m["file_size"]) if m["file_size"] else "0"
        res = m.get("data") or ""
        if m["type"] == "Dir":
            res = "—"
        del_mark = " [DEL]" if m.get("is_deleted") else ""
        mod = (m.get("modified") or "")[:19]
        print(f"{m.get('id') or m['oid']:<14} {m['type']:<5} {size_str:>12}  {res:<15}  {mod:<19}  {m['path']}{del_mark}")
    n = len(matches)
    print(f"\n{n} match{'es' if n != 1 else ''}. Use `details <path>`, `details --id FileRef` "
          f"(HomeOID:FileID) or `details --id OID` for full detail.")

# ─── Bootstrap ────────────────────────────────────────────────────────
def bootstrap(image_path, partition_start=None):
    """Bootstrap the full ReFS parsing chain.
    Returns (f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns)."""
    if partition_start is not None:
        ps = partition_start
    else:
        ps, desc = find_refs_partition(image_path)
        if ps is None:
            raise ValueError(desc)

    f = open(image_path, "rb")
    try:
        cs, vmaj, vmin, chk_algo, bpc = parse_vbr(f, ps)
        cpc = bpc // cs

        chkp_lcns = parse_supb(f, ps, cs)

        # Get newest checkpoint
        best_vc = 0; best_roots = None
        for cl in chkp_lcns:
            try:
                vc, flags, roots = parse_chkp(f, ps, cs, cl)
                if vc >= best_vc:
                    best_vc = vc; best_roots = roots
            except Exception:
                continue
        if not best_roots:
            raise ValueError(
                "no valid checkpoint could be parsed from the superblock's checkpoint list — the bootstrap "
                "chain (VBR -> SUPB -> CHKP) is damaged. Inspect it with `refsanalysis.py <image> supb -v` "
                "and `chkp -v`, or diagnose with `refsanalysis.py <image> bootedit repair --dry-run`.")

        # Build container table translator — select by Table-ID 0x0B, not by root index 7 (#337)
        ct_vlcns = _select_ct_root(f, ps, cs, best_roots)
        ct_page = b""
        for l in ct_vlcns: f.seek(ps + l * cs); ct_page += f.read(cs)
        ct_map_raw = _parse_ct_page(ct_page, f, ps, cs)
        ct_map = {k: v[0] for k, v in ct_map_raw.items()}
        tr = Translator(ct_map, cpc)
        try:    tr._image = os.path.basename(image_path)   # audit 4.2: label the caveat with its image
        except Exception:   pass
        _ALL_TRS.append(tr)   # audit 3.2/4.2: remember Translators so their caveat can be surfaced at exit
        del _ALL_TRS[:-4]     # ...but keep only the most recent few. A CLI run builds 1 (2 for --cow-before);
                              # capping stops a long-running LIBRARY process (e.g. verify_claim bootstrapping the
                              # whole corpus in one process) from accumulating every container map — the old
                              # single _LAST_TR never grew, and this must not regress that.

        # Build object map
        ot_vlcns = _select_ot_root(f, ps, cs, tr, best_roots)
        obj_map = build_object_map(f, ps, cs, tr, ot_vlcns)

        return f, ps, cs, tr, best_roots, obj_map, vmaj, vmin, chkp_lcns
    except Exception:
        f.close()
        raise

# ─── Main ─────────────────────────────────────────────────────────────
# forefst uses an `<image> <subcommand> [options]` CLI (mirrors refsanalysis). The default subcommand is
# `files`, so `forefst <image>` still lists files. Functions are positional subcommands; format/behaviour
# modifiers stay as --flags.
# ════════════════════════════════════════════════════════════════════════
#  Migrated forensic commands (Phase 2): usn / mlog / timeline
#  Ported VERBATIM from refsanalysis (datetime refs adapted to forefst's `import datetime`).
#  They reuse the USN/MLog parsing already defined above and bootstrap the image themselves;
#  routed via FORENSIC_HANDLERS before argparse (they use flags argparse doesn't model).
# ════════════════════════════════════════════════════════════════════════

# Import-alias shims: the ported commands reference refsanalysis's `_forefst_*`/`_validate_image`
# aliases for forefst's own functions. Define them so the verbatim-copied bodies resolve identically
# (without these, e.g. cmd_deleted/cmd_integrity's `_forefst_parse_chkp` NameError'd → 0 checkpoints).
_validate_image = validate_image
_forefst_parse_vbr = parse_vbr
_forefst_parse_supb = parse_supb
_forefst_parse_chkp = parse_chkp

class _UsageExit1Parser(argparse.ArgumentParser):
    """argparse parser whose usage errors exit 1, like every hand-parsed command.

    argparse's default is 2, which is ALSO this tool's scriptable "finding of interest" code (`integrity`
    and `security --audit` return it on a real finding). That made a mistyped flag on `files` indistinguish-
    able from a genuine integrity failure. Renumbering the finding code would break every caller that
    branches on it, so the usage error moves instead: 1 on all 19 commands, and 2 now means a finding and
    nothing else. `--help` and `--version` still exit 0 -- they go through exit(), not error().
    """

    def error(self, message):
        self.print_usage(sys.stderr)
        print(f"{self.prog}: error: {message}", file=sys.stderr)
        sys.exit(1)


def die(msg, prog=None):
    """Fatal usage/runtime error: one line to stderr, exit 1 (the frozen contract -- 2 means a finding).

    `prog` exists so refsanalysis can reuse this body while still printing its OWN name. The two tools had
    byte-identical copies of this function, but each closed over its own module-level PROG, so importing it
    naively would have made refsanalysis say "forefst: error:" -- identical source is not the same as
    interchangeable when the body reads a module global.
    """
    print(f"{prog or PROG}: error: {msg}", file=sys.stderr)
    sys.exit(1)

def _looks_text(b, sample=8192):
    """Conservative text sniff for the C1 stdout-newline: no EMBEDDED NUL, and decodes as UTF-8.

    TRAILING NULs are padding, not content — a Zone.Identifier ADS ends with one, and rejecting it on that
    basis left genuine text without its newline so the next stderr line ran on to the same line."""
    chunk = b.rstrip(b"\x00")[:sample]
    if not chunk or b"\x00" in chunk:
        return False
    try:
        chunk.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False

def _check_out(dest):
    """A2: fail friendly (not a traceback) when an output path is an existing directory."""
    if dest and os.path.isdir(dest):
        die(f"output path {dest!r} is a directory — give a FILE path (e.g. {os.path.join(dest, 'out')})")

def _filetime_to_str(ft):
    if ft == 0 or ft == 0xFFFFFFFFFFFFFFFF: return "(none)"
    try:
        # integer // (not float /): float division rounds up at ~0.9999999 s, displaying a second 1 too
        # high vs filetime_to_iso's // (E12 fix). Whole-second display; format (incl. ' UTC') unchanged.
        ts = (ft - 116444736000000000) // 10000000
        return datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except (OSError, ValueError):
        return f"0x{ft:x}"

def _parse_args(remaining, flags=None, valued=None, prog=None):
    flags = flags or []
    valued = valued or []
    result = {f.lstrip("-").replace("-", "_"): False for f in flags}
    result.update({v.lstrip("-").replace("-", "_"): None for v in valued})
    result["_rest"] = []
    i = 0
    while i < len(remaining):
        a = remaining[i]
        if a in flags:
            result[a.lstrip("-").replace("-", "_")] = True
        elif a in valued:
            if i + 1 >= len(remaining):
                die(f"option {a} requires a value", prog)
            result[a.lstrip("-").replace("-", "_")] = remaining[i + 1]; i += 1
        elif a.startswith("-"):
            # reject typos / unsupported flags instead of silently treating them as a positional
            die(f"unknown option: {a}", prog)
        else:
            result["_rest"].append(a)
        i += 1
    return result

def _int_arg(val, name, base=10, prog=None):
    try:
        return int(val, base) if isinstance(val, str) else int(val)
    except (ValueError, TypeError):
        die(f"invalid value for {name}: '{val}'", prog)

def _check_unknown_flags(remaining, known_flags, valued_flags=()):
    """Reject unrecognised -flags for the manually-parsed commands (usn/mlog), matching the rejection the
    other forensic commands get from _parse_args. A valued flag consumes the next token ONLY when it is a
    real value (does not itself start with '-') — same rule those commands use to read e.g. `--csv FILE`."""
    i = 0
    while i < len(remaining):
        a = remaining[i]
        if a in valued_flags:
            if i + 1 < len(remaining) and not remaining[i + 1].startswith("-"):
                i += 2
            else:
                i += 1
            continue
        if a.startswith("-") and a != "-" and a not in known_flags:
            die(f"unknown option: {a}")     # a bare "-" is the stdout/stdin sentinel, not an unknown flag
        i += 1

# ── Phase-2 standardized data output (--csv/--json/--jsonl [FILE]) ────────────────────────────────
# One convention for every data-listing command: a bare `--csv`/`--json`/`--jsonl` writes to stdout; the
# same flag followed by a path writes that file and prints a one-line record count. Mutually exclusive.
_OUT_FMT_FLAGS = ("--csv", "--json", "--jsonl", "--body")

def _extract_output_fmt(remaining, allow=("--csv", "--json", "--jsonl")):
    """Pull an output-format selector out of `remaining` (so the caller's own parser never sees it or its
    optional FILE value). Returns (fmt, dest, cleaned_remaining): fmt in csv/json/jsonl/body or None; dest is
    the FILE path, or '-' for stdout. A second, different format flag is an error."""
    fmt = None; dest = "-"; out = []; i = 0
    while i < len(remaining):
        a = remaining[i]
        if a in allow:
            newfmt = a.lstrip("-")
            if fmt and fmt != newfmt:
                die(f"choose one output format: --{fmt} or --{newfmt}")
            fmt = newfmt
            if i + 1 < len(remaining) and not remaining[i + 1].startswith("-"):
                dest = remaining[i + 1]; i += 2
            else:
                i += 1
            continue
        out.append(a); i += 1
    return fmt, dest, out

def _emit_records(records, columns, fmt, dest, label="records"):
    """Write `records` (list of dicts) as csv/json/jsonl to stdout (dest='-'/None) or a FILE. On a FILE write,
    print 'Wrote N <label> to <file>'. `columns` is the ordered key list used for CSV (and CSV only)."""
    import csv as _csv
    to_file = dest not in (None, "-")
    if to_file: _check_out(dest)
    out = open(dest, "w", newline="", encoding="utf-8") if to_file else sys.stdout
    try:
        if fmt == "csv":
            w = _csv.writer(out)
            w.writerow(columns)
            for r in records:
                w.writerow([_csv_cell(r.get(c, "")) for c in columns])   # faithful by default; --csv-safe to guard
        elif fmt == "json":
            json.dump(records, out, indent=2, ensure_ascii=False)
            out.write("\n")
        elif fmt == "jsonl":
            for r in records:
                out.write(json.dumps(r, ensure_ascii=False) + "\n")
        else:
            die(f"unsupported output format: {fmt}")
    finally:
        if to_file:
            out.close()
    if to_file:
        print("Wrote %d %s to %s" % (len(records), label, dest))

def _native_fmt_dest(args):
    """Resolve (fmt, dest) for the native commands (files/summary/search/details) from their argparse args.
    fmt in csv/json/jsonl/body. dest = None (stdout) or a FILE path. `--json/--jsonl/--csv [FILE]` win (bare =
    stdout; +FILE = that file); a bare format flag with `-o FILE` writes to FILE; else default CSV to -o/stdout."""
    o = getattr(args, "output", None)
    def _d(v): return o if (v == "-" and o) else (None if v == "-" else v)
    if getattr(args, "json", None)  is not None: return "json",  _d(args.json)
    if getattr(args, "jsonl", None) is not None: return "jsonl", _d(args.jsonl)
    if getattr(args, "csv", None)   is not None: return "csv",   _d(args.csv)
    if getattr(args, "body", None) is not None:  return "body",  _d(args.body)
    return "csv", o

def _native_out(dest):
    """Open a text stream for the native emitters: a FILE (dest set) or stdout. Returns (stream, close?)."""
    if dest:
        _check_out(dest)
        return open(dest, "w", newline="", encoding="utf-8"), True
    import io as _io
    return _io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", newline=""), False

def _emit_json_obj(obj, dest, label="report"):
    """Write a single curated JSON object (for report-style commands whose output is not a flat record list)
    to stdout (dest='-'/None) or a FILE. Prints 'Wrote <label> to FILE' on a file write."""
    to_file = dest not in (None, "-")
    if to_file: _check_out(dest)
    out = open(dest, "w", encoding="utf-8") if to_file else sys.stdout
    try:
        json.dump(obj, out, indent=2, ensure_ascii=False, default=str)
        out.write("\n")
    finally:
        if to_file:
            out.close()
    if to_file:
        print("Wrote %s to %s" % (label, dest))

_USN_FILE_ATTR_SHORT = {
    0x0001: "R", 0x0002: "H", 0x0004: "S", 0x0010: "D",
    0x0020: "A", 0x0040: "Dev", 0x0080: "N", 0x0100: "Tmp",
    0x0200: "Sparse", 0x0400: "Reparse", 0x0800: "Compress",
    0x1000: "Offline", 0x2000: "NCI", 0x4000: "Encrypt",
    0x8000: "Integrity", 0x00020000: "NoScrub",
    0x10000000: "Dir",
}

def _usn_attrs_short(attrs):
    parts = []
    for bit, name in sorted(_USN_FILE_ATTR_SHORT.items()):
        if attrs & bit:
            parts.append(name)
    return ",".join(parts) if parts else "0x%08x" % attrs

def _usn_filetime_iso(ft):
    if ft == 0:
        return ""
    try:
        us = (ft - 116444736000000000) // 10
        if us < 0:
            return "0x%016x" % ft
        dt = datetime.datetime(1970, 1, 1) + datetime.timedelta(microseconds=us)
        return dt.strftime("%Y-%m-%dT%H:%M:%S") + ".%03dZ" % (dt.microsecond // 1000)
    except (OverflowError, OSError, ValueError):
        return "0x%016x" % ft

def _usn_filetime_short(ft):
    if ft == 0:
        return ""
    try:
        us = (ft - 116444736000000000) // 10
        if us < 0:
            return "0x%016x" % ft
        dt = datetime.datetime(1970, 1, 1) + datetime.timedelta(microseconds=us)
        return dt.strftime("%Y-%m-%d %H:%M:%S") + " UTC"
    except (OverflowError, OSError, ValueError):
        return "0x%016x" % ft

def _usn_resolve_path(oid, oid_paths):
    if oid == 0:
        return ""
    if oid in oid_paths:
        return oid_paths[oid]
    if oid < 0x700:
        return "<system 0x%x>" % oid
    return "<oid 0x%x>" % oid

_MLOG_INFO_TEXT = """\
=== MLog Parser — Action Reference ===

ACTIONS (classified from redo opcode sequences)
──────────────────────────────────────────────────────────────────────
  CREATE      New file or directory created (OpenTable + InsertRow +
              SetParentId). The name comes from the InsertRow value.
  DELETE      File or directory deleted — the object's own table is
              destroyed (RedoDeleteTable, opcode 0x0F). A bare DeleteRow
              with no DeleteTable is NOT a deletion (see ENTRY_REMOVE).
  RENAME      Name changed in the same directory: DeleteRow of old name +
              InsertRow of new name under the SAME parent-directory OID.
  MOVE        Moved to a different directory: DeleteRow + InsertRow whose
              parent-directory OIDs DIFFER. (On v3.14 a same-dir rename
              also carries RedoReparentTable, so the parent OID — not the
              reparent opcode — is the move/rename distinguisher.)
  ENTRY_REMOVE  Lone DeleteRow with no matching InsertRow — a name-entry
              removal (e.g. the old-name half of a rename/move), NOT a
              file deletion.
  REPARENT    RedoReparentTable seen without a resolvable rename/move
              name pair.
  WRITE       File data written — typically InsertRow + SetObjectRecord
              or InsertRow + UpdateDataWithRoot.
  MODIFY      Metadata update: UpdateRow, UpdateDataWithRoot,
              SetRangeState, or SetObjectRecordPayload.
  UPDATE      Row replacement: DeleteRow + InsertRow on the same table.
  INSERT      Single InsertRow without other context.
  ALLOCATE    Space allocation or deallocation without row changes.
  STREAM_UPD  Stream-level update (UpdateStreamUserPayload).
  CONTAINER   Container table change (RedoMoveContainer / AddContainer).
  DEDUP       Data deduplication (RedoDuplicateCluster).
  EXTENT_MOD  Extent-level modification.
  OP          Unclassified opcode combination.

__REDO_OPCODES__

TIMESTAMPS
──────────────────────────────────────────────────────────────────────
  MLog records do not have a dedicated timestamp field in their
  header. Timestamps shown in --parse and --csv are extracted from
  the VALUE DATA of records that modify file metadata.

SCHEMA NAMES
──────────────────────────────────────────────────────────────────────
"""

def _gen_redo_opcode_table():
    """R4: render the REDO opcode reference from REDO_OPS_V314 so `mlog --info` cannot go stale — the old
    hand-maintained block stopped at 0x13, omitting 28 of the 44 v3.14 opcodes (MoveContainer, GhostExtents,
    the compression/dedup/encrypt ops, the 0x17 error slot). Generated the same way `op_short` is (C4)."""
    out = ["REDO OPCODES (generated from REDO_OPS_V314 — PerformRedo dispatch, E2; v3.4 uses a 0x00–0x1C subset)",
           "─" * 70]
    for op in sorted(REDO_OPS_V314):
        out.append("  0x%02X  %s" % (op, REDO_OPS_V314[op]))
    return "\n".join(out)

_MLOG_INFO_TEXT = _MLOG_INFO_TEXT.replace("__REDO_OPCODES__", _gen_redo_opcode_table())

def _redo_ops_for_version(vmin):
    """Pick the redo-opcode dispatch table for a ReFS minor version.

    v3.4 → REDO_OPS_V34 (29 ops, 0x00–0x1C). **v3.7 and up → REDO_OPS_V314.** On-disk evidence
    shows v3.7/v3.9/v3.10 all use the v3.14 opcode SUBSET — including the 0x1D–0x1F stream ops that
    are absent from v3.4 — and never emit the version-ambiguous 0x16/0x17, so V314 names them
    correctly. The previous `vmin >= 9` boundary mis-routed v3.7 to V34 and left its 0x1F records
    unresolved (78 on win1121h2test). No v3.7–v3.10 driver exists to decompile; this routing is
    RD-validated to 0 unknown opcodes across the whole corpus. (finding #330)"""
    return REDO_OPS_V314 if vmin >= 7 else REDO_OPS_V34

def _mlog_pair_si_timestamp(f, ps_off, cs, plcn, block):
    """A rename / permanent-delete redo transaction carries NO inline FILETIME — the event time is written to
    the paired $SI-update in the NEXT 4 KiB LogCore block, whose $SI MACB quartet sits at +0x140. Return that
    FILETIME (the create/modify/change stamp), or 0 if the next block is not a $SI-update.

    Discriminator (RD, bi0sCTF v3.4): a $SI-update block has >=3 valid FILETIMEs at +0x140/+0x148/+0x150; a redo
    block has 0 there — so this can never borrow a redo block's bytes. Used ONLY for a transaction that has no
    inline timestamp, so it can only ADD an event time, never change one. 6/6 CTF rename/delete events exact
    (structure_reference §MLog; redo_opcode_complete.md 'Transaction & timestamp model')."""
    per = max(1, cs // MLOG_BLOCK)
    nb_plcn, nb_block = (plcn, block + 1) if block + 1 < per else (plcn + 1, 0)
    try:
        f.seek(ps_off + nb_plcn * cs + nb_block * MLOG_BLOCK)
        blk = f.read(MLOG_BLOCK)
    except (OSError, ValueError):
        return 0
    if len(blk) < 0x158:
        return 0
    q = [le64(blk, 0x140 + 8 * i) for i in range(3)]     # $SI create / modify / change
    return q[0] if all(_FT_MIN < t < _FT_MAX for t in q) else 0


# Actions whose event FILETIME is not inline but in the paired next-block $SI-update (name change / deletion).
_MLOG_PAIRED_TS_ACTIONS = ("RENAME", "MOVE", "UPDATE", "DELETE", "ENTRY_REMOVE", "REPARENT")

def _mlog_resolve_txn(txn, oid_paths, f=None, ps_off=None, cs=None):
    recs = txn["records"]
    action = classify_mlog_transaction(recs)
    # op_detail: the concrete fact that justifies the label, so the enhancement stays verifiable.
    op_detail = ""
    if action in ("MOVE", "RENAME"):
        _hmap = _mlog_handle_oid_map(recs)
        _old = sorted(_mlog_name_entry_parents(recs, 0x02, _hmap))
        _new = sorted(_mlog_name_entry_parents(recs, 0x01, _hmap))
        if action == "MOVE" and _old and _new:
            op_detail = "parent 0x%x → 0x%x" % (_old[0], _new[0])
        elif action == "RENAME" and _new:
            op_detail = "same parent 0x%x" % _new[0]
    elif action == "DELETE" and any(r["opcode"] == 0x0F for r in recs):
        op_detail = "object table destroyed"
    handle_oids = {}
    for r in recs:
        if r["opcode"] == 0x00 and r["target_oid"] != 0:
            handle_oids[r["handle"]] = r["target_oid"]
        if r["target_oid"] != 0:
            handle_oids.setdefault(r["handle"], r["target_oid"])
    primary_oid = 0
    for r in recs:
        oid = r["target_oid"]
        if oid == 0:
            oid = handle_oids.get(r["handle"], 0)
        if oid >= 0x600 and primary_oid == 0:
            primary_oid = oid
    path = oid_paths.get(primary_oid, "")
    if not path and primary_oid:
        path = "OID 0x%x" % primary_oid
    fnames = [r["filename"] for r in recs if r["filename"]
              and r["filename"] != "$I30"]
    fname = fnames[0] if fnames else ""
    oid_str = "0x%x" % primary_oid if primary_oid else "system"
    if fname and fname not in path:
        label = "%s → %s" % (path, fname) if path else fname
    else:
        label = path or oid_str
    ts = 0
    for r in recs:
        if r["timestamp"] > ts:
            ts = r["timestamp"]
    # A rename/delete has no inline FILETIME; recover its event time from the paired next-block $SI-update
    # (+0x140). Only when the transaction is otherwise untimestamped, so an inline stamp always wins.
    ts_paired = False
    if ts == 0 and f is not None and action in _MLOG_PAIRED_TS_ACTIONS:
        _pt = _mlog_pair_si_timestamp(f, ps_off, cs, txn["plcn"], txn.get("block", 0))
        if _pt:
            ts, ts_paired = _pt, True
    return {
        "action": action, "op_detail": op_detail, "label": label, "path": path, "name": fname,
        "oid": primary_oid, "timestamp": ts, "ts_str": _filetime_str(ts), "ts_paired": ts_paired,
        "plcn": txn["plcn"], "recs": recs,
        "ops_str": " ".join(r["op_short"] for r in recs),
        "handle_oids": handle_oids,
    }

def cmd_mlog(image, remaining, partition_start):
    import csv as _csv

    _check_unknown_flags(remaining,
                         {"-v", "--verbose", "--parse", "--stats", "--raw-scan", "--info"}, {"--csv", "--json"})
    verbose = "-v" in remaining or "--verbose" in remaining
    do_parse = "--parse" in remaining
    do_stats = "--stats" in remaining
    do_json = "--json" in remaining
    do_raw = "--raw-scan" in remaining
    do_info = "--info" in remaining
    csv_arg = None
    json_arg = "-"      # --json to stdout, or to a FILE if `--json FILE` (Phase 2)
    for i, a in enumerate(remaining):
        if a == "--csv":
            csv_arg = remaining[i + 1] if i + 1 < len(remaining) and not remaining[i + 1].startswith("-") else "-"
        elif a == "--json":
            json_arg = remaining[i + 1] if i + 1 < len(remaining) and not remaining[i + 1].startswith("-") else "-"

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, _ = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        redo_ops = _redo_ops_for_version(vmin)
        # C4/C5: redo-opcode NAMES are decompiler-verified only for v3.4 and v3.14. v3.7-v3.13 have no
        # decompiled driver and reuse the v3.14 mapping (RD-validated to 0 unknown opcodes corpus-wide,
        # finding #330 — the opcodes match, but the semantic names are inferred). Surface that (stderr,
        # so --csv/--json output is untouched).
        if 4 < vmin < 14:
            print(f"  NOTE: ReFS v{vmaj}.{vmin} redo-opcode names are inferred from the v3.14 driver "
                  f"(no decompiled driver for this build; opcodes RD-validated, names best-effort).",
                  file=sys.stderr)
        W = 78

        mlog_info = get_mlog_info(f, ps, cs, tr, obj_map)
        if mlog_info is None:
            print("Logfile Information Table (OID 0x9/0xA) not found")
            return 1

        ctrl = read_mlog_control(f, ps, cs, mlog_info)

        if do_info:
            print(_MLOG_INFO_TEXT)
            for sid in sorted(MLOG_SCHEMA_NAMES):
                print("  0x%04x  %s" % (sid, MLOG_SCHEMA_NAMES[sid]))
            print()
            return 0

        if do_parse or csv_arg is not None:
            oid_paths = build_oid_path_map(f, ps, cs, tr, obj_map)
            # Stream the log data area: extract_mlog_transactions consumes the block generator in a
            # single linear pass, so the 1 GiB of log blocks is never materialized, and the redo-record
            # list (unused on this path) is not built — this is what fixes the large-log OOM.
            txns = extract_mlog_transactions(
                scan_mlog_data_area(f, ps, cs, tr, mlog_info, ctrl), redo_ops)

            if csv_arg is not None:
                ts_written = [0]
                def _write_csv(out):
                    w = _csv.writer(out)
                    w.writerow(["seq", "timestamp", "action", "path", "name", "oid",
                                "opcodes", "record_count", "plcn"])
                    for i, txn in enumerate(txns, 1):
                        t = _mlog_resolve_txn(txn, oid_paths, f, ps, cs)
                        if t["ts_str"]:
                            ts_written[0] += 1
                        w.writerow(_csv_row([
                            i, t["ts_str"], t["action"], t["path"], t["name"],
                            "0x%x" % t["oid"] if t["oid"] else "",
                            t["ops_str"], len(t["recs"]), t["plcn"],
                        ]))
                if csv_arg == "-":
                    _write_csv(sys.stdout)
                else:
                    with open(csv_arg, "w", newline="") as cf:
                        _write_csv(cf)
                    print("Wrote %d transactions to %s (%d carry a timestamp — the rest have an empty"
                          " timestamp column and do not appear in `timeline --source MLOG`)."
                          % (len(txns), csv_arg, ts_written[0]))
            else:
                print("Building OID → path map …")
                print("  %d paths resolved" % len(oid_paths))
                print()
                print("=" * W)
                print("MLog Transactions (parsed)")
                print("=" * W)
                if not txns:
                    print("  No transactions found.")
                else:
                    print("  Total transactions: %d\n" % len(txns))
                    if verbose:
                        print("  (-v: each redo record is shown as  <opcode> <name>  target_oid  @PLCN.blk+offset  "
                              "key — on disk at  ps + PLCN*cluster_size + blk*0x1000 + offset)\n")
                    action_counts = {}
                    ts_count = 0
                    for txn in txns:
                        t = _mlog_resolve_txn(txn, oid_paths, f, ps, cs)
                        action = t["action"]
                        action_counts[action] = action_counts.get(action, 0) + 1
                        if t["ts_str"]:
                            ts_count += 1
                        ts_part = "  %s" % t["ts_str"] if t["ts_str"] else ""
                        detail_part = "  (%s)" % t["op_detail"] if t["op_detail"] else ""
                        print("  [%-12s] %s%s%s" % (action, t["label"], detail_part, ts_part))
                        if verbose:
                            # -v: per-record byte-level PROOF — opcode, table OID, and the exact PLCN+offset
                            # where the record lives, so an analyst can verify any field against the raw disk.
                            for r in t["recs"]:
                                oid = r["target_oid"] or t["handle_oids"].get(r["handle"], 0)
                                key = ('  key="%s"' % r["filename"]) if r["filename"] and r["filename"] != "$I30" else ""
                                sch = MLOG_SCHEMA_NAMES.get(r["attr_schema"], "")
                                sch = "  schema=%s" % sch if sch else ""
                                print("      0x%02x %-26s target_oid=0x%-8x @PLCN %d.blk%d+0x%x%s%s"
                                      % (r["opcode"], r["op_name"], oid, r["plcn"], r.get("block", 0), r.get("rec_off", 0), key, sch))
                        else:
                            print("    %s" % t["ops_str"])
                            for r in t["recs"]:
                                if r["filename"] and r["filename"] != "$I30":
                                    oid = r["target_oid"] or t["handle_oids"].get(r["handle"], 0)
                                    oid_path = oid_paths.get(oid, "")
                                    schema_name = MLOG_SCHEMA_NAMES.get(r["attr_schema"], "")
                                    detail_parts = []
                                    if oid_path:
                                        detail_parts.append("in %s" % oid_path)
                                    if schema_name:
                                        detail_parts.append(schema_name)
                                    detail = " (%s)" % ", ".join(detail_parts) if detail_parts else ""
                                    print('      name: "%s"%s' % (r["filename"], detail))
                        print()
                    print("-" * W)
                    print("Action summary")
                    print("  File operations (what a user did):")
                    _fo = [a for a in MLOG_FILE_OPS if action_counts.get(a)]
                    for a in _fo:
                        print("    %-14s %6d" % (a, action_counts[a]))
                    if not _fo:
                        print("    (none captured in the log window)")
                    print("  Low-level / metadata records (B+-tree redo that accompanies the above):")
                    _seen = set(MLOG_FILE_OPS)
                    for a in MLOG_LOW_LEVEL + tuple(sorted(k for k in action_counts if k not in _seen and k not in MLOG_LOW_LEVEL)):
                        if action_counts.get(a):
                            print("    %-14s %6d" % (a, action_counts[a]))
                    print()
                    print("  %d of %d transactions carry an embedded timestamp; only those appear in"
                          % (ts_count, len(txns)))
                    print("  `timeline --source MLOG` (an untimestamped transaction cannot be placed on a timeline).")
            return 0

        # json / default / raw-scan iterate the blocks multiple times and display the redo records,
        # so for these paths materialize the block list and the records once.
        pages = list(scan_mlog_data_area(f, ps, cs, tr, mlog_info, ctrl))
        records = extract_redo_records(pages, redo_ops)

        if do_json:
            output = {
                "version": "%d.%d" % (vmaj, vmin),
                "control": ctrl,
                "mlog_info": {k: v for k, v in (mlog_info or {}).items() if k != "page"},
                "data_area": {"total_pages": len(pages), "page_types": {}},
                "integrity": mlog_verify_pages(pages),
                "records": records,
            }
            for p in pages:
                t = p["type"]
                output["data_area"]["page_types"][t] = output["data_area"]["page_types"].get(t, 0) + 1
            _emit_json_obj(output, json_arg, "%d redo records" % len(records))
            return 0

        # Default: control + data summary + records
        print("=" * W)
        print("ReFS MLog Analysis — %s" % os.path.basename(image))
        print("ReFS v%d.%d | cluster_size=0x%x | objects=%d" % (vmaj, vmin, cs, len(obj_map)))
        print("=" * W)
        print()

        # Control area
        print("=" * W)
        print("MLog Control Area")
        print("=" * W)
        if not ctrl:
            print("  No valid MLog control page found.")
        else:
            print("  Control PLCN:      0x%x" % ctrl.get("plcn", 0))
            print("  Signature:         %s" % ctrl.get("signature", "?"))
            print("  Format magic:      0x%08x (per-volume format/log-instance constant; changes after a reformat)" % ctrl.get("format_magic", 0))
            print("  Version:           %s" % ctrl.get("version", "?"))
            print("  Sector size:       0x%x" % ctrl.get("sector_size", 0))
            print("  UUID:              %s" % ctrl.get("uuid", "?"))
            seq = ctrl.get("sequence", ctrl.get("sequence_raw", "?"))
            print("  Sequence:          %s" % seq)
            print("  Write counter:     %s" % ctrl.get("write_counter", "?"))
            print("  Flags:             0x%x" % ctrl.get("flags", 0))
            print("  Total entries:     %s" % ctrl.get("total_entries", "?"))
            print("  Generation:        %s" % ctrl.get("generation", "?"))
            ds = ctrl.get("data_start_lcn", mlog_info.get("data_start_lcn", 0))
            de = ctrl.get("data_end_lcn", mlog_info.get("data_end_lcn", 0))
            print("  Data area:         0x%x - 0x%x (%d clusters)" % (ds, de, de - ds))
            lsn_o = ctrl.get("lsn_oldest", 0)
            if lsn_o:
                lo = lsn_o & 0xFFFFFFFF
                hi = (lsn_o >> 32) & 0xFFFFFFFF
                print("  LSN oldest:        0x%x.%x" % (lo, hi))
            table = _redo_ops_for_version(vmin)
            print("  Dispatch table:    %s (%d opcodes)" % (
                "v3.4" if vmin < 7 else ("v3.14" if vmin >= 14 else "v3.7+ (v3.14 table)"), len(table)))
        print()

        # Data summary or raw scan
        if do_raw:
            print("=" * W)
            print("Data Area Raw Scan")
            print("=" * W)
            for p in pages:
                if p["type"] == PAGE_TYPE_ZERO:
                    continue
                page = p.get("page", b"")
                sig = page[:4].hex() if page else "----"
                u32_0 = le32(page, 0) if page and len(page) >= 4 else 0
                u32_4 = le32(page, 4) if page and len(page) >= 8 else 0
                blk = ".%02d" % p["block"] if p.get("block") else "    "
                print("  VLCN 0x%06x  PLCN 0x%06x%s  %-5s  sig=%s"
                      "  u32[0]=0x%08x  u32[1]=0x%08x" % (
                          p["vlcn"], p["plcn"], blk, p["type"], sig, u32_0, u32_4))
            print()
        else:
            print("=" * W)
            print("Data Area Summary")
            print("=" * W)
            if not pages:
                print("  No data area pages found.")
            else:
                counts = {}
                for p in pages:
                    t = p["type"]
                    counts[t] = counts.get(t, 0) + 1
                total = len(pages)
                print("  Total pages:       %d" % total)
                for t in [PAGE_TYPE_ZERO, PAGE_TYPE_MSBP, PAGE_TYPE_DATA, PAGE_TYPE_MLOG]:
                    c = counts.get(t, 0)
                    if c > 0:
                        print("  %-20s %6d  (%5.1f%%)" % (t, c, c * 100.0 / total))
            print()

        # Records
        print("=" * W)
        print("Redo Records")
        print("=" * W)
        if not records:
            print("  No redo records found in data area.")
            print("  (Log may be clean — all transactions checkpointed.)")
        else:
            print("  Total records:      %d" % len(records))
            txn_starts = sum(1 for r in records if r["txn_start"])
            txn_commits = sum(1 for r in records if r["txn_commit"])
            print("  Transaction starts: %d" % txn_starts)
            print("  Transaction commits: %d  (commit is marked at the checkpoint/LogCore layer, not by a"
                  % txn_commits)
            print("                          per-redo-record flag — this is 0 on every volume, healthy or not;")
            print("                          do NOT read starts>commits as 'uncommitted work')")
            print()
            print("  The MLog is the volume's DURABLE TRANSACTION LOG. Operations logged here may not yet be")
            print("  checkpointed into the committed on-disk tree, so `files`/`summary` (which read the committed")
            print("  tree) can omit recent operations that appear here; a fully-checkpointed log can conversely be")
            print("  near-empty while the tree is complete. Cross-check pending activity with `mlog --parse`.")
            print()
            if verbose:
                print("  %4s  %6s  %-40s  %10s  %6s  %5s" % (
                    "#", "Opcode", "Name", "OID", "Flags", "Size"))
                print("  %s  %s  %s  %s  %s  %s" % ("─"*4, "─"*6, "─"*40, "─"*10, "─"*6, "─"*5))
                for i, r in enumerate(records):
                    oid_str = "0x%x" % r["object_id"] if r["object_id"] else "—"
                    flag_parts = []
                    if r["txn_start"]:
                        flag_parts.append("S")
                    if r["txn_commit"]:
                        flag_parts.append("C")
                    flag_str = "+".join(flag_parts) if flag_parts else "—"
                    print("  %4d  0x%04x  %-40s  %10s  %6s  %5d" % (
                        i, r["opcode"], r["op_name"], oid_str, flag_str, r["size"]))
                print()

        # LogCore record headers (verbose) — the outer wrapper around each redo block
        if verbose:
            hdrs = []
            for p in pages:
                if p["type"] == PAGE_TYPE_MLOG and p.get("page"):
                    h = parse_mlog_record_header(p["page"])
                    if h:
                        h["plcn"] = p["plcn"]
                        h["block"] = p.get("block", 0)
                        hdrs.append(h)
            if hdrs:
                print("=" * W)
                print("LogCore Record Headers (%d data records)" % len(hdrs))
                print("=" * W)
                print("  %-11s  %-13s  %-13s  %-10s  %4s  %4s" % (
                    "PLCN.blk", "LSN", "prevLSN", "checksum", "type", "poff"))
                print("  %s  %s  %s  %s  %s  %s" % (
                    "─" * 11, "─" * 13, "─" * 13, "─" * 10, "─" * 4, "─" * 4))
                prev = None
                for h in hdrs[:64]:
                    lsn = h["lsn"]
                    plsn = h["prev_lsn"]
                    chain = "" if (prev is None or plsn == prev) else " !chain"
                    prev = lsn
                    print("  0x%06x.%02d  0x%011x  0x%011x  0x%08x  %4d  0x%02x%s" % (
                        h["plcn"], h["block"], lsn, plsn, h["checksum"] & 0xFFFFFFFF,
                        h["record_type"], h["payload_offset"], chain))
                if len(hdrs) > 64:
                    print("  … %d more" % (len(hdrs) - 64))
                magics = sorted(set(h["format_magic"] for h in hdrs))
                print("  format_magic (per-volume format/log-instance constant): %s" %
                      ", ".join("0x%08x" % m for m in magics))
                print()

        # Stats
        if do_stats:
            iv = mlog_verify_pages(pages)
            if iv["checked"]:
                print("=" * W)
                print("Record Integrity")
                print("=" * W)
                print("  Every log record carries an 8-byte integrity value covering the record itself. The")
                print("  driver recomputes it before replaying the record; forefst recomputes it the same way,")
                print("  so a torn or altered record shows up here. It is an integrity check, not a signature:")
                print("  it catches damage and byte-level edits, it is not proof of authenticity.")
                print()
                print("  Records checked:    %d" % iv["checked"])
                print("  Verified:           %d" % iv["verified"])
                print("  Failed:             %d%s" % (iv["failed"],
                                                      "" if not iv["failed"] else "   <-- torn or altered"))
                for blk, st, co in iv["failures"]:
                    print("    block %-10d stored=0x%08x  computed=0x%08x" % (blk, st, co))
                if iv["failures_truncated"]:
                    print("    (only the first %d failing records are listed)" % len(iv["failures"]))
                for key in ("ctrl_plcn_0", "ctrl_plcn_1"):
                    cplcn = (mlog_info or {}).get(key, 0)
                    if not cplcn:
                        continue
                    f.seek(ps + cplcn * cs)
                    cr = mlog_verify_record(f.read(max(cs, 4096)))
                    if cr is not None:
                        print("  Control copy %s (PLCN 0x%x): %s" %
                              (key[-1], cplcn, "verified" if cr[0] else
                               "FAILED  stored=0x%08x computed=0x%08x" % (cr[1], cr[2])))
                print()

        if do_stats and records:
            print("=" * W)
            print("Opcode Frequency")
            print("=" * W)
            freq = {}
            for r in records:
                freq[r["opcode"]] = freq.get(r["opcode"], 0) + 1
            cat_freq = {}
            for r in records:
                cat = OPCODE_CATEGORIES.get(r["op_name"], "other")
                cat_freq[cat] = cat_freq.get(cat, 0) + 1
            total = len(records)
            print("\n  %6s  %6s  %5s  %-40s" % ("Opcode", "Count", "%", "Name"))
            print("  %s  %s  %s  %s" % ("─"*6, "─"*6, "─"*5, "─"*40))
            for op in sorted(freq.keys()):
                name = redo_ops.get(op, "UNKNOWN_0x%02x" % op)
                pct = freq[op] * 100.0 / total
                print("  0x%04x  %6d  %5.1f  %s" % (op, freq[op], pct, name))
            print("\n  %-20s  %6s  %5s" % ("Category", "Count", "%"))
            print("  %s  %s  %s" % ("─"*20, "─"*6, "─"*5))
            for cat in sorted(cat_freq.keys(), key=lambda c: -cat_freq[c]):
                pct = cat_freq[cat] * 100.0 / total
                print("  %-20s  %6d  %5.1f" % (cat, cat_freq[cat], pct))
            unknown = sum(1 for r in records if r["opcode"] not in redo_ops)
            if unknown:
                print("\n  WARNING: %d records with unknown opcodes" % unknown)
            print()

        return 0

    except (struct.error, ValueError, IndexError) as e:
        print("Error parsing MLog data: %s" % e, file=sys.stderr)
        return 1
    finally:
        f.close()

def cmd_usn(image, remaining, partition_start):
    import csv as _csv

    _check_unknown_flags(remaining, {"-v", "--verbose", "--stats", "--info", "--list"}, {"--csv", "--json"})
    verbose = "-v" in remaining or "--verbose" in remaining
    do_stats = "--stats" in remaining
    do_json = "--json" in remaining
    do_info = "--info" in remaining
    do_list = "--list" in remaining
    csv_arg = None
    json_arg = "-"      # --json writes to stdout, or to a FILE if `--json FILE` (Phase 2)
    for i, a in enumerate(remaining):
        if a == "--csv":
            csv_arg = remaining[i + 1] if i + 1 < len(remaining) and not remaining[i + 1].startswith("-") else "-"
        elif a == "--json":
            json_arg = remaining[i + 1] if i + 1 < len(remaining) and not remaining[i + 1].startswith("-") else "-"

    # Phase 3 §5: bare `usn` shows the STATS SUMMARY (mirrors `mlog`) — dumping every record (often tens of
    # thousands of lines) is not a useful default. `usn --list` (or `-v`) prints the on-screen record list;
    # `usn --csv/--json [FILE]` exports the records.
    if not (do_info or do_stats or do_json or csv_arg is not None or do_list or verbose):
        do_stats = True

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, _ = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        W = 78
        vd, entry_meta = locate_change_journal(f, ps, cs, tr, obj_map)
        if vd is None:
            print("No Change Journal found in %s" % os.path.basename(image))
            print("  (OID 0x520 %s — journal not activated)" % (
                "present" if OID_FS_METADATA in obj_map else "absent"))
            return 0

        streams = parse_usn_journal_streams(vd, cs, tr)
        if not streams["j_extents"]:
            print("Change Journal entry found but no $J stream extents decoded")
            print("  Value size: %d bytes, sub-records: %d" % (
                len(vd), streams["subrecord_count"]))
            return 1

        j_data = read_usn_j_stream(f, ps, cs, streams["j_extents"],
                                    streams["j_stream_size"])
        records = parse_usn_records(j_data, alloc=len(j_data))
        # `$J` is a RING: once it wraps, buffer order stops being time order and the listing runs
        # backwards across the wrap point. Sorting by USN restores the chronology the analyst is
        # actually reading. Measured: `winsider` is wrapped (1 descending step in 217,892 records),
        # the first wrapped journal observed on this corpus -- E77 had the wrap model recorded as
        # inferred with none seen. Unwrapped journals are already in USN order, so this is a no-op
        # for them (verified: 0 descending steps on every other corpus journal).
        records.sort(key=lambda r: r.usn)
        journal_meta = parse_usn_journal_metadata(streams, f, ps, cs)

        oid_paths = build_oid_path_map(f, ps, cs, tr, obj_map)

        def _usn_stats():
            """Activity summary — bare `usn`, `usn --stats`, and (2usn-7) alongside a `--csv/--json FILE` export."""
            print("=" * 78)
            print("USN Journal Statistics (%d records)" % len(records))
            print("=" * 78); print()
            if not records:
                print("  (no records)"); return
            reason_counts = {}; file_counts = {}; dir_set = set(); ts_min = ts_max = None
            for r in records:
                for bit, name in sorted(USN_REASON_FLAGS.items()):
                    if r.reason & bit:
                        reason_counts[name] = reason_counts.get(name, 0) + 1
                file_counts[r.filename] = file_counts.get(r.filename, 0) + 1
                dir_set.add(r.parent_oid)
                if r.timestamp > 0:
                    ts_min = r.timestamp if ts_min is None else min(ts_min, r.timestamp)
                    ts_max = r.timestamp if ts_max is None else max(ts_max, r.timestamp)
            print("  Reason code distribution:")
            for name, cnt in sorted(reason_counts.items(), key=lambda x: -x[1]):
                print("    %-30s %5d" % (name, cnt))
            print()
            print("  Top files by record count:")
            for name, cnt in sorted(file_counts.items(), key=lambda x: -x[1])[:15]:
                print("    %-40s %5d" % (name, cnt))
            print()
            print("  Unique filenames:    %d" % len(file_counts))
            print("  Unique parent dirs:  %d" % len(dir_set))
            print("  USN range:           %d — %d" % (min(r.usn for r in records), max(r.usn for r in records)))
            if ts_min and ts_max:
                print("  Time range:          %s" % _usn_filetime_short(ts_min))
                print("                    to %s" % _usn_filetime_short(ts_max))

        if do_info:
            print("=" * W)
            print("USN Journal Information")
            print("=" * W)
            print()
            print("  Change Journal entry in OID 0x520:")
            if entry_meta:
                print("    Value size:     %d bytes" % entry_meta.get("value_len", 0))
                print("    Stream count:   %s" % entry_meta.get("stream_count", "?"))
                ct = entry_meta.get("create_time", 0)
                if ct:
                    print("    Created:        %s" % _usn_filetime_short(ct))
            print()
            print("  $J stream (data):")
            print("    Extents:        %d" % len(streams.get("j_extents", [])))
            if streams.get("j_extents"):
                total_cl = sum(e["clusters"] for e in streams["j_extents"])
                print("    Allocated size: %s bytes (%d clusters) — the journal's rolling window, read in full" %
                      ("{:,}".format(total_cl * cs), total_cl))
                for i, ext in enumerate(streams["j_extents"]):
                    print("    [%d] VLCN=0x%x PLCN=0x%x vcn=%d len=%d" % (
                        i, ext["vlcn"], ext["plcn"], ext["file_vcn"], ext["clusters"]))
            print()
            print("  $Max stream (parameters):")
            print("    Extents:        %d" % len(streams.get("max_extents", [])))
            if journal_meta.get("max_size") is not None:
                print("    Max journal:    %s bytes (%.1f MB)" % (
                    "{:,}".format(journal_meta["max_size"]),
                    journal_meta["max_size"] / (1024*1024)))
            if journal_meta.get("allocation_delta") is not None:
                print("    Alloc delta:    %s bytes" % "{:,}".format(journal_meta["allocation_delta"]))
            if journal_meta.get("journal_id") is not None:
                print("    Journal ID:     0x%016x" % journal_meta["journal_id"])
            print()
            print("  Parsed records:")
            print("    Count:          %d" % len(records))
            if records:
                versions = set("%d.%d" % (r.major_version, r.minor_version) for r in records)
                print("    Versions:       %s" % ", ".join(sorted(versions)))
                usn_min = min(r.usn for r in records)
                usn_max = max(r.usn for r in records)
                print("    USN range:      %d — %d" % (usn_min, usn_max))
            print()
            print("  USN_RECORD_V3 layout:")
            print("    Offset  Size  Field")
            for off, sz, name in [
                (0x00, 4, "Record length (u32)"),
                (0x04, 2, "Major version (u16) = 3"),
                (0x06, 2, "Minor version (u16) = 0"),
                (0x08, 16, "File ID (u128)"),
                (0x18, 16, "Parent file ID (u128)"),
                (0x28, 8, "USN (u64)"),
                (0x30, 8, "Timestamp (FILETIME)"),
                (0x38, 4, "Reason (u32)"),
                (0x3C, 4, "Source info (u32)"),
                (0x40, 4, "Security ID (u32)"),
                (0x44, 4, "File attributes (u32)"),
                (0x48, 2, "File name length (u16)"),
                (0x4A, 2, "File name offset (u16)"),
                (0x4C, 0, "File name (UTF-16LE, variable)"),
            ]:
                print("    0x%02X    %-4d  %s" % (off, sz, name))
            print()
            print("  Note: ReFS leaves Source info (0x3C) and Security ID (0x40) = 0 in every USN record")
            print("        (not populated by the filesystem), and the parent file-ID ordinal is 0 by")
            print("        construction (a parent is a directory, addressed as OID:0). In the --csv/--json")
            print("        output these three fields are placed last; they carry no per-record signal.")
            print()
            print("  Reason codes:")
            for bit in sorted(USN_REASON_FLAGS.keys()):
                print("    0x%08x  %s" % (bit, USN_REASON_FLAGS[bit]))
            print()
            return 0

        if csv_arg is not None:
            def _write_csv(out):
                w = _csv.writer(out)
                # security_id / source_info / parent_idx are LAST: ReFS does not populate SourceInfo(0x3C)
                # or SecurityId(0x40) in USN records (both structurally 0), and the parent file-ID ordinal
                # is 0 by construction (a parent is a directory, addressed as OID:0). Kept for completeness.
                # Identity: home_oid = the reference OID (the containing directory for a FILE, the object's
                # OWN OID for a DIRECTORY); file_id = the per-home ordinal (0 ⇔ a directory self-reference).
                # file_ref = home_oid:file_id is the 128-bit USN FileReferenceNumber (== files.FileRef).
                # security_id / source_info / parent_idx are LAST (all structurally 0 on ReFS; a parent is a
                # directory, addressed as OID:0).
                # 'version' (constant USN_RECORD_V3 = 3.0) removed 2026-08-09 — shown once by `usn --info`,
                # not repeated per row.
                w.writerow(["usn", "timestamp", "reason_hex", "reason", "filename",
                            "entry_type", "file_ref", "home_oid", "file_id", "parent_oid", "path",
                            "attrs_hex", "attrs", "record_length",
                            "security_id", "source_info", "parent_idx"])
                for r in records:
                    parent_path = _usn_resolve_path(r.parent_oid, oid_paths)
                    full_path = "%s/%s" % (parent_path, r.filename) if parent_path and parent_path != "/" else r.filename
                    w.writerow(_csv_row([
                        r.usn, _usn_filetime_iso(r.timestamp),
                        "0x%08x" % r.reason, usn_reason_to_short(r.reason),
                        r.filename, "dir" if r.file_idx == 0 else "file",
                        "0x%x:0x%x" % (r.file_oid, r.file_idx),
                        "0x%x" % r.file_oid, "0x%x" % r.file_idx,
                        "0x%x" % r.parent_oid, full_path, "0x%08x" % r.file_attrs,
                        _usn_attrs_short(r.file_attrs), r.record_length,
                        r.security_id, "0x%08x" % r.source_info, "0x%x" % r.parent_idx,
                    ]))
            if csv_arg == "-":
                _write_csv(sys.stdout)
            else:
                with open(csv_arg, "w", newline="") as cf:
                    _write_csv(cf)
                print("Wrote %d records to %s" % (len(records), csv_arg))
                print()
                _usn_stats()   # 2usn-7: activity summary alongside a file export
            return 0

        if do_json:
            entries = []
            for r in records:
                parent_path = _usn_resolve_path(r.parent_oid, oid_paths)
                entries.append({
                    "usn": r.usn, "timestamp": _usn_filetime_iso(r.timestamp),
                    "reason": r.reason, "reason_text": usn_reason_to_short(r.reason),
                    "filename": r.filename,
                    "entry_type": "dir" if r.file_idx == 0 else "file",
                    "file_ref": "0x%x:0x%x" % (r.file_oid, r.file_idx),
                    "home_oid": r.file_oid, "file_id": r.file_idx, "parent_oid": r.parent_oid,
                    "path": "%s/%s" % (parent_path, r.filename) if parent_path and parent_path != "/" else r.filename,
                    "file_attrs": r.file_attrs, "record_length": r.record_length,
                    # ReFS-unpopulated / structural (always 0) — kept last for completeness:
                    "security_id": r.security_id, "source_info": r.source_info,
                    "parent_idx": r.parent_idx,
                })
            obj = {"journal": journal_meta, "record_count": len(entries), "records": entries}
            _emit_json_obj(obj, json_arg, "%d USN records" % len(entries))
            if json_arg and json_arg != "-":
                print()
                _usn_stats()   # 2usn-7: activity summary alongside a file export
            return 0

        if do_stats:
            _usn_stats()
            if records:
                print()
                print("  See the records:  `usn --list` (on screen) · `usn --csv/--json [FILE]` (export) · "
                      "`usn --info` (journal health)")
            return 0

        # Record list (usn --list, or -v for the verbose form; formerly the bare-usn default)
        print("=" * W)
        print("USN Journal Records (%d entries)" % len(records))
        print("=" * W)
        print("  --stats for the reason/activity summary · --info for journal health · --csv/--json [FILE] for records")
        print()
        for r in records:
            parent_path = _usn_resolve_path(r.parent_oid, oid_paths)
            print("  USN %-10d %s" % (r.usn, r.filename))
            print("    Time:    %s" % _usn_filetime_short(r.timestamp))
            print("    Reason:  %s (0x%08x)" % (usn_reason_to_str(r.reason), r.reason))
            print("    FileRef: 0x%x:0x%x  (%s)" % (
                r.file_oid, r.file_idx, "directory" if r.file_idx == 0 else "file"))
            print("    Parent:  0x%x  -> %s" % (r.parent_oid, parent_path))
            print("    Attrs:   %s" % _usn_attrs_short(r.file_attrs))
            if r.source_info:
                src_parts = []
                for bit, name in sorted(USN_SOURCE_FLAGS.items()):
                    if r.source_info & bit:
                        src_parts.append(name)
                print("    Source:  %s (0x%08x)" % (" | ".join(src_parts), r.source_info))
            if r.security_id:
                print("    SecID:   %d" % r.security_id)
            if verbose:
                print("    RecLen:  %d  Version: %d.%d  StreamOff: 0x%x" % (
                    r.record_length, r.major_version, r.minor_version, r.offset))
            print()

        return 0

    except (struct.error, ValueError, IndexError, OverflowError) as e:
        print("Error parsing USN data: %s" % e, file=sys.stderr)
        return 1
    finally:
        f.close()

def cmd_timeline(image, remaining, partition_start):
    # Phase-2: --csv/--json/--jsonl [FILE] (stdout if no FILE). Pulled out before the command's own parser.
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining)
    args = _parse_args(remaining, flags=["--no-si", "--fast", "-v", "--verbose"],
                       valued=["--file", "--oid", "--limit", "--source", "--depth"])
    skip_si = args["no_si"] or args["fast"]   # --fast is a friendly alias for --no-si
    verbose = args["v"] or args["verbose"]    # -v: show the FULL name/path (no truncation)
    si_depth = _int_arg(args["depth"], "--depth") if args["depth"] else DEFAULT_DEPTH
    name_filter = args["file"].lower() if args["file"] else None
    oid_filter = _int_arg(args["oid"], "--oid", 0) if args["oid"] else None
    limit = _int_arg(args["limit"], "--limit") if args["limit"] else 0
    # accept the source token with or without the leading '$' (event labels are "$SI"/"USN"/"MLog";
    # docs/help say "SI") — normalize both sides by stripping a leading '$' so `--source SI` == `--source $SI`.
    src_filter = args["source"].upper().lstrip("$") if args["source"] else None

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, _ = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        oid_paths = build_oid_path_map(f, ps, cs, tr, obj_map)
        events = []   # (filetime, source, oid, name/path, detail)
        counts = {"USN": 0, "MLog": 0, "$SI": 0}

        # (3-of-3 validated parsers — see report; merge order doesn't matter, we sort by time)

        # (1) $SI MACB — per-file Created/Modified/MFT-Changed/Accessed (always present).
        # enrich=False: the MACB timestamps are cached in each directory entry, so we do NOT need the
        # per-object $SI read that enrich=True does (SecurityId/USN/internal-flags) — those aren't used
        # in the timeline. Dropping enrich removes one B+-tree read PER non-resident object (the former
        # bottleneck: ~26k extra reads on a 35k-object volume).
        if not skip_si:
            for e in walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, si_depth, False, set()):
                oid = e.get("oid", 0); path = e.get("path", e.get("name", ""))
                for fld, lbl in (("create_time", "Created"), ("modify_time", "Modified"),
                                 ("change_time", "Metadata-Changed"), ("access_time", "Accessed")):
                    ts = e.get(fld, 0)
                    if ts:
                        events.append((ts, "$SI", oid, path, lbl)); counts["$SI"] += 1

        # (2) USN — per-record change events (only if the journal is active)
        vd, _em = locate_change_journal(f, ps, cs, tr, obj_map)
        if vd is not None:
            streams = parse_usn_journal_streams(vd, cs, tr)
            if streams["j_extents"]:
                j_data = read_usn_j_stream(f, ps, cs, streams["j_extents"], streams["j_stream_size"])
                for r in parse_usn_records(j_data):
                    nm = getattr(r, "filename", "") or oid_paths.get(r.file_oid, "")
                    events.append((r.timestamp, "USN", r.file_oid, nm,
                                   usn_reason_to_short(r.reason))); counts["USN"] += 1

        # (3) MLog — per-transaction events that carry an embedded timestamp
        redo_ops = _redo_ops_for_version(vmin)
        # MLog events have NO true wall-clock time — the per-transaction time is read from an embedded $SI
        # FILETIME in the redo value (the affected object's birth, which for a RENAME/MOVE is NOT the op time
        # and can be old/stomped). A time that PREDATES the volume's own creation is therefore a provably-wrong
        # mis-extraction (an operation cannot occur before the volume existed): we UNDATE it (so it no longer
        # mis-sorts before real events, e.g. a rename appearing before its create) and mark it. (Fixes the
        # timeline MLog-timestamp misdating, ~1% of MLog rows on win11refstestmftecmd.)
        mlog_info = get_mlog_info(f, ps, cs, tr, obj_map)
        if mlog_info:
            _vol_create, _ = _volume_times(f, ps, cs, tr, obj_map)
            ctrl = read_mlog_control(f, ps, cs, mlog_info)
            # stream the block generator straight into the transaction extractor (single pass) so the
            # full 1 GiB log is never materialized — fixes timeline OOM on very large logs.
            mlog_undated = 0
            for txn in extract_mlog_transactions(
                    scan_mlog_data_area(f, ps, cs, tr, mlog_info, ctrl), redo_ops):
                t = _mlog_resolve_txn(txn, oid_paths, f, ps, cs)
                if t["timestamp"]:
                    mts = t["timestamp"]; action = t["action"]
                    if _vol_create and mts < _vol_create - TS_MARGIN_100NS:
                        mts = 0; action = t["action"] + " [MLog time unreliable]"; mlog_undated += 1
                    events.append((mts, "MLog", t["oid"], t["path"] or t["name"], action))
                    counts["MLog"] += 1
            if mlog_undated:
                counts["mlog_undated"] = mlog_undated

        # filter
        if oid_filter is not None:
            events = [ev for ev in events if ev[2] == oid_filter]
        if name_filter:
            events = [ev for ev in events if name_filter in str(ev[3]).lower()]
        if src_filter:
            events = [ev for ev in events if ev[1].upper().lstrip("$") == src_filter]
        # chronological sort (undated events — ts==0 — sink to the end)
        events.sort(key=lambda ev: ev[0] if ev[0] else (1 << 63))
        if limit:
            events = events[:limit]

        if out_fmt:
            cols = ["timestamp_utc", "source", "oid", "name", "event"]
            recs = [{"timestamp_utc": _filetime_to_str(ts), "source": src,
                     "oid": "0x%x" % oid if oid else "", "name": nm, "event": det}
                    for ts, src, oid, nm, det in events]
            _emit_records(recs, cols, out_fmt, out_dest, "events")
            return 0

        W = 78
        print("=" * W)
        print("ReFS Super-Timeline — %s" % os.path.basename(image))
        print("=" * W)
        print("  Sources merged: USN=%d  MLog=%d  $SI-MACB=%d  (time-sorted; correlated by name/path —" % (
            counts["USN"], counts["MLog"], counts["$SI"]))
        print("                  a file has no OID: $SI shows OID —, USN the home-dir OID, MLog the target OID)")
        if skip_si:
            print("  MODE: --fast — $SI MACB walk skipped; change-journals only (USN + MLog).")
        elif len(obj_map) > 8000:
            print("  NOTE: the $SI MACB walk visits every file — slow on large volumes. Use --fast")
            print("        (USN + MLog change-journals only) for a quick pass.")
        if counts["USN"] == 0:
            print("  NOTE: USN journal inactive on this image — timeline is $SI + MLog only.")
        print("  Caveat: USN and $SI carry exact FILETIMEs. MLog has NO wall-clock time — an MLog row's time is")
        print("          the affected object's embedded $SI birth (approximate; for a RENAME/MOVE it is the object")
        print("          birth, not the op time). MLog times that predate the volume are undated + marked.")
        if counts.get("mlog_undated"):
            print(f"          ({counts['mlog_undated']} MLog rows had an impossible pre-volume time → undated.)")
        print("-" * W)
        print("  %-23s  %-5s  %-10s  %-26s  %s" % ("Timestamp (UTC)", "Src", "OID", "Name/Path", "Event"))
        print("  %s" % ("-" * (W - 2)))
        for ts, src, oid, nm, det in events:
            tn = (nm or "") if verbose else ((nm[:24] + "…") if nm and len(nm) > 25 else (nm or ""))
            print("  %-23s  %-5s  %-10s  %-26s  %s" % (
                _filetime_to_str(ts) if ts else "(undated)", src,
                "0x%x" % oid if oid else "—", tn, det))
        if not events:
            print("  (no events — try without --file/--oid filters)")
        print("-" * W)
        print("  %d events" % len(events))
        return 0
    finally:
        f.close()


# ════════════════════════════════════════════════════════════════════════
#  Migrated forensic commands (Phase 3): timestomp / extract / security
#  Ported VERBATIM from refsanalysis (closure: SD/ACL parsers, extent/data-run readers, _sid_name
#  wrapper + _parse_sid alias over forefst's canonical parse_sid/sid_name). Routed via FORENSIC_HANDLERS.
# ════════════════════════════════════════════════════════════════════════

_ACE_TYPES = {
    0x00: "ACCESS_ALLOWED", 0x01: "ACCESS_DENIED",
    0x02: "SYSTEM_AUDIT", 0x03: "SYSTEM_ALARM",
    0x05: "ACCESS_ALLOWED_COMPOUND",
    0x06: "ACCESS_ALLOWED_OBJECT", 0x07: "ACCESS_DENIED_OBJECT",
    0x09: "ACCESS_ALLOWED_CALLBACK", 0x0A: "ACCESS_DENIED_CALLBACK",
    0x0B: "ACCESS_ALLOWED_CALLBACK_OBJECT",
    0x0C: "ACCESS_DENIED_CALLBACK_OBJECT",
    0x11: "SYSTEM_MANDATORY_LABEL", 0x12: "SYSTEM_RESOURCE_ATTRIBUTE",
    0x13: "SYSTEM_SCOPED_POLICY_ID", 0x14: "SYSTEM_PROCESS_TRUST_LABEL",
    }

_ADS_DESCRIPTOR = 0x000500B0

_DATA_ATTR_MARKER = 0x80000002

_FILE_RIGHTS = {
    0x00000001: "READ_DATA", 0x00000002: "WRITE_DATA",
    0x00000004: "APPEND_DATA", 0x00000008: "READ_EA",
    0x00000010: "WRITE_EA", 0x00000020: "EXECUTE",
    0x00000040: "DELETE_CHILD", 0x00000080: "READ_ATTRIBUTES",
    0x00000100: "WRITE_ATTRIBUTES", 0x00010000: "DELETE",
    0x00020000: "READ_CONTROL", 0x00040000: "WRITE_DAC",
    0x00080000: "WRITE_OWNER", 0x00100000: "SYNCHRONIZE",
    0x01000000: "ACCESS_SYSTEM_SECURITY", 0x02000000: "MAXIMUM_ALLOWED",
    0x10000000: "GENERIC_ALL", 0x20000000: "GENERIC_EXECUTE",
    0x40000000: "GENERIC_WRITE", 0x80000000: "GENERIC_READ",
    }

_MANDATORY_LABEL_RIGHTS = {0x1: "NO_WRITE_UP", 0x2: "NO_READ_UP", 0x4: "NO_EXECUTE_UP"}

_SD_CONTROL_FLAGS = {
    0x0001: "SE_OWNER_DEFAULTED", 0x0002: "SE_GROUP_DEFAULTED",
    0x0004: "SE_DACL_PRESENT", 0x0008: "SE_DACL_DEFAULTED",
    0x0010: "SE_SACL_PRESENT", 0x0020: "SE_SACL_DEFAULTED",
    0x0100: "SE_DACL_AUTO_INHERIT_REQ", 0x0200: "SE_SACL_AUTO_INHERIT_REQ",
    0x0400: "SE_DACL_AUTO_INHERITED", 0x0800: "SE_SACL_AUTO_INHERITED",
    0x1000: "SE_DACL_PROTECTED", 0x2000: "SE_SACL_PROTECTED",
    0x4000: "SE_RM_CONTROL_VALID", 0x8000: "SE_SELF_RELATIVE",
    }

_SIMPLE_ACE_LAYOUT = {0x00, 0x01, 0x02, 0x03, 0x09, 0x0A, 0x0D, 0x0E, 0x11, 0x12, 0x13}

_parse_sid = parse_sid

def _hx(v):
    return f"0x{v:x}" if v is not None else "n/a"

def _sid_name(sid_str):
    n = sid_name(sid_str)
    return f"{n} ({sid_str})" if n else sid_str

def _format_access_mask(mask, ace_type=None):
    if ace_type == 0x11:  # SYSTEM_MANDATORY_LABEL — mask is an integrity policy, not file rights
        flags = [name for bit, name in sorted(_MANDATORY_LABEL_RIGHTS.items()) if mask & bit]
        return "|".join(flags) if flags else _hx(mask)
    if mask == 0x1F01FF: return "FULL_CONTROL"
    if mask == 0x1301BF: return "MODIFY"
    if mask == 0x1200A9: return "READ_EXECUTE"
    if mask == 0x120089: return "READ"
    if mask == 0x120116: return "WRITE"
    flags = [name for bit, name in sorted(_FILE_RIGHTS.items()) if mask & bit]
    return "|".join(flags) if flags else _hx(mask)

def _parse_acl(data, offset):
    if offset == 0 or offset + 8 > len(data): return []
    ace_count = le16(data, offset + 4)
    aces = []
    pos = offset + 8
    for _ in range(ace_count):
        if pos + 4 > len(data): break
        ace_type = data[pos]
        ace_flags = data[pos + 1]
        ace_size = le16(data, pos + 2)
        if pos + ace_size > len(data): break
        ace = {
            "type": _ACE_TYPES.get(ace_type, f"Unknown(0x{ace_type:02x})"),
            "type_id": ace_type, "flags": ace_flags, "size": ace_size,
        }
        if ace_type in _SIMPLE_ACE_LAYOUT and ace_size >= 8:
            ace["mask"] = le32(data, pos + 4)
            ace["mask_str"] = _format_access_mask(ace["mask"], ace_type)
            sid_str, _ = _parse_sid(data, pos + 8)
            ace["sid"] = sid_str
            ace["sid_name"] = _sid_name(sid_str)
        pos += ace_size
        aces.append(ace)
    return aces

def _parse_security_descriptor(sd_data):
    if len(sd_data) < 20:
        return {"error": f"SD too short ({len(sd_data)} bytes)"}
    control = le16(sd_data, 2)
    off_owner = le32(sd_data, 4)
    off_group = le32(sd_data, 8)
    off_sacl = le32(sd_data, 12)
    off_dacl = le32(sd_data, 16)
    result = {
        "revision": sd_data[0], "control": control,
        "control_flags": [name for bit, name in _SD_CONTROL_FLAGS.items() if control & bit],
        "size": len(sd_data),
    }
    if off_owner and off_owner < len(sd_data):
        sid_str, _ = _parse_sid(sd_data, off_owner)
        result["owner"] = sid_str; result["owner_name"] = _sid_name(sid_str)
    else:
        result["owner"] = "(none)"; result["owner_name"] = "(none)"
    if off_group and off_group < len(sd_data):
        sid_str, _ = _parse_sid(sd_data, off_group)
        result["group"] = sid_str; result["group_name"] = _sid_name(sid_str)
    else:
        result["group"] = "(none)"; result["group_name"] = "(none)"
    result["dacl"] = _parse_acl(sd_data, off_dacl) if (control & 0x0004 and off_dacl and off_dacl < len(sd_data)) else []
    result["sacl"] = _parse_acl(sd_data, off_sacl) if (control & 0x0010 and off_sacl and off_sacl < len(sd_data)) else []
    return result

def _parse_sd_stream(f, ps, cs, tr, obj_map):
    if 0x530 not in obj_map:
        return [], "OID 0x530 (Security Descriptor Stream) not found in Object Table"
    rows = walk_bplus(f, ps, cs, tr, obj_map[0x530])
    descriptors = []
    for kd, vd in rows:
        if len(kd) >= 16:
            sid_high = le32(kd, 8); sid_low = le32(kd, 12)
            security_id = (sid_high << 32) | sid_low
        elif len(kd) >= 8:
            security_id = le64(kd, 0)
        else:
            security_id = 0
        SD_HEADER_SIZE = 12
        if len(vd) >= SD_HEADER_SIZE + 20:
            # Wrapper: +0x00 SD hash (=SecurityId low), +0x04 generation (=SecurityId high), +0x08 entry size
            val_hash = le32(vd, 0); val_generation = le32(vd, 4)
            sd_bytes = vd[SD_HEADER_SIZE:]
            sd = _parse_security_descriptor(sd_bytes)
            sd["security_id"] = security_id
            sd["sd_hash"] = val_hash; sd["generation"] = val_generation
            # Tampering check: the stored hash must equal the recomputed content hash
            sd["computed_hash"] = _refs_sd_hash(sd_bytes)
            sd["hash_valid"] = (sd["computed_hash"] == val_hash)
            sd["key_hex"] = kd.hex(); sd["key_len"] = len(kd)
            sd["raw"] = sd_bytes
            descriptors.append(sd)
        else:
            descriptors.append({
                "security_id": security_id, "key_hex": kd.hex(),
                "key_len": len(kd), "value_len": len(vd),
                "value_hex": vd.hex() if len(vd) < 64 else vd[:64].hex() + "...",
                "note": f"Value too short ({len(vd)} bytes, need {SD_HEADER_SIZE + 20}+)",
            })
    return descriptors, None

def _print_sd(sd, verbose=False, index=None):
    prefix = f"[{index}] " if index is not None else ""
    sec_id = sd.get("security_id", 0)
    hash_str = f", hash={_hx(sd['sd_hash'])}" if "sd_hash" in sd else ""
    gen_str = f", gen={sd['generation']}" if "generation" in sd else ""
    valid_str = ""
    if "hash_valid" in sd:
        valid_str = " [hash OK]" if sd["hash_valid"] else f" [HASH MISMATCH: computed {_hx(sd['computed_hash'])}]"
    print(f"  {prefix}SecurityId: {_hx(sec_id)}{hash_str}{gen_str}{valid_str}")
    if "error" in sd:
        print(f"    ERROR: {sd['error']}"); return
    if "note" in sd:
        print(f"    NOTE: {sd['note']} (value_len={sd.get('value_len', 0)})")
        if "value_hex" in sd: print(f"    Value hex: {sd['value_hex']}")
        return
    print(f"    Revision: {sd.get('revision', '?')}, Size: {sd.get('size', '?')} bytes")
    print(f"    Control:  {_hx(sd.get('control', 0))} ({', '.join(sd.get('control_flags', []))})")
    print(f"    Owner:    {sd.get('owner_name', '(none)')}")
    print(f"    Group:    {sd.get('group_name', '(none)')}")
    dacl = sd.get("dacl", [])
    if dacl:
        print(f"    DACL ({len(dacl)} ACEs):")
        for ace in dacl:
            print(f"      {ace.get('type','?')}: {ace.get('sid_name', ace.get('sid','?'))} -> {ace.get('mask_str', _hx(ace.get('mask',0)))}")
    else:
        print("    DACL: (none)")
    sacl = sd.get("sacl", [])
    if sacl:
        print(f"    SACL ({len(sacl)} ACEs):")
        for ace in sacl:
            print(f"      {ace.get('type','?')}: {ace.get('sid_name', ace.get('sid','?'))} -> {ace.get('mask_str', _hx(ace.get('mask',0)))}")
    if verbose and "raw" in sd:
        raw = sd["raw"]
        print(f"    Raw SD hex ({len(raw)} bytes):")
        for off in range(0, min(len(raw), 256), 16):
            hexline = " ".join(f"{b:02x}" for b in raw[off:off+16])
            ascii_line = "".join(chr(b) if 32 <= b < 127 else "." for b in raw[off:off+16])
            print(f"      {off:04x}: {hexline:<48} {ascii_line}")
        if len(raw) > 256: print(f"      ... ({len(raw) - 256} more bytes)")

def _refs_sd_hash(sd_data):
    """Recompute the ReFS/NTFS $Secure security-descriptor hash over the SD bytes.
    h = 0; for each little-endian u32 dword d in the SD: h = (d + rol(h,3)) & 0xFFFFFFFF.
    Equals the SecurityId low 32 bits (verified 1113/1113 across v3.4+v3.14). Used to
    detect descriptor tampering: a stored hash != recomputed hash flags corruption."""
    h = 0
    for i in range(0, len(sd_data) - 3, 4):
        d = le32(sd_data, i)
        h = (d + (((h << 3) | (h >> 29)) & 0xFFFFFFFF)) & 0xFFFFFFFF
    return h

def _stream_extent_records(vd, ctx=None):
    """E61: extent lists for NON-RESIDENT (>= 2 KB) streams of a resident type-0x30 value. A large ADS's
    content is NOT inline and NOT in its 0xB0 descriptor — it lives in a separate **type-0x0 sub-record**
    (key type 0x00), one per non-resident stream, using the SAME 24-byte type-0x40 extent format as
    snapshots. Returns {stream_size: [(file_vcn, vlcn, run_length), ...]} keyed by stream_size (the link:
    the 0xB0 descriptor's stream_size == the type-0x0 record's stream_size@0x38). PROVEN byte-exact on 161
    extent-backed ADS (win11refs8g v2 sweep 2 KB..2 MB + multi-ADS). Header: ihdr=le32(v,0);
    extent_count=le32(v,ihdr+0x14); extents at v[ihdr+0x28] (vlcn@+0, file_vcn@+0x0C, run@+0x14)."""
    recs = {}
    for k, v in parse_resident_btree_rows(vd, ctx):
        # E84: identify the record by its own key SHAPE, not by a zero byte at k[12]. A stream-extent key is
        # 0x50 bytes with the attribute type 0x0003 at key+0x08 (657/657 corpus-wide, every one carrying a
        # plausible stream size at value+0x38). The old test also admitted 2,382 rows of a DIFFERENT record —
        # 14-byte keys whose type at key+0x08 is 0x0080 — for which value+0x38 is not a stream size at all
        # (implausible on 2,330 of 2,350). They never collided with a real record's size on any corpus image,
        # so this changes no output; it removes the possibility of one shadowing a real stream.
        if len(k) != 0x50 or le16(k, 8) != 0x0003 or len(v) < 0x50:
            continue
        ihdr = le32(v, 0)
        if ihdr <= 0 or ihdr + 0x18 > len(v):
            continue
        cnt = le32(v, ihdr + 0x14)
        eo = ihdr + 0x28
        exts = []
        for i in range(cnt):
            b = eo + i * 24
            if b + 24 > len(v):
                break
            vlcn, fvcn, run = le64(v, b), le32(v, b + 0x0C), le32(v, b + 0x14)
            if run == 0 or run > 0x1000000:
                continue
            exts.append((fvcn, vlcn, run))
        if exts:
            recs[le64(v, 0x38)] = sorted(exts)     # keyed by stream_size
    return recs

def _read_vlcn_extents(f, ps_off, cs, tr, exts, size, _content_what=None):
    """Reassemble a stream from its (file_vcn, vlcn, run_length) extent list (24-byte type-0x40 format):
    place each run at file_vcn*cs, VLCN->PLCN via the Container Table, trim to `size`. Reuses the proven
    snapshot/CoW read path. Bytes may be stale for a recovered/deleted stream (no freshness check)."""
    if not exts:
        return b""
    alloc = min(max(fv + run for fv, _vl, run in exts) * cs, 512 * 1024 * 1024)
    buf = bytearray(alloc)
    _runs = []
    for fvcn, vlcn, run in sorted(exts):
        for j in range(run):
            try:
                plcn = tr.tr(vlcn + j)
            except Exception:
                plcn = vlcn + j
            off = (fvcn + j) * cs
            if off + cs > len(buf):
                break
            _runs.append((plcn, 1, off))
            f.seek(ps_off + plcn * cs)
            buf[off:off + cs] = f.read(cs)
    if _content_what:
        # An extent-backed ADS is output too (`export ads`), and this reader had no hole check at all.
        content_holes(f, ps_off, cs, _runs, _content_what, stream_size=size)
    return bytes(memoryview(buf)[:size])

def _ads_storage_map(vd, ctx=None):
    """{stream name: residency} for one record's named streams, from the SAME parser `export ads` uses.

    An ADS is not always inline. Below 2 KiB it usually is; at or above it the bytes live in a type-0x0
    extent record and the name row holds only the descriptor (E61). Reporting a stream without saying which
    invites the reader to assume the content is in the record -- so `details` and `specials ads` print it.
    """
    out = {}
    try:
        for a in _parse_ads_from_value(vd, ctx):
            out[a["name"]] = a.get("storage") or "unknown"
    except Exception as _e:
        # Counted, not swallowed. A stream whose residency could not be read is a gap in the evidence and
        # the reader is told; `pass` here would report the stream as though its storage were simply unknown.
        _skip_note("ADS residency", "one record", _e)
    return out


def _parse_ads_from_value(vd, ctx=None):
    """Extract Alternate Data Stream entries (name + inline content) from a resident directory-entry value.

    C11a: this now enumerates ADS via the embedded B+-tree ROW TABLE (the same structural walk `files`
    uses via detect_ads_in_resident), NOT a linear byte-scan. The old scanner skipped past each stream's
    content and MISSED every ADS beyond the first on a multi-ADS file. All-disk validation: the row table
    finds 956 ADS vs the scanner's 678; content byte-for-byte MATCHES the scanner on all 678 common ADS and
    recovers 278 more with correct content. Each ADS row's value carries the descriptor at vrow+0x08
    (le32==0x0C, le32+4==0x30 => hdr=vrow+0x04), storage_type at hdr+0x0C, alloc@hdr+0x14, size@hdr+0x1C,
    inline content at hdr+0x38. Snapshots share the 0xB0 key but have StreamSummary flags==2 (excluded via
    _is_snapshot_value). Same entry-dict shape the scanner returned, so callers are unchanged."""
    ads = []
    _ext_recs = _stream_extent_records(vd, ctx)     # E61: type-0x0 extent lists for non-resident (>=2KB) ADS
    for kd, vrow in parse_resident_btree_rows(vd, ctx):
        if not _is_b0_snapshot_key(kd) or _is_snapshot_value(vrow):
            continue
        stream_name = _b0_stream_name(kd)
        if not stream_name:
            continue
        hdr = None
        for scan in range(0, len(vrow) - 8):
            if le32(vrow, scan) == 0x0C and le32(vrow, scan + 4) == 0x30:
                hdr = scan - 4
                break
        if hdr is None or hdr < 0 or hdr + 0x24 > len(vrow):
            ads.append({"name": stream_name, "stream_size": 0, "alloc_size": 0, "storage": "unknown"})
            continue
        storage_type = le32(vrow, hdr + 0x0C)
        alloc_size = le64(vrow, hdr + 0x14)
        stream_size = le64(vrow, hdr + 0x1C)
        # R6: label the storage honestly — a genuinely-INLINE ADS keeps its bytes in the value at hdr+0x38,
        # and stores them packed exactly, so alloc_size == stream_size. If alloc != size, the inline window
        # at hdr+0x38 holds descriptor tail, NOT content, so it must not be emitted as inline content.
        # (E60 added this alloc==size guard.) The guard is ADS-specific: a $DATA main stream legitimately
        # rounds alloc up, so it is NOT applied to get_resident_data_content (there it would reject 221k
        # genuine inline files).
        # E61 (supersedes the earlier E60 "adstest is MLog-only" characterization): an ADS whose content is
        # >= 2 KB — or a small refsutil-streamsnapshot-created ADS like `adstest` — is EXTENT-BACKED. Its
        # content is not inline; the extents live in a type-0x0 sub-record keyed by stream_size (see
        # _stream_extent_records). storage_type stays 0 (still an ADS, not a snapshot). `adstest`
        # (win11refs2tsnapshots: size=30, alloc=4096) IS such an entry: its 30 bytes live in 1 committed
        # extent (vlcn 108101828), recovered byte-exact via the extent path — the MLog page at 0x98c7560 was
        # an ADDITIONAL journaled copy, not the only copy. So: claim inline only when alloc==size AND < 2 KB;
        # otherwise resolve the extent record (extent-backed) and fall back to metadata-only if none exists.
        content_off = hdr + 0x38
        inline = (storage_type == 0 and alloc_size == stream_size
                  and content_off + stream_size <= len(vrow) and stream_size <= 0x100000)
        ext_list = _ext_recs.get(stream_size) if storage_type == 0 else None
        if inline:
            storage = "inline"
        elif ext_list:
            storage = "extent-backed"
        elif storage_type == 0:
            storage = "non-inline (alloc!=size — content not in the record)"
        else:
            storage = "non-inline (type %d)" % storage_type
        entry = {"name": stream_name, "stream_size": stream_size, "alloc_size": alloc_size, "storage": storage}
        if storage == "inline":
            entry["content"] = bytes(vrow[content_off:content_off + stream_size])
        elif storage == "extent-backed":
            entry["extents"] = ext_list          # [(file_vcn, vlcn, run_length), ...] — read via _read_vlcn_extents
        ads.append(entry)
    return ads

def _find_extents_in_subrecord(vd, rec_off, rec_size, needed, tr, cs, result):
    """Search a sub-record for extent table entries."""
    rec_end = rec_off + rec_size
    for scan_off in range(rec_off + 4, rec_end - 24, 4):
        start = le32(vd, scan_off)
        end = le32(vd, scan_off + 4)
        cap = le32(vd, scan_off + 12)
        count = le32(vd, scan_off + 20)
        if not (0x10 <= start <= 0x200 and end > start and
                count > 0 and count <= 1000 and cap >= 0x100):
            continue
        entry_area = end - start
        if entry_area < count * 24 or entry_area > count * 32 + 16:
            continue
        entries_off = scan_off + start

        # Fixed 24-byte stride (normal extents)
        total_clusters = 0
        candidate_extents = []
        for i in range(count):
            eoff = entries_off + i * 24
            if eoff + 24 > len(vd): break
            vlcn = le32(vd, eoff)
            vlcn_hi = le32(vd, eoff + 4)
            flags = le32(vd, eoff + 8)
            file_vcn = le32(vd, eoff + 12)
            run_len = le32(vd, eoff + 20)
            full_vlcn = vlcn | (vlcn_hi << 32)
            if run_len > 0 and full_vlcn > 0:
                # NOTE: no tr.tr() here. Translating a candidate that is then REJECTED counted a
                # container-table miss, and that counter is surfaced to the analyst as "output may be
                # incomplete (corrupt/truncated container table)" — a false alarm on healthy volumes
                # (measured: 794 of 794 misses on three corpus images were rejected candidates).
                candidate_extents.append({
                    "vlcn": full_vlcn, "plcn": 0, "file_vcn": file_vcn,
                    "clusters": run_len, "flags": flags, "disk_offset": 0,
                })
                total_clusters += run_len
        if total_clusters == needed and candidate_extents:
            for _e in candidate_extents:                 # resolve only an ACCEPTED set
                _e["plcn"] = tr.tr(_e["vlcn"])
            result["extents"] = candidate_extents
            return

        # Variable-stride for integrity streams (32-byte checksum entries)
        total_clusters = 0
        candidate_extents = []
        eoff = entries_off
        for i in range(count):
            if eoff + 24 > len(vd): break
            vlcn = le32(vd, eoff)
            vlcn_hi = le32(vd, eoff + 4)
            flags = le32(vd, eoff + 8)
            file_vcn = le32(vd, eoff + 12)
            run_len = le32(vd, eoff + 20)
            full_vlcn = vlcn | (vlcn_hi << 32)
            if run_len > 0 and full_vlcn > 0:
                candidate_extents.append({                 # translation deferred — see the first loop
                    "vlcn": full_vlcn, "plcn": 0, "file_vcn": file_vcn,
                    "clusters": run_len, "flags": flags, "disk_offset": 0,
                    "integrity_checksum": flags == 0x1c00d0,
                })
                total_clusters += run_len
            eoff += 32 if flags == 0x1c00d0 else 24
        if total_clusters == needed and candidate_extents:
            for _e in candidate_extents:
                _e["plcn"] = tr.tr(_e["vlcn"])
            result["extents"] = candidate_extents
            return

    # Fallback: single-extent pattern (0x80000002 marker)
    for scan_off in range(rec_off + 4, rec_end - 16, 4):
        if le32(vd, scan_off) == _DATA_ATTR_MARKER:
            vlcn = le32(vd, scan_off + 4)
            cluster_count = le64(vd, scan_off + 8) if scan_off + 16 <= len(vd) else 0
            if cluster_count == needed and vlcn > 0 and _vlcn_mappable(tr, vlcn):
                # The mappability test (not tr.tr()) matters twice here: this is a heuristic marker scan, so a
                # coincidental match on an UNMAPPABLE vlcn would otherwise be accepted and read identity-mapped
                # — the wrong clusters — and would also count a container-table miss the analyst sees as
                # evidence the volume is damaged.
                result["extents"] = [{
                    "vlcn": vlcn, "plcn": tr.tr(vlcn), "file_vcn": 0,
                    "clusters": cluster_count, "flags": 0, "disk_offset": 0,
                }]
                return

def _parse_extents_from_type40(vd, cs, tr):
    """Parse data extent information from a type 0x40 value."""
    result = {
        "file_size": 0, "alloc_size": 0, "file_attrs": 0,
        "timestamps": [], "extents": [], "val_len": len(vd),
    }
    if len(vd) < 0x68: return result
    result["timestamps"] = [le64(vd, 0x28), le64(vd, 0x30),
                            le64(vd, 0x38), le64(vd, 0x40)]
    result["file_attrs"] = le32(vd, 0x48)
    result["file_size"] = le64(vd, 0x58)
    result["alloc_size"] = le64(vd, 0x60)
    needed = (result["alloc_size"] + cs - 1) // cs if result["alloc_size"] > 0 else 0
    if needed == 0: return result

    off = 0xA8
    while off < len(vd) - 4:
        rec_size = le32(vd, off)
        if rec_size == 0 or rec_size > len(vd) - off or rec_size > 4096: break
        _find_extents_in_subrecord(vd, off, rec_size, needed, tr, cs, result)
        off += rec_size
    return result


def _contiguous_cover(extents, need):
    """The corruption guard. True iff `extents` (dicts with file_vcn/clusters) form an EXACT contiguous cover
    [0, need) of a file's clusters — no gap, no overlap, ending exactly at `need`. A decoded set that passes
    this maps every file cluster exactly once, so reassembly cannot silently drop, duplicate, or misplace a
    cluster; a heuristic misread that changes a run/file_vcn (the common failure, e.g. two extents both at
    file_vcn 0) is rejected. Callers that fail this emit NO extents (a clean `extract` failure) rather than
    risk wrong bytes. (A wrong physical vlcn with the right file_vcn/run is not caught here — that is guarded
    separately by cross-agreement with the validated decoder and, where present, integrity CRC verification.)"""
    if need < 0 or not extents:
        return False
    pos = 0
    for e in sorted(extents, key=lambda e: e["file_vcn"]):
        if e["file_vcn"] != pos:
            return False
        pos += e["clusters"]
    return pos == need


def _parse_inline_holder_extents(vd, cs, tr):
    """Decode a v3.4/v3.7/v3.9/v3.10/upgraded inline-holder non-resident file's extent map by walking the
    embedded B+-tree node's INDEX ARRAY, so fragmented / multi-node files (whose runs are laid out as B+-tree
    leaf rows, not a contiguous array) decode correctly. Returns extents forming a contiguous cover of the
    allocation (value+0x60), or [] if it cannot be decoded that way (caller falls back / fails cleanly).

    Structure (RD 2026-08-20, structure_reference §C.3b): the $DATA holder (descriptor 0x00010028 at
    holder+0x04) contains a ReFS B+-tree node at `node = holder + u32@holder`. The node's rows are addressed
    by a trailing index array of `u16` offsets each tagged with a `0xffff` marker word. Each addressed row is a
    standard 24-byte extent (VLCN@0x00, flags@0x08, file_vcn@0x0C, run_length@0x14; §C.4). The file's data
    extents are exactly the rows in the holder MSB+ node's leaf index array (node table header tbl[4]/tbl[8];
    inner-node bit tbl[3]&0x100 — the same node structure walk_bplus/_walk parse). This function instead scans
    for the `…0xffff` row markers and drops rows with flag **bit 0x04** — the aggregate/fence entries that sit
    outside the leaf index array (RD-equivalent to the node-index-array decode: 855/855 holders, 0 diff). A
    contiguous-cover check then validates the result (a wrong pick can't form a clean cover). See §C.4a/§C.3b —
    note: bit 0x04 here is the extent flags@0x08, NOT the B+-tree director *key* bit (a different field)."""
    if len(vd) < 0x68 or cs <= 0:
        return []
    alloc = le64(vd, 0x60)
    if alloc <= 0 or alloc % cs:
        return []
    need = alloc // cs
    holder = None
    for off in range(0x80, len(vd) - 8, 4):
        if le32(vd, off + 4) == 0x00010028 and le32(vd, off) in (0x80000001, 0x80000002):
            holder = off
            break
    if holder is None:
        for off in range(0x80, len(vd) - 8, 4):
            if le32(vd, off) == 0x00010028:
                holder = off - 4
                break
    if holder is None:
        return []
    node = holder + le32(vd, holder)
    if not (0 < node < len(vd)):
        return []
    uniq = {}
    for off in range(node, len(vd) - 3, 2):
        if le16(vd, off + 2) != 0xffff:
            continue
        w = le16(vd, off)
        if not (0x20 <= w < 0x200):
            continue
        o = node + w
        if o + 24 > len(vd):
            continue
        flags = le32(vd, o + 8)
        if flags & 0x04:                       # aggregate/fence row outside the leaf index array (RD), not leaf data
            continue
        run_len = le32(vd, o + 0x14)
        if run_len == 0:
            continue
        vlcn = le64(vd, o)
        file_vcn = le32(vd, o + 0x0C)
        uniq[(file_vcn, vlcn, run_len, flags)] = {
            "vlcn": vlcn, "plcn": 0,
            "file_vcn": file_vcn, "clusters": run_len, "flags": flags, "disk_offset": 0,
        }
    exts = sorted(uniq.values(), key=lambda e: e["file_vcn"])
    if not _contiguous_cover(exts, need):
        return []
    # Translate ONLY the accepted set. The marker scan above is a heuristic: it treats any 0xffff-tagged
    # word as a row pointer, so most candidates it enumerates are row-header or text bytes that happen to
    # match. Translating them was harmless for the RESULT (the cover guard rejects them) but not for the
    # SIDE EFFECT: each one counted as a container-map miss, and a healthy volume ended an `extract` with
    # "N VLCN(s) had no container mapping — corrupt/truncated container table". Measured corpus-wide:
    # 6,520 of 52,200 candidates were untranslatable, but only 45 of them survive into an accepted cover —
    # so deferring the translation removes 6,475 false misses and keeps every genuine one.
    for e in exts:
        e["plcn"] = tr.tr(e["vlcn"]) if e["vlcn"] else 0
    return exts


def _decode_holder_extents(vb, cs, tr):
    """Hybrid, cover-guarded extent decode for a non-resident file's stored extents — used for BOTH the
    inline-holder value (long key_flags=0x01, §C.3b) AND the type-0x40 backing record (key_flags=0x02, §C.3a),
    which share the same $DATA-holder layout. Tries the embedded B+-tree index array first (decodes fragmented /
    multi-node files, common on v3.4–v3.10), falls back to the contiguous-array 0xA8 scan (the simple layout
    native v3.14 uses), and accepts the result only if it forms an EXACT contiguous file_vcn cover of the
    allocation (value+0x60). A parse that fails the cover check returns [] so callers fail cleanly rather than
    emit wrong bytes. On native v3.14 the index array does not match (returns []), so this reduces to the
    existing heuristic + cover check and is byte-identical to prior behavior (verified across the v3.14 corpus,
    incl. integrity and snapshot volumes; RD 2026-08-20)."""
    if len(vb) < 0x68 or cs <= 0:
        return []
    alloc = le64(vb, 0x60)
    need = alloc // cs if alloc > 0 and alloc % cs == 0 else -1
    exts = _parse_inline_holder_extents(vb, cs, tr)
    if not exts:
        exts = _parse_extents_from_type40(vb, cs, tr)["extents"]
    if not _contiguous_cover(exts, need):
        return []
    # Report any address in an ACCEPTED cover that the container table cannot map. The cover is
    # structurally complete, so the extents are real; an unmappable address means the read of
    # those clusters will fall back to identity and return whatever is at that physical offset.
    # Silence here is how wrong bytes reach the operator looking like right ones.
    if tr is not None:
        bad = [e["vlcn"] for e in exts if e.get("vlcn") and not _vlcn_mappable(tr, e["vlcn"])]
        if bad:
            _skip_note("extent cover (unmappable VLCN)",
                       "%d of %d addresses, first 0x%x" % (len(bad), len(exts), bad[0]),
                       ValueError("container table has no mapping"))
    return exts


# ─── Nested extent node inside an embedded $DATA record (E86) ────────────────
# A large file's extent map does not sit as a flat run array in its $DATA value. The value holds a B+-tree
# node (0x28-byte header) whose LEAF rows are the extent records, and when that outgrows one node the node
# becomes an INDEX node whose rows carry the standard 48-byte 4-LCN child reference. Row fields are the same
# ones _parse_extents_from_type40 already reads (vlcn lo/hi +0x00/+0x04, flags +0x08, file_vcn +0x0C,
# run +0x14); the extra field is `row_size` at +0x0A, which is 24 for a plain row and 24 + run*4 when the
# stream carries per-cluster CRC32-C (integrity streams), the trailing u32s being those checksums.

def _vlcn_mappable(tr, vlcn):
    """True when the container table can map this VLCN — tested WITHOUT calling tr.tr(). Two reasons:
    tr.tr() falls back to IDENTITY on a miss, so an unchecked call silently accepts an unmapped VLCN as a
    physical cluster and reads the wrong data; and its miss counter feeds the analyst-facing "output may be
    incomplete" caveat, which a speculative walk must not move."""
    if tr is None:
        return True
    try:
        key = vlcn >> tr.shift
        if key in tr.map:
            return True
        # Below the FIRST container id the address space is not containerised at all: container
        # ids begin at 2 (E74), so keys 0 and 1 never appear in the table and an address there is
        # a real physical cluster that needs no translation. Treating those as "unmappable" made
        # the tool warn that output "may be incomplete" for three perfectly readable large files
        # on every v3.4 volume -- the same false-alarm shape as the container-warning fix in the
        # 2026-09-03 pass, where 794 of 794 warnings were spurious.
        low = min(tr.map) if tr.map else None
        return low is not None and key < low
    except Exception:
        return False

def _extent_node_rows(buf, N):
    """(level, [row_offset, ...]) for the extent node whose 0x28-byte header starts at buf[N:].
    level 0 = leaf (rows are extents), non-zero = index (rows carry child-page references).
    Returns (None, []) when buf[N:] is not such a node."""
    if N < 0 or N + 0x28 > len(buf) or le32(buf, N) != 0x28:
        return None, []
    # Header fields as `_walk` reads them on a page (btree_node.md, E77 item 6): the key-index
    # array runs from +0x10 to +0x20 with a 4-byte stride, and its length must agree with the
    # row count at +0x14. Deriving the array's start from a u64 at +0x20 worked only because the
    # top four bytes happen to be zero, and it silently produced a plausible offset when the
    # header was damaged instead of rejecting the node.
    nrows = le32(buf, N + 0x14)
    idx_start = le32(buf, N + 0x10)
    idx_end = le32(buf, N + 0x20)
    if not (0 < nrows < 8192):
        return None, []
    if not (0x28 <= idx_start < idx_end <= len(buf) - N):
        return None, []
    if (idx_end - idx_start) // 4 != nrows:
        _skip_note("extent node header", "index array (%d-%d)/4 != %d rows"
                   % (idx_end, idx_start, nrows), ValueError("node-header invariant"))
        return None, []
    idx = N + idx_start                    # index array: u16 row offset + u16 key hint
    offs = []
    for r in range(nrows):
        a = idx + 4 * r
        if a + 4 > len(buf):
            break
        offs.append(N + le16(buf, a))
    return buf[N + 0x0C], offs

def _extent_node_map(buf, N, f, ps, cs, tr, depth=4, seen=None):
    """Every extent below the node at buf[N:], descending index nodes into their child pages.
    Returns extent dicts in the shape the rest of the tool uses. No cover check here — the caller
    applies _contiguous_cover so an incomplete walk fails cleanly instead of emitting wrong bytes."""
    if seen is None:
        seen = set()
    if depth <= 0:
        return []
    level, offs = _extent_node_rows(buf, N)
    if level is None:
        return []
    out = []
    if level == 0:
        for ro in offs:
            if ro + 0x18 > len(buf):
                continue
            row_sz = le16(buf, ro + 0x0A)
            run = le32(buf, ro + 0x14)
            # a plain run row is 24 bytes; an integrity-stream row appends one u32 CRC32-C per cluster
            if run == 0 or row_sz not in (24, 24 + run * 4):
                continue
            vlcn = le64(buf, ro)
            if vlcn == 0 or not _vlcn_mappable(tr, vlcn):
                continue
            # NOTE: no translation here. A VLCN is resolved only once the caller has accepted the set as a
            # cover, so a speculative walk that comes to nothing never probes the container table — which
            # would otherwise inflate the "VLCN had no container mapping" count the analyst reads as
            # evidence the output may be incomplete.
            out.append({"vlcn": vlcn, "plcn": None, "file_vcn": le32(buf, ro + 0x0C),
                        "clusters": run, "flags": le32(buf, ro + 8), "disk_offset": 0})
        return out
    for ro in offs:
        if ro + 0x10 > len(buf):
            continue
        _sz, _ko, _kl, _fl, vo, vl, _x = struct.unpack_from("<I6H", buf, ro)
        if vl < 32 or ro + vo + vl > len(buf):
            continue
        nref = buf[ro + vo:ro + vo + vl]
        lcns = [x for x in (le64(nref, j * 8) for j in range(4))
                if x not in (0, 0xFFFFFFFFFFFFFFFF)]
        if not lcns:
            continue
        if not all(_vlcn_mappable(tr, l) for l in lcns):
            continue
        key = tuple(lcns)
        if key in seen:                     # cycle / repeated child guard (same rule as _walk)
            continue
        seen.add(key)
        page = b""
        try:
            for l in lcns:
                f.seek(ps + (tr.tr(l) if tr else l) * cs)
                page += f.read(cs)
        except Exception:
            continue
        if len(page) < 0x54 or page[:4] != b"MSB+":
            continue
        out += _extent_node_map(page, 0x50 + le32(page, 0x50), f, ps, cs, tr, depth - 1, seen)
    return out

def _embedded_data_extents(vd, cs, ctx):
    """Extents of the CURRENT stream when its $DATA record lives in the object's embedded attribute tree
    and holds its extent map in a nested node (E86). Returns [] unless the result is an exact contiguous
    cover of the record's own allocation, so a partial walk fails cleanly.

    The row MUST be selected on the sub-stream id (key+0x10 == 0x1000). A file with snapshots carries one
    $DATA row per version under the same key prefix; picking by size or by first-match returns a SNAPSHOT's
    extents and therefore that version's bytes, not the live ones."""
    if not ctx or len(ctx) < 4 or not vd:
        return []
    f, ps, tr = ctx[0], ctx[1], ctx[3]
    for kd, val in parse_resident_btree_rows(vd, ctx):
        if (len(kd) >= 0x14 and le32(kd, 8) == 0x80000002 and le16(kd, 0x0C) == 0x0080
                and le32(kd, 0x10) == 0x1000 and len(val) > 0x88 and le32(val, 0) == 0x88):
            exts = _extent_node_map(bytes(val), 0x88, f, ps, cs, tr)
            alloc = le64(val, 0x30)
            need = alloc // cs if alloc > 0 and cs and alloc % cs == 0 else -1
            if not _contiguous_cover(exts, need):
                return []
            for e in exts:                      # resolve only an accepted cover (see _extent_node_map)
                try:
                    e["plcn"] = tr.tr(e["vlcn"]) if tr else e["vlcn"]
                except Exception as _e:
                    # [] is the documented "fail cleanly" answer, but it also means "this stream has no
                    # embedded extents" -- so a translation failure would be read as a fact about the file.
                    _skip_note("embedded extent translate", f"vlcn {e.get('vlcn')}", _e)
                    return []
            return exts
    return []


def _analyze_dir_extents(f, ps, cs, tr, obj_map, dir_oid):
    """Analyze a directory's B+-tree for file data extent information."""
    if dir_oid not in obj_map: return []
    rows = walk_bplus(f, ps, cs, tr, obj_map[dir_oid])
    files = []
    resident_files = []
    type40_map = {}

    for kd, vd in rows:
        if len(kd) < 4: continue
        attr_type = le16(kd, 0)
        key_flags = le16(kd, 2)
        if attr_type == 0x30:
            name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
            # E4 fix: non-resident value is 72 B on v3.4-v3.9, 84 B on v3.10+ (driver gate
            # RefsAddFileNameIndexEntry: 0x48 when version<0x309, else 0x54). `== 84` skipped every
            # pre-3.10 non-resident file. All reads below are <= 0x40, identical in both layouts (§C.3).
            if key_flags == 0x02 and 0x48 <= len(vd) <= 84:
                stream_idx = le64(vd, 0x00)
                target_oid = le64(vd, 0x08)
                ts = [le64(vd, 0x10), le64(vd, 0x18),
                      le64(vd, 0x20), le64(vd, 0x28)]
                alloc_size = le64(vd, 0x30)
                file_size = le64(vd, 0x38)
                file_attrs = le32(vd, 0x40)
                is_dir = bool(file_attrs & 0x10000000)
                if not is_dir:
                    # A 0-byte file is still a file. Skipping it here emitted NO record at all, so
                    # `extract` reported "file not found" for a name that `files`/`details` list
                    # (measured: every empty hard-linked name on win11refs2tspecials). Its content
                    # resolves through the normal path below and is correctly empty.
                    files.append((name, stream_idx, target_oid, file_size,
                                  alloc_size, file_attrs, ts))
            elif key_flags == 0x01 and len(vd) > 84:
                resident_files.append((name, bytes(vd)))
        elif attr_type == 0x40 and len(kd) >= 24 and len(vd) >= 0x68:
            stream_idx = le64(kd, 8)
            parent_oid = le64(kd, 16)
            # C1: keep the backing's OWN size/alloc. A name row caches a copy at value+0x38 that can go
            # stale (measured: 190 of 83,176 index-entry names corpus-wide, v3.7-v3.14); the backing is the
            # object's record, and its value+0x58 agreed with the independently-decoded $DATA stream size on
            # 190/190 of those. Every size that gates a read or a write resolves through here.
            type40_map[(stream_idx, parent_oid)] = {"extents": _decode_holder_extents(bytes(vd), cs, tr),
                                                    "obj_size": le64(vd, 0x58), "obj_alloc": le64(vd, 0x60),
                                                    "raw": bytes(vd),      # for _stream_data_form (W6)
                                                    "inline": _backing_inline_data(vd, (f, ps, cs, tr))}

    results = []
    _home_cache = {}   # target_oid -> {stream_idx: ext_info}; authoritative backing streams in the home tree
    def _home_streams(oid):
        if oid not in _home_cache:
            m = {}
            if oid in obj_map:
                for rkd, rvd in walk_bplus(f, ps, cs, tr, obj_map[oid]):
                    if len(rkd) >= 24 and le16(rkd, 0) == 0x40 and len(rvd) >= 0x68:
                        m.setdefault(le64(rkd, 8), {"extents": _decode_holder_extents(bytes(rvd), cs, tr),
                                                    "obj_size": le64(rvd, 0x58), "obj_alloc": le64(rvd, 0x60),
                                                    "raw": bytes(rvd),     # for _stream_data_form (W6)
                                                    "inline": _backing_inline_data(rvd, (f, ps, cs, tr))})
            _home_cache[oid] = m
        return _home_cache[oid]
    for name, stream_idx, target_oid, file_size, alloc_size, file_attrs, ts in files:
        # B1 fix: a non-resident file's $DATA backing is the type-0x40 stream owned by its HOME object
        # (target_oid = dir-entry value+0x08). Resolve from the home tree; keying by the enclosing
        # dir_oid alone mis-selected a stray colliding-stream_idx record physically stored in the dir.
        ext_info = None
        source = "unresolved"
        if target_oid == dir_oid:
            ext_info = type40_map.get((stream_idx, dir_oid))     # self-hosted: backing is in this dir's tree
            if ext_info: source = "local"
        elif target_oid in obj_map:
            ext_info = _home_streams(target_oid).get(stream_idx)  # resolve from the HOME tree (authoritative)
            if ext_info: source = "remote"
        # C1: the OBJECT's size wins over the name's cached copy. `files` already does this (the F-1
        # hardening); doing it here makes `dataruns`, `extract` and `export` agree with it, so the recovered
        # content of an object no longer depends on which of its names the analyst addressed. The stale value
        # is kept and reported rather than silently dropped.
        stale_name_size = None
        if ext_info:
            _osz = ext_info.get("obj_size") or 0
            if _osz and _osz != file_size:
                stale_name_size = file_size
                file_size = _osz
                if ext_info.get("obj_alloc"):
                    alloc_size = ext_info["obj_alloc"]
        # E82: the record was split out of the name row, but the DATA can still be inline in that record.
        # When the backing resolves with no extents and carries the resident-form $DATA, the bytes are right
        # here — report it as resident storage and hand the content over, instead of hunting for extents that
        # do not exist and failing with "no extents decoded".
        _inline = ext_info.get("inline") if ext_info else None
        if _inline is not None and not (ext_info.get("extents") or []):
            results.append({
                "name": name, "stream_idx": stream_idx, "target_oid": target_oid,
                "file_size": file_size, "alloc_size": alloc_size,
                "file_attrs": file_attrs, "timestamps": ts,
                "extents": [], "storage": "resident", "extent_source": source,
                "record_placement": "split",
                "data_residency": (_stream_data_form(ext_info["raw"], (f, ps, cs, tr))
                                   if ext_info and ext_info.get("raw") else DATA_INLINE),
                "stale_name_size": stale_name_size,
                # T9 / MD_ADS_RA_005: a split record's named streams live in the BACKING, which is the value
                # already read here -- not in the type-0x30 name row this branch came from.
                "ads": (_parse_ads_from_value(ext_info["raw"], (f, ps, cs, tr))
                        if ext_info and ext_info.get("raw") else []),
                "resident_content": _inline,
            })
            continue
        info = {
            "name": name, "stream_idx": stream_idx, "target_oid": target_oid,
            "file_size": file_size, "alloc_size": alloc_size,
            "file_attrs": file_attrs, "timestamps": ts,
            "extents": ext_info["extents"] if ext_info else [],
            "storage": "non-resident",
            "record_placement": "split",
            # W6: the FULL residency vocabulary from the one classifier `files` uses, so a
            # snapshot-shared or sparse stream is not flattened into "extents".
            "data_residency": (_stream_data_form(ext_info["raw"], (f, ps, cs, tr))
                               if ext_info and ext_info.get("raw") else DATA_EXTENTS),
            "extent_source": source if ext_info else "unresolved",
            "stale_name_size": stale_name_size,
            "ads": (_parse_ads_from_value(ext_info["raw"], (f, ps, cs, tr))   # T9, as above
                    if ext_info and ext_info.get("raw") else []),
        }
        for ext in info["extents"]:
            ext["disk_offset"] = ps + ext["plcn"] * cs
        results.append(info)

    for name, vd in resident_files:
        # v3.4 / v3.7 / v3.9 / upgraded: a "long" (>84 B) type-0x30 value can inline a NON-RESIDENT file's extent
        # map as a MULTI-LEVEL embedded B+-tree that parse_resident_btree_rows can't reach (so get_resident_file_size
        # == 0 and it looks "resident"). `files`/walk_directory_tree already report these IsResident=False via
        # _multilevel_extent_backed_size; decode the extents here too so `dataruns`/`extract` agree. The extent
        # framing is size@0x58 / alloc@0x60 / runs@0xA8+ (read by _parse_extents_from_type40 — proven byte-exact on
        # the CTF ReAL-FS image + win10refs8g, which were previously mis-reported resident with 0 extents).
        _ml_size = _multilevel_extent_backed_size(bytes(vd), cs)
        if _ml_size is not None:
            vb = bytes(vd)
            _alloc = le64(vb, 0x60)
            # Hybrid, cover-guarded decode (index-array primary, 0xA8-scan fallback): decodes fragmented /
            # multi-node inline-holder files and emits extents only for an exact contiguous cover, else none
            # (clean `extract` failure) — never wrong bytes.
            exts = _decode_holder_extents(vb, cs, tr)
            if not exts:
                # E86: the map is not a flat run array here — it is a nested node inside the embedded
                # $DATA record (and, past one node, a child page). Fallback ONLY: when the holder decode
                # already produced a cover, nothing changes.
                exts = _embedded_data_extents(vb, cs, (f, ps, cs, tr))
            for ext in exts:
                ext["disk_offset"] = ps + ext["plcn"] * cs
            results.append({
                "name": name, "stream_idx": 0, "target_oid": 0,
                "file_size": _ml_size, "alloc_size": _alloc,
                "file_attrs": le32(vd, 0x48) if len(vd) >= 0x4C else 0,
                "timestamps": [le64(vd, 0x28), le64(vd, 0x30), le64(vd, 0x38), le64(vd, 0x40)] if len(vd) >= 0x48 else [],
                "extents": exts, "storage": "non-resident",
                "record_placement": "embedded",
                "data_residency": _stream_data_form(vd, (f, ps, cs, tr)) or DATA_EXTENTS,
                "extent_source": "inline-holder", "ads": _parse_ads_from_value(vd, (f, ps, cs, tr)) if len(vd) > 0xA8 else [],
            })
            continue
        file_size = get_resident_file_size(vd)
        alloc_size = 0
        file_attrs = le32(vd, 0x48) if len(vd) >= 0x4C else 0
        ts = ([le64(vd, 0x28), le64(vd, 0x30), le64(vd, 0x38), le64(vd, 0x40)]
              if len(vd) >= 0x48 else [])
        extents = []
        if alloc_size >= cs and len(vd) > 0xA8:
            needed = (alloc_size + cs - 1) // cs
            ext_info = {"extents": []}
            _find_extents_in_subrecord(vd, 0xA8, len(vd) - 0xA8, needed, tr, cs, ext_info)
            extents = ext_info["extents"]
            for ext in extents:
                ext["disk_offset"] = ps + ext["plcn"] * cs
        ads_list = _parse_ads_from_value(vd, (f, ps, cs, tr)) if len(vd) > 0xA8 else []
        if not extents and file_size and get_resident_data_content(vd) is None:
            # E86: an extent-backed record whose map is a nested node in the embedded $DATA row. Fallback
            # ONLY — a file whose bytes are inline (resident) or reachable by the existing paths is not
            # touched, so nothing that resolves today changes.
            _nested = _embedded_data_extents(vd, cs, (f, ps, cs, tr))
            if _nested:
                for ext in _nested:
                    ext["disk_offset"] = ps + ext["plcn"] * cs
                extents = _nested
        entry = {
            "name": name, "file_size": file_size, "alloc_size": alloc_size,
            "storage": "resident", "extents": extents,
            # E87 two axes: this record is EMBEDDED in its directory entry, which says nothing about where
            # its BYTES are. `extents` is non-empty exactly when the map resolved (including the E86 nested
            # node), so data residency follows the bytes, not the record.
            "record_placement": "embedded",
            "data_residency": (_stream_data_form(vd, (f, ps, cs, tr))
                               or (DATA_EXTENTS if extents else DATA_INLINE)),
            "file_attrs": file_attrs, "timestamps": ts,
            "ads": ads_list,
            # Q7: inline $DATA bytes so `extract` can write a resident file's content (None if non-inline).
            "resident_content": get_resident_data_content(vd),
            # F5: a "long value" whose current stream is extent-backed is really non-resident (its bytes live
            # on disk, held by an inline 0x10028 holder we don't yet reassemble) — flagged so `extract` is
            # honest and consistent with `files` (which reports IsResident=False for it).
            "extent_backed": _current_stream_extent_backed(vd),
            # Q7/CoW: a resident file with no plain-inline $DATA may be UNMODIFIED since a snapshot — its live
            # bytes are shared with the newest snapshot. Recover them (safe case only; None otherwise).
            "cow_content": (recover_cow_current_content(f, ps, cs, tr, vd)
                            if get_resident_data_content(vd) is None
                            and not _current_stream_extent_backed(vd) else None),
            # raw type-0x30 value — lets `extract` reassemble an extent_backed file's inline 0x10028 extents.
            "raw_value": bytes(vd),
        }
        results.append(entry)
    return results

def _parse_dir_entries(f, ps, cs, tr, vlcns):
    """Walk a directory object's B+ tree and extract type-0x30 entries."""
    rows = walk_bplus(f, ps, cs, tr, vlcns)
    entries = []
    for kd, vd in rows:
        if len(kd) < 4: continue
        attr_type = le16(kd, 0)
        if attr_type != 0x30: continue
        flags = le16(kd, 2)
        try: name = kd[4:].decode("utf-16-le").rstrip("\x00")
        except UnicodeDecodeError: name = kd[4:].hex()

        if len(vd) <= 84:
            file_id = le64(vd, 0x00) if len(vd) >= 8 else 0   # F6: per-dir child ordinal (hard-link grouping)
            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
            create_time = le64(vd, 0x10) if len(vd) >= 0x18 else 0
            modify_time = le64(vd, 0x18) if len(vd) >= 0x20 else 0
            change_time = le64(vd, 0x20) if len(vd) >= 0x28 else 0
            access_time = le64(vd, 0x28) if len(vd) >= 0x30 else 0
            file_attrs = le32(vd, 0x40) if len(vd) >= 0x44 else 0
            file_size = le64(vd, 0x38) if len(vd) >= 0x40 else 0
            is_dir = bool(file_attrs & 0x10000000)
            resident = False
            # val+0x08 is the child's own OID only for a SUBDIRECTORY; a non-resident FILE has the
            # home-dir backref there (not its own OID -- files have no own OID). Keep child_oid = own
            # OID for dirs (drives recursion); expose 0 for files and keep the backref aside. --oid bug.
            home_oid = 0 if is_dir else child_oid
            if not is_dir:
                child_oid = 0
        else:
            file_id = 0
            child_oid = 0
            home_oid = 0
            create_time = le64(vd, 0x28) if len(vd) >= 0x30 else 0
            modify_time = le64(vd, 0x30) if len(vd) >= 0x38 else 0
            change_time = le64(vd, 0x38) if len(vd) >= 0x40 else 0
            access_time = le64(vd, 0x40) if len(vd) >= 0x48 else 0
            file_attrs = le32(vd, 0x48) if len(vd) >= 0x4C else 0
            file_size = 0
            is_dir = False
            resident = True

        ads_list = _parse_ads_from_value(vd, (f, ps, cs, tr)) if resident and len(vd) > 0xA8 else []
        entries.append({
            "name": name, "flags": flags, "child_oid": child_oid, "home_oid": home_oid, "file_id": file_id,
            "create_time": create_time, "modify_time": modify_time,
            "change_time": change_time, "access_time": access_time,
            "file_attrs": file_attrs, "file_size": file_size,
            "is_dir": is_dir, "resident": resident, "value_len": len(vd),
            "raw_value": vd, "ads": ads_list,
        })
    return entries

def _walk_dir_tree(f, ps, cs, tr, obj_map, oid, path, depth, max_depth, results):
    """Recursively walk directory tree, collecting entries."""
    if oid not in obj_map: return
    try: entries = _parse_dir_entries(f, ps, cs, tr, obj_map[oid])
    except Exception: return
    for entry in entries:
        child_path = f"{path}/{entry['name']}" if path else entry["name"]
        entry_type = "DIR " if entry["is_dir"] else "FILE"
        results.append({
            "path": child_path, "type": entry_type,
            "oid": entry["child_oid"], **entry,
        })
        if entry["is_dir"] and depth < max_depth and entry["child_oid"] in obj_map:
            _walk_dir_tree(f, ps, cs, tr, obj_map, entry["child_oid"],
                           child_path, depth + 1, max_depth, results)

def _walk_dir_files_with_sid(f, ps, cs, tr, obj_map, oid, path, depth, max_depth):
    """List {name, security_id, file_attrs, is_dir} for every entry under `oid`.

    Delegates to the shared walk_directory_tree(enrich=True) so SecurityId is resolved correctly for EVERY
    entry type — resident files (value+0x50), **directories** (their own type-0x10 $SI), and **non-resident
    files** (their type-0x40 backing record +0x50). The previous per-row reader unconditionally set
    security_id=0 for every <=84-byte value, i.e. for ALL directories and non-resident files (E006 +
    problem.md #3 fix, 2026-06-28). `path` prefixes the names so the recursive signature stays compatible."""
    if oid not in obj_map:
        return []
    prefix = (path + "/") if path else ""
    out = []
    for e in walk_directory_tree(f, ps, cs, tr, obj_map, oid, max_depth, True, set()):
        out.append({"name": prefix + e["path"],
                    "security_id": e.get("security_id", 0) or 0,
                    "file_attrs": e.get("file_attrs", 0),
                    "is_dir": e.get("is_dir", False)})
    return out

def _ts_vol_times(f, ps, cs, tr, obj_map):
    """Volume creation/last-modify FILETIMEs from OID 0x500, key-type 0x520 (val+0x90/0xA0)."""
    if 0x500 in obj_map:
        try:
            for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[0x500]):
                if len(kd) >= 2 and le16(kd, 0) == 0x520 and len(vd) >= 0xA8:
                    return le64(vd, 0x90), le64(vd, 0xA0)
        except Exception:
            pass
    return 0, 0

def cmd_timestomp(image, remaining, partition_start):
    """Detect files whose $SI timestamps are inconsistent with the file's real
    history on this volume — the ReFS timestomping check. Combines:
      • intrinsic $SI signals (CHANGE_LATE / PRE_FORMAT / CREATE_GT_MODIFY / FUTURE)
      • the USN journal (authoritative): a standalone BASIC_INFO_CHANGE record is a
        deliberate timestamp/attribute edit with no content change; FILE_CREATE gives
        the true creation time to compare against $SI.
    Tiers come from timestomp_verdict(), the single source: HIGH only where an AUTHORITATIVE source
    corroborates (the journal, or a hard-link sibling); MEDIUM for CHANGE_LATE without PRE_FORMAT or for
    FUTURE; INFO where every signal present is one a timestamp-preserving copy also produces; LOW
    otherwise. A count of intrinsic signals never reaches HIGH."""
    import csv as _csv
    # Phase 2: standardized --csv/--json [FILE] (bare = stdout). Pulled out before the command's own parser.
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining, allow=("--csv", "--json"))
    args = _parse_args(remaining, flags=["--all"], valued=["--min", "--margin-days", "--depth"])
    do_json = (out_fmt == "json")
    show_all = args["all"]
    # Phase 3 (§5 timestomp): the default screen view shows HIGH-confidence rows only (the authoritative
    # ones); lower tiers are revealed with `--min MEDIUM`/`--min LOW`. CSV/JSON keep ALL tiers unless --min
    # is given explicitly, so an export is complete.
    _explicit_min = args["min"] is not None
    min_conf = (args["min"] or "HIGH").upper()
    margin = int(args["margin_days"]) * 24 * 3600 * 10**7 if args["margin_days"] else TS_MARGIN_100NS
    max_depth = _int_arg(args["depth"], "--depth") if args["depth"] else DEFAULT_DEPTH
    csv_arg = out_dest if out_fmt == "csv" else None
    # INFO sits BELOW LOW: it is a reported observation (a timestamp-preserving copy), not a suspicion.
    rank = {"HIGH": 4, "MEDIUM": 3, "LOW": 2, "INFO": 1, "NONE": 0}

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, _ = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        vol_create, vol_modify = _ts_vol_times(f, ps, cs, tr, obj_map)

        # Walk every file (raw MACB).
        results = []
        _walk_dir_tree(f, ps, cs, tr, obj_map, 0x600, "", 0, max_depth, results)
        files = [r for r in results if r.get("type") == "FILE"]

        # USN journal (optional, authoritative when present).
        usn_create = {}        # unique filename -> [FILETIME of FILE_CREATE]
        bic_names = set()      # filenames with a standalone BASIC_INFO_CHANGE (reason == 0x8000)
        name_count = {}
        for r in files:
            name_count[r["name"]] = name_count.get(r["name"], 0) + 1
        journal = False
        try:
            vd, _meta = locate_change_journal(f, ps, cs, tr, obj_map)
            if vd is not None:
                streams = parse_usn_journal_streams(vd, cs, tr)
                if streams.get("j_extents"):
                    j_data = read_usn_j_stream(f, ps, cs, streams["j_extents"], streams["j_stream_size"])
                    recs = parse_usn_records(j_data)
                    journal = True
                    tmp = {}
                    for rec in recs:
                        if rec.reason & 0x00000100:  # FILE_CREATE
                            tmp.setdefault(rec.filename, []).append(rec.timestamp)
                        if rec.reason == 0x00008000 and rec.filename:  # standalone BASIC_INFO_CHANGE
                            bic_names.add(rec.filename)
                    usn_create = tmp
        except Exception:
            journal = False

        # F6: HARDLINK_MACB_MISMATCH — a ReFS-native, JOURNAL-INDEPENDENT timestomp signal. On ReFS $SI is stored
        # per-name-entry (per hard-link), NOT per-inode as on NTFS: a name-scoped SetFileTime rewrites only the
        # opened name (and the shared backing), while sibling hard-link names keep the TRUE birth. So two names of
        # one file (same home_oid + file_id) whose Created diverges reveal the stomp, and the LATEST Created is the
        # authentic birth. We flag only the backdated name(s), never the clean sibling (no false positive).
        # RD-proven on win11refs8g.raw File ID 0x1e: f6.bin Created 2011 vs f6_link.bin Created 2026 (E59 / FN_LINK_003).
        hl_groups = {}
        for r in files:
            if r.get("resident") or r.get("is_dir"):
                continue
            key = (r.get("home_oid", 0), r.get("file_id", 0))
            if key == (0, 0):
                continue
            hl_groups.setdefault(key, []).append(r)
        hl_mismatch = {}     # id(r) -> authentic (latest) Created among its hard-link siblings
        for members in hl_groups.values():
            valid = [m for m in members if _ft_valid(m.get("create_time", 0))]
            if len(valid) < 2:
                continue
            authentic = max(m["create_time"] for m in valid)
            for m in valid:
                if authentic - m["create_time"] > margin:
                    hl_mismatch[id(m)] = authentic

        def _classify(r):
            ct, mt = r.get("create_time", 0), r.get("modify_time", 0)
            chg, acc = r.get("change_time", 0), r.get("access_time", 0)
            flags = timestomp_intrinsic_flags(ct, mt, chg, acc, vol_create, vol_modify, margin)
            evidence = list(flags)
            # F6: sibling hard-link preserves the true birth -> journal-independent structural proof.
            hl_conf = id(r) in hl_mismatch
            if hl_conf:
                evidence.append("HARDLINK_MACB_MISMATCH")
            # USN cross-checks (only when the filename is unambiguous among live files)
            usn_conf = False
            if journal and name_count.get(r["name"], 0) == 1:
                if r["name"] in bic_names and ("CHANGE_LATE" in flags or "PRE_FORMAT" in flags
                                               or "CREATE_GT_MODIFY" in flags):
                    evidence.append("USN_BASIC_INFO_CHANGE")
                    usn_conf = True
                cts = usn_create.get(r["name"])
                if cts and _ft_valid(ct):
                    if min(abs(ct - u) for u in cts) > margin:
                        evidence.append("USN_CREATE_MISMATCH")
                        usn_conf = True
            # 1.C: whole-second (.0000000) Created AND Modified = a WEAK "tool-set date" hint. Corpus-measured
            # (30 imgs/134k files) it also fires on legit driver-package / archive-extracted files, so it is a
            # LOW signal ONLY — it never rises above LOW on its own and never upgrades another tier.
            round_ts = (_ft_valid(ct) and ct % 10_000_000 == 0 and _ft_valid(mt) and mt % 10_000_000 == 0)
            if round_ts:
                evidence.append("ROUND_TIMESTAMPS")
            # Single source (timestomp_verdict). This is now the ONLY surface that tiers a timestamp
            # anomaly: v1.11.0 removed the `files` TimestompFlags column, which called the same function
            # without the journal and so could only ever report the weaker half. The old local ladder here
            # tiered CHANGE_LATE+PRE_FORMAT as HIGH on a false independence premise; see timestomp_verdict.
            tier, evidence = timestomp_verdict(evidence, usn_conf=usn_conf, hl_conf=hl_conf,
                                               round_ts=round_ts)
            return tier, evidence

        rows = []
        for r in files:
            tier, evidence = _classify(r)
            if tier == "NONE" and not show_all:
                continue
            rows.append({
                # Same E87 vocabulary as `search`: this is the DATA axis, so the data words.
                "path": r["path"],
                "storage": _hx(r["oid"]) if r.get("oid") else ("(inline)" if r.get("resident") else "(extents)"),
                "tier": tier, "signals": evidence,
                "created": _filetime_to_str(r.get("create_time", 0)).replace(" UTC", ""),
                "modified": _filetime_to_str(r.get("modify_time", 0)).replace(" UTC", ""),
                "changed": _filetime_to_str(r.get("change_time", 0)).replace(" UTC", ""),
                "accessed": _filetime_to_str(r.get("access_time", 0)).replace(" UTC", ""),
            })
        # sort by confidence then path
        rows.sort(key=lambda x: (-rank[x["tier"]], x["path"]))
        flagged = [x for x in rows if x["tier"] != "NONE"]
        suspects = [x for x in flagged if rank[x["tier"]] >= rank.get(min_conf, 1)]
        counts = {t: sum(1 for x in flagged if x["tier"] == t) for t in ("HIGH", "MEDIUM", "LOW", "INFO")}
        # CSV/JSON export ALL flagged tiers by default (complete artifact); a screen view defaults to HIGH.
        export_rows = suspects if _explicit_min else flagged

        if csv_arg is not None:
            def _w(out):
                w = _csv.writer(out)
                w.writerow(["path", "storage", "confidence", "signals", "created", "modified", "changed", "accessed"])
                for x in (rows if show_all else export_rows):
                    w.writerow(_csv_row([x["path"], x["storage"], x["tier"], "|".join(x["signals"]),
                                x["created"], x["modified"], x["changed"], x["accessed"]]))
            if csv_arg == "-":
                _w(sys.stdout)
            else:
                with open(csv_arg, "w", newline="") as out:
                    _w(out)
                print(f"Wrote {len(rows if show_all else export_rows)} rows to {csv_arg}")
            return 0

        if do_json:
            _emit_json_obj({
                "image": os.path.basename(image), "refs_version": f"{vmaj}.{vmin}",
                "volume_create": _filetime_to_str(vol_create).replace(" UTC", ""),
                "volume_modify": _filetime_to_str(vol_modify).replace(" UTC", ""),
                "journal_present": journal, "files_examined": len(files),
                "counts": counts, "suspects": rows if show_all else export_rows,
            }, out_dest, "timestomp report")
            return 0

        W = 78
        print("=" * W)
        print("ReFS Timestamp-Anomaly (Timestomp) Detection")
        print("=" * W)
        print(f"  Image:           {os.path.basename(image)}  (ReFS {vmaj}.{vmin})")
        print(f"  Volume created:  {_filetime_to_str(vol_create).replace(' UTC','')}")
        print(f"  Volume modified: {_filetime_to_str(vol_modify).replace(' UTC','')}")
        print(f"  USN journal:     {'present (authoritative cross-check ON)' if journal else 'absent (intrinsic signals only)'}")
        print(f"  Files examined:  {len(files)}")
        print(f"  Flagged:         {len(flagged)}  (HIGH {counts['HIGH']} / MEDIUM {counts['MEDIUM']} / "
              f"LOW {counts['LOW']} / INFO {counts['INFO']} — INFO = ambiguous: a timestamp-preserving "
              f"copy and a backdated creation produce the same signals; corroborate with USN)")
        print()
        print("  This flags timestamps that LOOK anomalous — it is investigative INFORMATION, not proof of")
        print("  tampering. Weigh the BASIS of each row: a journal/hardlink signal is authoritative; an")
        print("  intrinsic ($SI-only) signal is a heuristic that also fires on legitimate timestamp-preserving")
        print("  copies/restores. Tiers, exactly as timestomp_verdict() decides them:")
        print("    HIGH   — an AUTHORITATIVE corroboration: the change journal, or a hard-link sibling that")
        print("             preserves the true birth. A count of intrinsic signals never reaches HIGH.")
        print("    MEDIUM — CHANGE_LATE without PRE_FORMAT (created on THIS volume, metadata altered later),")
        print("             or FUTURE (created after the volume's last metadata write).")
        print("    INFO   — every signal present is one a timestamp-preserving copy also produces")
        print("             (PRE_FORMAT / CHANGE_LATE / CREATE_GT_MODIFY / ROUND_TIMESTAMPS), so a copy and a")
        print("             backdate are indistinguishable here however many of them fire.")
        print("    LOW    — anything else.")
        print()
        if not suspects and not show_all:
            hidden = counts["MEDIUM"] + counts["LOW"] + counts["INFO"] if min_conf == "HIGH" else 0
            if hidden:
                print(f"  No HIGH-confidence timestamp anomalies. {hidden} lower-tier row(s) exist "
                      f"(MEDIUM {counts['MEDIUM']} / LOW {counts['LOW']}) — `--min MEDIUM` or `--min LOW` to see them.")
            else:
                print("  No timestamp anomalies at or above the requested confidence.")
            return 0
        _AUTH_SIGS = {"USN_BASIC_INFO_CHANGE", "USN_CREATE_MISMATCH", "HARDLINK_MACB_MISMATCH"}
        print(f"  {'Conf':<6} {'Basis':<13} {'Claimed birth':<21} {'Last real write':<21} Path")
        print(f"  {'-'*96}")
        for x in (rows if show_all else suspects):
            sigs = x["signals"]
            basis = "journal/link" if any(s in _AUTH_SIGS for s in sigs) else "intrinsic"
            print(f"  {x['tier']:<6} {basis:<13} {x['created']:<21} {x['changed']:<21} {x['path']}")
            print(f"  {'':<6} signals: {', '.join(sigs) or '(none)'}")
        if not show_all and min_conf == "HIGH" and (counts["MEDIUM"] or counts["LOW"] or counts["INFO"]):
            print()
            print(f"  ({counts['MEDIUM']} MEDIUM + {counts['LOW']} LOW row(s) hidden — `--min MEDIUM` / `--min LOW` "
                  f"to show; CSV/JSON already include every tier.)")
        print()
        print("  Signal legend  (AUTHORITATIVE = independent evidence · HEURISTIC = suggestive $SI-only):")
        print("    [AUTHORITATIVE]")
        print("      USN_BASIC_INFO_CHANGE  the USN journal recorded a deliberate basic-info edit (no content change)")
        print("      USN_CREATE_MISMATCH    $SI created differs from the FILE_CREATE journal record (true birth known)")
        print("      HARDLINK_MACB_MISMATCH one hard-link name's $SI created diverges from a sibling's (ReFS per-name")
        print("                             MACB); the LATEST sibling created is the authentic birth — only the")
        print("                             back-dated name is flagged, never the clean sibling")
        print("    [HEURISTIC — $SI only, corroborate]")
        print("      CHANGE_LATE            $SI change-time post-dates created/modified (SetFileTime/PowerShell/.NET")
        print("                             can't reach change-time) — defeated by a native-API/raw-disk stomp")
        print("      PRE_FORMAT / FUTURE    created before the volume existed / after its last write")
        print("      CREATE_GT_MODIFY       created after last write")
        print("      ROUND_TIMESTAMPS       created AND modified are whole-second (.0000000) — a tool often sets a")
        print("                             date with no sub-second time; LOW only (driver packages / archive")
        print("                             extraction also produce whole-second times)")
        print("  Note: PRE_FORMAT / CHANGE_LATE / CREATE_GT_MODIFY also fire on a legitimate")
        print("  timestamp-preserving copy (robocopy /COPY:T, a restore, an archive extraction) — and")
        print("  equally on a deliberately backdated creation. That pair alone is INFO: ambiguous, not")
        print("  cleared. The one intrinsic signal that reaches HIGH is HARDLINK_MACB_MISMATCH, which a")
        print("  copy cannot produce; corroborate anything below HIGH with the USN journal.")
        return 0
    finally:
        f.close()

def _parse_id_ref(id_str):
    """Parse a `--id HomeOid:FileId` reference (e.g. 0x3069:0x2) into (home_oid, file_id) ints (4.F). Both
    parts accept 0x-hex or decimal. Dies on a malformed reference."""
    if ":" not in id_str:
        # A bare OID is a directory / system object: its own reference is `OID:0` (FileId 0 == the object
        # itself), which is exactly how the change journal identifies a directory. So `--id 0x703` and
        # `--id 0x703:0x0` mean the same thing, and one flag addresses either kind of object.
        try:
            return int(id_str, 0), 0
        except ValueError:
            die(f"--id: expected an OID (e.g. 0x703) or a FileRef HomeOID:FileID (e.g. 0x703:0x2e), "
                f"got {id_str!r}")
    a, b = id_str.split(":", 1)
    try:
        return int(a, 0), int(b, 0)
    except ValueError:
        die(f"--id: bad reference {id_str!r} — expected HomeOid:FileId (hex or decimal)")

def _resolve_id_entry(f, ps, cs, tr, obj_map, home_oid, file_id):
    """Resolve the USN 128-bit reference (home_oid, file_id) to its walked entry (with full 'path'), or None.
    Matches file_id within the referenced home directory (home_oid); file_id==0 is a directory self-reference
    (the object's own OID == home_oid). This addresses a file WITHOUT a path (recycle-bin/$-name/duplicates)."""
    for e in walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, DEFAULT_DEPTH, True, set()):
        if e.get("file_id") == file_id and (e.get("home_oid") == home_oid or e.get("parent_oid") == home_oid):
            return e
    return None

# ─── image holes (D13) ───────────────────────────────────────────────────────
# A raw image is usually a SPARSE file, and a region the acquisition never wrote reads back as zeros. So a
# file whose data was not captured extracts at the right LENGTH with zero CONTENT, silently -- the shape of
# E83, with an acquisition cause instead of a decode one. Found by the content proof on
# win11refs2t64ksha256checksums: a well-formed 8-cluster map for a 505,381-byte file, every cluster in a
# hole, 505,381 zero bytes emitted with no warning.
#
# BUT a hole is NOT by itself evidence of missing data, and an earlier version of this check assumed it was.
# A sparse image legitimately stores a file's own zero-runs as holes: measured, a 791 MB ISO, a 1-second
# silent WAV and 245 files with correct `GFSAREPLAY` content all overlap holes and all extract CORRECTLY.
# Warning on any overlap would cry wolf on ordinary volumes.
#
# The signal that survives is narrow and is the one the content proof actually found: the content is
# ENTIRELY zero *and* the whole allocation lies in holes. Even then it is "the image may not contain this",
# not proof -- a genuinely zero-filled file looks the same. SEEK_DATA is not available everywhere, so the
# answer is three-valued: a byte count, or None for "could not determine" -- never 0, which would be a
# silent false negative.

def _hole_bytes_in(fd, start, end):
    """Bytes of [start, end) that lie in a sparse hole. None when the platform cannot tell."""
    if end <= start:
        return 0
    total = 0
    pos = start
    try:
        while pos < end:
            try:
                nxt = os.lseek(fd, pos, os.SEEK_DATA)
            except OSError as e:
                if e.errno == errno.ENXIO:      # no data at or after pos: the rest is hole/EOF
                    return total + (end - pos)
                raise
            if nxt >= end:
                return total + (end - pos)
            if nxt > pos:
                total += nxt - pos
            try:
                dend = os.lseek(fd, nxt, os.SEEK_HOLE)
            except OSError:
                return total
            if dend <= nxt:                     # no forward progress: stop rather than spin
                return total
            pos = min(dend, end)
    except (OSError, AttributeError, ValueError):
        return None                             # SEEK_DATA unsupported here -- unknown, not "none"
    return total


def _hole_ranges_in(fd, start, end):
    """Hole intervals of [start, end) as [(a, b)] in IMAGE coordinates. None when the platform cannot tell."""
    if end <= start:
        return []
    out = []
    pos = start
    try:
        while pos < end:
            try:
                nxt = os.lseek(fd, pos, os.SEEK_DATA)
            except OSError as e:
                if e.errno == errno.ENXIO:          # no data at or after pos: the rest is hole/EOF
                    out.append((pos, end))
                    return out
                raise
            if nxt >= end:
                out.append((pos, end))
                return out
            if nxt > pos:
                out.append((pos, nxt))
            try:
                dend = os.lseek(fd, nxt, os.SEEK_HOLE)
            except OSError:
                return out
            if dend <= nxt:                          # no forward progress: stop rather than spin
                return out
            pos = min(dend, end)
    except (OSError, AttributeError, ValueError):
        return None                                  # SEEK_DATA unsupported here -- unknown, not "none"
    return out


_CONTENT_HOLES = []


def content_holes(f, ps, cs, runs, what, stream_size=None):
    """THE hole check for any read whose bytes become OUTPUT. Records and warns; returns hole bytes.

    `runs` is [(plcn, n_clusters), ...] -- the PHYSICAL clusters a producer is about to turn into content.
    Returns the number of bytes that lie in image holes, 0 when none, or None when the host cannot say.

    Why this exists as one function rather than a check at each producer: the check already existed and
    had exactly ONE caller each (`_extent_hole_ranges` -> cmd_extract, `_extent_hole_bytes` ->
    get_file_content), and every other content path emitted holes as zeros with a clean exit. A punched
    cluster behind a snapshot-shared file produced five zero bytes labelled
    "snapshot-shared with the latest snapshot", rc=0 -- fabricated content under the tool's most
    confident label. Adding a seventh call site would leave an eighth to be forgotten, so producers are
    routed through here and `check_content_hole_coverage.py` asserts that they are.

    A hole is NOT proof the data is missing: a sparsely stored image keeps a file's own zero content the
    same way it keeps a range that was never captured. The caller says what it cannot distinguish.
    """
    name = getattr(f, "name", None)
    if not isinstance(name, str) or not runs:
        return None if runs else 0
    try:
        fd = os.open(name, os.O_RDONLY)
    except OSError as _e:
        # None means "the host cannot say", which callers already treat as undeterminable -- but the
        # REASON should not vanish: this is the check that decides whether output bytes are trustworthy.
        _skip_note("content hole check", what, _e)
        return None
    try:
        total = 0
        for entry in runs:
            plcn, n, foff = (entry if len(entry) == 3 else (entry[0], entry[1], None))
            if n <= 0:
                continue
            span = n * cs
            if stream_size is not None and foff is not None:
                # CLIP to the stream's logical size, exactly as _extent_hole_ranges does: "slack is not
                # content". Without this the check counts allocation slack past EOF, and D13's own note
                # records where that leads -- a 791 MB ISO, a silent WAV and 245 files with correct
                # GFSAREPLAY content all overlap holes and all extract CORRECTLY. Warning on those is
                # crying wolf, and it is the failure mode this check exists to avoid, not to cause.
                if foff >= stream_size:
                    continue                        # entirely past EOF: slack
                span = min(span, stream_size - foff)
            got = _hole_bytes_in(fd, ps + plcn * cs, ps + plcn * cs + span)
            if got is None:
                return None
            total += got
    finally:
        os.close(fd)
    if total:
        _CONTENT_HOLES.append((what, total))
        print(f"[{PROG}] WARNING: {total} byte(s) of {what} come from ranges the image stores as HOLES "
              f"and read back as zeros. A sparse image stores a file's own zero content the same way it "
              f"stores a range never captured, so this does not by itself prove data is missing — and it "
              f"does not confirm the zeros are the file's. Corroborate before relying on them.",
              file=sys.stderr)
    return total


def _content_hole_summary():
    if _CONTENT_HOLES:
        n = sum(b for _w, b in _CONTENT_HOLES)
        # NOT "bytes the image does not contain" -- that overclaims. On a sparsely stored image a hole is
        # equally how the file's OWN zero content is kept, and the tool cannot separate the two. The
        # shipped snapshots sample proves the point: 69,632 bytes of one version read from holes on a
        # perfectly healthy image. Say what is true -- the bytes came from holes -- and no more.
        print(f"[{PROG}] {len(_CONTENT_HOLES)} output stream(s) drew {n} byte(s) from ranges the image "
              f"stores as holes. Those bytes read back as zeros; whether they are the file's own zeros or "
              f"a range never captured cannot be told from this image alone.", file=sys.stderr)


# `extract` reports a hole-sourced stream three ways: a note, a `.holes.json` sidecar, and exit 2 -- and
# `--refuse-holes` withholds the bytes. Until 1.11.2 the BULK exports had only the note, so a script could
# not branch on them and an examiner got no sidecar. These three give the bulk paths the same contract,
# per OUTPUT STREAM: each written file is treated exactly as `extract` treats its one file.
_REFUSE_HOLES = False      # set from --refuse-holes by any command that writes content in bulk
_HOLE_STREAMS = []         # [{"file", "what", "hole_bytes"}] -- what the bulk sidecar records
_HOLE_REFUSALS = []        # destinations NOT written because --refuse-holes was in force


def _bulk_hole_finish(out_dir):
    """Close out a bulk export: write <out_dir>/holes.json and return the exit code (2 if any stream drew
    from image holes, else 0).

    Written even when nothing drew from holes -- an examiner keeping sidecars beside extracted files should
    not have to infer, from the absence of one, whether the run was checked and clean or never checkable.
    That is the same reason `extract` writes a sidecar for the undeterminable case."""
    status = "holes_present" if _HOLE_STREAMS else "none"
    for _h in _HOLE_STREAMS:
        try:
            _h["file"] = os.path.relpath(_h["file"], out_dir)
        except ValueError:
            pass                       # different drive on Windows: keep what we have rather than crash
    doc = {"status": status,
           "streams_with_holes": len(_HOLE_STREAMS),
           "hole_bytes": sum(h["hole_bytes"] for h in _HOLE_STREAMS),
           "refused": [os.path.relpath(_r, out_dir) for _r in _HOLE_REFUSALS],
           "streams": _HOLE_STREAMS,
           "note": "Bytes listed here were read from ranges the image stores as holes, which read back as "
                   "zeros. A sparse image stores a file's own zero content the same way it stores a range "
                   "that was never captured, so this is not by itself evidence that data is missing -- and "
                   "not confirmation that the zeros are the file's. Corroborate before relying on them."}
    try:
        # A run that matched nothing never created its export directory; the sidecar still has to exist,
        # because "checked and clean" and "never checked" are different evidential positions.
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir, "holes.json"), "w", encoding="utf-8") as fh:
            json.dump(doc, fh, indent=2)
    except OSError as _e:
        print(f"[{PROG}] WARNING: could not write {os.path.join(out_dir, 'holes.json')}: {_e}",
              file=sys.stderr)
    if _HOLE_REFUSALS:
        print(f"[{PROG}] --refuse-holes: {len(_HOLE_REFUSALS)} output stream(s) were NOT written because "
              f"their bytes would have come from image holes; every other stream was written normally.",
              file=sys.stderr)
    if _HOLE_STREAMS:
        print(f"[{PROG}] wrote {os.path.join(out_dir, 'holes.json')} naming the "
              f"{len(_HOLE_STREAMS)} stream(s) that drew from holes.", file=sys.stderr)
        return 2
    return 0


atexit.register(lambda: _content_hole_summary())


def _extent_hole_ranges(f, ps, cs, exts, file_size):
    """Holes inside the file's DATA range, as [(file_offset, length)]. None when undeterminable.

    Reports the ACTUAL hole intervals, not the extents that contain them, and clips to [0, file_size) so
    allocation slack past EOF is never reported: slack is not content.
    """
    name = getattr(f, "name", None)
    if not isinstance(name, str) or not exts or not file_size:
        return None if (exts and file_size) else []
    try:
        fd = os.open(name, os.O_RDONLY)
    except OSError:
        return None
    out = []
    try:
        for ext in sorted(exts, key=lambda e: e["file_vcn"]):
            fstart = ext["file_vcn"] * cs
            fend = min(fstart + ext["clusters"] * cs, file_size)
            if fend <= fstart:
                continue
            istart = ps + ext["plcn"] * cs
            holes = _hole_ranges_in(fd, istart, istart + (fend - fstart))
            if holes is None:
                return None
            for a, b in holes:
                out.append((fstart + (a - istart), b - a))
    finally:
        os.close(fd)
    # W7: the walk is per extent, so one hole crossing an extent boundary arrives as two adjacent
    # entries (0-4095, 4096-97672). That is a fact about the extent map, not about the hole; merge
    # them so the reported ranges are the ranges.
    out.sort()
    merged = []
    for off, ln in out:
        if merged and merged[-1][0] + merged[-1][1] == off:
            merged[-1][1] += ln
        else:
            merged.append([off, ln])
    return [(o, l) for o, l in merged]


def _extent_hole_bytes(f, ps, cs, exts):
    """Bytes of `exts` that fall in image holes, or None when undeterminable. Read-only, own fd."""
    name = getattr(f, "name", None)
    if not isinstance(name, str) or not exts:
        return None if exts else 0
    try:
        fd = os.open(name, os.O_RDONLY)
    except OSError:
        return None
    try:
        total = 0
        for ext in exts:
            n = _hole_bytes_in(fd, ps + ext["plcn"] * cs, ps + (ext["plcn"] + ext["clusters"]) * cs)
            if n is None:
                return None
            total += n
        return total
    finally:
        os.close(fd)


def get_file_content(f, ps, cs, tr, info, verify_integrity=False, _content_what=None):
    """Return (bytes | None, meta) — a file's $DATA content resolved for ANY residency, using the SAME cascade
    `cmd_extract` runs. `info` is an `_analyze_dir_extents` entry (fields: storage, file_size, extents,
    resident_content, cow_content, extent_backed, raw_value). Single source of truth so every content consumer
    (`extract`, `recyclebin`, `export recyclebin`) reads a file identically — no more resident-only assumptions
    (this is the class behind #640 extract + the deleted-carve gap + the recyclebin non-resident $I bug).

    meta["source"] is one of: empty / resident / cow / inline-holder / extents; or a NON-recoverable reason
    (inline-holder-overflow / resident-nonplain / no-extents / too-large) with bytes=None. `verify_integrity`
    attaches meta["integrity"] for the inline-holder path (the CRC32-C per-cluster check `extract` prints).
    Byte-for-byte identical to `cmd_extract` on every corpus file (validated); reads are length-safe so a
    past-EOF/stale extent cannot truncate the buffer (never wrong bytes)."""
    storage = info.get("storage")
    file_size = info.get("file_size", 0)
    extents = info.get("extents") or []
    # (A) resident-storage with no extent list: inline $DATA / snapshot-shared / inline-0x10028-holder (§C.3b).
    if file_size == 0 and not extents:
        return b"", {"source": "empty", "size": 0}
    if storage == "resident" and not extents:
        if file_size == 0:
            return b"", {"source": "empty", "size": 0}
        rc = info.get("resident_content")
        if rc is not None:
            return rc, {"source": "resident", "size": file_size}
        cow = info.get("cow_content")
        if cow is not None:
            return cow, {"source": "cow", "size": file_size}
        if info.get("extent_backed"):
            ic = _recover_inline_extent_content(f, ps, cs, tr, info.get("raw_value", b""), _content_what)
            if ic is not None:
                meta = {"source": "inline-holder", "size": file_size}
                if verify_integrity:
                    meta["integrity"] = _verify_inline_integrity(f, ps, cs, tr, info.get("raw_value", b""))
                return ic, meta
            return None, {"source": "inline-holder-overflow", "size": file_size}
        return None, {"source": "resident-nonplain", "size": file_size}
    # (B) non-resident: content lives in on-disk extents (type-0x40 backing or inline-holder multilevel map).
    if not extents:
        return None, {"source": "no-extents", "size": file_size}
    sorted_exts = sorted(extents, key=lambda e: e["file_vcn"])
    alloc = max(e["file_vcn"] + e["clusters"] for e in sorted_exts) * cs
    if alloc > 4 * 1024 * 1024 * 1024:
        return None, {"source": "too-large", "size": file_size}
    buf = bytearray(alloc)
    _runs = []
    for ext in sorted_exts:
        plcn = ext["plcn"]
        for i in range(ext["clusters"]):
            off = (ext["file_vcn"] + i) * cs
            _runs.append((plcn + i, 1, off))
            f.seek(ps + (plcn + i) * cs)
            chunk = f.read(cs)
            buf[off:off + len(chunk)] = chunk          # length-safe (a short/past-EOF read must not shrink buf)
    # This branch reassembles content from clusters, so it is a producer like every other: ask the shared
    # choke point whether any IN-RANGE cluster came from a hole. The older `not any(out)` gate below only
    # looked when the result was ENTIRELY zero, which is blind to a PARTIALLY punched file (real clusters +
    # punched ones pass `any(out)` and were never asked about) -- the D13 class one level down.
    if _content_what:
        content_holes(f, ps, cs, _runs, _content_what, stream_size=file_size)
    out = bytes(memoryview(buf)[:file_size])
    meta = {"source": "extents", "size": file_size, "n_extents": len(sorted_exts)}
    # Only ask about holes when the content is entirely zero -- that is the only case where a hole changes
    # the answer, and it keeps the syscalls off the path for every normal file.
    if file_size and not any(out):
        hb = _extent_hole_bytes(f, ps, cs, sorted_exts)
        meta["hole_bytes"] = hb
        meta["zeros_from_image_hole"] = None if hb is None else (hb >= alloc)
    return out, meta


def cmd_extract(image, remaining, partition_start):
    args = _parse_args(remaining, flags=["--no-verify-integrity", "--refuse-holes"],
                       valued=["--oid", "--depth", "--path", "--id", "-o", "--output"])
    # accept a bare name, an absolute /dir/file path, --path, or --id HomeOid:FileId (symmetric with `details`)
    id_arg = args["id"]
    filename = args["path"] or (args["_rest"][0] if args["_rest"] else None)
    start_oid = _int_arg(args["oid"], "--oid", 0) if args["oid"] else 0x600
    # Default bare-name search depth = 100 (parity with the `search` command), not 3 — a bare name is found at
    # any real tree depth. A full PATH does not use this at all (it resolves directly; see below). `--depth` overrides.
    max_depth = _int_arg(args["depth"], "--depth") if args["depth"] else DEFAULT_DEPTH
    outp = args["o"] or args["output"]

    def _emit(data):
        # Q2 UX: -o FILE saves the bytes; otherwise write to stdout and hint how to save.
        if outp:
            if os.path.isdir(outp):                                  # A2: friendly error, not a traceback
                _base = os.path.basename((stream_name or filename or "output").rstrip(":")) or "output"
                die(f"-o {outp!r} is a directory — give a FILE path (e.g. {os.path.join(outp, _base)})")
            try:
                with open(outp, "wb") as _fh:
                    _fh.write(data)
            except OSError as _e:
                die(f"could not write {outp!r}: {_e}")
            print(f"[{PROG}] wrote {len(data)} bytes to {outp}", file=sys.stderr)
        else:
            sys.stdout.buffer.write(data)
            # C1: text payload to a TTY -> add a trailing newline so the shell prompt starts on its own line.
            # stdout-only (never -o FILE), gated on isatty + a text sniff so a redirect/pipe of binary stays byte-exact.
            if data and sys.stdout.isatty() and not data.endswith(b"\n") and _looks_text(data):
                sys.stdout.buffer.write(b"\n")
            if data:
                print(f"[{PROG}] ({len(data)} bytes to stdout — add `-o FILE` to save to a file)",
                      file=sys.stderr)

    if not filename and not id_arg:
        die("extract requires a filename, a /path, or --id HomeOid:FileId")

    stream_name = None
    if filename and ":" in filename:
        parts = filename.rsplit(":", 1)
        if parts[1]:
            filename, stream_name = parts[0], parts[1]

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        if id_arg:
            # 4.F: resolve the file by its (home_oid, file_id) reference to a full path, then extract normally.
            home_oid, file_id = _parse_id_ref(id_arg)
            if file_id == 0:
                die(f"extract: --id {id_arg} refers to a DIRECTORY (file_id 0) — directories have no content")
            ent = _resolve_id_entry(f, ps, cs, tr, obj_map, home_oid, file_id)
            if ent is None:
                die(f"extract: no file found for --id {id_arg} (home_oid:file_id)")
            filename = ent["path"]; args["path"] = ent["path"]; start_oid = 0x600
        if start_oid not in obj_map:
            die(f"OID {_hx(start_oid)} not found in Object Table")

        all_results = []

        def process_dir(dir_oid, path, depth):
            results = _analyze_dir_extents(f, ps, cs, tr, obj_map, dir_oid)
            for info in results:
                full_path = f"{path}/{info['name']}" if path else info['name']
                info["path"] = full_path
                all_results.append(info)
            if depth > 0:
                dir_rows = walk_bplus(f, ps, cs, tr, obj_map[dir_oid])
                for kd, vd in dir_rows:
                    if len(kd) >= 4 and le16(kd, 0) == 0x30 and len(vd) >= 0x44:
                        child_attrs = le32(vd, 0x40)
                        if child_attrs & 0x10000000:
                            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
                            if child_oid and child_oid in obj_map:
                                child_name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
                                child_path = f"{path}/{child_name}" if path else child_name
                                process_dir(child_oid, child_path, depth - 1)

        target = None
        # Fast path: a PATH (has a separator, or came via --path) is resolved DIRECTLY — component by component
        # from the root — so there is NO depth limit and no full-tree walk (O(path length)). A full path therefore
        # always finds its file at any depth. Gated on no explicit --oid (which scopes a bare-name search instead).
        # Falls back to the name walk below if resolve_path can't resolve it (e.g. a bare name passed to --path
        # that lives in a subdirectory) — so nothing that used to resolve stops resolving.
        is_path = (not args["oid"]) and (args["path"] is not None or "/" in filename or "\\" in filename)
        if is_path:
            _poid, _pkd, _pvd = resolve_path(f, ps, cs, tr, obj_map, filename)
            if _pkd is not None and _poid in obj_map:
                _exact = _pkd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
                for info in _analyze_dir_extents(f, ps, cs, tr, obj_map, _poid):
                    if info["name"] == _exact:
                        info["path"] = filename.lstrip("/")
                        target = info
                        break

        # Bare name (or a path resolve_path could not resolve, or an --oid-scoped search): walk from start_oid to
        # max_depth (default 100) and match by name or path-suffix. `--depth` bounds ONLY this search.
        if target is None:
            process_dir(start_oid, "", max_depth)
            # strip a leading slash so an absolute /dir/file path matches the stored relative path; match on
            # a component boundary ("/"+fn) so "file.txt" no longer also matches "myfile.txt".
            fn = filename.lstrip("/")
            for info in all_results:
                p = info.get("path", "")
                if info["name"] == fn or p == fn or p.endswith("/" + fn):
                    target = info
                    break

        if not target:
            die(f"file '{filename}' not found")

        if stream_name:
            ads_match = None
            for ads in target.get("ads", []):
                if ads["name"] == stream_name:
                    ads_match = ads
                    break
            if not ads_match:
                die(f"ADS '{stream_name}' not found on '{target['name']}'")
            if ads_match["storage"] == "inline":
                content = ads_match.get("content")
                if content is None:
                    die(f"ADS '{stream_name}' has no extractable content")
                print(f"Extracting '{target['name']}:{stream_name}' ({len(content)} bytes):", file=sys.stderr)
                _emit(content)
                return 0
            if ads_match["storage"] == "extent-backed" and ads_match.get("extents"):
                # E61: a large (>=2 KB) non-resident ADS — content in on-disk extents (type-0x0 record).
                _hb0 = len(_CONTENT_HOLES)
                buf = _read_vlcn_extents(f, ps, cs, tr, ads_match["extents"], ads_match["stream_size"],
                                         _content_what=f"'{target['name']}:{stream_name}'")
                print(f"Extracting '{target['name']}:{stream_name}' ({len(buf)} bytes — extent-backed ADS, "
                      f"{len(ads_match['extents'])} extents):", file=sys.stderr)
                if target.get("file_attrs", 0) & 0x4000:
                    print(f"[{PROG}] WARNING: host is EFS-encrypted — ADS bytes are CIPHERTEXT.", file=sys.stderr)
                _emit(buf)
                return 2 if len(_CONTENT_HOLES) > _hb0 else 0
            die(f"ADS '{stream_name}' storage is '{ads_match['storage']}' — its content is not inline in the "
                f"directory value and no extent list was found, so it cannot be extracted from this record")

        if (target.get("file_size", 0) == 0 and not target["extents"]
                and target["storage"] != "resident"):
            # An empty file whose record was split out of its name row: there are no bytes and no
            # extents, so the correct result is an empty output, not a failure. Reported without
            # the word "resident" because this record does not carry the inline form.
            print(f"Extracting '{target['name']}' (0 bytes — empty file):", file=sys.stderr)
            _emit(b"")            # -o was given: create the (empty) file rather than nothing
            return 0
        if target["storage"] == "resident" and not target["extents"]:
            if target.get("file_size", 0) == 0:
                print(f"Extracting '{target['name']}' (0 bytes — empty file, inline form):", file=sys.stderr)
                _emit(b"")        # -o was given: create the (empty) file rather than nothing
                return 0
            # Q7: resident files store their $DATA inline in the directory value — write those bytes.
            content = target.get("resident_content")
            if content is not None:
                fsz = target.get("file_size", 0)
                print(f"Extracting '{target['name']}' ({len(content)} bytes — inline):", file=sys.stderr)
                if len(content) != fsz:
                    print(f"[{PROG}] WARNING: inline content is {len(content)} bytes but $DATA size is {fsz} "
                          f"— verify before relying on the output.", file=sys.stderr)
                _emit(content)
                return 0
            # Q7/CoW: a resident file unmodified since a snapshot keeps its live bytes shared with the newest
            # snapshot (current 0x10028 holder has disk_alloc==0). Recovered via the tested snapshot extractor.
            cow = target.get("cow_content")
            if cow is not None:
                # Recompute for THIS file with a name attached, so the shared-cluster reads go through
                # content_holes(). The walk's precomputed copy was produced without the check (it runs for
                # every file there); this repeats the work once, for the file actually asked for.
                _hb0 = len(_CONTENT_HOLES)
                _re = recover_cow_current_content(f, ps, cs, tr, target.get("raw_value", b""),
                                                  _content_what=f"'{target['name']}'")
                if _re is not None:
                    cow = _re
                fsz = target.get("file_size", 0)
                print(f"Extracting '{target['name']}' ({len(cow)} bytes — snapshot-shared with the latest snapshot):",
                      file=sys.stderr)
                if len(_CONTENT_HOLES) > _hb0:
                    print(f"[{PROG}] '{target['name']}': part of the bytes above came from ranges the "
                          f"image stores as holes — see the warning. Their completeness is unverified.",
                          file=sys.stderr)
                    _emit(cow)
                    return 2
                if len(cow) != fsz:
                    print(f"[{PROG}] WARNING: recovered {len(cow)} bytes but $DATA size is {fsz} — verify.",
                          file=sys.stderr)
                _emit(cow)
                return 0
            # Fell through: the $DATA is not a plain inline stream.
            if target.get("extent_backed"):
                # Non-resident file whose extent map is held INLINE in the directory value (0x10028 holder;
                # `files` reports IsResident=False). Reassemble from those inline extents (validated decode +
                # coverage gate; sparse-aware; integrity CRC32-C checksums skipped). Returns None to DEFER only
                # when the extents don't fully+cleanly cover the allocation (large/overflow holders) — then we
                # keep the honest "not supported" message rather than emit anything wrong.
                _before = len(_DEFERRALS)
                _ic = _recover_inline_extent_content(f, ps, cs, tr, target.get("raw_value", b""),
                                                     _defer_ctx=f"'{target['name']}'")
                if _ic is None and len(_DEFERRALS) > _before:
                    # A REQUESTED file was declined for an evidence reason (not the structural "this
                    # holder form is not supported" defer). Exiting 0 here would leave the caller with a
                    # missing file and a clean status -- the silent-default class in another form.
                    print(f"[{PROG}] '{target['name']}' was NOT written: the volume does not support "
                          f"reassembling it (see the warning above). Nothing was fabricated.",
                          file=sys.stderr)
                    return 2
                if _ic is not None:
                    fsz = target.get("file_size", 0)
                    print(f"Extracting '{target['name']}' ({len(_ic)} bytes — extent-backed, inline extent map):",
                          file=sys.stderr)
                    if target.get("file_attrs", 0) & 0x4000:
                        print(f"[{PROG}] WARNING: '{target['name']}' is EFS-encrypted — the extracted bytes are "
                              f"CIPHERTEXT (plaintext needs the user's key; see docs/attributes/EFS.md).", file=sys.stderr)
                    if len(_ic) != fsz:
                        print(f"[{PROG}] WARNING: reassembled {len(_ic)} bytes but $DATA size is {fsz} — verify.",
                              file=sys.stderr)
                    if not args["no_verify_integrity"]:
                        _iv = _verify_inline_integrity(f, ps, cs, tr, target.get("raw_value", b""))
                        if _iv is not None:                 # the file carries inline CRC32-C integrity checksums
                            if _iv["bad_count"] == 0:
                                _extra = f", {_iv['unset']} unset" if _iv["unset"] else ""
                                print(f"[{PROG}] integrity: {_iv['ok']}/{_iv['checked']} clusters CRC32-C-verified"
                                      f"{_extra}.", file=sys.stderr)
                            else:
                                print(f"[{PROG}] WARNING: INTEGRITY MISMATCH — {_iv['bad_count']} of "
                                      f"{_iv['checked']} checksummed clusters FAILED CRC32-C (possible corruption/"
                                      f"tampering; bytes still extracted):", file=sys.stderr)
                                for _fv, _vl, _pl, _st, _ac in _iv["bad"][:8]:
                                    print(f"[{PROG}]   file_vcn={_fv} vlcn={_vl} plcn={_pl} "
                                          f"stored=0x{_st:08x} actual=0x{_ac:08x}", file=sys.stderr)
                                if _iv["bad_count"] > 8:
                                    print(f"[{PROG}]   ... and {_iv['bad_count'] - 8} more", file=sys.stderr)
                    _emit(_ic)
                    return 0
                print(f"File '{target['name']}' is NON-RESIDENT — its $DATA is stored in on-disk extents held "
                      f"inline in the directory value ({target.get('file_size',0)} bytes). The inline extent map "
                      f"could not be fully decoded here (large/overflow holder); use `dataruns` for the map.",
                      file=sys.stderr)
                return 1
            # A CoW'd / snapshotted resident file keeps its live bytes in a 0x10028 holder.
            print(f"File '{target['name']}' has no extent map, but its $DATA is not a plain inline stream "
                  f"({target.get('file_size',0)} bytes) — for a CoW/snapshotted file use `snapshots --extract`.",
                  file=sys.stderr)
            return 1

        if not target["extents"]:
            die(f"no extents decoded for '{target['name']}'")

        # Q6: EFS guard — extracted bytes of an encrypted file are ciphertext, not plaintext.
        if target.get("file_attrs", 0) & 0x4000:
            print(f"WARNING: '{target['name']}' is EFS-encrypted (FILE_ATTRIBUTE_ENCRYPTED). "
                  "The extracted bytes are CIPHERTEXT — plaintext recovery needs the user's RSA "
                  "private key (off-volume; see docs/attributes/EFS.md).", file=sys.stderr)

        # C1: say so when this NAME cached a different size from the object's own record. It is not a
        # coverage gap and not corruption — a name row keeps a copy of the size that the driver does not
        # refresh on every update, so a hard-link or moved name can carry a stale one. The object's size is
        # what gets extracted.
        if target.get("stale_name_size") is not None:
            print(f"[{PROG}] NOTE: the name '{target['name']}' caches a stale size "
                  f"{target['stale_name_size']} — the object's own record says "
                  f"{target.get('file_size', 0)}, which is what is extracted.", file=sys.stderr)
        print(f"Extracting '{target['name']}' ({target.get('file_size',0)} bytes):", file=sys.stderr)
        sorted_exts = sorted(target["extents"], key=lambda e: e["file_vcn"])
        file_size = target.get("file_size", 0)
        alloc = max(e["file_vcn"] + e["clusters"] for e in sorted_exts) * cs
        if alloc > 4 * 1024 * 1024 * 1024:
            die(f"file allocation size {alloc} bytes exceeds 4 GiB safety limit")
        buf = bytearray(alloc)
        for ext in sorted_exts:
            plcn = ext["plcn"]
            for i in range(ext["clusters"]):
                f.seek(ps + (plcn + i) * cs)
                chunk = f.read(cs)
                offset = (ext["file_vcn"] + i) * cs
                buf[offset:offset + cs] = chunk
        # E8: signal a short read — the decoded extents cover fewer bytes than the declared file_size.
        # Emitted to stderr (not an error/exit change) because a legitimately SPARSE file also has
        # allocation < size; the examiner must decide. Byte output is unchanged (the covered bytes).
        written = min(file_size, len(buf))
        if written < file_size:
            print(f"[{PROG}] WARNING: extracted {written} of {file_size} declared bytes for "
                  f"'{target['name']}' — decoded extents cover less than the file size (coverage gap "
                  f"or a sparse file). Verify before relying on the output.", file=sys.stderr)
        _out = bytes(memoryview(buf)[:file_size])
        # D13. A hole in the image is NOT evidence that the data is missing. Raw images are stored
        # sparsely -- this corpus is 55 TB apparent / 58 GB allocated, and `cp --sparse=always` alone took
        # one 67 MB sample to 40 MB by turning REAL zero clusters into holes -- so on a sparse-stored image
        # "every cluster in a hole" is exactly what a genuinely all-zero file looks like. An earlier version
        # of this check refused such files as "an acquisition gap, not a zero-filled file"; that wording was
        # false in both halves for the two files it fired on here. The image cannot tell the two apart, so
        # the tool must not claim to.
        #
        # What it does instead: emit the bytes, say which ranges came from holes, and exit 2 so a script can
        # branch on it. The check runs on ANY hole inside the file's data range, not only on an all-zero
        # file -- a partial gap inside a file with real content is the case that used to pass silently.
        _hranges = _extent_hole_ranges(f, ps, cs, sorted_exts, file_size) if file_size else []
        _rc_holes = 0
        if _hranges is None:
            # UNDETERMINABLE is not "no holes". `if _hranges:` treated the two the same, so a file whose
            # hole coverage could not be read was written with no note, exit 0 -- and `--refuse-holes`,
            # whose whole purpose is to withhold content that may come from image holes, did not refuse.
            #
            # The default exit stays 0 on purpose: the usual cause is a filesystem without SEEK_DATA/
            # SEEK_HOLE, which says nothing about the evidence, and exiting 2 there would report a finding
            # on every extract. The strict flag is a different question -- it cannot confirm, so it refuses.
            print(f"[{PROG}] WARNING: could not determine whether any of '{target['name']}' comes from "
                  f"ranges the image stores as holes (the host could not be queried). The bytes are "
                  f"written as read; treat their completeness as unverified.", file=sys.stderr)
            if args["refuse_holes"]:
                print(f"[{PROG}] --refuse-holes: hole coverage is undeterminable, so nothing written.",
                      file=sys.stderr)
                return 2
            if outp:
                # The sidecar is written for this case TOO. An examiner who keeps sidecars beside
                # extracted files should not have to infer, from the absence of one, whether the file was
                # checked and clean or never checkable -- those are different evidential positions.
                _sidecar = outp + ".holes.json"
                try:
                    with open(_sidecar, "w", encoding="utf-8") as _sf:
                        json.dump({"file": target["name"], "size": file_size,
                                   "status": "undeterminable",
                                   "hole_bytes": None, "ranges": [],
                                   "note": "Whether any of this file's bytes come from ranges the image "
                                           "stores as holes could not be determined (the host could not "
                                           "be queried for hole coverage). The bytes were written as "
                                           "read; their completeness is unverified, not verified."},
                                  _sf, indent=2)
                    print(f"[{PROG}] wrote {_sidecar} recording that hole coverage is undeterminable.",
                          file=sys.stderr)
                except OSError as _e:
                    print(f"[{PROG}] WARNING: could not write {_sidecar}: {_e}", file=sys.stderr)
        if _hranges:
            _hbytes = sum(n for _o, n in _hranges)
            _rtxt = ", ".join(f"{o}-{o + n - 1}" for o, n in _hranges[:8])
            if len(_hranges) > 8:
                _rtxt += f", … ({len(_hranges)} ranges)"
            _verb = "would be written from" if args["refuse_holes"] else "were written from"
            print(f"[{PROG}] NOTE: {_hbytes} of {file_size} bytes of '{target['name']}' {_verb} ranges the "
                  f"image stores as holes, which read back as zeros: {_rtxt}. A sparse image stores a file's "
                  f"own zero content the same way it stores a range that was never captured, so this does "
                  f"not by itself mean the data is missing — and does not confirm the zeros are the file's. "
                  f"Corroborate before relying on them.", file=sys.stderr)
            if outp and not args["refuse_holes"]:      # no sidecar beside a file we are not writing
                _sidecar = outp + ".holes.json"
                try:
                    with open(_sidecar, "w", encoding="utf-8") as _sf:
                        json.dump({"file": target["name"], "size": file_size,
                                   "status": "holes_present",
                                   "hole_bytes": _hbytes,
                                   "note": "Ranges read back as zeros because the image stores them as "
                                           "holes. On a sparsely-stored image that is also how genuine "
                                           "zero content is stored; the image cannot distinguish them.",
                                   "ranges": [{"offset": o, "length": n} for o, n in _hranges]},
                                  _sf, indent=2)
                    print(f"[{PROG}] wrote {_sidecar} listing those ranges.", file=sys.stderr)
                except OSError as _e:
                    print(f"[{PROG}] WARNING: could not write {_sidecar}: {_e}", file=sys.stderr)
            _rc_holes = 2
            if args["refuse_holes"]:
                print(f"[{PROG}] --refuse-holes: nothing written.", file=sys.stderr)
                return 2
        _emit(_out)

        return _rc_holes

    finally:
        f.close()

# ─── $RECYCLE.BIN ($I metadata) — F8 ─────────────────────────────────────────
def _decode_recycle_i(data):
    """Decode a Windows $I recycle-bin metadata file. Returns a dict or None.
    Format 2 (Win10/11): u64 header(=2)@0x00, u64 original size@0x08, u64 deletion FILETIME@0x10,
    u32 path length in WCHARs incl NUL@0x18, UTF-16LE original path@0x1C.
    Format 1 (Vista-8.1): u64 header(=1)@0x00, size@0x08, deletion FILETIME@0x10, fixed 260-WCHAR path@0x18."""
    if data is None or len(data) < 0x18:
        return None
    header = le64(data, 0x00)
    if header not in (1, 2):
        return None
    size = le64(data, 0x08)
    del_ft = le64(data, 0x10)
    if header == 2:
        if len(data) < 0x1C:
            return None
        nchars = le32(data, 0x18)
        raw = data[0x1C:0x1C + nchars * 2]
    else:
        raw = data[0x18:0x18 + 260 * 2]
    orig = raw.decode("utf-16-le", errors="replace").split("\x00", 1)[0]
    return {"header": header, "size": size, "deletion_time": del_ft, "original_path": orig}


def _walk_recycle(f, ps, cs, tr, obj_map, dir_oid, sid, depth, out):
    """Descend the $RECYCLE.BIN subtree, decoding $I rows inline (the SID is the top-level subfolder name)."""
    if depth < 0 or dir_oid not in obj_map:
        return
    child_dirs = []; names_here = set(); i_rows = []
    for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[dir_oid]):
        if len(kd) < 4 or le16(kd, 0) != 0x30:
            continue
        name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
        names_here.add(name)
        # file_attrs live at value+0x40 in the NON-resident (<=84 B) layout but at value+0x48 in the
        # resident (>84 B) layout — the $I metadata files are RESIDENT, so reading +0x40 for them gets
        # garbage and can wrongly set the directory bit (dropped $I6O4T60.md). Use the right offset.
        if len(vd) <= NON_RESIDENT_MAX_VALUE:
            attrs = le32(vd, 0x40) if len(vd) >= 0x44 else 0
        else:
            attrs = le32(vd, 0x48) if len(vd) >= 0x4C else 0
        if attrs & 0x10000000:
            child_dirs.append((le64(vd, 0x08) if len(vd) >= 0x10 else 0, name))
        elif name.startswith("$I"):
            i_rows.append((name, bytes(vd)))
    # Resolve each $I's content through the SHARED resident-or-non-resident reader (get_file_content), so a
    # NON-RESIDENT $I (len(vd)<=84, common on ReFS 3.4) is followed to its on-disk extents instead of failing
    # "plain inline record". _analyze_dir_extents already resolved every file in this dir (resident inline /
    # inline-holder / type-0x40 backing); the inline fallback covers any $I it did not enumerate.
    infos = {info["name"]: info for info in _analyze_dir_extents(f, ps, cs, tr, obj_map, dir_oid)}
    for name, vd in i_rows:
        if name in infos:
            content, _m = get_file_content(f, ps, cs, tr, infos[name],
                                           _content_what="recycle-bin metadata (%s)" % name)
        else:
            content = get_resident_data_content(vd) if len(vd) > 84 else None
        meta = _decode_recycle_i(content)
        r_name = "$R" + name[2:]
        out.append({"sid": sid, "i_name": name, "r_name": r_name,
                    "r_present": r_name in names_here, "meta": meta})
    for child_oid, cname in child_dirs:
        _walk_recycle(f, ps, cs, tr, obj_map, child_oid, sid or cname, depth - 1, out)


def cmd_recyclebin(image, remaining, partition_start):
    """F8: decode $RECYCLE.BIN $I metadata files -> original path + deletion time + size, and whether the
    $R payload survives. The $I is a small resident file, so its bytes come from the same inline-$DATA path
    as `extract`."""
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining)
    _parse_args(remaining)   # reject any stray flags
    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))
    try:
        recycle_oid = None
        if 0x600 in obj_map:
            for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[0x600]):
                if len(kd) >= 4 and le16(kd, 0) == 0x30 and len(vd) >= 0x10:
                    if kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00") == "$RECYCLE.BIN":
                        recycle_oid = le64(vd, 0x08); break
        recs = []
        if recycle_oid is not None:
            _walk_recycle(f, ps, cs, tr, obj_map, recycle_oid, "", 8, recs)

        if out_fmt:
            cols = ["sid", "i_file", "r_file", "r_present", "decoded",
                    "original_path", "deletion_time", "size"]
            out = [{"sid": r["sid"], "i_file": r["i_name"], "r_file": r["r_name"],
                    "r_present": r["r_present"], "decoded": r["meta"] is not None,
                    "original_path": r["meta"]["original_path"] if r["meta"] else None,
                    "deletion_time": filetime_to_iso(r["meta"]["deletion_time"]) if r["meta"] else None,
                    "size": r["meta"]["size"] if r["meta"] else None} for r in recs]
            _emit_records(out, cols, out_fmt, out_dest, "recycled items"); return 0

        print("=" * 78)
        print(f"ReFS $RECYCLE.BIN — deleted-to-recycle-bin items ({os.path.basename(image)})")
        print("=" * 78)
        if recycle_oid is None:
            print("  No $RECYCLE.BIN directory on this volume."); return 0
        if not recs:
            print("  $RECYCLE.BIN present but holds no $I metadata files (recycle bin empty)."); return 0
        recs.sort(key=lambda r: (filetime_to_iso(r["meta"]["deletion_time"]) if r["meta"] else ""))
        for r in recs:
            print(f"\n  {r['i_name']}   (SID {r['sid'] or '?'})")
            m = r["meta"]
            if m:
                print(f"    Original path:  {m['original_path']}")
                print(f"    Deleted:        {filetime_to_iso(m['deletion_time'])}")
                print(f"    Size:           {m['size']:,} bytes")
            else:
                print("    ($I content could not be decoded from a plain inline record)")
            print(f"    Payload ({r['r_name']}): {'present' if r['r_present'] else 'MISSING (metadata only)'}")
        print(f"\n  {len(recs)} recycled item(s).")
        if recs:
            print(f"  Recover the $R payloads with:  forefst {os.path.basename(image)} export recyclebin <DIR>")
        return 0
    finally:
        f.close()

def cmd_security(image, remaining, partition_start):
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining, allow=("--json",))
    args = _parse_args(remaining, flags=["-v", "--verbose", "--files", "--audit"], valued=["--sid", "--file"])
    verbose = args["v"] or args["verbose"]

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        descriptors, error = _parse_sd_stream(f, ps, cs, tr, obj_map)
        if error:
            print(f"ERROR: {error}", file=sys.stderr); return 1
        sd_by_id = {sd.get("security_id", 0): sd for sd in descriptors}
        sid_filter = _int_arg(args["sid"], "--sid", 0) if args["sid"] else None

        if args["audit"]:
            # Q4: one-shot content-addressed-hash audit (tamper check) over every descriptor.
            checked = [sd for sd in descriptors if "hash_valid" in sd]
            failures = [sd for sd in checked if not sd["hash_valid"]]
            print("=" * 78)
            print(f"ReFS Security Descriptor Hash Audit — {os.path.basename(image)}")
            print("=" * 78)
            print(f"  Descriptors: {len(descriptors)}  (hash-checked: {len(checked)})")
            if not failures:
                print(f"  VERDICT: CLEAN — 0/{len(checked)} descriptors fail the content-addressed hash")
            else:
                print(f"  VERDICT: *** {len(failures)}/{len(checked)} FAIL the hash — possible tampering ***")
                for sd in failures:
                    print(f"    SecurityId {_hx(sd.get('security_id',0))}: stored {_hx(sd.get('sd_hash',0))} "
                          f"!= computed {_hx(sd.get('computed_hash',0))}")
            return 0 if not failures else 2

        if out_fmt:
            output = {"security_descriptors": [{k: v for k, v in sd.items() if k != "raw"} for sd in descriptors]}
            if args["files"] or args["file"]:
                files = _walk_dir_files_with_sid(f, ps, cs, tr, obj_map, 0x600, "", 0, 10)
                if args["file"]:
                    fl = args["file"].lower()
                    files = [fe for fe in files if fl in fe["name"].lower()]
                output["file_mappings"] = files
            _emit_json_obj(output, out_dest, "%d security descriptors" % len(descriptors))
            return 0

        print("=" * 78)
        print("ReFS Security Descriptors")
        print("=" * 78)
        print(f"  Image:        {image}")
        print(f"  ReFS version: {vmaj}.{vmin}")

        if sid_filter is not None:
            if sid_filter in sd_by_id:
                print(f"\nSecurity Descriptor for SecurityId {_hx(sid_filter)}:")
                _print_sd(sd_by_id[sid_filter], verbose=verbose)
            else:
                found = False
                for sd in descriptors:
                    if sd.get("security_id") == sid_filter:
                        print(f"\nSecurity Descriptor for SecurityId {_hx(sid_filter)}:")
                        _print_sd(sd, verbose=verbose); found = True; break
                if not found:
                    print(f"\n  SecurityId {_hx(sid_filter)} not found in OID 0x530")
                    print(f"  Available SecurityIds: {', '.join(_hx(sd.get('security_id', 0)) for sd in descriptors[:20])}")
        elif args["files"] or args["file"]:
            files = _walk_dir_files_with_sid(f, ps, cs, tr, obj_map, 0x600, "", 0, 10)
            if args["file"]:
                fl = args["file"].lower()
                files = [fe for fe in files if fl in fe["name"].lower()]
            if not files:
                print("\n  No files found" + (f" matching '{args['file']}'" if args["file"] else ""))
            else:
                # Q7: per-owner-SID file-count summary BEFORE the (long) per-file list.
                sid_counts = {}
                for fe in files:
                    sid_counts[fe["security_id"]] = sid_counts.get(fe["security_id"], 0) + 1
                print(f"\n  Files per owner SID ({len(sid_counts)} distinct SID(s)):")
                print(f"    {'SecurityId':<14} {'Files':>7}   Owner")
                print(f"  {'-'*76}")
                for sid, n in sorted(sid_counts.items(), key=lambda kv: (-kv[1], kv[0])):
                    owner = sd_by_id[sid].get("owner_name", "(none)") if sid in sd_by_id else "(unknown)"
                    print(f"    {_hx(sid):<14} {n:>7}   {owner}")
                print(f"  {'-'*76}")
                print(f"    Total: {len(files)} files across {len(sid_counts)} owner SID(s)")

                print(f"\n  {'Name':<40} {'Type':<6} {'SecurityId':<14} {'Owner'}")
                print(f"  {'-'*76}")
                for fe in files:
                    sid = fe["security_id"]
                    ftype = "DIR" if fe["is_dir"] else "FILE"
                    owner = sd_by_id[sid].get("owner_name", "(none)") if sid in sd_by_id else "(unknown)"
                    print(f"  {fe['name']:<40} {ftype:<6} {_hx(sid):<14} {owner}")
                if verbose:
                    unique_sids = set(fe["security_id"] for fe in files)
                    print(f"\n  Referenced Security Descriptors ({len(unique_sids)} unique):")
                    for sid in sorted(unique_sids):
                        if sid in sd_by_id:
                            print(); _print_sd(sd_by_id[sid], verbose=True)
        else:
            print(f"\n  Total security descriptors: {len(descriptors)}\n")
            for i, sd in enumerate(descriptors):
                _print_sd(sd, verbose=verbose, index=i); print()

        if sid_filter is None and not args["file"]:
            unique_owners = set()
            for sd in descriptors:
                owner = sd.get("owner", "")
                if owner and owner != "(none)": unique_owners.add(owner)
            print("  Summary:")
            print(f"    Total SDs:        {len(descriptors)}")
            print(f"    Unique owners:    {len(unique_owners)}")
            for owner in sorted(unique_owners):
                print(f"      {_sid_name(owner)}")

        return 0

    finally:
        f.close()


# ════════════════════════════════════════════════════════════════════════
#  Migrated forensic commands (Phase 4): reparse / deleted / snapshots / integrity / export / dataruns
#  Ported VERBATIM from refsanalysis (closure: reparse decoders, deleted/slack scanners, snapshot
#  parsers, page-checksum verifiers, data-run/export readers; _attrs_to_str/_tag_name over forefst's
#  canonical attrs_to_str/REPARSE_TAGS). Routed via FORENSIC_HANDLERS.
# ════════════════════════════════════════════════════════════════════════

_CT_ROOT_INDICES = {7, 8, 12}

_KNOWN_OIDS = {
    0x0007: "Upcase Table",
    0x0008: "Upcase Table (dup)",
    0x0009: "Logfile Information Table",
    0x000A: "Logfile Information (dup)",
    0x000D: "Trash Table",
    0x0030: "Session Activity Table",
    0x0500: "Volume Information",
    0x0501: "Volume Information (dup)",
    0x0520: "FS Metadata",
    0x0530: "Security Descriptor Stream",
    0x0540: "Reparse Point Index",
    0x0541: "Reparse Point Index (dup)",
    0x0600: "Root Directory",
}

_VALID_SIGS = {b"MSB+", b"CHKP", b"SUPB", b"MLog"}

def _attrs_to_str(attrs, full=True):
    # adapter over the canonical helper (hex render on no-flags = legacy refsanalysis behaviour)
    return attrs_to_str(attrs, full=full, hex_if_empty=True)

def _tag_name(tag):
    return REPARSE_TAGS.get(tag, f"Unknown(0x{tag:08x})")

def _decode_symlink(data, offset=0):
    if len(data) < offset + 20: return {"error": "Symlink data too short"}
    sub_off = le16(data, offset); sub_len = le16(data, offset + 2)
    print_off = le16(data, offset + 4); print_len = le16(data, offset + 6)
    flags = le32(data, offset + 8)
    buf_start = offset + 12
    result = {"flags": flags, "relative": bool(flags & 1)}
    if buf_start + sub_off + sub_len <= len(data) and sub_len > 0:
        result["substitute_name"] = data[buf_start+sub_off:buf_start+sub_off+sub_len].decode("utf-16-le", errors="replace")
    if buf_start + print_off + print_len <= len(data) and print_len > 0:
        result["print_name"] = data[buf_start+print_off:buf_start+print_off+print_len].decode("utf-16-le", errors="replace")
    return result

def _decode_mount_point(data, offset=0):
    if len(data) < offset + 16: return {"error": "Mount point data too short"}
    sub_off = le16(data, offset); sub_len = le16(data, offset + 2)
    print_off = le16(data, offset + 4); print_len = le16(data, offset + 6)
    buf_start = offset + 8
    result = {}
    if buf_start + sub_off + sub_len <= len(data) and sub_len > 0:
        result["substitute_name"] = data[buf_start+sub_off:buf_start+sub_off+sub_len].decode("utf-16-le", errors="replace")
    if buf_start + print_off + print_len <= len(data) and print_len > 0:
        result["print_name"] = data[buf_start+print_off:buf_start+print_off+print_len].decode("utf-16-le", errors="replace")
    return result

def _decode_lx_symlink(data, offset=0):
    if len(data) < offset + 4: return {"error": "LX symlink data too short"}
    lx_flags = le32(data, offset)
    target_bytes = data[offset+4:]
    if target_bytes and target_bytes[-1] == 0: target_bytes = target_bytes[:-1]
    try: target = target_bytes.decode("utf-8", errors="replace")
    except Exception: target = target_bytes.hex()
    return {"lx_flags": lx_flags, "target": target}

def _decode_reparse_data(tag, data):
    result = {"tag": tag, "tag_name": _tag_name(tag), "data_len": len(data)}
    if tag == 0xA000000C:
        result.update(_decode_symlink(data))
    elif tag == 0xA0000003:
        result.update(_decode_mount_point(data))
    elif tag == 0xA000001D:
        result.update(_decode_lx_symlink(data))
    elif tag == 0x80000024:
        result["note"] = "WSL LX_FIFO (named pipe)"
        if len(data) >= 8:
            result["dev_major"] = le32(data, 0); result["dev_minor"] = le32(data, 4)
    elif tag in (0x80000025, 0x80000026):
        result["note"] = "WSL special file (LX_CHR/LX_BLK character/block device)"
        if len(data) >= 8:
            result["dev_major"] = le32(data, 0); result["dev_minor"] = le32(data, 4)
    elif tag == 0x80000023:
        result["note"] = "WSL AF_UNIX (Unix domain socket)"
    elif tag == 0x80000013:
        result["note"] = "Data deduplication chunk store reference"
    elif tag == 0x80000017:
        result["note"] = "Windows Overlay Filter (WOF, compressed)"
    elif tag == 0x8000001B:
        result["note"] = "App execution alias (APPEXECLINK) -- Store app package + target exe"
    elif tag == 0x80000018:
        result["note"] = "Windows Container Isolation (WCI)"
    else:
        result["raw_hex"] = data[:64].hex() if data else ""
        if len(data) > 64: result["raw_hex"] += f"... ({len(data)} total bytes)"
    return result

def _extract_reparse_from_resident(vd):
    if len(vd) < 0xA8: return None
    off = 0xA8
    while off < len(vd) - 8:
        marker = le32(vd, off)
        if marker == 0x80000001:
            desc = le32(vd, off + 4)
            if desc == 0xC0:
                # Reparse sub-record: marker(4) + desc(4) + header(12) + REPARSE_DATA_BUFFER
                buf_off = off + 0x14
                if buf_off + 8 > len(vd):
                    break
                tag = le32(vd, buf_off)
                data_len = le16(vd, buf_off + 4)
                if tag in REPARSE_TAGS and 0 < data_len < len(vd) - buf_off - 8:
                    return _decode_reparse_data(tag, vd[buf_off+8:buf_off+8+data_len])
            # Skip to next marker
            off = _next_subrecord(vd, off + 8)
        elif marker == 0x80000002:
            off = _next_subrecord(vd, off + 8)
        else:
            off += 4
    return None

def _parse_reparse_index(f, ps, cs, tr, obj_map):
    if 0x540 not in obj_map:
        return [], "OID 0x540 (Reparse Point Index) not found"
    rows = walk_bplus(f, ps, cs, tr, obj_map[0x540])
    entries = []
    for kd, vd in rows:
        if len(kd) >= 24:
            # 24-byte key (driver-verified 2026-07-05, E2 + disk-verified): u32 marker 0x80000001 @0,
            # ReparseTag @4, then a 16-byte _REFS_FILE_REFERENCE = word0 @8 + OID @0x10. word0 is a small
            # entry ordinal (2..32 observed); the OID @0x10 is the reparse file's CONTAINING-DIRECTORY OID
            # (disk: every index OID matches a reparse file's parent OID — 242/242 across 3 images), NOT the
            # file's own OID (ReFS files have none). Together they are the file's 128-bit reference.
            # See structure_reference §C.8.
            entries.append({
                "reparse_tag": le32(kd, 4), "tag_name": _tag_name(le32(kd, 4)),
                "file_ref_word0": le64(kd, 8), "dir_oid": le64(kd, 16),
                "marker": le32(kd, 0),
                "key_hex": kd.hex(), "value_len": len(vd),
            })
        elif len(kd) >= 8:
            reparse_tag = le32(kd, 4) if len(kd) >= 8 else le32(kd, 0)
            entries.append({
                "reparse_tag": reparse_tag, "tag_name": _tag_name(reparse_tag),
                "key_hex": kd.hex(), "key_len": len(kd), "value_len": len(vd),
            })
    return entries, None

def _walk_dir_for_reparse(f, ps, cs, tr, obj_map, oid, path, depth, max_depth):
    if depth > max_depth or oid not in obj_map: return []
    rows = walk_bplus(f, ps, cs, tr, obj_map[oid])
    files = []
    for kd, vd in rows:
        if len(kd) < 4 or le16(kd, 0) != 0x30: continue
        name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
        full_path = f"{path}/{name}" if path else name
        if len(vd) <= 84:
            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
            is_dir = bool(le32(vd, 0x40) & 0x10000000) if len(vd) >= 0x44 else False
            if is_dir and child_oid and child_oid in obj_map:
                files.extend(_walk_dir_for_reparse(f, ps, cs, tr, obj_map, child_oid, full_path, depth + 1, max_depth))
            continue
        file_attrs = le32(vd, 0x48) if len(vd) >= 0x4C else 0
        has_reparse = bool(file_attrs & 0x0400)
        is_dir = bool(file_attrs & 0x10000000)
        entry = {
            "name": full_path, "file_attrs": file_attrs, "has_reparse": has_reparse,
            "is_dir": is_dir, "value_len": len(vd), "reparse_data": None, "wsl_eas": {},
        }
        if has_reparse and len(vd) >= 0xA8:
            entry["reparse_data"] = _extract_reparse_from_resident(vd)
        if file_attrs & 0x00040000:
            for search_off in range(0xA0, len(vd) - 20):
                if vd[search_off+8:search_off+11] == b"$LX":
                    eas = _parse_extended_attributes(vd[search_off:])
                    for ea in eas:
                        if ea["name"] == "$LXUID" and len(ea["value"]) >= 4: entry["wsl_eas"]["lxuid"] = le32(ea["value"], 0)
                        elif ea["name"] == "$LXGID" and len(ea["value"]) >= 4: entry["wsl_eas"]["lxgid"] = le32(ea["value"], 0)
                        elif ea["name"] == "$LXMOD" and len(ea["value"]) >= 4:
                            entry["wsl_eas"]["lxmod"] = le32(ea["value"], 0)
                            entry["wsl_eas"]["lxmod_str"] = f"{le32(ea['value'], 0):06o}"
                        elif ea["name"] == "$LXDEV" and len(ea["value"]) >= 8:
                            entry["wsl_eas"]["lxdev_major"] = le32(ea["value"], 0)
                            entry["wsl_eas"]["lxdev_minor"] = le32(ea["value"], 4)
                    break
        files.append(entry)
        if is_dir:
            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
            if child_oid and child_oid in obj_map:
                files.extend(_walk_dir_for_reparse(f, ps, cs, tr, obj_map, child_oid, full_path, depth + 1, max_depth))
    return files

def _classify_b0_entry(val_data):
    return 'TRUE_SNAPSHOT' if _is_snapshot_value(val_data) else 'ADS'

def _decode_dir_row_value(vd):
    """Decode a type-0x30 directory-entry VALUE into name/MACB/attrs metadata. Resident entries (>84 B)
    carry the inline $SI at value+0x28; non-resident entries carry timestamps at value+0x10."""
    e = {"value_len": len(vd), "resident": len(vd) > 84}
    # E1 fix: discriminate on >84 (NON_RESIDENT_MAX_VALUE), NOT >=0x50 — an 84-byte v3.10+/v3.14
    # NON-resident value (84>=0x50) previously took the resident branch and was mis-decoded with
    # resident offsets. Resident values are always >84; non-resident (72/84 B) use +0x10/+0x40 (§C.3).
    if len(vd) > 84:
        e["create_time"] = le64(vd, 0x28); e["modify_time"] = le64(vd, 0x30)
        e["change_time"] = le64(vd, 0x38); e["access_time"] = le64(vd, 0x40)
        e["file_attrs"] = le32(vd, 0x48); e["is_dir"] = bool(le32(vd, 0x48) & 0x10000000)
    elif len(vd) >= 0x44:
        e["child_oid"] = le64(vd, 0x08) if len(vd) >= 0x10 else 0
        e["create_time"] = le64(vd, 0x10); e["modify_time"] = le64(vd, 0x18)
        e["change_time"] = le64(vd, 0x20); e["access_time"] = le64(vd, 0x28)
        e["file_attrs"] = le32(vd, 0x40); e["is_dir"] = bool(le32(vd, 0x40) & 0x10000000)
    return e

def _next_subrecord(vd, start):
    for pos in range(start, len(vd) - 4, 4):
        m = le32(vd, pos)
        if m in (0x80000001, 0x80000002):
            return pos
    return len(vd)

def _parse_extended_attributes(data):
    """Parse Windows Extended Attributes (EA) chain from raw bytes."""
    eas = []
    offset = 0
    for _ in range(100):
        if offset + 8 > len(data): break
        next_off = le32(data, offset)
        ea_flags = data[offset + 4]
        name_len = data[offset + 5]
        value_len = le16(data, offset + 6)
        if name_len == 0 and value_len == 0: break
        name_start = offset + 8
        name_end = name_start + name_len
        if name_end >= len(data): break
        name = data[name_start:name_end].decode("ascii", errors="replace")
        value_start = name_end + 1
        value_end = value_start + value_len
        if value_end > len(data): break
        value = data[value_start:value_end]
        eas.append({"name": name, "value": value, "flags": ea_flags})
        if next_off == 0: break
        offset += next_off
    return eas

def _parse_snapshot_value(val_data, snap_name):
    info = {"name": snap_name, "raw_len": len(val_data),
            "is_true_snapshot": _classify_b0_entry(val_data) == 'TRUE_SNAPSHOT'}
    if len(val_data) >= 0x28: info["stream_size"] = le64(val_data, 0x20)
    if len(val_data) >= 0x30: info["allocation_size"] = le64(val_data, 0x28)
    if len(val_data) >= 0x38: info["snapshot_alloc"] = le64(val_data, 0x30)
    if len(val_data) >= 0x48: info["data_sub_id"] = le32(val_data, 0x44)
    if len(val_data) >= 0x4C:
        snap_id = le32(val_data, 0x48)
        if 0 < snap_id < 1000: info["snapshot_id"] = snap_id
    for off in [0x50, 0x48, 0x40, 0x58]:
        if off + 8 <= len(val_data):
            ft = le64(val_data, off)
            if 0x01D0000000000000 < ft < 0x01F0000000000000:
                info["creation_time"] = ft; break
    return info

def _parse_snapshots_from_value(vd, ctx=None):
    snapshots = []
    for kd, vd_row in parse_resident_btree_rows(vd, ctx):
        snap_name = _extract_snapshot_name(kd)
        if snap_name is not None:
            snapshots.append(_parse_snapshot_value(vd_row, snap_name))
    return snapshots

def _extract_snapshot_name(key_data):
    if len(key_data) < 18: return None
    if (key_data[8:12] == b'\x02\x00\x00\x80' and key_data[12] == 0xB0 and key_data[13] == 0x00 and le32(key_data, 4) == 0):
        name = key_data[16:].decode("utf-16-le", errors="replace").rstrip("\x00")
        if name and '\x00' not in name: return name
    return None

def _find_snapshot_files(f, ps, cs, tr, obj_map, oid, path, depth, max_depth, results):
    if depth > max_depth or oid not in obj_map: return
    rows = walk_bplus(f, ps, cs, tr, obj_map[oid])
    for kd, vd in rows:
        if len(kd) < 4 or le16(kd, 0) != 0x30: continue
        name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
        full_path = f"{path}/{name}" if path else name
        if len(vd) <= 84:
            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
            is_dir = bool(le32(vd, 0x40) & 0x10000000) if len(vd) >= 0x44 else False
            if is_dir and child_oid and child_oid in obj_map:
                _find_snapshot_files(f, ps, cs, tr, obj_map, child_oid, full_path, depth + 1, max_depth, results)
            # A non-resident FILE has no own OID/tree: val+0x08 is its home-dir backref, so scanning
            # obj_map[backref] returns the HOME DIRECTORY's $SNAPSHOT entries, not the file's -- a
            # file/dir mix. (The file's own CoW versions live in its type-0x40 extents, which this
            # snapshot-named-key scan does not match.) Skip rather than mis-attribute. --oid bug class.
        else:
            snapshots = _parse_snapshots_from_value(vd)
            if snapshots:
                file_info = {"path": full_path, "snapshots": snapshots, "value_len": len(vd), "vd": vd}
                if len(vd) >= 0x50:
                    file_info["create_time"] = le64(vd, 0x28); file_info["modify_time"] = le64(vd, 0x30)
                    file_info["file_size"] = get_resident_file_size(vd)
                results.append(file_info)

def _get_current_files(f, ps, cs, tr, obj_map, oid=0x600, path="", depth=0, max_depth=10):
    files = set()
    if depth > max_depth or oid not in obj_map: return files
    for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[oid]):
        if len(kd) < 4 or le16(kd, 0) != 0x30: continue
        name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
        files.add(name)
        if len(vd) >= 0x44 and len(vd) <= 84:
            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
            if bool(le32(vd, 0x40) & 0x10000000) and child_oid and child_oid in obj_map:
                full_path = f"{path}/{name}" if path else name
                files.update(_get_current_files(f, ps, cs, tr, obj_map, child_oid, full_path, depth + 1, max_depth))
    return files

def _iter_msb_clusters(f, ps, cs, end_cl, start_cl=0, skip=None, block_bytes=(16 << 20), progress=None):
    """Yield (cluster_index, cluster_bytes) for every cluster in [start_cl, end_cl) that starts with 'MSB+'.

    Reads in large SEQUENTIAL blocks (16 MiB, so the buffer stays bounded on 64 K-cluster volumes too)
    instead of one seek+read(4) per cluster, and hands back the bytes it already holds so a hit is never
    re-read. `skip` is an optional set of cluster indices to ignore (the known-live pages).
    `progress(done, total)` is called once per block so a whole-volume scan can say where it is.
    A short read (EOF / hole at the tail) ends the walk cleanly.
    """
    cl = start_cl
    total = max(0, end_cl - start_cl)
    block_clusters = max(1, block_bytes // cs)
    while cl < end_cl:
        n = min(block_clusters, end_cl - cl)
        try:
            f.seek(ps + cl * cs)
            buf = f.read(n * cs)
        except (OSError, OverflowError):
            cl += n
            if progress: progress(min(cl - start_cl, total), total)
            continue
        got = len(buf) // cs
        if got == 0:
            break
        # Only a cluster's FIRST byte can start the signature, so take one byte per cluster with a single
        # C-level strided slice and hunt for 'M' in that tiny digest — a Python-level compare per cluster
        # would touch 536 million clusters on a 2 TB volume (measured ~12x slower).
        sig = buf[0:got * cs:cs]
        pos = 0
        while True:
            i = sig.find(b"M", pos)
            if i < 0:
                break
            pos = i + 1
            base = i * cs
            if buf[base:base + 4] != b"MSB+":
                continue
            idx = cl + i
            if skip is None or idx not in skip:
                yield idx, buf[base:base + cs]
        cl += got
        if progress: progress(min(cl - start_cl, total), total)


def _scan_cov_line(stats):
    """Coverage line for the recovery log, or None when no orphan scan ran."""
    if not stats:
        return None
    return _scan_coverage_note(stats["scanned_clusters"], stats["total_clusters"], stats["bounded"])


def _scan_coverage_note(scanned, total, bounded):
    """One honest line about how much of the volume an orphan scan actually covered."""
    pct = (100.0 * scanned / total) if total else 100.0
    if not bounded:
        return f"scanned {scanned:,} of {total:,} clusters (100% of the volume)"
    return (f"scanned {scanned:,} of {total:,} clusters ({pct:.2f}% of the volume) "
            f"-- INCOMPLETE: bounded by --max-scan; deleted data outside this range was NOT examined")


def _scan_for_deleted_entries(f, ps, cs, tr, current_plcns, search_name=None, max_scan_clusters=None):
    """Orphan-page name scan (--scan-pages). Covers the WHOLE volume unless max_scan_clusters bounds it,
    in which case the coverage line says so — a page-level search that silently stopped part-way would
    report "not found" for a file that is still on the disk."""
    found = []
    image_size = f.seek(0, 2)
    vol_clusters = (image_size - ps) // cs
    bounded = max_scan_clusters is not None and max_scan_clusters < vol_clusters
    max_clusters = min(vol_clusters, max_scan_clusters) if max_scan_clusters is not None else vol_clusters
    print("  Orphan-page scan: " + _scan_coverage_note(max_clusters, vol_clusters, bounded))
    orphan_count = 0
    for plcn, page in _iter_msb_clusters(f, ps, cs, max_clusters, skip=current_plcns):
        if len(page) < 0x54: continue
        thoff = 0x50 + le32(page, 0x50)
        if thoff + 40 > len(page): continue
        tbl = struct.unpack_from("<10I", page, thoff)
        if bool(tbl[3] & 0x100): continue
        orphan_count += 1
        astart, aend = tbl[4], tbl[8]
        if astart >= aend: continue
        for i in range((aend - astart) // 4):
            aa = thoff + astart + i * 4
            if aa + 4 > len(page): break
            ro = thoff + le16(page, aa)
            if ro + 16 > len(page): break
            rh = struct.unpack_from("<I6H", page, ro)
            _, ko, kl, _, vo, vl, _ = rh
            if ko == 0 or kl < 4: continue
            kd = page[ro+ko:ro+ko+kl] if ro+ko+kl <= len(page) else b""
            vd = page[ro+vo:ro+vo+vl] if vo > 0 and vl > 0 and ro+vo+vl <= len(page) else b""
            if le16(kd, 0) == 0x30 and kl > 4:
                name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
                if name and not name.startswith("\x00"):
                    entry = {"name": name, "plcn": plcn, "value_len": len(vd), "vd": bytes(vd)}
                    entry["resident"] = len(vd) > 84
                    # E2 fix: discriminate on >84, not >=0x50 (an 84-byte NON-resident value was
                    # mis-decoded with resident offsets). The non-resident branch now also reads
                    # create/modify from +0x10/+0x18 (§C.3) so the boundary fix does not DROP the
                    # timestamps for recovered 84-byte rows.
                    if len(vd) > 84:
                        entry["create_time"] = le64(vd, 0x28); entry["modify_time"] = le64(vd, 0x30)
                        entry["file_attrs"] = le32(vd, 0x48)
                        entry["is_dir"] = bool(le32(vd, 0x48) & 0x10000000)
                    elif len(vd) >= 0x44:
                        entry["child_oid"] = le64(vd, 0x08) if len(vd) >= 0x10 else 0
                        entry["create_time"] = le64(vd, 0x10) if len(vd) >= 0x18 else 0
                        entry["modify_time"] = le64(vd, 0x18) if len(vd) >= 0x20 else 0
                        entry["file_attrs"] = le32(vd, 0x40)
                        entry["is_dir"] = bool(le32(vd, 0x40) & 0x10000000)
                    if search_name is None or search_name.lower() in name.lower():
                        found.append(entry)
    print(f"  Found {orphan_count} orphaned MSB+ leaf pages")
    return found

def _scan_page_slack(page, plcn, tag):
    """Recover deleted directory entries from B+-tree node SLACK. ReFS deletion
    (`CmsBPlusTable::DeleteFromIndex`) removes only the row's slot in the offset array — the row body is
    NOT scrubbed and persists until a later CoW rewrite. This brute-walks the page for type-0x30 row
    headers that are NOT referenced by the live offset array, validating each (key_off==0x10, key type
    0x30, in-bounds, decodable UTF-16 name). Recovered rows may include partially-overwritten remnants."""
    out = []
    if len(page) < 0x54 or page[:4] != b"MSB+":
        return out
    thoff = 0x50 + le32(page, 0x50)
    if thoff + 40 > len(page):
        return out
    tbl = struct.unpack_from("<10I", page, thoff)
    astart, aend = tbl[4], tbl[8]
    live = set()
    if astart < aend:
        for i in range((aend - astart) // 4):
            aa = thoff + astart + i * 4
            if aa + 2 > len(page):
                break
            live.add(thoff + le16(page, aa))
    for off in range(thoff, len(page) - 16, 4):
        if off in live:
            continue
        rsz, ko, kl, fl, vo, vl, _ = struct.unpack_from("<I6H", page, off)
        # a directory-entry row: key 0x10 past the header, key type 0x30, sane lengths, in-bounds
        if ko != 0x10 or not (4 < kl < 0x400) or not (0 < vl < 0x1000) or vo < 0x10:
            continue
        if off + ko + kl > len(page) or off + vo + vl > len(page):
            continue
        kd = page[off + ko:off + ko + kl]
        if len(kd) < 6 or le16(kd, 0) != 0x30:
            continue
        try:
            name = kd[4:].decode("utf-16-le").rstrip("\x00")
        except UnicodeDecodeError:
            continue
        if len(name) < 2 or not all(0x20 <= ord(c) < 0xFFFE for c in name):
            continue
        e = _decode_dir_row_value(page[off + vo:off + vo + vl])
        e.update({"name": name, "plcn": plcn, "page_off": off, "tag": tag,
                  "vd": bytes(page[off + vo:off + vo + vl]),
                  # Q6: the page header's TableIdLow (page+0x48) is the OID of the directory that owns this
                  # B+-tree page — i.e. which directory the recovered row was deleted FROM. Resolved to a
                  # path in _slack_recover (0 / unmapped => left blank; never invent a path).
                  "owning_table_oid": le64(page, 0x48) if len(page) >= 0x50 else 0})
        # confidence: a genuine row carries plausible MACB FILETIMEs; remnants/partials do not.
        _SANE = lambda ts: 129037248000000000 < ts < 142000000000000000  # ~2009-11..2050-12 (R5b)
        ct, mt = e.get("create_time", 0), e.get("modify_time", 0)
        e["confidence"] = "high" if (_SANE(ct) and _SANE(mt)) else (
            "medium" if (_SANE(ct) or _SANE(mt)) else "partial")
        out.append(e)
    return out

def _scan_page_slack_t40(page):
    """Recover type-0x40 BACKING records (a non-resident file's own $SI + $DATA extent map) from B+-tree
    node SLACK — the rows unlinked from the live offset array when the file was deleted. ReFS deletion
    removes only the offset-array slot; the type-0x40 body (with its extent table) persists until a CoW
    rewrite, exactly like the type-0x30 name row. Keyed (file_id @key+0x08, parent_oid @key+0x10). Returns
    {file_id, parent_oid, vd} rows for later join to a recovered type-0x30 name row (by file_id + home +
    size). This is what makes exact-extent recovery of a DELETED non-resident file possible: its extents
    live in this separate backing, NOT inline in the name row, and the backing is gone from the live tree."""
    out = []
    if len(page) < 0x54 or page[:4] != b"MSB+":
        return out
    thoff = 0x50 + le32(page, 0x50)
    if thoff + 40 > len(page):
        return out
    tbl = struct.unpack_from("<10I", page, thoff)
    astart, aend = tbl[4], tbl[8]
    live = set()
    if astart < aend:
        for i in range((aend - astart) // 4):
            aa = thoff + astart + i * 4
            if aa + 2 > len(page):
                break
            live.add(thoff + le16(page, aa))
    for off in range(thoff, len(page) - 16, 4):
        if off in live:
            continue
        try:
            _rsz, ko, kl, _fl, vo, vl, _ = struct.unpack_from("<I6H", page, off)
        except struct.error:
            continue
        # a type-0x40 backing row: key 0x10 past the header, 24-byte key type 0x40, backing value >= 0x68
        if ko != 0x10 or not (0x18 <= kl < 0x40) or not (0x68 <= vl < 0x2000) or vo < 0x10:
            continue
        if off + ko + kl > len(page) or off + vo + vl > len(page):
            continue
        kd = page[off + ko:off + ko + kl]
        if len(kd) < 0x18 or le16(kd, 0) != 0x40:
            continue
        out.append({"file_id": le64(kd, 0x08), "parent_oid": le64(kd, 0x10),
                    "vd": bytes(page[off + vo:off + vo + vl])})
    return out

def _scan_trash_table(f, ps, cs, tr, obj_map):
    if 0xD not in obj_map: return []
    entries = []
    for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[0xD]):
        entry = {"key_len": len(kd), "key_hex": kd.hex(),
                 "value_len": len(vd), "value_hex": vd[:64].hex() if len(vd) > 64 else vd.hex()}
        if len(kd) >= 16: entry["oid"] = le64(kd, 8)
        entries.append(entry)
    return entries

def find_orphan_objects(f, ps, cs, tr, obj_map, referenced_oids, log_fn=None):
    """Find OIDs present in the Object Table but NOT reachable from the directory tree — a complementary
    deletion signal (an object still parked in the OT after its tree link was removed, before GC reclaims it).

    Each orphan OID is a DIRECTORY (non-resident files have no own OID; #327/E7), so its B+-tree holds its
    CHILDREN's rows: the recovered `name` is a child, the row is labelled by the directory's OID. This is a
    LOW-volume, LOW-confidence method — see the `--orphans` tier, which identity-filters the output. Captures
    the child's create_time so the caller can drop orphans whose child is still LIVE (a prior/still-referenced
    structure), never mislabelling a live file as deleted."""
    SYSTEM_OIDS = {0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
                   0x10, 0x20, 0x21, 0x22, 0x30, 0x500, 0x501, 0x520, 0x530, 0x540, 0x541, 0x600}
    orphan_oids = {o for o in (set(obj_map.keys()) - referenced_oids - SYSTEM_OIDS) if o > 0x600}
    if log_fn:
        log_fn(f"[{PROG}] {len(orphan_oids)} orphan OIDs found in Object Table")
    results = []
    for oid in sorted(orphan_oids):
        vlcns = obj_map.get(oid)
        if not vlcns:
            continue
        try:
            rows = walk_bplus(f, ps, cs, tr, vlcns)
        except Exception:
            continue
        name = None; child_ct = 0; si_data = {}
        for kd, vd in rows:
            if len(kd) < 2:
                continue
            attr_type = le16(kd, 0)
            if attr_type == 0x10 and len(vd) >= 0x60 and not si_data:
                si_data = {
                    "create_time": le64(vd, 0x28), "modify_time": le64(vd, 0x30),
                    "change_time": le64(vd, 0x38), "access_time": le64(vd, 0x40),
                    "file_attrs": le32(vd, 0x48), "security_id": le64(vd, 0x50),
                    "usn": le64(vd, 0x68) if len(vd) >= 0x70 else 0,
                }
            elif attr_type == 0x30 and len(kd) > 4 and name is None:
                try:
                    name = kd[4:].decode("utf-16-le").rstrip("\x00")
                    child_ct = _decode_dir_row_value(vd).get("create_time", 0)
                except UnicodeDecodeError:
                    pass
        if not name and not si_data:
            continue
        fa = si_data.get("file_attrs", 0)
        results.append({
            "path": f"$ORPHAN/DIR_OID_0x{oid:x}", "parent_path": "$ORPHAN", "parent_oid": 0,
            "name": f"DIR_OID_0x{oid:x}", "recovered_child": name or "", "recovered_child_create_time": child_ct,
            "oid": oid, "is_resident": False, "is_dir": True, "is_deleted": True, "deletion_source": "orphan",
            "create_time": si_data.get("create_time", 0), "modify_time": si_data.get("modify_time", 0),
            "change_time": si_data.get("change_time", 0), "access_time": si_data.get("access_time", 0),
            "file_attrs": fa, "internal_flags": 0, "security_id": si_data.get("security_id", 0),
            "usn": si_data.get("usn", 0), "file_size": 0,
            "is_encrypted": bool(fa & 0x4000), "is_compressed": bool(fa & 0x0800),
            "has_integrity": bool(fa & 0x8000), "has_ea": bool(fa & 0x00040000),
            "has_reparse": bool(fa & 0x0400), "has_ads": False, "ads_names": "",
            "reparse_target": "", "snapshot_count": 0,
        })
    return results


def _build_live_identity(f, ps, cs, tr, obj_map):
    """Map every LIVE type-0x30 row to its identity: {(name, create_time) -> set(owning dir OIDs)}.

    Walks the FULL object map (not depth-limited from root), so it is the authoritative "does a live file with
    this exact identity exist, and where" index. Shared by the deleted-vs-still-present classifier (in
    `_slack_recover`) and the `--orphans` tier's identity filter, so both agree and the walk runs once."""
    live_identity = {}
    for _oid, _vl in obj_map.items():
        try:
            for _kd, _vd in walk_bplus(f, ps, cs, tr, _vl):
                if len(_kd) > 4 and le16(_kd, 0) == 0x30:
                    _nm = _kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
                    live_identity.setdefault((_nm, _decode_dir_row_value(_vd).get("create_time", 0)), set()).add(_oid)
        except Exception:
            pass
    return live_identity


def _slack_recover(f, ps, cs, tr, roots, obj_map, max_scan, log, scan_orphans=True, live_identity=None,
                   stats=None):
    """Scan B+-tree node slack. Always scans every LIVE metadata page (cheap — those pages are already read
    by the tree walk). When scan_orphans is True it ALSO scans the volume for orphan MSB+ pages — the freed
    pages of deleted objects — which is the slow half but where the majority of older deletions live.
    `recovery` mode passes scan_orphans=False (live pages only); `full` passes True.

    The orphan scan covers the WHOLE volume unless the caller passes an explicit max_scan cluster budget;
    a bounded scan is always reported as INCOMPLETE. `stats`, if given, receives the coverage numbers."""
    visited = set(); ptc = []
    for idx, rv in enumerate(roots):
        if rv:
            _walk_btree_pages(f, ps, cs, (None if idx in _CT_ROOT_INDICES else tr), rv, visited, ptc)
    for _oid, vlcns in obj_map.items():
        _walk_btree_pages(f, ps, cs, tr, vlcns, visited, ptc)
    entries = []
    live_plcns = set()
    t40_slack = {}    # (file_id, parent_oid) -> [backing value bytes]  (deleted non-res files' extent maps)
    def _ingest_t40(data):
        for r in _scan_page_slack_t40(data):
            t40_slack.setdefault((r["file_id"], r["parent_oid"]), []).append(r["vd"])
    for head, plcns in ptc:
        live_plcns.add(head)
        data = b""
        ok = True
        for p in plcns:
            try:
                f.seek(ps + p * cs); data += f.read(cs)
            except (OSError, OverflowError):
                ok = False; break
        if ok:
            entries += _scan_page_slack(data, head, "live-slack")
            _ingest_t40(data)
    # orphan MSB+ pages (not referenced by the live tree) — the slow half, skipped in `recovery` mode
    orphans = 0
    if scan_orphans:
        vol_clusters = (f.seek(0, 2) - ps) // cs
        bounded = max_scan is not None and max_scan < vol_clusters
        end_cl = min(vol_clusters, max_scan) if max_scan is not None else vol_clusters
        log("  Orphan-page scan: " + _scan_coverage_note(end_cl, vol_clusters, bounded))
        _pstate = [0]

        def _prog(done, total):
            if total < 4000000:                 # only worth reporting on volumes that take real time
                return
            pct = int(100 * done / total) // 10 * 10
            if pct > _pstate[0]:
                _pstate[0] = pct
                log(f"    ... {pct}% ({done:,}/{total:,} clusters)")

        for cl, data in _iter_msb_clusters(f, ps, cs, end_cl, skip=live_plcns, progress=_prog):
            ent = _scan_page_slack(data, cl, "orphan-slack")
            _ingest_t40(data)          # a backing can survive on an orphan page with no surviving name row
            if ent:
                orphans += 1; entries += ent
        if stats is not None:
            stats.update(scanned_clusters=end_cl, total_clusters=vol_clusters,
                         bounded=bounded, orphan_pages=orphans)
    # Q6: resolve each recovered row's owning-table OID to the directory path it was deleted FROM.
    # build_oid_path_map covers live directories; an unmapped/zero OID stays blank (no invented path).
    oid_paths = build_oid_path_map(f, ps, cs, tr, obj_map)
    # Feature A: group children of a DELETED directory. When a recovered row's owning-table OID is not a live
    # directory, its parent directory was itself deleted -- that directory's page survives in slack with the
    # child rows, but its OID is gone from the tree. The reliable, UNAMBIGUOUS fact is physical provenance: the
    # remnant was recovered from that deleted directory's B+-tree page (OID = owning_table_oid, page+0x48). We
    # anchor the path on that OID -- $DELETED/DIR_OID_0x<oid>/<child> -- and attach the deleted directory's NAME
    # only as a BEST-EFFORT candidate list. We do NOT reconstruct a named ancestor chain: rename/move churn
    # leaves MULTIPLE conflicting names for one OID in slack (26/110 OIDs on the churn corpus; verified against
    # the fsactivity log -- elvis_dir_zulu_127761 was renamed to november_804548), so a single reconstructed
    # name/path would be plausible-but-WRONG forensic evidence. Names annotate; they never assert the path.
    _parent_names = {}    # deleted-dir OID -> set of candidate names seen in slack subdir entries
    for e in entries:
        vd = e.get("vd") or b""
        if e.get("is_dir") and len(vd) >= 0x10 and e.get("name"):
            sub_oid = le64(vd, 0x08)             # a directory entry stores the subdir's own OID at value+0x08
            if sub_oid > 0x600:
                _parent_names.setdefault(sub_oid, set()).add(e["name"])
    for e in entries:
        oto = e.get("owning_table_oid", 0)
        if not oto:
            e["owning_path"] = ""
        elif oto in oid_paths:
            e["owning_path"] = oid_paths[oto]                  # Q6: live parent directory (resolved path)
        else:                                                   # Feature A: parent directory is itself deleted
            e["owning_path"] = f"$DELETED/DIR_OID_0x{oto:x}"
            e["parent_deleted"] = True
            e["parent_name_candidates"] = sorted(_parent_names.get(oto, ()))
    # DELETED vs STILL-PRESENT by FILE IDENTITY (name + create_time), not by directory alone. A file that still
    # exists ANYWHERE on the volume — including one that was moved or renamed out of the directory a remnant was
    # found in — is NOT a deletion. create_time is preserved across move/rename, so it separates the SAME file
    # relocated from a DIFFERENT file that merely shares the name (a plain name test mis-buckets those — e.g.
    # two unrelated Shield.png). A remnant whose identity is live NOWHERE is a genuine deletion — including an
    # original deleted after being COPIED (the copy gets a NEW create_time, so the deleted original still
    # resolves as recoverable). Stay NEUTRAL: is_prior_version only records "a live file with this exact identity
    # exists"; where the remnant was found vs where that file now lives (live_location_oid) is left for the
    # analyst — the tool does not label it move / rename / copy. This is also mode-stable (identity is global),
    # so `recovery` (live pages) is always a subset of `--full` (live + orphan pages).
    # (name, create_time) -> live dir OIDs holding that identity. Reuse a caller-supplied map (built once in
    # cmd_deleted and shared with the --orphans filter) or build it here.
    _live_identity = live_identity if live_identity is not None else _build_live_identity(f, ps, cs, tr, obj_map)
    for e in entries:
        _dirs = _live_identity.get((e["name"], e.get("create_time", 0)))
        e["is_prior_version"] = _dirs is not None            # a live file with this identity exists (not deleted)
        if _dirs is not None and e.get("owning_table_oid", 0) not in _dirs:
            # Neutral: the remnant is in a directory the file no longer occupies but the identity lives elsewhere
            # (a move / rename / copy — the tool does not interpret which). A same-dir match is a CoW prior version.
            e["former_location"] = True
            e["live_location_oid"] = next(iter(_dirs))
    # Feature C: join each recovered NON-RESIDENT name row to a type-0x40 backing recovered from slack, so a
    # deleted non-resident file whose extent map lives in a SEPARATE backing (not inline in the name row) can
    # be carved. A deleted file's backing is gone from the live tree (fetch_t40_backing would miss it) but its
    # body persists in the same page slack. Match on (file_id @value+0x00, home-dir backref @value+0x08) +
    # EXACT size (name value+0x38 == backing value+0x58, collision-safe). The backing's extents must parse to
    # the full allocation (_parse_extents_from_type40 requires total_clusters == needed), else metadata_only.
    # Carved bytes may be STALE (clusters possibly reused post-deletion) — flagged like the inline carve path.
    joined = 0
    for e in entries:
        vd = e.get("vd") or b""
        if e.get("resident") or len(vd) < 0x40:      # only SHORT non-resident name rows carry file_id@0x00
            continue
        key = (le64(vd, 0x00), le64(vd, 0x08))
        nsize = le64(vd, 0x38)
        for bvd in t40_slack.get(key, ()):
            if len(bvd) < 0x68 or le64(bvd, 0x58) != nsize:
                continue
            info = _parse_extents_from_type40(bvd, cs, tr)
            if info["extents"]:
                e["t40_backing"] = bvd
                e["t40_extent_count"] = len(info["extents"])
                joined += 1
                break
    log(f"  Scanned {len(ptc)} live pages"
        + (f" + {orphans} orphan pages" if scan_orphans
           else " (orphan-page scan skipped — add --full to also scan the freed pages of older deletions)")
        + " with recoverable slack rows"
        + (f"; {joined} split-record file(s) matched a type-0x40 extent map in slack" if joined else ""))
    if scan_orphans and stats and stats.get("bounded"):
        log(f"  WARNING: the orphan-page scan was bounded by --max-scan "
            f"({stats['scanned_clusters']:,} of {stats['total_clusters']:,} clusters). This run is INCOMPLETE — "
            f"drop --max-scan to scan the whole volume.")
    return entries

def _scan_backup_copies(f, ps, cs, chkp_lcns):
    """Inventory ReFS redundant copies for resilience: the alternating checkpoint pair, the backup
    boot sector (last LBA), and the secondary SUPB copies near the partition end. Verifies presence
    + validity only — it does NOT yet fail over to a backup when the primary is corrupt (future)."""
    import hashlib
    out = {"checkpoints": [], "vbr": None, "supb": []}

    # --- Boot sector (primary @ sector 0) + backup (@ last sector) ---
    f.seek(ps); pv = f.read(512)
    pv_ok = pv[3:7] == b"ReFS"
    pv_cksum_ok = pv_ok and (_vbr_checksum(pv, le16(pv, 0x14)) == le16(pv, 0x16))
    total_sectors = le64(pv, 0x18) if len(pv) >= 0x20 else 0
    vbr = {"primary_ok": pv_ok, "primary_cksum_ok": pv_cksum_ok,
           "total_sectors": total_sectors, "backup": None}
    if total_sectors > 1:
        blba = total_sectors - 1
        try:
            f.seek(ps + blba * 512); bv = f.read(512)
            bv_ok = len(bv) == 512 and bv[3:7] == b"ReFS"
            vbr["backup"] = {
                "lba": blba,
                "present": bv_ok,
                "matches_primary": bv == pv,
                "sha256": hashlib.sha256(bv).hexdigest() if bv_ok else None,
                "cksum_ok": bv_ok and _vbr_checksum(bv, le16(bv, 0x14)) == le16(bv, 0x16),
                # the backup boot sector is NOT rewritten on upgrade, so it preserves the original
                # (pre-upgrade) ReFS version — a forensic record of the volume's birth version
                "version": (f"{bv[0x28]}.{bv[0x29]}" if bv_ok else None),
                "primary_version": f"{pv[0x28]}.{pv[0x29]}" if pv_ok else None,
            }
        except (OSError, OverflowError):
            vbr["backup"] = {"lba": blba, "present": False, "error": True}
    out["vbr"] = vbr

    # --- Checkpoint copies (SUPB references the pair; newest virtual clock = current) ---
    best_vc = -1
    for cl in chkp_lcns:
        rec = {"lcn": cl, "sig_ok": False, "vc": None, "roots_ok": False}
        try:
            f.seek(ps + cl * cs); raw = f.read(4 * cs)
            rec["sig_ok"] = raw[:4] == b"CHKP"
            if rec["sig_ok"]:
                rec["sha256"] = hashlib.sha256(raw).hexdigest()
                rec["vc"] = le64(raw, 0x10)
                rec["self_lcn"] = le64(raw, 0x20)                 # page self-address (should equal its own LCN)
                rec["self_lcn_ok"] = (rec["self_lcn"] == cl)
                rec["cksum_ok"], rec["ckname"] = _verify_self_checksum(raw, cs)   # B3
                try:
                    _vc, _fl, roots = _forefst_parse_chkp(f, ps, cs, cl)
                    rec["roots_ok"] = bool(roots) and any(roots)
                except Exception:
                    rec["roots_ok"] = False
                if rec["vc"] > best_vc:
                    best_vc = rec["vc"]
        except (OSError, OverflowError):
            rec["error"] = True
        out["checkpoints"].append(rec)
    for rec in out["checkpoints"]:
        # B5: the older checkpoint slot is the SECONDARY (previous consistent state / rollback target),
        # not a "backup" — the two CHKP slots are symmetric alternating (ping-pong) slots.
        rec["role"] = ("PRIMARY" if rec.get("vc") == best_vc and best_vc >= 0 else "secondary")

    # --- Secondary SUPB copies (primary @ SUPB_LCN; copies sit near the partition end) ---
    f.seek(ps + SUPB_LCN * cs); _psupb = f.read(cs)
    _pck = _verify_self_checksum(_psupb, cs) if _psupb[:4] == b"SUPB" else (None, "-")
    out["supb"].append({"lcn": SUPB_LCN, "role": "PRIMARY", "ok": _psupb[:4] == b"SUPB",
                        "cksum_ok": _pck[0], "ckname": _pck[1],
                        "self_lcn": le64(_psupb, 0x20) if _psupb[:4] == b"SUPB" else None,
                        "self_lcn_ok": (le64(_psupb, 0x20) == SUPB_LCN) if _psupb[:4] == b"SUPB" else None,
                        "sha256": hashlib.sha256(_psupb).hexdigest() if _psupb[:4] == b"SUPB" else None})
    if total_sectors > 1:
        end_lcn = (total_sectors * 512) // cs
        for lcn in range(max(0, end_lcn - 64), end_lcn):
            try:
                f.seek(ps + lcn * cs); _s = f.read(cs)
                if _s[:4] == b"SUPB":
                    _bck = _verify_self_checksum(_s, cs)
                    out["supb"].append({"lcn": lcn, "role": "backup", "ok": True,
                                        "cksum_ok": _bck[0], "ckname": _bck[1],
                                        "self_lcn": le64(_s, 0x20), "self_lcn_ok": (le64(_s, 0x20) == lcn),
                                        "sha256": hashlib.sha256(_s).hexdigest()})
            except (OSError, OverflowError):
                break
    return out

def _read_full_page(f, ps, cs, slots, use_tr):
    """Read a full metadata page = concatenation of its page-reference LCN slots.
    Returns b'' on any unreadable/untranslatable slot (so checksum verify skips, never crashes)."""
    pg = b""
    for s in slots:
        if s in (0, 0xFFFFFFFFFFFFFFFF):
            break
        try:
            plcn = use_tr.tr(s) if use_tr else s
            if plcn is None or plcn < 0:
                _skip_note("integrity page read", f"lcn {s}", ValueError("no physical mapping"))
                return None
            f.seek(ps + plcn * cs)
            chunk = f.read(cs)
        except (KeyError, OSError, OverflowError, TypeError, ValueError) as _e:
            # `return b""` made an UNREADABLE page indistinguishable from one that is simply not a B+
            # page: the caller tests `pg[:4] != b"MSB+"` and returns, so the page was neither checked
            # nor counted, and `integrity` reported a clean verdict over a volume it had not fully read.
            _skip_note("integrity page read", f"lcn {s}", _e)
            return None
        if len(chunk) < cs:
            _skip_note("integrity page read", f"lcn {s}", IOError("short read"))
            return None
        pg += chunk
    return pg

def _check_page(data, lcn, expected_volsig, max_vc, report, verbose):
    report["pages_checked"] += 1
    sig = data[:4]
    detail = {"lcn": lcn, "sig": sig, "issues": []}
    if sig in _VALID_SIGS:
        report["pages_valid_sig"] += 1
    else:
        report["pages_invalid_sig"] += 1
        report["issues"].append(("FAIL", lcn, f"Invalid signature: {sig!r}"))
        detail["issues"].append("bad_sig")
    if len(data) >= 0x10:
        page_volsig = le32(data, 0x0C)
        if page_volsig == expected_volsig or page_volsig == 0:
            report["pages_volsig_match"] += 1
        else:
            report["pages_volsig_mismatch"] += 1
            report["issues"].append(("WARN", lcn, f"Volume sig mismatch: page={_hx(page_volsig)} expected={_hx(expected_volsig)}"))
            detail["issues"].append("volsig_mismatch")
    if len(data) >= 0x18:
        page_vc = le64(data, 0x10)
        if page_vc <= max_vc:
            report["pages_vc_ok"] += 1
        else:
            report["pages_vc_exceed"] += 1
            report["issues"].append(("WARN", lcn, f"VC exceeds checkpoint: page_vc={page_vc} > chkp_vc={max_vc}"))
            detail["issues"].append("vc_exceed")
    if len(data) >= 0x28 and sig == b"MSB+":
        self_lcns = []
        for sl in range(4):
            off = 0x20 + sl * 8
            if off + 8 <= len(data):
                v = le64(data, off)
                if v not in (0, 0xFFFFFFFFFFFFFFFF): self_lcns.append(v)
        if self_lcns:
            if all(self_lcns[i] == self_lcns[0] + i for i in range(len(self_lcns))):
                report["pages_selfaddr_ok"] += 1
            else:
                report["pages_selfaddr_bad"] += 1
                report["issues"].append(("WARN", lcn, f"Self-address tuple not consecutive: {[_hx(x) for x in self_lcns]}"))
                detail["issues"].append("selfaddr_bad")
        else:
            report["pages_selfaddr_ok"] += 1
    if sig == b"MSB+" and len(data) >= 0x80:
        try:
            thoff = 0x50 + le32(data, 0x50)
            if thoff + 40 <= len(data):
                tbl = struct.unpack_from("<10I", data, thoff)
                is_inner = bool(tbl[3] & 0x100)
                astart, aend = tbl[4], tbl[8]
                if astart <= aend:
                    if is_inner: report["btree_inner_ok"] += 1
                    else: report["btree_leaf_ok"] += 1
                else:
                    report["btree_struct_error"] += 1
                    report["issues"].append(("FAIL", lcn, f"B+-tree array bounds invalid: start={astart} > end={aend}"))
                    detail["issues"].append("btree_bounds")
        except Exception:
            report["btree_struct_error"] += 1
            detail["issues"].append("btree_parse_error")
    if verbose: report["page_details"].append(detail)

def _walk_btree_pages(f, ps, cs, tr, vlcns, visited, pages_to_check, depth=5):
    """Enumerate logical metadata pages reachable from `vlcns` — the LCN slots of ONE page.

    A ReFS metadata page = all of its page-reference slot-clusters concatenated (e.g. 4×4 KiB =
    16 KiB). Only the FIRST slot carries the MSB+ header; continuation slots hold the rest of the
    same logical page (often mostly zero padding). They must NOT be validated as standalone pages —
    doing so flagged every clean multi-cluster volume's continuation clusters as 'Invalid signature'.
    Appends (head_plcn, [plcn,...]) per logical page; the caller concatenates + validates the page."""
    plcns = [tr.tr(v) for v in vlcns] if tr else list(vlcns)
    plcns = [p for p in plcns if p not in (0, 0xFFFFFFFFFFFFFFFF)]
    if not plcns:
        return
    head = plcns[0]
    if head in visited:
        return
    visited.add(head)
    pages_to_check.append((head, plcns))
    page = b""
    for p in plcns:
        try:
            f.seek(ps + p * cs); page += f.read(cs)
        except (OSError, OverflowError):
            return
    if page[:4] != b"MSB+" or depth <= 0:
        return
    thoff = 0x50 + le32(page, 0x50)
    if thoff + 40 > len(page): return
    tbl = struct.unpack_from("<10I", page, thoff)
    if not bool(tbl[3] & 0x100): return
    astart, aend = tbl[4], tbl[8]
    if astart >= aend: return
    for i in range((aend - astart) // 4):
        aa = thoff + astart + i * 4
        if aa + 4 > len(page): break
        ro = thoff + le16(page, aa)
        if ro + 16 > len(page): break
        rh = struct.unpack_from("<I6H", page, ro)
        vl = rh[5]
        vd = page[ro + rh[4]:ro + rh[4] + vl] if vl > 0 else b""
        if len(vd) >= 32:
            cvld = [le64(vd, j*8) for j in range(4) if le64(vd, j*8) not in (0, 0xFFFFFFFFFFFFFFFF)]
            _walk_btree_pages(f, ps, cs, tr, cvld, visited, pages_to_check, depth - 1)

def _verify_page_checksums(f, ps, cs, tr, chk, dl, root_count, max_pages=300000, full=True):
    """F1: recompute each metadata page's CRC64 (cktype 2) / SHA-256 (cktype 4) from its
    parent page reference and compare to the stored value.

    `full=False` (--checksums): verify only the CHKP **root tables'** B+-trees (the system metadata —
    Object Table, Container Table, Allocator, etc.; ~tens of pages). Fast.
    `full=True`  (--fullchecksums): additionally cross the Object Table (CHKP root idx 0) leaf rows —
    each leaf value embeds the object root's page reference at value+0x20 — into **every** file/dir/
    stream B+-tree, making it a complete tamper/corruption verifier over the whole metadata Merkle
    structure (can be thousands of pages on a large volume).

    Note on the root offset list: parse_chkp resolves the per-root descriptor offsets via an
    indirect base when CHKP flags bit 0x200 is set (olb = le32(chk,0x94)), else directly at 0x94.
    We replicate that here so root idx 0 maps to the Object Table on every volume layout (the
    indirect form is used by native v3.14)."""
    import hashlib
    st = {"crc64_ok": 0, "crc64_bad": 0, "sha_ok": 0, "sha_bad": 0,
          "none": 0, "pages": 0, "objects": 0, "capped": False, "mismatches": [],
          "unreadable": 0}
    visited = set()

    def verify_ref(rec, use_tr, is_ot=False, depth=0):
        if st["pages"] >= max_pages:
            st["capped"] = True
            return
        if len(rec) < 0x30 or depth > 96:
            return
        slots = [le64(rec, i * 8) for i in range(4)]
        if slots[0] in (0, 0xFFFFFFFFFFFFFFFF):
            return
        # dedup on (addressing-mode, first-slot): a translated VLCN and a physical LCN may
        # share a numeric value without being the same page.
        key = (use_tr is not None, slots[0])
        if key in visited:
            return
        visited.add(key)
        cktype = rec[0x22]
        pg = _read_full_page(f, ps, cs, slots, use_tr)
        if pg is None:                      # could not READ it -- not the same as "not a B+ page"
            st["unreadable"] += 1
            return
        if pg[:4] != b"MSB+":
            return
        st["pages"] += 1
        # 5integrity-2: locate a mismatched page physically — VLCN, its PLCN (post container
        # translation), the container id it lives in, and the on-image byte offset. Computed only
        # on a mismatch (rare) so it adds no per-page cost / no extra translator miss-counting.
        def _loc():
            if use_tr is not None:
                return use_tr.tr(slots[0]), (slots[0] >> use_tr.shift)
            return slots[0], None                     # physical LCN (CT roots) — no container map
        if cktype == 2:
            stored = le64(rec, 0x28)
            calc = refs_crc64(pg)
            if calc == stored or stored == REFS_CRC64_SENTINEL:
                st["crc64_ok"] += 1
            else:
                st["crc64_bad"] += 1
                _plcn, _cont = _loc()
                st["mismatches"].append((slots[0], _plcn, _cont, "CRC64", _hx(stored), _hx(calc)))
        elif cktype == 4 and len(rec) >= 0x48:
            stored = rec[0x28:0x48]
            calc = hashlib.sha256(pg).digest()
            if calc == stored:
                st["sha_ok"] += 1
            else:
                st["sha_bad"] += 1
                _plcn, _cont = _loc()
                st["mismatches"].append((slots[0], _plcn, _cont, "SHA256", stored.hex()[:16], calc.hex()[:16]))
        else:
            st["none"] += 1
        th = 0x50 + le32(pg, 0x50)
        if th + 40 > len(pg):
            return
        tbl = struct.unpack_from("<10I", pg, th)
        is_inner = bool(tbl[3] & 0x100)
        astart, aend = tbl[4], tbl[8]
        if astart >= aend:
            return
        for i in range((aend - astart) // 4):
            aa = th + astart + i * 4
            if aa + 4 > len(pg):
                break
            r = th + le16(pg, aa)
            if r + 16 > len(pg):
                break
            rh = struct.unpack_from("<I6H", pg, r)
            vd = pg[r + rh[4]:r + rh[4] + rh[5]]
            if is_inner:
                # inner-node child pointer: a bare page reference at value+0 (slots@0, cktype@0x22,
                # checksum@0x28). These use the compact 0x30-byte form even when the CHKP/OT
                # descriptor length `dl` is larger (0x68 on v3.4) — so guard on the checksum's own
                # extent, not `dl`, or whole v3.4 subtrees go undescended. Same VLCN addressing.
                if len(vd) >= 0x30:
                    verify_ref(vd, use_tr, is_ot, depth + 1)
            elif is_ot:
                # Object Table leaf: the object root's page reference is embedded at value+0x20.
                # Its checksum sits at a FIXED ref-internal offset (cktype@+0x22, checksum@+0x28 =>
                # value+0x42 / value+0x48) — independent of the descriptor length `dl`. On v3.4 dl is
                # 0x68 and a `>= 0x20+dl` guard would wrongly skip the (shorter) OT-leaf values,
                # missing every object tree. Guard on the checksum's own extent instead, and hand
                # verify_ref the whole tail. Object B+-trees are VLCN-addressed (translate via tr).
                if len(vd) >= 0x50:
                    st["objects"] += 1
                    verify_ref(vd[0x20:], tr, False, depth + 1)

    flags = le32(chk, 0x78)
    olb = le32(chk, 0x94) if (flags & 0x200) else 0x94
    for idx in range(root_count):
        oe = olb + idx * 4
        if oe + 4 > len(chk):
            continue
        ro = le32(chk, oe)
        if ro == 0 or ro + dl > len(chk):
            continue
        use_tr = None if idx in _CT_ROOT_INDICES else tr
        # full=False stops at the system root tables; full=True crosses the OT (root 0) into objects
        verify_ref(chk[ro:ro + dl], use_tr, is_ot=(idx == 0 and full))
    return st

def _vbr_checksum(sector, vbr_size):
    checksum = 0
    for off in range(0x03, vbr_size):
        if off in (0x16, 0x17): continue
        checksum = ((checksum >> 1) | ((checksum & 1) << 15)) & 0xFFFF
        checksum = (checksum + sector[off]) & 0xFFFF
    return checksum

# ─── Specials umbrella (Q1) — one discoverable home for every special-attribute view ─────────────
# Each entry: (type, one-line description, row predicate). Predicates read fields the enriched files
# walk already produces — this is pure re-homing of `files --filter <type>` + the sparse predicate,
# NO new parsing. The dedicated verbs stay for DEEP ops (reparse --index, snapshots --extract, dataruns,
# extract name:stream); `specials` is the discovery/list layer.
SPECIALS_TYPES = [
    ("ads",        "named data streams",               lambda r: bool(r.get("has_ads"))),
    ("reparse",    "symlinks / junctions / WSL links",  lambda r: bool(r.get("has_reparse"))),
    ("wsl",        "WSL / Linux-metadata links",        lambda r: r.get("reparse_tag_value", 0) in
                     (0x80000023, 0x80000024, 0x80000025, 0x80000026, 0xA000001D)),
    ("hardlink",   "multi-linked files (link groups)",  lambda r: r.get("hard_link_count", 1) > 1
                     and not r.get("is_resident") and not r.get("is_dir")),
    # The label must name what the predicate actually tests. It reads the FILE_ATTRIBUTE_SPARSE_FILE bit,
    # which is the file's declared sparseness — not a comparison of allocated against logical size.
    ("sparse",     "FILE_ATTRIBUTE_SPARSE_FILE (0x200)", lambda r: bool(r.get("file_attrs", 0) & 0x200)),
    ("encrypted",  "EFS-encrypted ($EFS)",              lambda r: bool(r.get("is_encrypted"))),
    ("compressed", "WOF / compressed",                  lambda r: bool(r.get("is_compressed"))),
    ("integrity",  "integrity checksum stream",         lambda r: bool(r.get("has_integrity"))),
    ("ea",         "extended attributes / WSL EA",       lambda r: bool(r.get("has_ea"))),
    ("snapshot",   "CoW prior-version streams",         lambda r: r.get("snapshot_count", 0) > 0),
]
_SPECIALS_BY_NAME = {t[0]: t for t in SPECIALS_TYPES}

def _specials_path(r):
    pp = r.get("parent_path", ""); nm = r["name"]
    return f"{pp}/{nm}" if pp and pp not in ("", ".") else nm

def _specials_print_type(typ, files):
    """Print the type-specific list for one special type; returns the row count."""
    pred = _SPECIALS_BY_NAME[typ][2]
    rows = [r for r in files if pred(r)]
    if typ == "hardlink":
        # group by the shared hard-link name set (one physical file -> one group)
        groups = {}
        for r in rows:
            key = tuple(sorted(r.get("hard_link_names") or [_specials_path(r)]))
            groups.setdefault(key, r)
        print(f"  Hard-link groups ({len(groups)} files, {len(rows)} names):")
        for names, r in sorted(groups.items()):
            print(f"    [{r.get('hard_link_count', len(names))} names] {' | '.join(names)}")
        return len(groups)
    if not rows:
        print("  (none)")
        return 0
    if typ == "ads":
        # One row per STREAM, not per host, and each says where its bytes are: an ADS at or above 2 KiB is
        # extent-backed, and printing only the name invites the reader to assume the content is inline.
        print(f"  {'STREAM':<26} {'RESIDENCY':<14} HOST FILE")
        for r in rows:
            st = r.get("ads_storage") or {}
            for nm in (r.get("ads_names") or "").split(";"):
                if nm:
                    print(f"    {nm:<24} {st.get(nm, 'unknown'):<14} {_specials_path(r)}")
        print("\n  Extract one:  forefst IMG export ads \"<file>:<stream>\"")
    elif typ in ("reparse", "wsl"):
        print(f"  {'TAG':<26} {'TARGET':<40} PATH")
        for r in rows:
            tag = reparse_tag_str(r.get("reparse_tag_value", 0)) if r.get("reparse_tag_value") else ""
            print(f"    {tag:<24} {(r.get('reparse_target') or ''):<40} {_specials_path(r)}")
    elif typ == "sparse":
        print(f"  {'LOGICAL':>14} {'ALLOCATED':>14} {'SAVED':>14}  PATH")
        for r in rows:
            fs = r.get("file_size", 0); al = r.get("allocated_size") or 0
            saved = fs - al if fs > al else 0
            print(f"    {fs:>14,} {al:>14,} {saved:>14,}  {_specials_path(r)}")
        print("\n  Extent/run map:  forefst IMG dataruns <path>")
    elif typ == "snapshot":
        print(f"  {'PRIORS':>6}  PATH")
        for r in rows:
            print(f"    {r.get('snapshot_count', 0):>6}  {_specials_path(r)}")
        print("\n  Extract versions:  forefst IMG export snapshots <dir>")
    else:  # encrypted / compressed / integrity / ea — path (+ owner for encrypted)
        for r in rows:
            extra = f"  [{r.get('owner_sid','')}]" if typ == "encrypted" and r.get("owner_sid") else ""
            print(f"    {_specials_path(r)}{extra}")
    return len(rows)

def _special_record(r, typ):
    """One flat record for a special-attribute entry (for --csv/--jsonl). `detail` is the type's key datum."""
    if typ == "ads":
        detail = r.get("ads_names", "") or ""
    elif typ in ("reparse", "wsl"):
        detail = r.get("reparse_target", "") or (reparse_tag_str(r.get("reparse_tag_value", 0))
                                                 if r.get("reparse_tag_value") else "")
    elif typ == "hardlink":
        detail = ";".join(r.get("hard_link_names") or [])
    elif typ == "sparse":
        detail = "logical=%s allocated=%s" % (r.get("file_size", 0), r.get("allocated_size") or 0)
    elif typ == "snapshot":
        detail = "snapshots=%d" % r.get("snapshot_count", 0)
    else:
        detail = ""
    return {"type": typ, "path": _specials_path(r),
            "home_oid": "0x%x" % r["home_oid"] if r.get("home_oid") else "",
            "file_id": "0x%x" % r["file_id"] if r.get("file_id") else "",
            "is_dir": bool(r.get("is_dir")), "detail": detail}

def cmd_specials(image, remaining, partition_start):
    """Q1: list files carrying a special attribute. No arg = a count summary of every type;
    `specials <type>` = that type's list; `specials all` = every type sectioned. --csv/--json/--jsonl [FILE]
    for machine output."""
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining)
    args = _parse_args(remaining)
    sub = args["_rest"][0].lower() if args["_rest"] else None
    if sub is not None and sub != "all" and sub not in _SPECIALS_BY_NAME:
        die(f"specials: unknown type {sub!r}. Types: {', '.join(t[0] for t in SPECIALS_TYPES)} (or 'all')")
    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))
    try:
        results = walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, DEFAULT_DEPTH, True, set())
        # Run every specials predicate over the SAME full object set `files --filter` sees (files AND
        # directories). Directories legitimately carry special attributes — reparse (junctions / dir
        # symlinks), integrity streams, EAs — and must be enumerated. Dropping them here silently
        # undercounted those types vs `files --filter` (e.g. 78 dir junctions on a real Windows volume,
        # dir integrity/EA). File-only predicates (e.g. hardlink) already self-guard on `not is_dir`.
        objs = results
        counts = {t[0]: sum(1 for r in objs if t[2](r)) for t in SPECIALS_TYPES}
        if out_fmt == "json":
            if sub is None:
                _emit_json_obj({"image": os.path.basename(image), "counts": counts}, out_dest, "special-attribute counts"); return 0
            types = [t[0] for t in SPECIALS_TYPES] if sub == "all" else [sub]
            out = {t: [_specials_path(r) for r in objs if _SPECIALS_BY_NAME[t][2](r)] for t in types}
            _emit_json_obj({"image": os.path.basename(image), "specials": out}, out_dest, "special-attribute lists"); return 0
        if out_fmt in ("csv", "jsonl"):
            # Flat records: one per (type, matching entry). A single type → just that type; else every type.
            types = [t[0] for t in SPECIALS_TYPES] if (sub is None or sub == "all") else [sub]
            recs = [_special_record(r, t) for t in types for r in objs if _SPECIALS_BY_NAME[t][2](r)]
            _emit_records(recs, ["type", "path", "home_oid", "file_id", "is_dir", "detail"],
                          out_fmt, out_dest, "special-attribute entries")
            return 0
        if sub is None:                       # summary
            print("=" * 70)
            print(f"ReFS special-attribute inventory — {os.path.basename(image)} (ReFS {vmaj}.{vmin})")
            print("=" * 70)
            print(f"  {'TYPE':<12} {'COUNT':>7}   run `specials <type>` for the list")
            print("  " + "-" * 60)
            for typ, desc, _p in SPECIALS_TYPES:
                print(f"  {typ:<12} {counts[typ]:>7}   {desc}")
            print("  " + "-" * 60)
            distinct = sum(1 for r in objs if any(t[2](r) for t in SPECIALS_TYPES))
            print(f"  {distinct} distinct objects carry >=1 special attribute.")
            print("  (per-type counts OVERLAP — one object can be several types at once, so the")
            print("   rows above sum to more than this de-duplicated total.)")
            print("  Deep ops: reparse --index · snapshots --extract · dataruns · export ads \"file:stream\"")
            return 0
        for typ in ([t[0] for t in SPECIALS_TYPES] if sub == "all" else [sub]):
            print(f"\n── {typ}  ({counts[typ]}) — {_SPECIALS_BY_NAME[typ][1]} ──")
            _specials_print_type(typ, objs)
        return 0
    finally:
        f.close()

def cmd_ads(image, remaining, partition_start):
    """List every named data stream (ADS) on the volume — a top-level shortcut for `specials ads` (reuses that
    path; no duplicate logic). Supports --csv/--json/--jsonl [FILE]; extract with `export ads "<file>:<stream>"`."""
    return cmd_specials(image, ["ads"] + list(remaining), partition_start)

def cmd_reparse(image, remaining, partition_start):
    args = _parse_args(remaining, flags=["-v", "--verbose", "--index", "--json"], valued=["--tag", "--file"])
    verbose = args["v"] or args["verbose"]
    tag_filter = _int_arg(args["tag"], "--tag", 0) if args["tag"] else None

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        if args["index"]:
            entries, error = _parse_reparse_index(f, ps, cs, tr, obj_map)
            if error: print(f"NOTE: {error}", file=sys.stderr)
            if tag_filter: entries = [e for e in entries if e.get("reparse_tag") == tag_filter]
            if args["json"]:
                print(json.dumps({"reparse_index": entries}, indent=2, default=str)); return 0
            print("=" * 78)
            print("ReFS Reparse Point Index (OID 0x540)")
            print("=" * 78)
            print(f"  Image:        {image}")
            print(f"  ReFS version: {vmaj}.{vmin}")
            print(f"\n  Total entries: {len(entries)}  (rows in the OID 0x540 reparse index table)")
            print("  Note: the driver inserts ONE index row per reparse-bearing OBJECT, when its reparse")
            print("        attribute is first created; extra hard-linked NAMES of that object add no row.")
            print("        The `reparse` command instead counts every REPARSE_POINT-flagged NAME, so its")
            print("        count is >= this row count (they measure different things and need not match).")
            if entries:
                by_tag = {}
                for e in entries: by_tag.setdefault(e.get("reparse_tag", 0), []).append(e)
                print(f"\n  {'Tag':<14} {'Name':<35} {'Count'}")
                print(f"  {'-'*60}")
                for tag in sorted(by_tag.keys()):
                    print(f"  {_hx(tag):<14} {_tag_name(tag):<35} {len(by_tag[tag])}")
                if verbose:
                    print("\n  Detailed entries:")
                    for e in entries:
                        oid = e.get("dir_oid", 0)
                        oid_s = _KNOWN_OIDS.get(oid, _hx(oid))
                        print(f"    Tag={_hx(e.get('reparse_tag', 0))} DirOID={oid_s} "
                              f"ordinal={e.get('file_ref_word0', 0)} Key={e.get('key_hex', '')}")
            else:
                print("  (no entries)")
            return 0

        if 0x600 not in obj_map:
            die("Root directory (OID 0x600) not found")
        # Q5 defect 1 fix: source the reparse list from the SHARED enriched walk (same one `files` uses),
        # so it is consistent BY CONSTRUCTION and includes the non-resident / hard-linked reparse points the
        # old dedicated walker dropped (it read file_attrs only from the resident 0x48 layout and skipped
        # every len<=84 file). We still run _walk_dir_for_reparse to MERGE in its rich per-file decode
        # (substitute/print name, LX target, device) for the entries it can fully decode from the value;
        # the rest fall back to the walk's resolved reparse_target + reparse_tag_value (backing-record aware).
        main_entries = walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, 100, True, set())
        def _mpath(r):
            pp = r.get("parent_path", "") or ""
            return (pp + "/" + r["name"]).lstrip("/") if pp not in ("", ".") else r["name"]
        rich = {}
        for _e in _walk_dir_for_reparse(f, ps, cs, tr, obj_map, 0x600, "", 0, 100):
            if _e.get("reparse_data") or _e.get("wsl_eas"):
                rich[_e["name"]] = _e
        all_files = []
        for r in main_entries:
            if not r.get("has_reparse"):
                continue
            fp = _mpath(r)
            rf = rich.get(fp)
            all_files.append({
                "name": fp, "is_dir": r.get("is_dir"), "file_attrs": r.get("file_attrs", 0),
                "has_reparse": True,
                "reparse_data": rf.get("reparse_data") if rf else None,
                "wsl_eas": rf.get("wsl_eas", {}) if rf else {},
                "reparse_target": r.get("reparse_target", ""),
                "reparse_tag_value": r.get("reparse_tag_value", 0),
            })
        if args["file"]:
            fl = args["file"].lower()
            results = [fe for fe in all_files if fl in fe["name"].lower()]
        else:
            results = list(all_files)
        if tag_filter:
            results = [fe for fe in results
                       if (fe.get("reparse_data") and fe["reparse_data"].get("tag") == tag_filter)
                       or fe.get("reparse_tag_value") == tag_filter]
        if args["json"]:
            print(json.dumps({"reparse_points": results}, indent=2, default=str)); return 0

        print("=" * 78)
        print("ReFS Reparse Points")
        print("=" * 78)
        print(f"  Image:        {image}")
        print(f"  ReFS version: {vmaj}.{vmin}")
        reparse_count = len(all_files)
        wsl_count = sum(1 for fe in all_files if fe.get("wsl_eas"))
        print(f"\n  Files with REPARSE_POINT flag: {reparse_count}")
        print(f"  Files with WSL EAs: {wsl_count}")
        print(f"  Total files scanned: {len(main_entries)}")
        if results:
            print(f"\n  Showing {len(results)} entries:\n")
            for entry in results:
                print(f"  {entry.get('name', '?')}")
                print(f"    Type:      {'DIR' if entry.get('is_dir') else 'FILE'}")
                print(f"    Attrs:     {_hx(entry.get('file_attrs', 0))}")
                rd = entry.get("reparse_data")
                if rd:
                    print(f"    Reparse:   {rd.get('tag_name', '?')} ({_hx(rd.get('tag', 0))})")
                    if "substitute_name" in rd: print(f"    Target:    {rd['substitute_name']}")
                    if "print_name" in rd: print(f"    Display:   {rd['print_name']}")
                    if "target" in rd: print(f"    LX Target: {rd['target']}")
                    if "relative" in rd: print(f"    Relative:  {rd['relative']}")
                    if "note" in rd: print(f"    Note:      {rd['note']}")
                    if "dev_major" in rd: print(f"    Device:    {rd['dev_major']}:{rd['dev_minor']}")
                    if "error" in rd: print(f"    Error:     {rd['error']}")
                    if verbose and "raw_hex" in rd: print(f"    Raw:       {rd['raw_hex']}")
                elif entry.get("reparse_target") or entry.get("reparse_tag_value"):
                    # non-resident / hard-linked reparse: rich buffer lives in the backing record; show the
                    # resolved tag + target from the shared walk (same values `files --filter reparse` shows).
                    _tv = entry.get("reparse_tag_value", 0)
                    print(f"    Reparse:   {_tag_name(_tv)} ({_hx(_tv)})  [split record]")
                    if entry.get("reparse_target"):
                        print(f"    Target:    {entry['reparse_target']}")
                else:
                    print("    Reparse:   (tag in attrs but target not recoverable from this record)")
                wsl = entry.get("wsl_eas", {})
                if wsl:
                    print("    WSL EAs:")
                    if "lxuid" in wsl: print(f"      UID:  {wsl['lxuid']}")
                    if "lxgid" in wsl: print(f"      GID:  {wsl['lxgid']}")
                    if "lxmod_str" in wsl: print(f"      Mode: {wsl['lxmod_str']}")
                    if "lxdev_major" in wsl: print(f"      Dev:  {wsl['lxdev_major']}:{wsl['lxdev_minor']}")
                print()
        elif args["file"]:
            print(f"\n  No files matching '{args['file']}'")
        else:
            print("\n  No reparse points found in root directory")
            print("  (Reparse points may exist in subdirectories — use --file or --index)")

        idx_entries, idx_error = _parse_reparse_index(f, ps, cs, tr, obj_map)
        if not idx_error and idx_entries:
            print(f"\n  Reparse Index (OID 0x540): {len(idx_entries)} indexed entries")
            by_tag = {}
            for e in idx_entries: by_tag.setdefault(e.get("reparse_tag", 0), []).append(e)
            for tag in sorted(by_tag.keys()):
                print(f"    {_tag_name(tag)}: {len(by_tag[tag])}")

        return 0

    finally:
        f.close()

# ── Deleted-file recoverability (view verdict) + `export deleted` writer ──────────────────────────
_RECOVER_LABEL = {
    "recoverable_inline": "FULL FILE recoverable (resident — {n} B stored inline in the record)",
    "extent_backed":      "metadata + carve (non-resident — data is in on-disk extents; `export deleted --carve`)",
    "metadata_only":      "metadata only (non-resident — file data is NOT in this remnant)",
    "content_zero_or_absent": ("content zero or absent (indistinguishable in the remnant) — the $DATA "
                               "descriptor survives and declares {n} inline bytes, and that region reads "
                               "as zeros: the file held zeros, or the deletion took the bytes"),
    "fragment_only":      "fragment only (Trash-table key/value)",
}
# Feature C: a non-resident deleted file whose extents live in a SEPARATE type-0x40 backing (not inline in the
# name row) — the backing was recovered from slack and joined by (file_id, home) + exact size in _slack_recover.
_T40_CARVE_LABEL = (_RECOVER_LABEL["extent_backed"]
                    + " [extent map from a type-0x40 backing recovered in slack — bytes may be stale]")

def _extent_backed_carveable(vd, ctx=None):
    """B4: True only when a deleted extent-backed remnant can ACTUALLY be carved — i.e. its 0x1000 holder
    yields a non-empty on-disk extent list (the exact predicate `_carve_extent_backed` uses). On a truncated
    slack remnant the disk_alloc field survives but the extent table is zeroed (ecount==0), so only metadata
    is recoverable and the 'extent_backed / --carve' promise would produce no file."""
    for k, v in parse_resident_btree_rows(vd, ctx):
        if (len(k) >= 0x18 and k[12] == 0x80 and k[13] == 0x00 and le64(k, 0x10) == 0x1000
                and len(v) >= 0x50 and le32(v, 4) == SNAP_DATA_DESC):
            stream_size, disk_alloc, exts = parse_snapshot_data_entry(v)
            return bool(disk_alloc > 0 and exts and stream_size > 0)
    return False

def _deleted_recoverability(e, cs=None, tr=None):
    """Grade a recovered deleted row (from the scan / slack engines) by whether — and how — its FILE
    CONTENT is reconstructable. Returns (enum, human_label, decoded_or_None). Disk-free (view-time safe):

    - recoverable_inline: a RESIDENT file whose inline $DATA decodes via get_resident_data_content (the
      SAME helper that extracts LIVE resident files). decoded bytes are returned -> `export deleted` writes
      a .recovered. This is the only FULL-FILE recovery from the remnant alone.
    - extent_backed: a NON-RESIDENT file (long value) whose current stream lives in on-disk extents held
      inline in this row (F5, _current_stream_extent_backed). The data is NOT in the remnant, but the extent
      MAP is -> `export deleted --carve` reads those clusters (best-effort; may be reallocated).
    - metadata_only: a non-resident file with no usable data/extent info in the remnant (short <=84 value,
      or a long value that is neither inline nor extent-backed) -> only name/size/timestamps survive here.
    - fragment_only: a Trash-table key/value fragment.

    'recoverable' means the content (or its extent map) is PRESENT in this remnant — NOT that the bytes are
    un-overwritten (there is no allocation/freshness check). EFS content decodes to CIPHERTEXT; sparse files
    short-read; a 'partial'-confidence slack remnant is hedged.

    On a **format <= 3.10 volume this can never return `recoverable_inline`**, and that is structural rather
    than a version check: the verdict is read from the `$DATA` descriptor's own form, and main `$DATA` is
    never written in the inline form before format 3.11 (E87 — 0 inline of 7,006 file rows over 18 corpus
    paths spanning v3.4/3.7/3.9/3.10). So the tool cannot promise row carving on those volumes; it grades
    them `extent_backed` or `metadata_only`, which is what they are. A version gate here would be an
    unreachable branch asserting something the byte test already guarantees."""
    vd = e.get("vd") or b""
    if not vd:
        return ("fragment_only", _RECOVER_LABEL["fragment_only"], None)
    if not e.get("resident"):                       # len(vd) <= 84 — non-resident, no data in the row
        if e.get("t40_extent_count", 0) > 0:        # extents recovered from a type-0x40 backing in slack
            return ("extent_backed", _T40_CARVE_LABEL, None)
        return ("metadata_only", _RECOVER_LABEL["metadata_only"], None)
    decoded = get_resident_data_content(vd)
    if decoded is not None and len(decoded) > 0 and not any(decoded):
        # The descriptor survived the deletion but its inline data region did not: every declared byte is
        # zero. Returning these as recovered content would emit bytes the remnant does not hold -- measured
        # on lab314_main T17, where a moved-then-deleted 500 B file yielded 500 zeros labelled EXACT, and on
        # the T16 set where 214 of 849 recovered f_*.bin were all zeros although the generator wrote 300
        # non-zero bytes to every one of them (MD_DEL_RA_004 / E93).
        # A genuinely zero-filled resident file is classified here too. That false negative is measured and
        # tiny -- 1 of 4,037 live resident files on lab314_main, 1 of 33,263 on winsider -- and its cost is
        # withholding a file of zeros whose metadata is still reported, against the alternative of asserting
        # content that was never read. Withholding is the correct side to err on for an evidence tool.
        return ("content_zero_or_absent", _RECOVER_LABEL["content_zero_or_absent"].format(n=len(decoded)), None)
    if decoded is not None:                         # truly resident: $DATA inline in the record
        label = _RECOVER_LABEL["recoverable_inline"].format(n=len(decoded))
        attrs = e.get("file_attrs", 0)
        tags = []
        if attrs & 0x4000: tags.append("CIPHERTEXT — EFS-encrypted")   # FILE_ATTRIBUTE_ENCRYPTED
        if attrs & 0x200:  tags.append("sparse — short read expected")  # FILE_ATTRIBUTE_SPARSE
        if e.get("confidence") == "partial": tags.append("PARTIAL remnant — corroborate")
        if tags:
            label += " [" + "; ".join(tags) + "]"
        return ("recoverable_inline", label, decoded)
    # long value, not inline => NON-RESIDENT. If its current stream is extent-backed (F5) the extent list is
    # in this remnant -> carve candidate; otherwise only metadata survives.
    if _current_stream_extent_backed(vd):
        if _extent_backed_carveable(vd):
            return ("extent_backed", _RECOVER_LABEL["extent_backed"], None)
        if e.get("t40_extent_count", 0) > 0:                             # extents in a slack type-0x40 backing
            return ("extent_backed", _T40_CARVE_LABEL, None)
        return ("metadata_only", _RECOVER_LABEL["metadata_only"], None)   # B4: extent map zeroed -> no carve
    if e.get("t40_extent_count", 0) > 0:                                 # long value, extents in slack backing
        return ("extent_backed", _T40_CARVE_LABEL, None)
    # v3.4 / v3.7 / v3.9 / upgraded: the extent map is inlined in this row as a MULTI-LEVEL embedded B+-tree that
    # _current_stream_extent_backed (parse_resident_btree_rows, outer level only) can't reach — the same case
    # cmd_extract/dataruns handle via the index-array walk (§C.3b, #640). Use _decode_holder_extents as the TRUE
    # carve predicate (it is disk-free — tr.tr is a container-table lookup — and cover-guarded, so it returns
    # extents only when the carve WILL yield an exact contiguous cover; native v3.14 returns [] here → unchanged).
    if cs and tr and _decode_holder_extents(vd, cs, tr):
        return ("extent_backed", _RECOVER_LABEL["extent_backed"], None)
    return ("metadata_only", _RECOVER_LABEL["metadata_only"], None)

def _safe_filename(name):
    """Filesystem-safe form of a name for on-disk extraction. Only characters that cannot be written to a path
    component (everything outside [alnum . _ - space]) are mapped to '_'; the name is otherwise preserved and,
    crucially, written at FULL LENGTH — it is never truncated or shortened, so the extracted name stays faithful
    to what is on the volume. A name longer than the host filesystem's component limit (255 bytes on ext4/NTFS)
    would raise OSError on write; that is deliberate — the tool never silently alters a name's length instead of
    surfacing it. (The whole validation corpus is <=171 bytes, so this cannot trigger there; a future release may
    add an OPT-IN cap for exotic volumes.) `_safe_relpath` applies this per path segment and additionally drops
    '.'/'..' for traversal safety. Provenance lives in the extraction index, not the on-disk name; collisions are
    resolved by _collision_free_path."""
    return "".join(c if c.isalnum() or c in "._- " else "_" for c in (name or "")) or "unnamed"

def _collision_free_path(path):
    """Never clobber an existing file: on collision append .dup1/.dup2/… (user-selected overwrite policy).
    The .row/.recovered names already embed the physical cluster [+page offset], so this fires only across
    sources or across repeated runs into the same directory — never for two rows of one scan."""
    if not os.path.exists(path):
        return path
    i = 1
    while os.path.exists(f"{path}.dup{i}"):
        i += 1
    return f"{path}.dup{i}"

def _guarded_extract_write(dest, data, failures, holes_mark=None, what=None):
    """Write bytes `data` to `dest`, catching OSError so one bad file cannot ABORT a bulk extraction (audit 4.1).
    The faithful (un-truncated) sanitizer can produce a name longer than the host filesystem's component limit;
    that, plus disk-full / permission, must be SURFACED (our docstring's promise), not propagated as a mid-run
    traceback that leaves a partial directory and no record. On failure, append a record to `failures` and return
    None; on success return `dest`. The parent directory is created here too, so a too-long *directory* segment
    (not just the leaf name) is caught the same way.

    `holes_mark` is `len(_CONTENT_HOLES)` taken by the caller BEFORE it produced `data`. If the producer
    recorded a hole since then, these bytes came from one: the stream is recorded for the sidecar, and
    under `--refuse-holes` it is not written at all (returning None, exactly as a failed write does, but
    WITHOUT being counted as a failure -- it is a deliberate refusal and is reported as one)."""
    if holes_mark is not None and len(_CONTENT_HOLES) > holes_mark:
        drew = sum(b for _w, b in _CONTENT_HOLES[holes_mark:])
        _HOLE_STREAMS.append({"file": dest, "what": what or os.path.basename(dest), "hole_bytes": drew})
        # `file` is rewritten relative to the export directory by _bulk_hole_finish: an absolute path is
        # wrong the moment the examiner moves or ships the directory.
        if _REFUSE_HOLES:
            _HOLE_REFUSALS.append(dest)
            return None
    try:
        d = os.path.dirname(dest)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(dest, "wb") as fh:
            fh.write(data)
        return dest
    except OSError as e:
        failures.append({"path": dest, "name": os.path.basename(dest), "error": str(e)})
        return None

def _report_extract_failures(failures, out_dir):
    """After a bulk extraction, record any writes that could not be completed to <out_dir>/_extract_failures.json
    and warn on stderr (audit 4.1), so a name the host filesystem cannot hold surfaces as evidence — the examiner
    learns how many files were skipped and why — instead of the run dying with an unhandled traceback."""
    if not failures:
        return
    try:
        with open(os.path.join(out_dir, "_extract_failures.json"), "w", encoding="utf-8") as fh:
            json.dump(failures, fh, indent=2)
    except OSError:
        pass
    print(f"[{PROG}] WARNING: {len(failures)} file(s) could not be written (name exceeds the host filesystem "
          f"limit, disk full, or permission) — extraction continued; see "
          f"{os.path.join(out_dir, '_extract_failures.json')}", file=sys.stderr)

def _carve_extent_backed(f, ps_off, cs, tr, vd, t40_backing=None, _carve_what=None):
    """Best-effort content carve for a NON-RESIDENT deleted remnant. Returns (bytes, declared_size) or None.
    Two extent sources, in order: (1) the current stream's extents held INLINE in the name row (F5); (2) if
    that is absent/empty, a type-0x40 BACKING recovered from slack (Feature C) — the common case for a deleted
    file whose extent map lives in a separate record (gone from the live tree, but its body persists in slack).

    The bytes MAY BE STALE — the clusters can be reallocated after deletion; there is no allocation-freshness
    check, so callers must warn. Sparse files legitimately read short / zero-padded. Reuses the validated
    snapshot extent format (parse_snapshot_data_entry, inline) / _parse_extents_from_type40 (backing) +
    cmd_extract's fvcn placement/trim (proven on win11refs2tsnapshots arg.txt current stream, byte-exact)."""
    # (1) inline current-stream holder (sub_id 0x1000)
    holder = None
    for k, v in parse_resident_btree_rows(vd, (f, ps_off, cs, tr)):
        if (len(k) >= 0x18 and k[12] == 0x80 and k[13] == 0x00 and le64(k, 0x10) == 0x1000
                and len(v) >= 0x50 and le32(v, 4) == SNAP_DATA_DESC):
            holder = v
            break
    if holder is not None:
        stream_size, disk_alloc, exts = parse_snapshot_data_entry(holder, _volume_ncl(f, ps_off, cs), tr)
        if disk_alloc > 0 and exts and stream_size > 0:
            alloc = max(fv + run for fv, _vl, run in exts) * cs
            if alloc <= 256 * 1024 * 1024:          # safety cap for a best-effort carve
                buf = bytearray(alloc); _cruns = []
                for fvcn, vlcn, run in sorted(exts, key=lambda x: x[0]):
                    if vlcn == 0:
                        continue                    # sparse hole -> leave zero-filled (never read boot region)
                    for j in range(run):
                        try:
                            plcn = tr.tr(vlcn + j)
                        except Exception:
                            plcn = vlcn + j
                        off = (fvcn + j) * cs
                        _cruns.append((plcn, 1, off))
                        f.seek(ps_off + plcn * cs)
                        chunk = f.read(cs)              # len(chunk)==cs on a normal read; a short/past-EOF read
                        buf[off:off + len(chunk)] = chunk   # must NOT shrink buf (slice-assign len-safe) -> zero-pad
                if _carve_what:
                    content_holes(f, ps_off, cs, _cruns, _carve_what, stream_size=stream_size)
                return (bytes(memoryview(buf)[:stream_size]), stream_size)
    # (2) type-0x40 backing recovered from slack — extents already VLCN->PLCN translated by the parser.
    if t40_backing is not None:
        info = _parse_extents_from_type40(t40_backing, cs, tr)
        exts = [x for x in info["extents"] if not x.get("integrity_checksum")]
        stream_size = info["file_size"]
        if exts and stream_size > 0:
            alloc = max(x["file_vcn"] + x["clusters"] for x in exts) * cs
            if alloc > 256 * 1024 * 1024:
                return None
            buf = bytearray(alloc); _cruns = []
            for x in exts:
                plcn, fvcn, run = x["plcn"], x["file_vcn"], x["clusters"]
                for j in range(run):
                    o = (fvcn + j) * cs
                    _cruns.append((plcn + j, 1, o))
                    f.seek(ps_off + (plcn + j) * cs)
                    chunk = f.read(cs)                  # len-safe assign (a past-EOF read must not shrink buf)
                    buf[o:o + len(chunk)] = chunk
            if _carve_what:
                content_holes(f, ps_off, cs, _cruns, _carve_what, stream_size=stream_size)
            return (bytes(memoryview(buf)[:stream_size]), stream_size)
    # (3) inline-holder MULTI-LEVEL extent map (v3.4 / v3.7 / v3.9 / upgraded): the current stream's runs live in
    # THIS row as an embedded B+-tree index array that step (1)'s parse_resident_btree_rows can't reach — the same
    # case cmd_extract/dataruns decode via the cover-guarded index-array walk (§C.3b, #640). Byte-exact or [] (the
    # cover guard rejects a partial/zeroed map), so a v3.4 deleted file's data is never emitted as wrong bytes.
    exts = _decode_holder_extents(vd, cs, tr)
    if exts and len(vd) >= 0x68:
        stream_size = le64(vd, 0x58)                # inline-holder FileSize (alloc@0x60 already cover-checked)
        alloc = max(x["file_vcn"] + x["clusters"] for x in exts) * cs
        if stream_size > 0 and 0 < alloc <= 256 * 1024 * 1024:
            buf = bytearray(alloc); _cruns = []
            got = 0
            for x in sorted(exts, key=lambda x: x["file_vcn"]):
                if x.get("vlcn", x["plcn"]) == 0:
                    continue                        # sparse hole -> leave zero-filled (never read boot region)
                plcn, fvcn, run = x["plcn"], x["file_vcn"], x["clusters"]
                for j in range(run):
                    _cruns.append((plcn + j, 1, (fvcn + j) * cs))
                    f.seek(ps_off + (plcn + j) * cs)
                    chunk = f.read(cs)              # len-safe assign; count real bytes so a stale/out-of-volume
                    got += len(chunk)               # map (plcn past EOF -> empty read) yields NO file, not a 0-byte
                    o = (fvcn + j) * cs
                    buf[o:o + len(chunk)] = chunk
            if got and _carve_what:
                content_holes(f, ps_off, cs, _cruns, _carve_what, stream_size=stream_size)
            if got:                                 # nothing readable (extent map points outside the volume) -> no carve
                return (bytes(memoryview(buf)[:stream_size]), stream_size)
    return None

DELETED_CSV_COLUMNS = ["FileName", "IsDirectory", "RecoverySource", "RecoveredFrom",
                       "Recoverability", "Created", "Modified", "RecoveredChild", "Cluster",
                       "FileAttributes", "Category", "Reliability", "ContentFile"]

# Reliability of the RECOVERED CONTENT (not "un-overwritten"): EXACT = a resident file's full content was inside
# the metadata remnant; BEST-EFFORT = a non-resident file carved from a surviving extent MAP (clusters may have
# been reused — verify); NONE = metadata only.
_RELIABILITY = {"recoverable_inline": "EXACT", "content_zero_or_absent": "NO CONTENT", "extent_backed": "BEST-EFFORT",
                "metadata_only": "NONE", "fragment_only": "NONE"}

def _deleted_category(name):
    """'system' = OS/BitLocker churn that floods the raw output (rotated `FVE2.{GUID}` / `FVE-*` metadata,
    `$Txf*`); 'user' = everything else. The index tags it so an analyst (or `--no-system`) can set the noise
    aside — on a typical volume most raw remnants are this system churn, not user deletions."""
    n = (name or "").lstrip("$")
    if n.startswith(("FVE2.", "FVE-")) or n in ("TxfLog", "Tops", "TxfLog.blf", "TxfLogContainer"):
        return "system"
    return "user"

def _deleted_rows(deleted, orphans, cs=None, tr=None):
    """Build the `deleted` command's output rows (dicts keyed by DELETED_CSV_COLUMNS) — one per truly-deleted
    entry — from the SAME lists + helpers as the text report (_deleted_recoverability, _filetime_to_str). Fields
    that did not survive the deletion are blank; RecoverySource is the recovery method (trash / checkpoint diff /
    node-slack / orphan). Emitted as csv/json/jsonl through the shared _emit_records (consistent with `files`)."""
    def _from(e):
        locs = e.get("all_owning_paths") or []
        if not locs:
            p = e.get("owning_path") or (f"0x{e.get('owning_table_oid', 0):x}" if e.get("owning_table_oid") else "")
            locs = [p] if p else []
        return ";".join(locs)
    def _ts(t): return _filetime_to_str(t) if t else ""
    rows = []
    for e in deleted:
        _rc = _deleted_recoverability(e, cs, tr)
        rows.append({"FileName": e.get("name", ""), "IsDirectory": bool(e.get("is_dir")),
                     "RecoverySource": e.get("tag", ""), "RecoveredFrom": _from(e),
                     "Recoverability": _rc[1], "Created": _ts(e.get("create_time", 0)),
                     "Modified": _ts(e.get("modify_time", 0)), "RecoveredChild": e.get("recovered_child", ""),
                     "Cluster": e.get("plcn", ""),
                     "FileAttributes": attrs_to_str(e.get("file_attrs", 0)) if e.get("file_attrs") else "",
                     "Category": _deleted_category(e.get("name", "")),
                     "Reliability": _RELIABILITY.get(_rc[0], "NONE"),
                     "ContentFile": e.get("_content_file", "")})
    for e in (orphans or []):
        rows.append({"FileName": e.get("name", ""), "IsDirectory": True, "RecoverySource": "orphan",
                     "RecoveredFrom": f"0x{e.get('oid', 0):x}" if e.get("oid") else "",
                     "Recoverability": "metadata only", "Created": _ts(e.get("create_time", 0)), "Modified": "",
                     "RecoveredChild": e.get("recovered_child", ""), "Cluster": "",
                     "FileAttributes": "", "Category": _deleted_category(e.get("name", "")),
                     "Reliability": "NONE", "ContentFile": e.get("_content_file", "")})
    return rows

def _write_recovery_log(path, image, vmaj, vmin, mode, methods, max_scan, deleted, present, extract_dir,
                        orphans=None, cs=None, tr=None, scan_cov=None):
    """Write a forensic RECOVERY-RUN log — an audit trail of what was recovered and how: image, mode, methods,
    and the per-entry deleted-vs-still-present split (with each remnant's source page and, for still-present
    rows, whether the live file sits in a different directory). `orphans` (optional) logs the low-confidence
    --orphans tier. Returns the path written, or None on failure."""
    import datetime
    def _from(e):
        return e.get("owning_path") or (f"0x{e.get('owning_table_oid', 0):x}" if e.get("owning_table_oid") else "?")
    out = ["=" * 78, f"{PROG} recovery log (v{VERSION})", "=" * 78,
           f"Image:        {image}", f"ReFS version: {vmaj}.{vmin}",
           f"Run (UTC):    {datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None).isoformat(timespec='seconds')}Z",
           f"Mode:         {mode}", f"Methods:      {methods}",
           f"Max-scan:     {max_scan if max_scan is not None else 'unbounded (whole volume)'}"]
    if scan_cov:
        out.append(f"Scan coverage: {scan_cov}")
    if extract_dir:
        out.append(f"Exported to:  {extract_dir}")
    out += ["", f"DELETED — no live file with this name + creation time remains ({len(deleted)}):"]
    for e in deleted:
        kind = "DIR " if e.get("is_dir") else "FILE"
        _locs = e.get("all_owning_paths") or [_from(e)]
        _lp = _locs[0] if len(_locs) <= 1 else f"{len(_locs)} directories: " + "; ".join(_locs)
        out.append(f"  {kind} {e['name']}  | deleted from {_lp} | {e.get('tag')} @cluster {e.get('plcn')} | "
                   f"{_deleted_recoverability(e, cs, tr)[1]}")
        if e.get("create_time"):
            out.append(f"        created {_filetime_to_str(e['create_time'])}  "
                       f"modified {_filetime_to_str(e.get('modify_time', 0))}")
    out += ["", f"STILL PRESENT — a live file with this identity exists ({len(present)}):"]
    for e in present:
        note = " [former location — live file in a different directory]" if e.get("former_location") \
               else " [CoW prior-version, same directory]"
        out.append(f"  {e['name']}  | remnant in {_from(e)} | {e.get('tag')} @cluster {e.get('plcn')}{note}")
    if orphans:
        out += ["", f"ORPHAN OBJECTS — Object-Table OIDs unlinked from the tree (LOW confidence, --orphans) "
                    f"({len(orphans)}):"]
        for e in orphans:
            _c = f"recovered child: {e['recovered_child']}" if e.get("recovered_child") else "no child name survived"
            out.append(f"  {e['name']}  (dir @ OID 0x{e.get('oid', 0):x})  | {_c}"
                       + (f"  created {_filetime_to_str(e['create_time'])}" if e.get("create_time") else ""))
    out += ["", "Note: 'recoverable' = the bytes or extent map are PRESENT in the remnant, not that they are",
            "un-overwritten. Carved non-resident content may be stale. Slack recovery is image-dependent.",
            "ORPHAN OBJECTS are a low-confidence complementary signal (OT entry pending GC) — corroborate before use."]
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(out) + "\n")
        return path
    except OSError:
        return None

def cmd_deleted(image, remaining, partition_start):
    # `--_from-export` is a private marker set by `export deleted` so the deprecation notice below is only
    # shown for a DIRECT `deleted --extract` call. Strip it before _parse_args (which rejects unknown flags).
    from_export = "--_from-export" in remaining
    remaining = [x for x in remaining if x != "--_from-export"]
    args = _parse_args(remaining, flags=["--trash", "--scan-pages", "--full", "--no-slack", "--slack",
                                         "--rows-only", "--content-only", "--carve", "--orphans",
                                         "--rows", "--no-system", "--refuse-holes"],
                       valued=["--search", "--max-scan", "--extract", "--log", "--csv", "--json", "--jsonl"])
    global _REFUSE_HOLES
    _REFUSE_HOLES = bool(args["refuse_holes"])
    # `--slack` is a silent no-op kept only for back-compat (the slack scan is the default `recovery` mode);
    # it is intentionally undocumented. Use `--full` for the complete scan, `--no-slack` to skip slack.
    search_name = args["search"]
    extract_dir = args["extract"]
    rows_only = args["rows_only"]
    content_only = args["content_only"]
    # NEW output model (2026-08-21): `export deleted DIR` writes an INDEX (deleted_files.csv/.json — one row per
    # entry) + only the readable CONTENT files (content/) + the recovery log; the raw .row remnants are written
    # ONLY with --rows (or --rows-only). This replaces the old flood of one .row per entry. --no-system drops the
    # OS/BitLocker FVE2 churn.
    write_rows = args["rows"] or rows_only          # emit the raw .row remnants?
    write_content = not rows_only                    # emit decoded/carved content?
    no_system = args["no_system"]
    # Two modes (simple front for the fine-grained flags below): the default `recovery` mode scans only the
    # live-page slack (quick); `--full` (fullrecovery) also scans orphan pages and, on export, carves
    # extent-backed non-resident files. The per-method flags still override for power users.
    full_mode = args["full"]
    carve = args["carve"] or full_mode
    if rows_only and content_only:
        die("--rows-only and --content-only are mutually exclusive")
    # Orphan-page scan budget. Default = None = the WHOLE volume: when the user asks for the deep scan
    # (--full / --scan-pages) it must cover the whole disk, otherwise "not found" would only mean "not
    # found in the first N clusters". --max-scan N is the explicit opt-out for a quick partial pass, and
    # every partial run is labelled INCOMPLETE in both the console output and the recovery log.
    max_scan = _int_arg(args["max_scan"], "--max-scan") if args["max_scan"] else None
    if max_scan is not None and max_scan < 0:
        die("invalid value for --max-scan: must be >= 0 (omit it to scan the whole volume)")
    # The B+-tree node-slack scan runs BY DEFAULT (it is where deleted rows + recoverability live);
    # --no-slack skips it for a fast Trash+checkpoint pass, and --trash returns after the Trash table only.
    do_slack = not args["no_slack"] and not args["trash"]
    do_scan_pages = args["scan_pages"]
    do_orphans = args["orphans"] and not args["trash"]   # opt-in low-confidence OT-orphan directory tier
    scan_orphans = full_mode          # recovery = live-page slack only; --full adds the orphan-page slack scan
    scan_stats = {}                   # filled by the orphan scan: how much of the volume it actually covered
    # Accumulators shared by the scan + slack extraction paths (one manifest per run). Two verdict buckets
    # so the roll-up (and the .recovered files export writes) reconcile by category: deleted files vs prior
    # versions of files still present. _rc counts the entries whose inline content actually decodes.
    _manifest = []
    _write_failures = []   # audit 4.1: bulk-writes skipped (name too long for the host FS, disk full, permission)
    _view_verdicts = []     # deleted files (scan `deleted` + slack d_solid + slack d_partial)
    _prior_verdicts = []    # prior versions of LIVE files (scan still_present + slack p_solid)
    _log_deleted, _log_present = [], []   # captured for the recovery log written at the end of the run
    _log_orphans = []                     # opt-in --orphans tier (OT-orphan directory OIDs), for the log

    def _emit(base, e, name, source, tag):
        """Write this entry's readable CONTENT and (only under --rows) its raw remnant; the decoded metadata
        goes to the deleted_files.csv/.json INDEX (built at the end), NOT one file per entry.
          • content/<name>          — a RESIDENT file's inline $DATA (byte-exact), or
          • content/<name>.carved   — a NON-RESIDENT file reassembled from its extent map (best-effort; may be
                                       stale) when --carve/--full is set. Never a 0-byte file.
          • rows/<prov>.row         — the raw remnant bytes (evidence), only with --rows/--rows-only.
        Real filenames (collision-suffixed .dupN); provenance (cluster/offset) lives in the index. Stamps
        e['_content_file'] so the index can point at the exported content. `--no-system` skips OS/BitLocker
        churn (FVE2.{…})."""
        vd = e.get("vd")
        if not extract_dir or not vd:
            return
        if no_system and _deleted_category(name) == "system":
            return
        os.makedirs(extract_dir, exist_ok=True)
        _hm_dec = len(_CONTENT_HOLES)
        venum, vlabel, decoded = _deleted_recoverability(e, cs, tr)
        prov = os.path.basename(base)                    # historical provenance name (…_c<plcn>o<off>)
        safe = _safe_filename(name)
        content_path = carved_path = row_path = None
        carved_len = carved_size = None
        if write_content and decoded:                    # RESIDENT — non-empty inline content (byte-exact; a
            cdir = os.path.join(extract_dir, "content"); os.makedirs(cdir, exist_ok=True)   # 0-byte file has
            content_path = _collision_free_path(os.path.join(cdir, safe))                   # nothing to recover)
            content_path = _guarded_extract_write(content_path, decoded, _write_failures,
                                                  holes_mark=_hm_dec,
                                                  what=f"deleted file '{name}'")   # audit 4.1
        elif write_content and carve and venum == "extent_backed":   # NON-RESIDENT — carve from the extent map
            _hm_carve = len(_CONTENT_HOLES)
            cres = _carve_extent_backed(f, ps, cs, tr, vd, e.get("t40_backing"),
                                        _carve_what=f"carved '{e.get('name') or e.get('path') or '?'}'")
            if cres:
                cbytes, carved_size = cres
                carved_len = len(cbytes)
                cdir = os.path.join(extract_dir, "content"); os.makedirs(cdir, exist_ok=True)
                carved_path = _collision_free_path(os.path.join(cdir, safe + ".carved"))
                carved_path = _guarded_extract_write(carved_path, cbytes, _write_failures,
                                                     holes_mark=_hm_carve,
                                                     what=f"carved '{name}'")   # audit 4.1
        if write_rows:                                   # raw remnant (evidence) — opt-in
            rdir = os.path.join(extract_dir, "rows"); os.makedirs(rdir, exist_ok=True)
            row_path = _collision_free_path(os.path.join(rdir, prov + ".row"))
            row_path = _guarded_extract_write(row_path, vd, _write_failures)   # audit 4.1
        cf = content_path or carved_path
        e["_content_file"] = ("content/" + os.path.basename(cf)) if cf else ""
        _manifest.append({
            "name": name, "source": source, "tag": e.get("tag", tag), "category": _deleted_category(name),
            "plcn": e.get("plcn"), "page_off": e.get("page_off"),
            "is_resident": venum == "recoverable_inline", "confidence": e.get("confidence"),   # B5: from verdict
            "value_len": len(vd), "recoverable": venum, "verdict": vlabel,
            "reliability": _RELIABILITY.get(venum, "NONE"),
            "row_file": ("rows/" + os.path.basename(row_path)) if row_path else None,
            "content_file": e["_content_file"] or None,
            "decoded_len": len(decoded) if decoded is not None else None,
            "carved_len": carved_len, "carved_declared_size": carved_size,
        })

    def _write_manifest():
        if not (extract_dir and _manifest):
            return
        _report_extract_failures(_write_failures, extract_dir)   # audit 4.1
        import csv as _csv
        # (1) THE INDEX — one row per recovered entry (deleted_files.csv/.json). Replaces the old flood of one
        #     .row file per entry: the analyst reads THIS to see what was deleted, how recoverable it is, and
        #     which content file (if any) holds its bytes.
        rows = _deleted_rows(_log_deleted, _log_orphans, cs, tr)
        if no_system:
            rows = [r for r in rows if r.get("Category") != "system"]
        idx = os.path.join(extract_dir, "deleted_files.csv")
        with open(idx, "w", newline="") as of:
            w = _csv.writer(of); w.writerow(DELETED_CSV_COLUMNS)
            for r in rows:
                w.writerow(_csv_row([r.get(c, "") for c in DELETED_CSV_COLUMNS]))
        with open(os.path.join(extract_dir, "deleted_files.json"), "w") as of:
            json.dump(rows, of, indent=2, default=str)
        # (2) detailed run manifest (programmatic provenance / per-file record)
        with open(os.path.join(extract_dir, "recovery_manifest.json"), "w") as mf:
            json.dump({"image": image, "entries": len(_manifest),
                       "note": ("content/<name> = a RESIDENT deleted file's content, decoded BYTE-EXACT from the "
                                "metadata remnant. content/<name>.carved = a NON-RESIDENT file reassembled from a "
                                "surviving extent MAP — BEST-EFFORT; its data clusters may have been reused since "
                                "deletion (no freshness check), so verify. Entries with no content file are "
                                "metadata-only. deleted_files.csv is the per-entry index; rows/ (only with --rows) "
                                "holds the raw remnant bytes."),
                       "records": _manifest}, mf, indent=2)
        # (3) end-of-run CLI summary — what was recovered + where it went.
        resident = sum(1 for m in _manifest if m["content_file"] and m["is_resident"])
        carved   = sum(1 for m in _manifest if m["content_file"] and not m["is_resident"])
        n_content = resident + carved
        n_row = sum(1 for m in _manifest if m["row_file"])
        n_sys = sum(1 for m in _manifest if m.get("category") == "system")
        n_idx = len(rows)
        print(f"\n  {n_idx} deleted entr{'y' if n_idx == 1 else 'ies'} indexed → {idx}  (+ .json)")
        if n_content:
            _st = f"; the {carved} carved are BEST-EFFORT (may be stale — verify)" if carved else ""
            print(f"    Content recovered: {resident} inline (exact) + {carved} extent-backed carved = "
                  f"{n_content} file{'s' if n_content != 1 else ''} → {os.path.join(extract_dir, 'content')}/{_st}")
        elif not write_content:
            print("    Content: not written (--rows-only) — see rows/ for the raw remnants")
        else:
            print("    Content recovered: none (every entry is metadata-only — the data did not survive)")
        print(f"    Recovery log → {os.path.join(extract_dir, 'recovery_log.txt')}")
        if n_row:
            print(f"    Raw remnants → {os.path.join(extract_dir, 'rows')}/  ({n_row} .row — see `help deleted` "
                  f"for how to read them)")
        if n_sys and not no_system:
            print(f"    ({n_sys} indexed entr{'y is' if n_sys == 1 else 'ies are'} OS/BitLocker (FVE2) system "
                  f"churn — add --no-system to hide.)")
        _eb = sum(1 for m in _manifest if m["recoverable"] == "extent_backed" and not m["content_file"])
        if not carve and _eb:
            print(f"    {_eb} extent-backed file(s) have a recoverable extent map — re-run with --full to carve "
                  f"their content (best-effort).")

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        # Parse both checkpoints
        checkpoints = []
        for lcn in chkp_lcns:
            try:
                vc, flags, chkp_roots = _forefst_parse_chkp(f, ps, cs, lcn)
                checkpoints.append((vc, chkp_roots, lcn))
            except Exception: pass
        checkpoints.sort(key=lambda x: x[0], reverse=True)

        print("=" * 78)
        print("ReFS Deleted File Finder")
        print("=" * 78)
        print(f"  Image:        {image}")
        print(f"  ReFS version: {vmaj}.{vmin}")
        print(f"  Cluster size: {_hx(cs)}")
        print(f"  Checkpoints:  {len(checkpoints)} (VC: {', '.join(str(c[0]) for c in checkpoints)})")
        print(f"  Objects:      {len(obj_map)}")
        print()

        if extract_dir and not from_export:
            print("  NOTE: 'deleted --extract DIR' is deprecated — 'export deleted DIR' does the same")
            print("        (writes the raw .row AND the decoded .recovered content). Proceeding.\n")

        print("── Trash Table (OID 0xD) ──")
        trash_entries = _scan_trash_table(f, ps, cs, tr, obj_map)
        if trash_entries:
            print(f"  {len(trash_entries)} entries pending cleanup:")
            for te in trash_entries:
                oid_str = f" (OID {_hx(te['oid'])})" if "oid" in te else ""
                print(f"    Key ({te['key_len']}B){oid_str}: {te['key_hex'][:64]}")
                print(f"    Val ({te['value_len']}B): {te['value_hex'][:64]}")
        else:
            print("  Empty (all deletions fully processed)")
        print()

        if args["trash"]:
            if extract_dir or args["csv"] or args["json"] or args["jsonl"]:
                print("  NOTE: --trash is a quick Trash-table view and does not emit --csv/--json/--jsonl or export")
                print("        (the Trash table holds raw key/value fragments, not recoverable files). Re-run")
                print("        WITHOUT --trash for the decoded deleted list — e.g. `export deleted DIR` or")
                print("        `deleted --csv FILE`.")
            return 0

        if len(checkpoints) > 1:
            print("── Checkpoint Comparison ──")
            old_vc, old_roots_raw = checkpoints[1][0], checkpoints[1][1]
            print(f"  Current checkpoint: VC={checkpoints[0][0]}")
            print(f"  Previous checkpoint: VC={old_vc}")
            # The old roots from _forefst_parse_chkp are the raw root list
            # We need to rebuild object table from old checkpoint
            # For simplicity, compare root directory files
            current_files = _get_current_files(f, ps, cs, tr, obj_map)
            # Try building old object map
            try:
                old_ot_vlcns = old_roots_raw[0] if len(old_roots_raw) > 0 else []
                if old_ot_vlcns:
                    old_obj_map = build_object_map(f, ps, cs, tr, old_ot_vlcns)
                    old_files = _get_current_files(f, ps, cs, tr, old_obj_map)
                    removed = old_files - current_files
                    added = current_files - old_files
                    if removed:
                        print(f"  Files in old checkpoint but NOT in current ({len(removed)}):")
                        for name in sorted(removed): print(f"    - {name}")
                    if added:
                        print(f"  Files in current but NOT in old ({len(added)}):")
                        for name in sorted(added): print(f"    + {name}")
                    if not removed and not added:
                        print("  Same top-level files in both (change may be in subdirectories or metadata)")
                else:
                    print("  Object Table root is identical in both checkpoints (no recent changes)")
            except Exception:
                print("  Could not parse old checkpoint's object table")
            print()

        if do_scan_pages:
            print("── Orphaned Page Scan ──")
            current_plcns = set()
            for root_vlcns in roots:
                for v in root_vlcns:
                    plcn = tr.tr(v) if tr else v
                    current_plcns.add(plcn)
            for oid_val, vlcns in obj_map.items():
                for v in vlcns:
                    plcn = tr.tr(v) if tr else v
                    current_plcns.add(plcn)
            print(f"  Current tree references {len(current_plcns)} unique physical clusters")
            current_files = _get_current_files(f, ps, cs, tr, obj_map)
            entries = _scan_for_deleted_entries(f, ps, cs, tr, current_plcns, search_name=search_name, max_scan_clusters=max_scan)
            if entries:
                seen = {}
                for e in entries:
                    if e["name"] not in seen or e.get("value_len", 0) > seen[e["name"]].get("value_len", 0):
                        seen[e["name"]] = e
                deleted = [(n, e) for n, e in sorted(seen.items()) if n not in current_files]
                still_present = [(n, e) for n, e in sorted(seen.items()) if n in current_files]
                def _export(name, e, tag):
                    if not extract_dir or not e.get("vd"):
                        return
                    os.makedirs(extract_dir, exist_ok=True)
                    safe = _safe_filename(name)   # faithful (no truncation) component sanitizer
                    base = os.path.join(extract_dir, f"{safe}__{tag}_c{e['plcn']}")
                    _emit(base, e, name, "orphan-scan", tag)

                if deleted:
                    print(f"\n  DELETED entries (not in current directory tree): {len(deleted)}\n")
                    for name, e in deleted:
                        kind = "DIR " if e.get("is_dir", False) else "FILE"
                        _venum, _vlabel, _ = _deleted_recoverability(e, cs, tr)   # B5: header residency from the verdict, not len(vd)>84
                        _hdr_res = ("resident" if _venum in ("recoverable_inline", "content_zero_or_absent")
                                    else "non-resident")   # a resident record either way; only its bytes are unreadable
                        print(f"    {kind} {name}  ({_hdr_res})")
                        if "create_time" in e: print(f"      Created:  {_filetime_to_str(e['create_time'])}")
                        if "modify_time" in e: print(f"      Modified: {_filetime_to_str(e['modify_time'])}")
                        print(f"      Found at: cluster {e['plcn']} (offset {_hx(e['plcn'] * cs)})")
                        _view_verdicts.append(_venum)
                        print(f"      Recoverable: {_vlabel}")
                        _export(name, e, "del")
                if still_present:
                    print(f"\n  Old versions of existing files (orphaned pages): {len(still_present)}")
                    for name, e in still_present:
                        _venum, _vlabel, _ = _deleted_recoverability(e, cs, tr)
                        _prior_verdicts.append(_venum)
                        print(f"    {name} (cluster {e['plcn']}) — {_vlabel}")
                        _export(name, e, "oldver")
            else:
                msg = f"matching '{search_name}'" if search_name else "in scanned area"
                print(f"  No deleted file entries found {msg}")

        # Build the live-identity index ONCE (name+create_time -> live dir OIDs) and share it between the slack
        # classifier and the --orphans filter, so the O(objects) walk runs a single time and both agree.
        live_ident = _build_live_identity(f, ps, cs, tr, obj_map) if (do_slack or do_orphans) else None

        if do_slack:
            print("── B+-tree Node Slack Scan (Method 5) ──")
            print("  Recovering deleted directory entries from metadata-page free space")
            print("  (ReFS deletion removes only the row's index slot; the row body persists).")
            raw = _slack_recover(f, ps, cs, tr, roots, obj_map, max_scan, print,
                                 scan_orphans=scan_orphans, live_identity=live_ident, stats=scan_stats)
            # dedup on (name, create_time, is_dir) — recover each identity ONCE (keep the longest row) — but
            # remember EVERY directory that identity was recovered from, so the log can list all locations a
            # file was deleted from (identical files deleted from several dirs => one recovered file, all dirs logged).
            dedup = {}; _all_locs = {}
            for e in raw:
                k = (e["name"], e.get("create_time", 0), e.get("is_dir", False))
                _op = e.get("owning_path") or (f"0x{e.get('owning_table_oid', 0):x}" if e.get("owning_table_oid") else "")
                if _op:
                    _all_locs.setdefault(k, set()).add(_op)
                if k not in dedup or len(e["vd"]) > len(dedup[k]["vd"]):
                    dedup[k] = e
            for _k, _e in dedup.items():
                _e["all_owning_paths"] = sorted(_all_locs.get(_k, ()))
            ent = list(dedup.values())
            if search_name:
                ent = [e for e in ent if search_name.lower() in e["name"].lower()]
            # B2: split by owner-aware is_prior_version (set in _slack_recover), not a global name set.
            deleted = sorted([e for e in ent if not e.get("is_prior_version")], key=lambda e: e["name"])
            prior = sorted([e for e in ent if e.get("is_prior_version")], key=lambda e: e["name"])
            _log_deleted, _log_present = deleted, prior   # captured for the recovery log

            def _export_slack(e, tag):
                if not extract_dir or not e.get("vd"):
                    return
                os.makedirs(extract_dir, exist_ok=True)
                safe = _safe_filename(e["name"])   # faithful (no truncation) — consistent with the other extractors
                base = os.path.join(extract_dir, f"{safe}__slack-{tag}_c{e['plcn']}o{e['page_off']:x}")
                _emit(base, e, e["name"], "slack", tag)

            def _conf_split(lst):
                solid = [e for e in lst if e["confidence"] in ("high", "medium")]
                partial = [e for e in lst if e["confidence"] == "partial"]
                return solid, partial
            d_solid, d_partial = _conf_split(deleted)
            p_solid, p_partial = _conf_split(prior)
            if deleted:
                print(f"\n  DELETED (no live file with this name + creation time remains on the volume): {len(deleted)}  "
                      f"[{len(d_solid)} with valid timestamps, {len(d_partial)} partial remnants]\n")
                for e in d_solid:
                    kind = "DIR " if e.get("is_dir") else "FILE"
                    tsane = "" if e["confidence"] == "high" else "  [one timestamp only]"
                    _hdr_res = ("resident" if _deleted_recoverability(e, cs, tr)[0]
                                in ("recoverable_inline", "content_zero_or_absent") else "non-resident")  # B5
                    print(f"    {kind} {e['name']}  ({_hdr_res}, "
                          f"{e['tag']} @ cluster {e['plcn']} off {_hx(e['page_off'])}){tsane}")
                    # Q6: which directory the row was deleted FROM (owning-table OID -> path).
                    if e.get("owning_path"):
                        print(f"      Deleted from: {e['owning_path']}  (table {_hx(e.get('owning_table_oid', 0))})")
                        # Recover-once/log-all: an identical file deleted from several directories is recovered
                        # once; note the extra locations here, list them all in the recovery log.
                        _locs = e.get("all_owning_paths") or []
                        if len(_locs) > 1:
                            print(f"      Also deleted from {len(_locs) - 1} other "
                                  f"director{'y' if len(_locs) == 2 else 'ies'} (see recovery log)")
                        # Feature A: the parent directory is itself deleted — annotate its recovered name(s) as a
                        # BEST-EFFORT hint (never in the authoritative path; ambiguous under rename churn).
                        if e.get("parent_deleted"):
                            _cands = e.get("parent_name_candidates") or []
                            if len(_cands) == 1:
                                print(f"        parent directory is DELETED — recovered name (best-effort): {_cands[0]}")
                            elif len(_cands) > 1:
                                print(f"        parent directory is DELETED — name AMBIGUOUS ({len(_cands)} slack "
                                      f"versions from rename/move churn): {', '.join(_cands)}")
                            else:
                                print("        parent directory is DELETED — its name did not survive in slack")
                    elif e.get("owning_table_oid"):
                        print(f"      Owning table: {_hx(e['owning_table_oid'])}  (path unresolved)")
                    if e.get("create_time"):
                        print(f"      Created:  {_filetime_to_str(e['create_time'])}")
                    if e.get("modify_time"):
                        print(f"      Modified: {_filetime_to_str(e['modify_time'])}")
                    _venum, _vlabel, _ = _deleted_recoverability(e, cs, tr)
                    _view_verdicts.append(_venum)
                    print(f"      Recoverable: {_vlabel}")
                    _export_slack(e, "del")
                if d_partial:
                    print(f"\n    + {len(d_partial)} partial remnants (name fragment only, no valid "
                          f"timestamps — corroborate before use):")
                    for e in d_partial[:30]:
                        print(f"      {e['name']!r}  ({e['tag']} c{e['plcn']} o{_hx(e['page_off'])})")
                    if len(d_partial) > 30:
                        print(f"      … and {len(d_partial) - 30} more")
                    for e in d_partial:
                        _view_verdicts.append(_deleted_recoverability(e, cs, tr)[0])
                        _export_slack(e, "del-partial")
            if prior:
                print(f"\n  STILL PRESENT — a live file with this name + creation time exists (CoW remnants, and "
                      f"former locations of moved/renamed files): {len(prior)}  [{len(p_solid)} with valid timestamps]")
                for e in p_solid:
                    _venum, _vlabel, _ = _deleted_recoverability(e, cs, tr)
                    _prior_verdicts.append(_venum)
                    # Neutral note: the remnant is in a DIFFERENT directory than where the live file now sits
                    # (a move/rename/copy — the tool does not interpret which; the recovery log has both paths).
                    _note = "  [former location — the live file is in a different directory]" if e.get("former_location") else ""
                    print(f"    {e['name']}  ({e['tag']} @ cluster {e['plcn']} off {_hx(e['page_off'])}) — {_vlabel}{_note}")
                    _export_slack(e, "prior")
            if not deleted and not prior:
                print("  No recoverable type-0x30 rows found in slack"
                      + (f" matching '{search_name}'" if search_name else "") + ".")
            print("\n  NOTE: slack rows are unindexed remnants. 'with valid timestamps' rows decode a full")
            print("        $SI (high confidence); 'partial remnants' are name fragments from a row whose")
            print("        body was partly overwritten — always corroborate before relying on one entry.")

        # Opt-in ORPHAN-OBJECT tier (--orphans, LOW CONFIDENCE): OIDs still parked in the Object Table but
        # unreachable from the directory tree — a complementary deletion signal (an object left in the OT after
        # its tree link was removed, before GC reclaims it). Identity-filtered against the shared live map: an
        # orphan whose recovered child is still LIVE (a prior/still-referenced structure) is dropped, so a live
        # file is never mislabelled deleted. Low volume by nature; genuine deleted dirs usually recover more
        # fully via the slack scan above.
        if do_orphans:
            print("\n── Orphan-Object Scan (Object Table \\ directory tree) — LOW CONFIDENCE (opt-in) ──")
            _ref = {r["oid"] for r in walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, 1000, True, set())
                    if r.get("oid")}
            _orph = find_orphan_objects(f, ps, cs, tr, obj_map, _ref, print)
            _kept, _dropped_live = [], 0
            for e in _orph:
                _ch, _cct = e.get("recovered_child"), e.get("recovered_child_create_time", 0)
                if _ch and (_ch, _cct) in live_ident:
                    _dropped_live += 1          # child still live => prior / still-referenced, not a deletion
                    continue
                _kept.append(e)
            if search_name:
                _kept = [e for e in _kept
                         if search_name.lower() in (e.get("recovered_child", "") or "").lower()
                         or search_name.lower() in e["name"].lower()]
            _log_orphans = _kept
            _drop_note = f"  ({_dropped_live} candidate(s) dropped — child still live)" if _dropped_live else ""
            if _kept:
                print(f"  {len(_kept)} orphan directory object(s) in the Object Table but unlinked from the "
                      f"tree{_drop_note}:")
                for e in _kept:
                    _c = (f"recovered child: {e['recovered_child']}" if e.get("recovered_child")
                          else "(no child name survived)")
                    print(f"    {e['name']}  (dir @ OID 0x{e['oid']:x})  {_c}")
                    if e.get("create_time"):
                        print(f"      Created:  {_filetime_to_str(e['create_time'])}")
                print("  NOTE: LOW confidence — an OID parked in the Object Table pending GC. Corroborate before")
                print("        use; genuine deleted directories usually recover more fully via the slack scan above.")
            else:
                print(f"  No orphan objects found{_drop_note}.")

        # Methods footer: name the mode, list what ran, and point at the other mode + the sibling commands.
        print("── Recovery methods ──")
        _mode = "full" if full_mode else "recovery"
        _ran = ["Trash table (0xD)", "checkpoint diff"]
        if do_slack:      _ran.append("B+-tree node-slack scan"
                                      + (" (live + orphan pages)" if scan_orphans else " (live pages only)"))
        if do_scan_pages: _ran.append("orphaned-page scan")
        if do_orphans:    _ran.append("orphan-object scan (low confidence)")
        print(f"  Mode: {_mode}.  Ran: {', '.join(_ran)}.")
        if do_slack and not full_mode:
            print("  This is `recovery` (quick, seconds): live-page slack only. Run `deleted --full` to ALSO scan")
            print("  orphan pages (the freed pages of deleted objects) and carve extent-backed content — that reads")
            print("  the WHOLE volume once (about a minute per 60-100 GB), but it typically finds far more.")
        elif full_mode:
            print("  This was `--full` (complete): live + whole-volume orphan-page slack + carve. `deleted` (no")
            print("  --full) is the quicker, live-pages-only pass.")
        else:
            print("  Slack scan SKIPPED (--no-slack). Run `deleted` (the default) to recover deleted rows.")
        print("  Fine-grained: --no-slack · --scan-pages · --orphans · --carve · --search SUB · --csv/--json/--jsonl FILE · `export deleted DIR`.")
        print("  --max-scan N stops the orphan scan early (faster, but the run is then INCOMPLETE); `help deleted` lists what each option costs.")
        if not do_orphans:
            print("  Also: `deleted --orphans` adds a low-confidence tier for OID-Table objects unlinked from the tree.")
        print("  Prior versions of files that still exist: `snapshots`.  Windows Recycle Bin: `recyclebin`.")
        print()

        # Recoverability roll-up, split by category so it reconciles with the files `export deleted` writes.
        if _view_verdicts or _prior_verdicts:
            _rc = lambda lst: sum(1 for v in lst if v == "recoverable_inline")
            _ec = lambda lst: sum(1 for v in lst if v == "extent_backed")
            _zc = lambda lst: sum(1 for v in lst if v == "content_zero_or_absent")
            if _view_verdicts:
                print(f"  DELETED files: {_rc(_view_verdicts)} of {len(_view_verdicts)} are INLINE with full "
                      f"content recoverable; {_ec(_view_verdicts)} are extent-backed (carve-able with --carve).")
                if _zc(_view_verdicts):
                    print(f"    {_zc(_view_verdicts)} more have an inline record whose declared region "
                          f"reads as zeros — the file held zeros, or the deletion took the bytes, and the two "
                          f"cannot be told apart from the remnant. Metadata only; no content is written.")
            if _prior_verdicts:
                print(f"  PRIOR versions of live files: {_rc(_prior_verdicts)} of {len(_prior_verdicts)} "
                      f"decode to a file.")
            print("  Restorability: a RESIDENT deleted file's FULL content is recovered exactly (content/<name>).")
            print("       A NON-RESIDENT file keeps its data in on-disk extents — if the extent map survives")
            print("       ('extent_backed'), --full/--carve reconstructs it best-effort (content/<name>.carved,")
            print("       may be stale); otherwise only METADATA survives (name/size/timestamps).")
            if not extract_dir:
                print("  Next: `export deleted <DIR>` writes a deleted_files.csv/.json index + the readable content")
                print("        files (content/); add --full to carve extent-backed files, --rows for the raw remnants.")
        _write_manifest()

        # Recovery log — a forensic audit trail, written ONLY when something is actually exported/recovered
        # (`export deleted` / `deleted --extract` / -o sets extract_dir) or when the user explicitly asks
        # for one (--log). A plain VIEW recovers nothing, so it must not litter the CWD with a log file.
        if extract_dir or args["log"]:
            import datetime as _dt
            _logmode = "full" if full_mode else ("no-slack" if not do_slack else "recovery")
            if args["log"]:
                _lp = args["log"]
            elif extract_dir:
                _lp = os.path.join(extract_dir, "recovery_log.txt")
            else:
                _b = os.path.basename(image).rsplit(".", 1)[0]
                _lp = f"forefst_recovery_{_b}_{_dt.datetime.now().strftime('%Y%m%d-%H%M%S')}.txt"
            _written = _write_recovery_log(_lp, image, vmaj, vmin, _logmode, ", ".join(_ran), max_scan,
                                           _log_deleted, _log_present, extract_dir, orphans=_log_orphans,
                                           cs=cs, tr=tr, scan_cov=_scan_cov_line(scan_stats))
            if _written and not (extract_dir and _manifest):   # export already reports the log in its summary
                print(f"  Recovery log: {_written}")

        # Machine-readable export (item 4) — csv/json/jsonl, consistent with the other commands and compatible
        # with every recovery flag (it runs on the finalized _log_deleted/_log_orphans, whatever tiers ran).
        _ofmt = "json" if args["json"] else ("jsonl" if args["jsonl"] else ("csv" if args["csv"] else None))
        if _ofmt:
            _emit_records(_deleted_rows(_log_deleted, _log_orphans, cs, tr), DELETED_CSV_COLUMNS,
                          _ofmt, args[_ofmt], label="deleted entries")

        print()
        return _bulk_hole_finish(extract_dir) if extract_dir else 0

    finally:
        f.close()

def cmd_snapshots(image, remaining, partition_start):
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining, allow=("--json",))
    args = _parse_args(remaining, flags=["-v", "--verbose", "--show", "--refuse-holes"],
                       valued=["--file", "--depth", "--extract", "--snapshot"])
    global _REFUSE_HOLES
    _REFUSE_HOLES = bool(args["refuse_holes"])
    verbose = args["v"] or args["verbose"]
    do_show = args["show"]
    extract_dir = args["extract"]
    _snap_failures = []   # audit 4.1
    snap_sel = args["snapshot"]              # select ONE version: name substring, or 1-based index number
    max_depth = _int_arg(args["depth"], "--depth") if args["depth"] else DEFAULT_DEPTH

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        results = []
        _find_snapshot_files(f, ps, cs, tr, obj_map, 0x600, "", 0, max_depth, results)

        true_snap_results = []
        ads_results = []
        for r in results:
            true_snaps = [s for s in r["snapshots"] if s.get("is_true_snapshot", True)]
            ads = [s for s in r["snapshots"] if not s.get("is_true_snapshot", True)]
            if true_snaps: true_snap_results.append({**r, "snapshots": true_snaps})
            if ads: ads_results.append({**r, "snapshots": ads})
        total_true = sum(len(r["snapshots"]) for r in true_snap_results)

        if out_fmt:
            json_out = {
                "image": image, "refs_version": f"{vmaj}.{vmin}", "cluster_size": cs,
                "files_with_snapshots": len(true_snap_results), "total_snapshots": total_true,
                "files": [],
            }
            for r in true_snap_results:
                fentry = {"path": r["path"],
                          "create_time": _filetime_to_str(r.get("create_time", 0)),
                          "modify_time": _filetime_to_str(r.get("modify_time", 0)),
                          "resident_bytes": r["value_len"], "snapshots": []}
                for s in r["snapshots"]:
                    sentry = {"name": s["name"], "stream_size": s.get("stream_size", 0),
                              "allocation_size": s.get("allocation_size", 0),
                              "snapshot_id": s.get("snapshot_id", None)}
                    ct = s.get("creation_time", 0)
                    if ct: sentry["creation_time"] = _filetime_to_str(ct)
                    fentry["snapshots"].append(sentry)
                json_out["files"].append(fentry)
            _emit_json_obj(json_out, out_dest, "%d snapshot-bearing files" % len(true_snap_results)); return 0

        print("=" * 78)
        print("ReFS Stream Snapshot Analysis")
        print("=" * 78)
        print(f"  Image:        {image}")
        print(f"  ReFS version: {vmaj}.{vmin}")
        print(f"  Cluster size: {_hx(cs)}")
        print(f"  Objects:      {len(obj_map)}")
        print()
        print(f"  Files with snapshots: {len(true_snap_results)}")
        print(f"  Total snapshots:      {total_true}")

        if not true_snap_results:
            print("\n  No files with stream snapshots found."
                  "  (Alternate data streams are listed by `specials ads` / `export ads`.)")
            return _bulk_hole_finish(extract_dir) if extract_dir else 0

        print(f"\n{'-'*78}")
        file_filter = args["file"]
        display_list = true_snap_results
        if file_filter:
            display_list = [r for r in display_list if file_filter in r["path"]]
            if not display_list:
                print(f"  No snapshot files matching '{file_filter}'")
                return _bulk_hole_finish(extract_dir) if extract_dir else 0

        # --snapshot: pick ONE version per file — a 1-based index number (as shown in the [N] listing),
        # or a case-insensitive substring of the version name. Returns the set of matching names, or None
        # (= all versions). Applied to BOTH the listing and the recovered/extracted streams (matched by
        # name, so the listing index and the recovery stay in lock-step).
        def _sel_names(snaps):
            if not snap_sel: return None
            if snap_sel.lstrip("-").isdigit():
                n = int(snap_sel)
                return {snaps[n - 1]["name"]} if 1 <= n <= len(snaps) else set()
            s = snap_sel.lower()
            return {sn["name"] for sn in snaps if s in (sn.get("name", "") or "").lower()}

        any_sel_match = False
        for r in display_list:
            sel = _sel_names(r["snapshots"])
            if sel is not None and not sel:
                continue                              # this file has no version matching --snapshot
            any_sel_match = any_sel_match or sel is None or bool(sel)
            shown = [s for s in r["snapshots"] if sel is None or s["name"] in sel]
            print(f"\n  FILE {r['path']}")
            if "create_time" in r: print(f"    Created:      {_filetime_to_str(r['create_time'])}")
            if "modify_time" in r: print(f"    Modified:     {_filetime_to_str(r['modify_time'])}")
            print(f"    Resident:     {r['value_len']} bytes")
            if sel is None:
                print(f"    Snapshots:    {len(r['snapshots'])}\n")
            else:
                print(f"    Snapshots:    {len(shown)} of {len(r['snapshots'])} (--snapshot {snap_sel})\n")
            for i, s in enumerate(r["snapshots"]):
                if s["name"] not in [sh["name"] for sh in shown]:
                    continue                          # keep original [N] numbering, show only the selected
                print(f"    [{i+1}] \"{s['name']}\"")
                ct = s.get("creation_time", 0)
                if ct: print(f"        Created:       {_filetime_to_str(ct)}")
                print(f"        Stream size:   {s.get('stream_size', 0)} bytes")
                if verbose:
                    print(f"        Alloc size:    {s.get('allocation_size', 0)} bytes")
                    print(f"        Snap alloc:    {s.get('snapshot_alloc', 0)} bytes")
                    print(f"        Snapshot ID:   {s.get('snapshot_id', '?')}")
                    print(f"        Raw val len:   {s['raw_len']}")

            # Content recovery via the extent chain (CoW prior content)
            if (do_show or extract_dir) and r.get("vd") is not None:
                recs = recover_snapshot_streams(f, ps, cs, tr, r["vd"])
                if sel is not None:
                    recs = [rec for rec in recs if rec["name"] in sel]
                if recs:
                    print(f"\n    Recovered content ({len(recs)} version(s)):")
                for rec in recs:
                    content = rec["content"]
                    if rec["inline"]:
                        status = "inline (in 0x30 body — current version)"
                    elif content is None:
                        status = "no DATA extent"
                    else:
                        status = f"{len(content)} bytes, {rec['n_extents']} extent(s)"
                    print(f"      [{rec['name']}] sub_id=0x{rec['sub_id']:x} "
                          f"size={rec['stream_size']} -> {status}")
                    if content is not None and do_show:
                        preview = content[:120]
                        try:
                            txt = preview.decode("utf-8")
                            shown = txt if all(c.isprintable() or c in "\r\n\t" for c in txt) else preview.hex()
                        except UnicodeDecodeError:
                            shown = preview.hex()
                        print(f"          {shown!r}")
                    if content is not None and extract_dir:
                        safe = (r["path"].strip("/").replace("/", "_") + "__" + rec["name"])
                        safe = _safe_filename(safe)   # faithful (no truncation) component sanitizer
                        os.makedirs(extract_dir, exist_ok=True)
                        outp = os.path.join(extract_dir, safe)
                        if _guarded_extract_write(outp, content, _snap_failures,
                                                  holes_mark=rec.get("_holes_mark"),
                                                  what=f"snapshot version '{rec['name']}' "
                                                       f"(0x{rec['sub_id']:x})"):   # audit 4.1
                            print(f"          -> wrote {outp}")

        if snap_sel and not any_sel_match:
            print(f"\n  No snapshot version matched --snapshot {snap_sel!r} "
                  f"(use a 1-based [N] index or part of a version name).")
        _report_extract_failures(_snap_failures, extract_dir)   # audit 4.1
        return _bulk_hole_finish(extract_dir) if extract_dir else 0

    finally:
        f.close()

def verify_page_references(f, ps, cs, tr, roots, limit=None):
    """Recompute every Object-Table page-reference digest (GN_PREF_RA_004). Returns a dict of counts.

    A page reference binds a child page's address to a digest of that page's contents, chaining the metadata
    tree into a Merkle tree anchored at the checkpoint. The digest covers the WHOLE page -- every valid LCN
    slot concatenated, read AFTER container translation, nothing excluded. Slot count follows the cluster
    size: 4 on 4 KiB, 1 on 64 KiB, both making one page.

    Scoped to the row the reader USES. An Object Table may hold more than one row per object id -- an earlier
    generation and a current one -- and build_object_map keeps the LAST. A superseded row may point at a page
    since freed or reallocated, so whether it still verifies says nothing about the volume. Measured that way
    the invariant holds with no carve-out: 33,883/33,883 across 89 corpus images, both algorithms.
    """
    # `algorithms` is a sorted LIST, not a set: a set reaches --json as the Python repr "{'CRC64'}", which is
    # not parseable by a consumer.
    algs = set()
    # `absent` is separated from `failed`: a page that reads ALL ZERO at a correctly translated,
    # in-bounds address is one the IMAGE does not contain, which is an acquisition fact. Counting it as
    # "failed" would report a partial image as an altered volume -- the two need different actions.
    out = {"checked": 0, "verified": 0, "failed": 0, "absent": 0, "superseded": 0, "skipped": 0,
           "algorithms": []}
    try:
        ot = _select_ot_root(f, ps, cs, tr, roots)
        rows = [(kd, vd) for kd, vd in walk_bplus(f, ps, cs, tr, ot)
                if len(kd) >= 16 and len(vd) >= 0x50]
    except Exception as e:
        _skip_note("page references", "object table not walkable", e)
        out["algorithms"] = sorted(algs)
        return out
    used = {}
    for i, (kd, _vd) in enumerate(rows):
        used[le64(kd, 8)] = i                      # same rule as build_object_map: the LAST row wins
    for i, (kd, vd) in enumerate(rows):
        if limit and out["checked"] >= limit:
            break
        if used[le64(kd, 8)] != i:
            out["superseded"] += 1
            continue
        lcns = [le64(vd, 0x20 + 8 * j) for j in range(4)]
        lcns = [x for x in lcns if x not in (0, 0xFFFFFFFFFFFFFFFF)]
        clen = le32(vd, 0x44)
        if not lcns or clen not in (8, 32) or 0x48 + clen > len(vd):
            out["skipped"] += 1
            continue
        data = b""
        try:
            for x in lcns:
                f.seek(ps + tr.tr(x) * cs)
                data += f.read(cs)
        except OSError as e:
            _skip_note("page references", f"read of oid 0x{le64(kd, 8):x}", e)
            out["skipped"] += 1
            continue
        if len(data) != len(lcns) * cs:
            out["skipped"] += 1
            continue
        out["checked"] += 1
        if clen == 8:
            algs.add("CRC64")
            good = refs_crc64(data) == le64(vd, 0x48)
        else:
            algs.add("SHA-256")
            good = hashlib.sha256(data).digest() == bytes(vd[0x48:0x48 + clen])
        if good:
            out["verified"] += 1
        elif not any(data):
            out["absent"] += 1
            if out["absent"] <= 3:
                print(f"[{PROG}] WARNING: the page for object 0x{le64(kd, 8):x} reads as all zeros — this "
                      f"image does not contain it (the address translates and is in bounds).",
                      file=sys.stderr)
        else:
            out["failed"] += 1
            if out["failed"] <= 3:
                print(f"[{PROG}] WARNING: metadata page for object 0x{le64(kd, 8):x} does not match its "
                      f"recorded checksum — the page has been altered since the checksum was written.",
                      file=sys.stderr)
    out["algorithms"] = sorted(algs)
    return out


def cmd_integrity(image, remaining, partition_start):
    # integrity is a multi-section diagnostic REPORT, not a record list — only --json applies (a structured
    # report object); --csv/--jsonl are not offered. The human text is captured and replaced by the object.
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining, allow=("--json",))
    args = _parse_args(remaining, flags=["-v", "--verbose", "--checksums", "--fullchecksums"],
                       valued=["--scan-range", "--max-pages"])
    verbose = args["v"] or args["verbose"]
    # fidelity override: raise the full-tree page cap on very large volumes (default 300000)
    max_pages = _int_arg(args["max_pages"], "--max-pages") if args["max_pages"] else 300000
    do_full = args["fullchecksums"]            # entire metadata tree (all object B+-trees)
    do_checksums = args["checksums"] or do_full  # --fullchecksums implies checksum verification

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    _saved_stdout = sys.stdout
    try:
        if out_fmt:                         # capture the human report; we emit a JSON object instead
            import io as _io
            sys.stdout = _io.StringIO()
        # Get volume sig and VC from CHKP
        best_vc = 0; best_volsig = 0; chk_type = 0; best_chk = None
        for cl in chkp_lcns:
            try:
                f.seek(ps + cl * cs); raw = f.read(4 * cs)
                if raw[:4] == b"CHKP":
                    vc = le64(raw, 0x10)
                    if vc >= best_vc:
                        best_vc = vc; best_volsig = le32(raw, 0x0C); best_chk = raw
            except Exception: pass
        f.seek(ps); bs = f.read(512)
        chk_type = le16(bs, 0x2A)
        chk_types = {0: "None", 2: "CRC64", 4: "SHA-256"}

        report = {
            "pages_checked": 0, "pages_valid_sig": 0, "pages_invalid_sig": 0,
            "pages_volsig_match": 0, "pages_volsig_mismatch": 0,
            "pages_vc_ok": 0, "pages_vc_exceed": 0,
            "pages_selfaddr_ok": 0, "pages_selfaddr_bad": 0,
            "btree_inner_ok": 0, "btree_leaf_ok": 0, "btree_struct_error": 0,
            "issues": [], "page_details": [],
        }

        if args["scan_range"]:
            parts = args["scan_range"].split("-")
            try:
                start_lcn = int(parts[0], 0)
                end_lcn = int(parts[1], 0) if len(parts) > 1 else start_lcn + 1
            except (ValueError, IndexError):
                die(f"--scan-range: expected an LCN or A-B range (0x hex ok), got {args['scan_range']!r}")
            # raw forensic scan: each LCN is one standalone cluster to inspect
            pages_to_check = [(lcn, [lcn]) for lcn in range(start_lcn, end_lcn)]
        else:
            visited = set()
            pages_to_check = []
            for idx, root_vlcns in enumerate(roots):
                if not root_vlcns: continue
                use_tr = None if idx in _CT_ROOT_INDICES else tr
                _walk_btree_pages(f, ps, cs, use_tr, root_vlcns, visited, pages_to_check)
            for oid_val, vlcns in obj_map.items():
                _walk_btree_pages(f, ps, cs, tr, vlcns, visited, pages_to_check)

        ct_entries = len(tr.map) if tr else 0
        for head, plcns in pages_to_check:
            try:
                data = b""
                for p in plcns:
                    f.seek(ps + p * cs); data += f.read(cs)
                _check_page(data, head, best_volsig, best_vc, report, verbose)
            except (OSError, OverflowError): pass

        print("=" * 78)
        print("ReFS Metadata Integrity Report")
        print("=" * 78)
        print(f"  Image:           {image}")
        print(f"  ReFS version:    {vmaj}.{vmin}")
        print(f"  Cluster size:    {_hx(cs)}")
        print(f"  Checksum type:   {chk_types.get(chk_type, f'Unknown({chk_type})')}")
        print(f"  Checkpoint VC:   {best_vc}")
        print(f"  Volume sig:      {_hx(best_volsig)}")
        print(f"  Container map:   {ct_entries} entries")
        print()
        print("-" * 78)
        print("Page Statistics")
        print("-" * 78)
        print(f"  Pages checked:           {report['pages_checked']}")
        print(f"  Valid signatures:        {report['pages_valid_sig']}")
        print(f"  Invalid signatures:      {report['pages_invalid_sig']}")
        print(f"  Volume sig matches:      {report['pages_volsig_match']}")
        print(f"  Volume sig mismatches:   {report['pages_volsig_mismatch']}")
        print(f"  VC within bounds:        {report['pages_vc_ok']}")
        print(f"  VC exceeds checkpoint:   {report['pages_vc_exceed']}")
        print(f"  Self-address valid:      {report['pages_selfaddr_ok']}")
        print(f"  Self-address invalid:    {report['pages_selfaddr_bad']}")
        print(f"  B+-tree inner nodes OK:  {report['btree_inner_ok']}")
        print(f"  B+-tree leaf nodes OK:   {report['btree_leaf_ok']}")
        print(f"  B+-tree struct errors:   {report['btree_struct_error']}")
        print()

        # GN_PREF_RA_004: every Object-Table row records a checksum of the page it points at. Recomputing
        # them answers "is the tree I just walked the tree the volume recorded?" -- independent of the page
        # self-checks above, which only say a page is internally well-formed.
        # Gated on --checksums like the page self-checks below: one 4-cluster read per object, and a real
        # Windows volume has 26,681 of them (427 MB, ~38 s). Running it unconditionally took `integrity`
        # from 1.4 s to 38.2 s. Cheap by default, deep on request -- the contract this command already had.
        _pr = verify_page_references(f, ps, cs, tr, roots) if do_checksums else None
        report["page_references"] = _pr
        print("-" * 78)
        print("Page-reference checksums (parent -> child binding)")
        print("-" * 78)
        if _pr is None:
            print("  not checked — add `--checksums` (one 4-cluster read per object; ~27,000 on a real volume)")
        elif not _pr["checked"]:
            print("  no Object-Table page references could be read")
        else:
            _algs = "/".join(_pr["algorithms"]) or "-"
            print(f"  Verified:                {_pr['verified']} of {_pr['checked']}  ({_algs})")
            print(f"  Mismatched:              {_pr['failed']}"
                  + ("   <-- the page differs from what the parent recorded" if _pr["failed"] else ""))
            print(f"  Absent from this image:  {_pr['absent']}"
                  + ("   <-- reads as all zeros; an acquisition gap, not an altered page"
                     if _pr["absent"] else ""))
            if _pr["superseded"]:
                print(f"  Superseded rows skipped: {_pr['superseded']}  (an earlier generation of the same "
                      f"object; the reader uses the current row)")
            if _pr["skipped"]:
                print(f"  Not checkable:           {_pr['skipped']}")
            print("  The digest covers the WHOLE page — every cluster of it, after container translation.")
        print()

        # F1: cryptographic page-checksum verification (CRC64 / SHA-256)
        ck_stats = None
        if do_checksums and best_chk is not None:
            dl = le32(best_chk, 0x5C); rc = le32(best_chk, 0x90)
            ck_stats = _verify_page_checksums(f, ps, cs, tr, best_chk, dl, rc,
                                              max_pages=max_pages, full=do_full)
            print("-" * 78)
            scope = "ENTIRE metadata tree" if do_full else "root-table metadata"
            print(f"Page Checksum Verification — {scope} (recomputed vs stored)")
            print("-" * 78)
            tot_ok = ck_stats["crc64_ok"] + ck_stats["sha_ok"]
            tot_bad = ck_stats["crc64_bad"] + ck_stats["sha_bad"]
            if do_full:
                print(f"  Coverage:                full metadata tree "
                      f"(system roots + {ck_stats['objects']} object B+-trees)")
            else:
                print("  Coverage:                system root tables only "
                      "(run --fullchecksums for every object B+-tree)")
            print(f"  Pages verified:          {ck_stats['pages']}")
            print(f"  CRC64  match / mismatch: {ck_stats['crc64_ok']} / {ck_stats['crc64_bad']}")
            print(f"  SHA256 match / mismatch: {ck_stats['sha_ok']} / {ck_stats['sha_bad']}")
            if ck_stats["none"]:
                print(f"  Unchecksummed pages:     {ck_stats['none']}")
            if ck_stats.get("unreadable"):
                # A page the reader could not READ is not a page that passed. It used to be dropped
                # silently (an empty buffer failed the "MSB+" test and returned), so the verdict below
                # was pronounced over a volume that had not been fully read.
                print(f"  UNREADABLE pages:        {ck_stats['unreadable']} "
                      f"(not checked — see the warnings above)")
            if ck_stats.get("capped"):
                print(f"  NOTE: page cap ({max_pages}) reached — coverage truncated; "
                      f"rerun with --max-pages N for full fidelity")
            if tot_bad:
                print(f"  *** {tot_bad} CHECKSUM MISMATCH(ES) — page content altered/corrupt ***")
                print(f"    {'VLCN':>12}  {'container':>9}  {'PLCN':>12}  {'byte offset':>14}  check   stored != computed")
                for s0, plcn, cont, kind, stored, calc in ck_stats["mismatches"][:20]:
                    coff = ps + plcn * cs
                    cstr = _hx(cont) if cont is not None else "physical"
                    print(f"    {_hx(s0):>12}  {cstr:>9}  {_hx(plcn):>12}  {_hx(coff):>14}  {kind:<6}  {stored} != {calc}")
            elif ck_stats.get("unreadable"):
                print(f"  VERDICT: the {tot_ok} checksummed pages that COULD be read VERIFIED — "
                      f"{ck_stats['unreadable']} page(s) were unreadable and are NOT covered")
            else:
                print(f"  VERDICT: all {tot_ok} checksummed pages VERIFIED — no tampering/corruption")
            print()

        # Redundancy inventory: ReFS keeps a backup boot sector (last LBA), an alternating
        # checkpoint pair, and secondary SUPB copies. Verify they are present + valid so a future
        # recovery mode could fall back to a backup if the primary is corrupt.
        bk = _scan_backup_copies(f, ps, cs, chkp_lcns)
        backup_warn = []
        print("-" * 78)
        print("Redundancy / Backup Copies")
        print("-" * 78)
        v = bk["vbr"]
        pmark = "OK" if v["primary_cksum_ok"] else ("sig-ok, checksum?" if v["primary_ok"] else "BAD")
        print(f"  Boot sector (primary):   LBA 0 — {pmark}")
        if v["backup"] is None:
            print("  Boot sector (backup):    not located (no volume-size field)")
        elif v["backup"].get("present"):
            same = "identical to primary" if v["backup"]["matches_primary"] else "DIFFERS from primary"
            ck = "checksum OK" if v["backup"]["cksum_ok"] else "checksum?"
            print(f"  Boot sector (backup):    LBA {v['backup']['lba']} — present, {same}, {ck}")
            if not v["backup"]["matches_primary"]:
                bvr, pvr = v["backup"].get("version"), v["backup"].get("primary_version")
                if bvr and pvr and bvr != pvr:
                    print(f"      ↳ version mismatch: primary v{pvr}, backup v{bvr} — an UPGRADE "
                          f"(the backup keeps the ORIGINAL pre-upgrade version) or VBR tampering.")
                    print("        The driver does NOT reconcile the two copies (no cross-copy "
                          "checksum/clock); the backup is consulted only if the primary fails to READ.")
                    backup_warn.append(f"boot-sector version differs: primary v{pvr} vs backup v{bvr}")
                else:
                    backup_warn.append("backup boot sector differs from primary")
        else:
            print(f"  Boot sector (backup):    LBA {v['backup'].get('lba','?')} — MISSING/unreadable")
            backup_warn.append("backup boot sector missing")
        for rec in bk["checkpoints"]:
            vc = rec.get("vc")
            status = "checksum OK" if rec.get("cksum_ok") else ("valid" if (rec["sig_ok"] and rec["roots_ok"]) else "INVALID")
            print(f"  Checkpoint [{rec['role']:9}]:   LCN {_hx(rec['lcn'])} — {status}"
                  + (f", vclock={vc}" if vc is not None else ""))
            if rec["role"] == "secondary" and not rec.get("cksum_ok"):   # B5: the older slot is the secondary
                backup_warn.append(f"secondary checkpoint @ {_hx(rec['lcn'])} invalid")
        n_supb = len(bk["supb"])
        print(f"  Superblock copies:       {n_supb}")
        for s in bk["supb"]:
            _sok = "checksum OK" if s.get("cksum_ok") else ("signature OK" if s.get("ok") else "BAD")
            print(f"      [{s.get('role','?'):7}] LCN {_hx(s['lcn'])} (offset {_hx(s['lcn'] * cs)}) — {_sok}")
        if n_supb < 2:
            backup_warn.append("fewer than 2 SUPB copies located")
        print()

        has_fail = any(s == "FAIL" for s, _, _ in report["issues"])
        has_warn = any(s == "WARN" for s, _, _ in report["issues"]) or bool(backup_warn)
        ck_bad = (ck_stats["crc64_bad"] + ck_stats["sha_bad"]) if ck_stats else 0
        if backup_warn:
            for w in backup_warn:
                print(f"  [WARN] redundancy: {w}")
        if has_fail or ck_bad:
            verdict = "FAIL — " + ("structural corruption" if has_fail else "") + \
                      (f"{' + ' if has_fail else ''}{ck_bad} checksum mismatch(es)" if ck_bad else "")
        elif has_warn:
            nwarn = sum(1 for s, _, _ in report['issues'] if s == 'WARN') + len(backup_warn)
            verdict = f"WARN — {nwarn} warning(s)" + (" (incl. redundancy)" if backup_warn else "")
        elif ck_stats: verdict = f"PASS — structurally valid AND {ck_stats['crc64_ok']+ck_stats['sha_ok']} page checksums verified"
        else: verdict = "PASS — all metadata pages structurally valid (run --checksums / --fullchecksums to verify CRC64/SHA-256)"
        print("-" * 78)
        print(f"Verdict: {verdict}")
        print("-" * 78)

        if report["issues"]:
            print("\nIssues:")
            for severity, lcn, msg in report["issues"][:50]:
                print(f"  [{severity}] LCN {_hx(lcn)}: {msg}")
            if len(report["issues"]) > 50:
                print(f"  ... and {len(report['issues']) - 50} more issues")

        if verbose and report["page_details"]:
            print(f"\n{'-'*78}\nPage Details\n{'-'*78}")
            for d in report["page_details"][:200]:
                sig_s = d["sig"].decode("ascii", errors="replace") if d["sig"] in _VALID_SIGS else d["sig"].hex()
                status = " ".join(d["issues"]) if d["issues"] else "OK"
                print(f"  LCN {_hx(d['lcn']):<10} {sig_s:<5} {status}")

        # Scriptable exit status: 2 = integrity failure (structural and/or checksum), 0 = clean.
        _rc = 2 if (has_fail or ck_bad) else 0
        if out_fmt:
            sys.stdout = _saved_stdout
            _report_obj = {
                "image": os.path.basename(image),
                "refs_version": f"{vmaj}.{vmin}",
                "cluster_size": cs,
                "checksum_type": chk_types.get(chk_type, f"Unknown({chk_type})"),
                "checkpoint_vc": best_vc,
                "volume_sig": best_volsig,
                "container_map_entries": ct_entries,
                "page_statistics": {k: v for k, v in report.items() if k not in ("issues", "page_details")},
                "checksum_verification": ck_stats,
                "redundancy": {"backup_copies": bk, "warnings": backup_warn},
                "issues": [{"severity": s, "lcn": l, "message": m} for s, l, m in report["issues"]],
                "verdict": verdict,
                "clean": not (has_fail or ck_bad),
            }
            _emit_json_obj(_report_obj, out_dest, "integrity report")
        return _rc

    finally:
        sys.stdout = _saved_stdout      # restore even if the body raised while capturing
        f.close()

def cmd_export_metadata(image, remaining, partition_start):
    """Export ReFS bootstrap + metadata structures as raw, hash-verified artifacts (the ReFS analogue of
    dumping a raw $MFT): VBR (primary+backup), both checkpoints, SUPB copies, the MLog control+log pages,
    the USN $J stream, and the full object B+-tree forest — plus manifest.json + sha256sums.txt."""
    import hashlib, json as _json
    args = _parse_args(remaining, flags=[],
                       valued=["-o", "--out", "--what", "--btree-mode", "--max-scan"])
    # 3.C convention: bulk exports take a positional DIR (like export resident-all/recyclebin/deleted);
    # -o/--out kept as a back-compat alias.
    outdir = args["o"] or args["out"] or (args["_rest"][0] if args["_rest"] else None)
    if not outdir:
        die("export metadata requires an output directory: `export metadata OUTDIR`")
    what = set((args["what"] or "all").lower().replace(" ", "").split(","))
    def want(x): return "all" in what or x in what
    btree_mode = (args["btree_mode"] or "packed").lower()
    max_scan = _int_arg(args["max_scan"], "--max-scan") if args["max_scan"] else 2000000

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        os.makedirs(outdir, exist_ok=True)
        manifest = {"image": os.path.basename(image), "partition_start_bytes": ps, "cluster_size": cs,
                    "refs_version": f"{vmaj}.{vmin}", "artifacts": []}
        sha_lines = []
        _md_failures = []   # audit 4.1

        def emit(name, data, source, **meta):
            if not data:
                return
            if _guarded_extract_write(os.path.join(outdir, name), data, _md_failures) is None:   # audit 4.1
                return
            h = hashlib.sha256(data).hexdigest()
            manifest["artifacts"].append(dict(file=name, bytes=len(data), sha256=h, source=source, **meta))
            sha_lines.append(f"{h}  {name}")
            print(f"  + {name:32s} {len(data):>13,d} B  {source}")

        def rd(lcn, nclu=1):
            f.seek(ps + lcn * cs); return f.read(nclu * cs)

        print("=" * 78)
        print(f"ReFS Metadata Export — {os.path.basename(image)} (v{vmaj}.{vmin})")
        print("=" * 78)

        f.seek(ps); vbr = f.read(512)
        total_sectors = le64(vbr, 0x18) if len(vbr) >= 0x20 else 0

        if want("vbr"):
            emit("vbr_primary.bin", vbr, "boot sector @ LBA 0", lba=0)
            if total_sectors > 1:
                try:
                    f.seek(ps + (total_sectors - 1) * 512)
                    emit("vbr_backup.bin", f.read(512), "backup boot sector @ last LBA",
                         lba=total_sectors - 1)
                except (OSError, OverflowError) as _e:
                    _skip_note("metadata export", "artefact at this offset", _e)

        if want("chkp"):
            for i, cl in enumerate(chkp_lcns):
                try:
                    d = rd(cl, 4)
                    role = "current" if i == 0 else "alternate"
                    emit(f"checkpoint_{i}_lcn{cl:x}.bin", d, f"CHKP ({role})", lcn=cl)
                except (OSError, OverflowError) as _e:
                    _skip_note("metadata export", "artefact at this offset", _e)

        if want("supb"):
            try:
                emit("supb_primary.bin", rd(SUPB_LCN), "SUPB primary @ LCN 0x1e", lcn=SUPB_LCN)
            except (OSError, OverflowError) as _e:
                _skip_note("metadata export", "artefact at this offset", _e)
            if total_sectors > 1:
                end_lcn = (total_sectors * 512) // cs
                for lcn in (end_lcn - 2, end_lcn - 3):
                    try:
                        d = rd(lcn)
                        if d[:4] == b"SUPB":
                            emit(f"supb_backup_lcn{lcn:x}.bin", d, "SUPB backup", lcn=lcn)
                    except (OSError, OverflowError) as _e:
                        _skip_note("metadata export", "artefact at this offset", _e)

        if want("mlog"):
            try:
                mi = get_mlog_info(f, ps, cs, tr, obj_map)
            except Exception:
                mi = None
            if mi:
                for k in ("ctrl_plcn_0", "ctrl_plcn_1"):
                    if mi.get(k):
                        try:
                            emit(f"mlog_{k}.bin", rd(mi[k]), f"MLog control page ({k})", lcn=mi[k])
                        except (OSError, OverflowError) as _e:
                            _skip_note("metadata export", "artefact at this offset", _e)
                # live log pages only (the data area is mostly zero — dump the MLog-signature blocks).
                # The data area is addressed by PHYSICAL LCN (NOT container-translated; structure_reference
                # §E + LogLibraryReadFromCopy reads the raw offset with a NULL table identity), and each
                # cluster packs cs//4096 4 KiB log blocks (16 on 64K volumes). So reuse the validated
                # scan_mlog_data_area (untranslated + per-4 KiB-block) — the same scanner mlog/usn/timeline
                # use — instead of tr.tr()-ing the start (which lands on the wrong cluster: 0 pages on
                # targeted/winsider) and reading one cluster per page (which misses 15/16 blocks on 64K).
                try:
                    ctrl = read_mlog_control(f, ps, cs, mi)
                    blob = bytearray(); idx = []
                    for pg in scan_mlog_data_area(f, ps, cs, tr, mi, ctrl):
                        blk = pg.get("page")
                        if blk and blk[:4] == b"MLog":
                            idx.append((pg["block_lcn"], len(blob))); blob += blk
                            if len(blob) >= max_scan * cs:   # bound the dump
                                break
                    if blob:
                        emit("mlog_log_pages.bin", bytes(blob),
                             f"{len(idx)} live MLog data pages (concatenated)")
                        emit("mlog_log_index.csv",
                             ("block_lcn,byte_offset\n" + "\n".join(f"0x{p:x},{o}" for p, o in idx)).encode(),
                             "index for mlog_log_pages.bin")
                except (OSError, OverflowError, KeyError):
                    pass

        if want("usn"):
            try:
                vd, _em = locate_change_journal(f, ps, cs, tr, obj_map)
                if vd is not None:
                    st = parse_usn_journal_streams(vd, cs, tr)
                    if st.get("j_extents"):
                        jd = read_usn_j_stream(f, ps, cs, st["j_extents"], st["j_stream_size"],
                                               _content_what="USN $J change-journal stream")
                        emit("usn_J.bin", jd, "USN $J change-journal stream (reassembled)")
            except Exception:
                pass

        if want("btree"):
            # the raw-metadata analogue: every reachable metadata page (system roots + every object tree)
            visited = set(); ptc = []
            for idx, rv in enumerate(roots):
                if rv:
                    _walk_btree_pages(f, ps, cs, (None if idx in _CT_ROOT_INDICES else tr),
                                      rv, visited, ptc)
            # object_table.bin = root 0's pages
            ot_heads = set()
            if roots and roots[0]:
                otv = set(); otp = []
                _walk_btree_pages(f, ps, cs, tr, roots[0], otv, otp)
                ot_heads = {h for h, _ in otp}
            for _oid, vlcns in obj_map.items():
                _walk_btree_pages(f, ps, cs, tr, vlcns, visited, ptc)
            if btree_mode == "per-object":
                # one file per object OID (its tree pages concatenated)
                for oid_val, vlcns in obj_map.items():
                    ov = set(); op = []
                    _walk_btree_pages(f, ps, cs, tr, vlcns, ov, op)
                    blob = bytearray()
                    for head, plcns in op:
                        for p in plcns:
                            blob += rd(p)
                    emit(f"object_{oid_val:x}.btree", bytes(blob), f"OID 0x{oid_val:x} B+-tree", oid=oid_val)
            else:
                blob = bytearray(); idx = ["head_plcn,n_clusters,byte_offset,owner"]
                for head, plcns in ptc:
                    off = len(blob)
                    for p in plcns:
                        blob += rd(p)
                    owner = "object_table" if head in ot_heads else "metadata"
                    idx.append(f"0x{head:x},{len(plcns)},{off},{owner}")
                emit("metadata_pages.bin", bytes(blob), f"{len(ptc)} metadata pages (packed)")
                emit("metadata_index.csv", ("\n".join(idx) + "\n").encode(),
                     "index for metadata_pages.bin")

        with open(os.path.join(outdir, "manifest.json"), "w") as mf:
            _json.dump(manifest, mf, indent=2)
        sha_lines.append(f"{hashlib.sha256(_json.dumps(manifest, indent=2).encode()).hexdigest()}  manifest.json")
        with open(os.path.join(outdir, "sha256sums.txt"), "w") as sf:
            sf.write("\n".join(sha_lines) + "\n")
        print(f"\n  {len(manifest['artifacts'])} artifacts + manifest.json + sha256sums.txt → {outdir}")
        print("  Verify later with:  sha256sum -c sha256sums.txt")
        _report_extract_failures(_md_failures, outdir)   # audit 4.1
        return _bulk_hole_finish(outdir)
    finally:
        f.close()

def cmd_dataruns(image, remaining, partition_start):
    out_fmt, out_dest, remaining = _extract_output_fmt(remaining)
    args = _parse_args(remaining, flags=["-v", "--verbose"], valued=["--oid", "--depth"])
    verbose = args["v"] or args["verbose"]
    start_oid = _int_arg(args["oid"], "--oid", 0) if args["oid"] else 0x600
    max_depth = _int_arg(args["depth"], "--depth") if args["depth"] else DEFAULT_DEPTH

    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))

    try:
        if not out_fmt:
            print("=" * 78)
            print("ReFS File Data Extent Analysis")
            print("=" * 78)
            print(f"  Image:        {image}")
            print(f"  ReFS version: {vmaj}.{vmin}")
            print(f"  Cluster size: {_hx(cs)} ({cs} bytes)")
            print(f"  Containers:   {len(tr.map) if tr else 0}")
            print(f"  Start OID:    {_hx(start_oid)}")
            print()

        if start_oid not in obj_map:
            die(f"OID {_hx(start_oid)} not found in Object Table")

        total_files = 0
        total_resident = 0
        total_nonresident = 0
        total_with_extents = 0
        total_shared = 0
        total_sparse = 0
        all_results = []

        def process_dir(dir_oid, path, depth):
            nonlocal total_files, total_resident, total_nonresident, total_with_extents
            nonlocal total_shared, total_sparse
            results = _analyze_dir_extents(f, ps, cs, tr, obj_map, dir_oid)
            for info in results:
                total_files += 1
                full_path = f"{path}/{info['name']}" if path else info['name']
                info["path"] = full_path
                # E87: count by DATA residency, not by record placement. Keying these on `storage`
                # (which is the record's placement) reported every embedded record as "resident (inline)",
                # including the extent-backed ones -- 206 of 219 on one sample volume, one of them 440 KB.
                _r = info.get("data_residency")
                if _r == DATA_INLINE:
                    total_resident += 1
                elif _r == DATA_SNAPSHOT_SHARED:
                    total_shared += 1
                elif _r == DATA_SPARSE:
                    total_sparse += 1
                else:
                    total_nonresident += 1
                    if info["extents"]:
                        total_with_extents += 1
                all_results.append(info)
            if depth > 0:
                dir_rows = walk_bplus(f, ps, cs, tr, obj_map[dir_oid])
                for kd, vd in dir_rows:
                    if len(kd) >= 4 and le16(kd, 0) == 0x30 and len(vd) >= 0x44:
                        child_attrs = le32(vd, 0x40)
                        if child_attrs & 0x10000000:
                            child_oid = le64(vd, 0x08) if len(vd) >= 0x10 else 0
                            if child_oid and child_oid in obj_map:
                                child_name = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
                                child_path = f"{path}/{child_name}" if path else child_name
                                process_dir(child_oid, child_path, depth - 1)

        process_dir(start_oid, "", max_depth)

        if out_fmt:
            cols = ["path", "storage", "record_placement", "data_residency",
                    "file_size", "extent_count", "clusters", "extents"]
            recs = []
            for info in all_results:
                runs = info.get("extents") or []
                recs.append({
                    "path": info["path"],
                    # `storage` now reports DATA residency (inline / extents), which is what a reader of a
                    # data-run listing means by it. `record_placement` carries the other axis explicitly.
                    "storage": info.get("data_residency", info["storage"]),
                    "record_placement": info.get("record_placement", ""),
                    "data_residency": info.get("data_residency", ""),
                    "file_size": info.get("file_size", 0),
                    "extent_count": len(runs),
                    "clusters": sum(e["clusters"] for e in runs),
                    "extents": ";".join("fvcn=%d,VLCN=%s,PLCN=%s,clu=%d" % (
                        e["file_vcn"], _hx(e["vlcn"]), _hx(e["plcn"]), e["clusters"]) for e in runs),
                    "runs": [{"file_vcn": e["file_vcn"], "vlcn": e["vlcn"], "plcn": e["plcn"],
                              "clusters": e["clusters"], "disk_offset": e["disk_offset"]} for e in runs],
                })
            _emit_records(recs, cols, out_fmt, out_dest, "files")
            return 0

        print("  Summary:")
        print(f"    Total files analyzed:   {total_files}")
        print(f"    Data inline in record:  {total_resident}")
        print(f"    Data in extents:        {total_nonresident}")
        print(f"    With decoded extents:   {total_with_extents}")
        if total_shared:
            print(f"    Shared with a snapshot: {total_shared}")
        if total_sparse:
            print(f"    Unallocated (never written): {total_sparse}")
        print()

        print("=" * 78)
        print("File Data Locations")
        print("=" * 78)

        for info in all_results:
            _place = info.get("record_placement", "?")
            _res = info.get("data_residency")
            if _res == DATA_SNAPSHOT_SHARED:
                # W6: the live stream owns no allocation — its bytes are the snapshot's clusters. Saying
                # "stored in the record" here was wrong in both halves: they are neither inline nor this
                # stream's. `files` has reported this state since 1.10.0; dataruns now agrees.
                if verbose:
                    print(f"  SHARED    {info['path']}")
                    print(f"            size={info.get('file_size', 0)} — no clusters of its own; the bytes "
                          f"are owned by the snapshot this stream still shares (record is {_place})")
            elif _res == DATA_SPARSE:
                if verbose:
                    print(f"  UNALLOC   {info['path']}")
                    print(f"            size={info.get('file_size', 0)} — never written; no allocation and "
                          f"no snapshot to share (record is {_place})")
            elif _res == DATA_INLINE:
                if verbose:
                    print(f"  INLINE    {info['path']}")
                    print(f"            size={info['file_size']} (bytes stored in the record; "
                          f"record is {_place}) — no clusters")
            else:
                if info["extents"]:
                    total_ext_clusters = sum(e["clusters"] for e in info["extents"])
                    print(f"  EXTENT    {info['path']}")
                    print(f"            record={_place}, "
                          f"size={info.get('file_size',0)}, "
                          f"attrs={_attrs_to_str(info['file_attrs'], full=False)}, "
                          f"extents={len(info['extents'])}, "
                          f"clusters={total_ext_clusters}")
                    if info.get("timestamps"):
                        print(f"            created={_filetime_to_str(info['timestamps'][0]).replace(' UTC', '')}")
                    if verbose:
                        for ext in info["extents"]:
                            print(f"            run: fvcn={ext['file_vcn']} "
                                  f"VLCN={_hx(ext['vlcn'])} "
                                  f"PLCN={_hx(ext['plcn'])} "
                                  f"clusters={ext['clusters']} "
                                  f"disk={_hx(ext['disk_offset'])}")
                        src = info.get("extent_source", "?")
                        if src == "remote":
                            print(f"            (extents in remote OID {_hx(info.get('target_oid', 0))})")
                elif verbose:
                    print(f"  NOEXTENT  {info['path']}")
                    print(f"            record={_place}, size={info.get('file_size',0)} "
                          f"(extents not decoded — may be in remote OID {_hx(info.get('target_oid', 0))})")

        return 0

    finally:
        f.close()


SUBCOMMANDS = {
    "files":       "List files and directories (default). Identity is one `ObjectRef` column "
                   "(a directory's own OID, or a file's FileRef `HomeOID:FileID`); `HomeOID` is the "
                   "directory the file was CREATED in (formerly `CreationDirOID`), which a move does not change",
    "summary":     "Extended volume summary — full directory walk + all metrics",
    "search":      "Search files/directories by name (PATTERN; add --regex)  [alias: find]",
    "details":     "All attributes for one object — a file by /path, a directory/system object by /path or 0xOID (/path | 0xOID | --path | --oid)",
}
# Still callable + documented (`fastsummary --help`), but hidden from --list/overview to reduce option
# overload — `summary` is a strict content superset. (Q7.)
HIDDEN_SUBCOMMANDS = {
    "fastsummary": "Extended quick summary — volume metrics, no directory walk (hidden alias of a fast summary)",
}
# Command-token aliases resolved to their canonical name at dispatch (Phase 0). Nothing is removed — the
# canonical spellings keep working; these are friendlier / clearer synonyms.
SUBCOMMAND_ALIASES = {
    "find": "search",       # friendlier name for the name search
    "snapshot": "snapshots", # singular convenience alias for the analysis command (distinct from `export snapshot`)
    # Phase 3 (4.B): silent singular/plural conveniences — the canonical spellings keep working.
    "file": "files",
    "special": "specials",
    "datarun": "dataruns",
    "recycle": "recyclebin",
}
# ─── Export umbrella (Q8 + the user's "export command" idea) — one home for "get data out" ────────
def _safe_relpath(path):
    """Turn a stored '/dir/sub/file' path into a safe on-disk relative name."""
    parts = [p for p in path.replace("\\", "/").split("/") if p and p not in (".", "..")]
    return os.path.join(*[_safe_filename(p) for p in parts]) if parts else "unnamed"   # faithful sanitizer per path segment

def cmd_export_resident(image, remaining, partition_start):
    """export resident-all <dir>: write every RESIDENT file's inline $DATA (and snapshot-shared resident content)
    to <dir>, preserving the directory tree. Reuses the same content path as `extract` (get_resident_data_content
    / recover_cow_current_content); skips 0-byte and non-inline entries."""
    args = _parse_args(remaining, flags=["--refuse-holes"], valued=["--oid", "--depth"])
    global _REFUSE_HOLES
    _REFUSE_HOLES = bool(args["refuse_holes"])
    out_dir = args["_rest"][0] if args["_rest"] else None
    if not out_dir:
        die("export resident-all requires an output directory")
    start_oid = _int_arg(args["oid"], "--oid", 0) if args["oid"] else 0x600
    max_depth = _int_arg(args["depth"], "--depth") if args["depth"] else DEFAULT_DEPTH
    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))
    try:
        os.makedirs(out_dir, exist_ok=True)
        written = 0; skipped = 0; _res_failures = []   # audit 4.1
        def walk(dir_oid, path, depth):
            nonlocal written, skipped
            for info in _analyze_dir_extents(f, ps, cs, tr, obj_map, dir_oid):
                if info.get("storage") != "resident":
                    continue
                _hm = len(_CONTENT_HOLES)
                content = info.get("resident_content")
                if content is None:
                    content = info.get("cow_content")
                    if content is not None:
                        # Same reason as cmd_extract's CoW branch: the walk precomputes this WITHOUT the
                        # hole check (it would cost syscalls for every file, most of which are never
                        # written). These bytes ARE written, so repeat the recovery once with the check on.
                        _re = recover_cow_current_content(f, ps, cs, tr, info.get("raw_value", b""),
                                                          _content_what=f"resident file '{info['name']}'")
                        if _re is not None:
                            content = _re
                if content is None or len(content) == 0:
                    skipped += 1; continue
                rel = _safe_relpath(f"{path}/{info['name']}" if path else info["name"])
                dest = os.path.join(out_dir, rel)
                if _guarded_extract_write(dest, content, _res_failures, holes_mark=_hm,
                                          what=f"resident file '{info['name']}'"):   # audit 4.1 (also creates the subdir)
                    written += 1
            if depth > 0:
                for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[dir_oid]):
                    if len(kd) >= 4 and le16(kd, 0) == 0x30 and len(vd) >= 0x44 and (le32(vd, 0x40) & 0x10000000):
                        child = le64(vd, 0x08) if len(vd) >= 0x10 else 0
                        if child and child in obj_map:
                            nm = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
                            walk(child, f"{path}/{nm}" if path else nm, depth - 1)
        if start_oid not in obj_map:
            die(f"OID {_hx(start_oid)} not found")
        walk(start_oid, "", max_depth)
        print(f"[{PROG}] export resident-all: wrote {written} file(s) with inline $DATA to {out_dir} "
              f"({skipped} skipped: 0-byte or non-inline). source: inline $DATA / snapshot-shared.",
              file=sys.stderr)
        _report_extract_failures(_res_failures, out_dir)   # audit 4.1
        return _bulk_hole_finish(out_dir)
    finally:
        f.close()

def cmd_export_recyclebin(image, remaining, partition_start):
    """export recyclebin <dir>: write each surviving $R payload from $RECYCLE.BIN to <dir>, named by its
    decoded original filename ($I). Reuses the recyclebin walk + the resident/extent content path."""
    args = _parse_args(remaining, flags=["--refuse-holes"], valued=[])
    global _REFUSE_HOLES
    _REFUSE_HOLES = bool(args["refuse_holes"])
    out_dir = args["_rest"][0] if args["_rest"] else None
    if not out_dir:
        die("export recyclebin requires an output directory")
    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(image, partition_start)
    except (ValueError, OSError) as e:
        die(str(e))
    try:
        recycle_oid = None
        if 0x600 in obj_map:
            for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[0x600]):
                if len(kd) >= 4 and le16(kd, 0) == 0x30 and len(vd) >= 0x10 and \
                        kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00") == "$RECYCLE.BIN":
                    recycle_oid = le64(vd, 0x08); break
        if recycle_oid is None:
            print(f"[{PROG}] no $RECYCLE.BIN on this volume", file=sys.stderr)
            return _bulk_hole_finish(out_dir)
        recs = []
        _walk_recycle(f, ps, cs, tr, obj_map, recycle_oid, "", 8, recs)
        os.makedirs(out_dir, exist_ok=True)
        written = 0; _rb_failures = []   # audit 4.1
        # map $R name -> its content by walking each SID dir's $R rows through _analyze_dir_extents
        r_content = {}
        def collect(dir_oid, sid):
            for info in _analyze_dir_extents(f, ps, cs, tr, obj_map, dir_oid):
                if info["name"].startswith("$R"):
                    # SHARED reader: resident inline / CoW / inline-holder / type-0x40 extents, placed by
                    # file_vcn (correct for sparse/gapped files — the old inline append was wrong there) and
                    # length-safe. This is how a NON-RESIDENT $R payload (ReFS 3.4) is now recovered.
                    _hm = len(_CONTENT_HOLES)
                    c, _m = get_file_content(f, ps, cs, tr, info,
                                             _content_what="recycled file %s" % info["name"])
                    if c:
                        r_content[(sid, info["name"])] = (c, _hm)   # mark travels with the bytes
            for kd, vd in walk_bplus(f, ps, cs, tr, obj_map[dir_oid]):
                if len(kd) >= 4 and le16(kd, 0) == 0x30 and len(vd) >= 0x44 and (le32(vd, 0x40) & 0x10000000):
                    child = le64(vd, 0x08) if len(vd) >= 0x10 else 0
                    if child and child in obj_map:
                        nm = kd[4:].decode("utf-16-le", errors="replace").rstrip("\x00")
                        collect(child, sid or nm)
        collect(recycle_oid, "")
        for r in recs:
            _got = r_content.get((r["sid"], r["r_name"]))
            if _got is None:
                continue
            content, _hm = _got
            orig = r["meta"]["original_path"] if r.get("meta") else r["r_name"]
            dest = os.path.join(out_dir, _safe_relpath(orig.replace("\\", "/").split("/")[-1] or r["r_name"]))
            if _guarded_extract_write(dest, content, _rb_failures, holes_mark=_hm,
                                      what="recycled file %s" % r["r_name"]):   # audit 4.1
                written += 1
        _report_extract_failures(_rb_failures, out_dir)   # audit 4.1
        print(f"[{PROG}] export recyclebin: wrote {written} recovered payload(s) to {out_dir}.", file=sys.stderr)
        return _bulk_hole_finish(out_dir)
    finally:
        f.close()

# `snapshots` is the primary name for extracting stream snapshots (0xB0, storage_type≠0, sub_id≥0x1000 —
# true CoW snapshot versions). `snapshot` and the older `prior-versions` are kept as aliases.
def cmd_export_reparse(image, remaining, partition_start):
    """export reparse [--json] [-o FILE]: the reparse-point inventory (decoded targets/tags/kind). Prints the
    human-readable TEXT view by default (same as the `reparse` command); add --json for the machine-readable
    form. Reparse data is metadata, not bulk content, so it prints to the screen (add -o FILE to save)."""
    args = _parse_args(remaining, flags=["--json"], valued=["-o", "--output"])
    outp = args["o"] or args["output"]
    inner = ["--json"] if args["json"] else []
    fmt = "JSON" if args["json"] else "text"
    if outp:
        _check_out(outp)
        with open(outp, "w") as fh:
            _old = sys.stdout
            sys.stdout = fh
            try:
                cmd_reparse(image, inner, partition_start)
            finally:
                sys.stdout = _old
        print(f"[{PROG}] reparse inventory ({fmt}) written to {outp}", file=sys.stderr)
        return 0
    rc = cmd_reparse(image, inner, partition_start)
    print(f"[{PROG}] (reparse inventory above, {fmt} — add `--json` for machine-readable, `-o FILE` to save)", file=sys.stderr)
    return rc

def _auto_export_dir(what):
    """Timestamped output dir for a bulk export when the user omits one (Q2 UX: bulk content can't go to the
    screen, so land it in a predictable folder instead of erroring). Named forefst_export_<what>_<stamp>."""
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"forefst_export_{what}_{stamp}"

# subverbs that write into a DIRECTORY (bulk); file/ads/reparse/metadata print to stdout or -o instead.
_EXPORT_BULK = ("resident-all", "snapshots", "snapshot", "prior-versions", "deleted", "recyclebin")
_EXPORT_SUBVERBS = ("file", "ads", "reparse", "resident-all", "snapshots", "snapshot", "prior-versions",
                    "deleted", "recyclebin", "metadata")
def cmd_export(image, remaining, partition_start):
    """export <what> — one home for getting data out. Subverbs: file <path> · ads <path:stream> · reparse ·
    resident-all [dir] · snapshots [dir] · deleted [dir] · recyclebin [dir] · metadata [-o dir]. A bulk
    subverb with NO directory auto-creates a timestamped one; `extract …` = `export file`; bare `export -o
    DIR` = `export metadata`; `snapshot`/`prior-versions` alias `snapshots`."""
    # §5: accept a leading `--<verb>` as a flag-equivalent of the positional subverb (e.g. `export --recyclebin
    # DIR` == `export recyclebin DIR`).
    if remaining and remaining[0].startswith("--") and remaining[0][2:] in _EXPORT_SUBVERBS:
        remaining = [remaining[0][2:]] + remaining[1:]
    if remaining and remaining[0] in _EXPORT_SUBVERBS:
        what, rest = remaining[0], remaining[1:]
        if what in ("file", "ads"):
            return cmd_extract(image, rest, partition_start)
        if what == "reparse":
            return cmd_export_reparse(image, rest, partition_start)
        if what == "metadata":
            return cmd_export_metadata(image, rest, partition_start)
        # bulk (directory) subverbs. The output dir is the FIRST bare positional; we skip the VALUE of a
        # valued flag (e.g. `--max-scan 6000`) so 6000 is not mistaken for the dir. If the user gave NO dir,
        # auto-create a timestamped one (Q2 UX) instead of erroring — bulk content cannot go to the screen.
        _VALUED = {"--search", "--max-scan", "--file", "--depth", "--oid", "--snapshot"}
        out_idx, skip = None, False
        for i, a in enumerate(rest):
            if skip:
                skip = False; continue
            if a in _VALUED:
                skip = True; continue
            if not a.startswith("-"):
                out_idx = i; break
        if out_idx is None:
            out_dir = _auto_export_dir(what)
            passthrough = list(rest)
            print(f"[{PROG}] no output directory given — writing to ./{out_dir}/", file=sys.stderr)
        else:
            out_dir = rest[out_idx]
            passthrough = rest[:out_idx] + rest[out_idx + 1:]
        if what == "resident-all":
            return cmd_export_resident(image, [out_dir] + passthrough, partition_start)
        if what == "recyclebin":
            return cmd_export_recyclebin(image, [out_dir] + passthrough, partition_start)
        if what in ("snapshots", "snapshot", "prior-versions"):
            return cmd_snapshots(image, ["--extract", out_dir] + passthrough, partition_start)
        if what == "deleted":
            return cmd_deleted(image, ["--extract", out_dir, "--_from-export"] + passthrough, partition_start)
    # Help-on-empty (4.C): a bare `export` (nothing to do) shows its help instead of erroring.
    if not remaining:
        _render_cmd_help("export")
        return 0
    # no recognized subverb (or a bare -o …) => the metadata bundle (back-compat with the old `export`)
    return cmd_export_metadata(image, remaining, partition_start)

# The two weakest results: both infer from heuristics over sources of differing reliability, so they are
# listed last, under their own heading, and labelled experimental wherever they are described.
EXPERIMENTAL_SUBCOMMANDS = ("timeline", "timestomp")

# Delegated forensic subcommands (Phase 2) — own option parsing; routed before argparse.
FORENSIC_SUBCOMMANDS = {
    "usn":       "USN (Change) Journal parser — file change records (-v/--stats/--json/--info/--csv FILE)",
    "mlog":      "MLog (durable log) parser — redo records and transactions (-v/--parse/--stats/--json/--raw-scan/--info)",
    "timeline":  "Super-timeline (experimental) — merge USN + MLog + $SI MACB, sorted by time (--csv/--no-si/--file/--oid/--limit/--source/--depth)",
    "timestomp": "Timestamp-anomaly detection (experimental) — $SI MACB vs USN, flags back-dating (--all/--json/--csv/--min/--margin-days/--depth)",
    "extract":   "Extract a file's content to stdout — by full path (direct, any depth) or bare name (first match; --oid/--depth scope the name search)",
    "security":  "Security descriptors / ACLs per object (-v/--files/--json/--audit/--sid/--file)",
    "specials":  "Special-attribute files — ads/reparse/wsl/hardlink/sparse/encrypted/compressed/integrity/ea/snapshot (specials [type|all]; --csv/--json/--jsonl)",
    "ads":       "Named data streams (ADS) across the volume — shortcut for `specials ads` (--csv/--json/--jsonl; extract via export ads)",
    "reparse":   "Reparse points — symlinks/junctions/WSL + the reparse index (-v/--index/--json/--tag/--file)",
    "deleted":   "Deleted-file VIEW + recoverability verdict — `recovery` mode by default; `--full` for the complete scan (write with `export deleted`)",
    "recyclebin": "Decode $RECYCLE.BIN $I metadata — original path, deletion time, size, $R payload (--json)",
    "snapshots": "Stream snapshots (CoW versions) — list / preview / extract (-v/--json/--show/--extract)",
    "integrity": "Verify metadata-page checksums (-v/--checksums/--fullchecksums)",
    "export":    "Get data out — export file|ads|reparse|resident-all|snapshots|deleted|recyclebin|metadata (screen or -o/auto-dir)",
    "dataruns":  "File data extents / data-runs per object (-v/--oid/--depth)",
}
FORENSIC_HANDLERS = {"usn": cmd_usn, "mlog": cmd_mlog, "timeline": cmd_timeline,
                     "timestomp": cmd_timestomp, "extract": cmd_extract, "security": cmd_security,
                     "reparse": cmd_reparse, "deleted": cmd_deleted, "snapshots": cmd_snapshots,
                     "recyclebin": cmd_recyclebin, "specials": cmd_specials, "ads": cmd_ads,
                     "integrity": cmd_integrity, "export": cmd_export, "dataruns": cmd_dataruns}

# F13: `files --filter <category>` subsets the listing by attribute category (folds in / retires the
# old `attributes` command). Field-based and EA-SAFE — WSL is detected via the reparse tag, NOT the
# EA-derived lx_mode. Output stays forefst's normal files CSV/JSON, just the matching rows.
# `files --filter <type>` predicates. The 10 types that also exist as `specials <type>` DELEGATE to the
# single SPECIALS_TYPES definition (via _SPECIALS_BY_NAME) so the two commands share one predicate (D2).
# For the counts to match, BOTH must apply that predicate over the SAME row set — the full walked tree,
# files AND directories (cmd_specials must NOT pre-filter directories, or dir-carried reparse/integrity/EA
# would silently drop out). The 2 view-only types (directory/resident) have no `specials` equivalent and
# live here. Deleted files are not part of the live `files` listing — use the `deleted` command.
FILE_FILTERS = {name: pred for name, _desc, pred in SPECIALS_TYPES}
FILE_FILTERS.update({
    "directory":  lambda r: bool(r.get("is_dir")),
    # DATA RESIDENCY (E87). `inline` is the current name; `resident` is kept as an accepted
    # alias for one release. Both now select on the same thing the `DataResidency` column
    # reports -- previously this filter read the internal placement/residency hybrid flag, so
    # it could disagree with the column beside it.
    "inline":     lambda r: _data_residency(r) == DATA_INLINE,
    "resident":   lambda r: _data_residency(r) == DATA_INLINE,   # alias, one release
})
VERSION_NOTE = ("Mainly validated on ReFS 3.14. All versions 3.4-3.14 parse, but some enriched fields "
                "(e.g. non-resident symlink targets) may be incomplete on 3.4-3.10.")

# ── Hand-written per-command help ────────────────────────────────────────────
# Each entry: tagline, a short description, the option list (flag, help), and runnable examples.
# Rendered by `forefst <image> <cmd> --help` / `forefst help <cmd>`; the option text mirrors what the
# command actually parses. Global format flags shared by the native commands: --json/--jsonl/--body/-o.
GLOBAL_HELP = ("Native subcommands (files/summary/fastsummary/search/details) take -o/--output FILE, "
               "--json, --jsonl, --body, -q/--quiet (silence stderr progress). --partition-start BYTES "
               "works on any subcommand; each forensic subcommand has its own flags (see its --help).")

CMD_HELP = {
 "files": {
  "tag": "List files and directories (the default subcommand) as enriched rows",
  "desc": ["Walks the directory B+-tree from the root object (OID 0x600) and emits one row per file/",
           "directory: timestamps, attributes, owner+group SID, ADS, EA, reparse, integrity,",
           "compression, encryption, hard-link names & counts, snapshot counts, USN, allocated size,",
           "IsSparse. Leads with the identity columns: OID (0 for files — ReFS files have no own OID),",
           "FileRef (=HomeOid:FileId, the stable 128-bit file reference == the USN FileReferenceNumber),",
           "HomeOid (the owner directory = the FileId 'home', constant across a file's hard-link names),",
           "FileId, FileName, then ParentOID/ParentPath (the namespace of THIS name — differs from HomeOid",
           "for hard-links & recycle-bin/deleted entries) and FullPath. The ReFS equivalent of an MFT",
           "listing/bodyfile. Default output is a 39-column CSV (OID..InternalFlags)."],
  "opts": [("--csv | --json | --jsonl [FILE]", "machine output (default CSV); bare → stdout, +FILE → write & print a count"),
           ("--body [FILE]", "bodyfile (mactime) output instead of CSV; bare \u2192 stdout, +FILE \u2192 write to FILE"),
           ("--filter CATEGORY", "keep only one category: reparse, encrypted, compressed, integrity, ea,"),
           ("", "ads, wsl, sparse, snapshot, directory, resident, hardlink"),
           ("--cow-before IMAGE", "recover prior CoW versions by diffing against an earlier image"),
           ("", "flags read TIER:SIGNAL — HIGH = authoritative (a hard-link sibling keeps the true"),
           ("", "birth); MEDIUM/LOW are $SI heuristics that also fire on timestamp-preserving copies"),
           ("--depth N", "cap directory recursion depth (default: full)"),
           ("-q, --quiet", "suppress stderr progress")],
  "ex": [("files --csv listing.csv", "full CSV file listing to a file"),
         ("files --filter hardlink", "only entries with more than one hard link"),
         ("files --filter ea --json", "non-resident & resident EA-bearing files as JSON"),
         ("files --body timeline.body", "bodyfile of the live tree (mactime); deleted files → `deleted`")],
 },
 "summary": {
  "tag": "Full volume triage report (identity + integrity + content census)",
  "desc": ["One-shot triage: volume identity (version, GUID/label, cluster/container size, checksum",
           "type), anchoring VBR/SUPB/CHKP hashes, on-disk state (original/upgraded/native), the 13",
           "root-table row counts, USN-journal status + UsnJournalId, then a full directory walk for",
           "file/dir/resident counts, total size, MACB extremes, and encrypted/integrity/compressed/",
           "hard-link/snapshot/ADS tallies. Extended-by-default."],
  "opts": [("--json [FILE]", "emit one JSON object instead of the text report (bare → stdout, +FILE → write & count)"),
           ("--hash-image", "also SHA-256 the whole image (chain-of-custody; streams the image)"),
           ("--depth N", "cap the content-census recursion depth (default: full — the whole tree)"),
           ("-q, --quiet", "suppress stderr progress")],
  "ex": [("summary", "full text triage report"),
         ("summary --json", "same data as one JSON object for jq/pipelines"),
         ("summary --hash-image", "add a full-image SHA-256 for evidence integrity")],
 },
 "fastsummary": {
  "tag": "Fast volume profile — metrics only, no directory walk",
  "desc": ["Everything `summary` reports about volume identity, layout, root-table counts and anchoring",
           "hashes, but WITHOUT the directory walk — so it returns in seconds on large images. Use it",
           "to triage before committing to a full `files`/`summary` pass."],
  "opts": [("--json [FILE]", "emit one JSON object instead of the text report (bare → stdout, +FILE → write & count)"),
           ("--hash-image", "also SHA-256 the whole image"),
           ("-q, --quiet", "suppress stderr progress")],
  "ex": [("fastsummary", "fast volume profile"),
         ("fastsummary --json", "machine-readable profile"),
         ("fastsummary --hash-image --json", "profile + full-image SHA-256")],
 },
 "search": {
  "tag": "Find files/directories by name",
  "desc": ["Case-insensitive substring match on the file/directory name across the whole tree (add",
           "--regex for a Python regex against the basename). Prints a table by default."],
  "opts": [("PATTERN", "(positional) the name substring, or regex with --regex"),
           ("--regex", "treat PATTERN as a case-insensitive regular expression"),
           ("--filter CATEGORY", "keep only one category: reparse, encrypted, compressed, integrity, ea,"),
           ("", "ads, wsl, sparse, snapshot, directory, resident, hardlink"),
           ("--csv | --json | --jsonl [FILE]", "emit matches as CSV / JSON / JSON Lines (bare → stdout, +FILE → write & count)"),
           ("-q, --quiet", "suppress stderr progress")],
  "ex": [("search report", "names containing 'report'"),
         ("search '^link\\d+_to' --regex", "regex on the basename"),
         ("deleted --search secret", "search deleted objects → use the `deleted` command")],
 },
 "details": {
  "tag": "All attributes for ONE object — files by /path, directory/system objects by /path or 0xOID",
  "desc": ["Full record for a single file, directory or object: timestamps, attributes (incl. EA),",
           "SecurityId/owner, USN, reparse target, and — for resident files — the inline sub-records",
           "($DATA, ADS, $EA/WSL metadata, snapshots). Address a file by /path; a directory or system object by /path or 0xOID (files have no OID)."],
  "opts": [("/path", "(positional) e.g. /dir/file.txt — a leading slash means path"),
           ("0xOID", "(positional) e.g. 0x705 — a 0x prefix means OID"),
           ("--path P", "address by path (e.g. /dir/file.txt)"),
           ("--id ID", "address by identity: an OID (0x703) or a FileRef HomeOID:FileID (0x703:0x2e)"),
           ("", "aliases: --OID, --FileRef, --oid — all mean --id"),
           ("--json [FILE]", "the full record as JSON — for a directory, its on-disk structure"),
           ("--csv | --jsonl [FILE]", "one row in the `files` schema (same columns, so it concatenates)")],
  "ex": [("details /wsltests/lxsymlink", "inspect a reparse/WSL file by path"),
         ("details 0x705", "inspect a directory object by OID"),
         ("details --FileRef 0x703:0x2e", "address a file by its reference — no path needed"),
         ("details /dir/file.txt --json", "machine-readable full record"),
         ("details /dir/file.txt --csv", "one row in the `files` column schema")],
 },
 "usn": {
  "tag": "USN (Change) Journal — file change records",
  "desc": ["Parses the $UsnJrnl:$J change journal: per-record USN, timestamp, reason flags, resolved name,",
           "and the file reference FileRef = home_oid:file_id (== files.FileRef; home_oid is the containing",
           "directory for a file / the object's own OID for a directory, file_id the per-home ordinal).",
           "entry_type is dir when file_id==0 (a directory self-reference) else file. Directories DO get USN",
           "records. Bare `usn` shows the activity SUMMARY (like `mlog`); `usn --list` prints the on-screen",
           "record list; --csv/--json export the records; --info shows journal health.",
           "The whole journal is read: $J is a bounded rolling log that fills its allocation, so every",
           "allocated extent is parsed (a file's `files`/`details` USN = its LastUsn, the byte offset of its",
           "most recent record here — resolvable while that record is still inside the live window)."],
  "opts": [("--list", "print the on-screen per-record list (formerly the bare-usn default)"),
           ("-v, --verbose", "with --list: add RecLen/Version/StreamOffset per record"),
           ("--info", "journal metadata instead of records ($J extents, $Max, record count)"),
           ("--stats", "activity summary (this is also what bare `usn` shows)"),
           ("--csv/--json [FILE]", "machine output to stdout or FILE; CSV cols incl. entry_type/file_ref/"
                                   "home_oid/file_id (security_id/source_info/parent_idx are 0, kept last)")],
  "ex": [("usn", "list every change record"),
         ("usn --info", "journal layout & health"),
         ("usn --stats", "reason-code & busiest-file summary"),
         ("usn --csv usn.csv", "export records to CSV")],
 },
 "mlog": {
  "tag": "MLog (durable transaction log) — redo records & concrete actions",
  "desc": ["Parses the durable logfile: control header, data-area page census, and the redo records.",
           "--parse groups the low-level redo opcodes of each transaction into a CONCRETE ACTION and",
           "resolves the object. MOVE vs RENAME is decided by FACT — the parent-directory OID of the old",
           "name entry vs the new one (same parent = RENAME, changed = MOVE, shown as 'parent 0x.. -> 0x..').",
           "DELETE is only reported when the object's own table is destroyed (RedoDeleteTable); a bare row",
           "removal is ENTRY_REMOVE, and a reparent record that can't be resolved to move-or-rename is",
           "REPARENT. Actions are grouped into file operations (CREATE/WRITE/RENAME/MOVE/DELETE) vs the",
           "low-level B+-tree/metadata records that accompany them. -v prints each redo record with its",
           "opcode, target OID and PLCN+offset so every field is verifiable against the raw disk bytes.",
           "NOTE: this is the DURABLE LOG — operations here may not yet be checkpointed into the committed",
           "tree, so `files`/`summary` can omit recent activity shown here (and vice-versa). The per-record",
           "'commit' flag is 0 on every volume (commit is a checkpoint/LogCore fact, not a redo-record flag).",
           "--stats also RECOMPUTES each record's own 8-byte integrity value the way the driver does before",
           "replaying it, so a torn or byte-edited record is reported instead of being parsed silently. It is",
           "an integrity check, not a signature: it catches damage and edits, it is not proof of authenticity.",
           "Cost is proportional to the log size (about 8 s on a 512 MiB log, well under 1 s on a typical one)."],
  "opts": [("-v, --verbose", "byte-level proof: each redo record as opcode/name/target_oid/@PLCN+offset/key"),
           ("--parse", "reconstruct concrete actions (CREATE/WRITE/RENAME/MOVE/DELETE + low-level groups)"),
           ("--stats", "record-integrity check + opcode-frequency section"),
           ("--raw-scan", "per-page raw dump instead of the data-area summary"),
           ("--info", "static opcode/action reference text only"),
           ("--csv FILE", "export transactions (action + opcodes + oid + plcn) to CSV"),
           ("--json", "emit version/control/mlog_info/data_area/integrity/records as JSON")],
  "ex": [("mlog", "control header + page census + redo counts"),
         ("mlog --parse", "concrete file operations + low-level records, with MOVE/RENAME parent OIDs"),
         ("mlog --parse -v", "same, plus the per-record byte-level proof (opcode/OID/@PLCN+offset)"),
         ("mlog --stats", "record-integrity verdict + opcode/category frequency"),
         ("mlog --csv mlog_txns.csv", "export the action timeline")],
 },
 "timeline": {
  "tag": "Super-timeline (experimental) — merge USN + MLog + $SI MACB, time-sorted",
  "desc": ["EXPERIMENTAL / informational: a corroborative reconstruction, not an authoritative log — the",
           "correlation is heuristic (identity/name + time) and coverage depends on which journals are active",
           "(USN is off by default; the MLog is a shallow circular buffer). Cross-check leads against the",
           "underlying artifacts rather than treating this as a standalone source of truth.",
           "Merges three event sources (USN journal, MLog transactions, $SI MACB timestamps) into one",
           "chronological timeline. --fast/--no-si skips the slow per-file $SI walk (USN+MLog only)."],
  "opts": [("--fast / --no-si", "skip the $SI MACB walk (USN + MLog only — much faster)"),
           ("-v, --verbose", "show the FULL name/path per event (no truncation)"),
           ("--csv/--json/--jsonl [FILE]", "machine output (timestamp_utc,source,oid,name,event); to stdout, "
                                           "or to FILE (prints a record count)"),
           ("--source S", "keep only one source: USN / MLOG / SI"),
           ("--file SUB", "keep events whose name/path contains SUB"),
           ("--oid O", "keep only events for object O (0x hex or decimal)"),
           ("--limit N", "keep only the first N events after filtering+sorting"),
           ("--depth N", "cap the $SI-walk recursion depth (default: full)")],
  "ex": [("timeline --fast --limit 50", "first 50 USN+MLog events (quick)"),
         ("timeline --csv > timeline.csv", "full super-timeline as CSV"),
         ("timeline --file hello.txt", "all events touching hello.txt"),
         ("timeline --source USN --oid 0x701", "one object's USN history")],
 },
 "timestomp": {
  "tag": "Timestamp-anomaly detection — experimental/informational, not proof",
  "desc": ["Flags timestamps that LOOK anomalous (investigative INFORMATION, NOT proof of tampering). Each",
           "row shows a BASIS: an AUTHORITATIVE signal (USN journal FILE_CREATE / BASIC_INFO_CHANGE, or the",
           "ReFS-native HARDLINK_MACB_MISMATCH where two names of one file have divergent Created — only the",
           "back-dated name is flagged, the sibling keeps the true birth) vs a HEURISTIC $SI-only signal",
           "(CHANGE_LATE / PRE_FORMAT / CREATE_GT_MODIFY / FUTURE) that also fires on legitimate timestamp-",
           "preserving copies. HIGH requires an AUTHORITATIVE source (the journal, or a hard-link sibling) --",
           "a count of heuristic signals never reaches it. MEDIUM is CHANGE_LATE without PRE_FORMAT, or FUTURE.",
           "INFO means every signal present is one a timestamp-preserving copy also produces, so a copy and a",
           "backdate cannot be told apart however many fire. The `files --timestomp` column shows only the $SI",
           "heuristic; this subcommand adds the authoritative checks. The screen view defaults to HIGH-confidence",
           "rows; --min reveals lower tiers; CSV/JSON keep ALL tiers unless --min is given. ROUND_TIMESTAMPS",
           "(whole-second created AND modified) never lifts a tier on its own."],
  "opts": [("--all", "include every file, even those with no anomaly (NONE tier)"),
           ("--min LEVEL", "lowest confidence to show on screen: HIGH | MEDIUM | LOW (default HIGH; CSV/JSON "
                           "export every tier unless this is set)"),
           ("--margin-days N", "tolerance (days) when comparing two timestamps before calling a difference an "
                               "anomaly (default 1). Larger N = fewer flags (fewer false positives, may miss "
                               "small back-dates); smaller N = more sensitive."),
           ("--csv/--json [FILE]", "machine output to stdout or FILE (every tier)"),
           ("--depth N", "max recursion depth (default: full)")],
  "ex": [("timestomp", "HIGH-confidence suspects (add --min LOW for all)"),
         ("timestomp --min HIGH", "high-confidence suspects only"),
         ("timestomp --csv suspects.csv --min MEDIUM", "export medium+ suspects")],
 },
 "extract": {
  "tag": "Extract a file's content (or one ADS) to stdout",
  "desc": ["Recovers a file's bytes and writes them to stdout (redirect to a file): non-resident files from",
           "their extents (inline or separate), RESIDENT files from their inline $DATA, and CoW resident files",
           "unmodified since a snapshot from the shared latest-snapshot blocks. Address by bare name, absolute",
           "/path, or --path; use name:stream for an inline ADS. (Large overflow extent maps: use `dataruns`.)",
           "A full PATH is resolved directly (component by component from the root) — no depth limit, so a file",
           "at any depth is found instantly. A BARE NAME is searched across the tree (to --depth) and the FIRST",
           "match is extracted — pass the full path to pick a specific file when the name is not unique.",
           "On integrity-stream files (v3.14, 4K clusters, CRC32-C) each cluster's stored CRC32-C is verified",
           "against the recovered bytes and reported; a mismatch (corruption/tampering) is flagged but the",
           "bytes are still written (disable with --no-verify-integrity).",
           "Raw images are stored sparsely, and a sparse image stores a file's OWN zero content the same way",
           "it stores a range that was never captured: as a hole. So a hole is not evidence that data is",
           "missing. When any byte of a file comes from a hole, extract WRITES the bytes, reports which",
           "ranges they came from and exits 2; with -o it also writes FILE.holes.json listing them. Expect",
           "this often on a sparse image — rc 2 here means read the note, not that something is wrong.",
           "Use --refuse-holes for a strict run: same report, nothing written."],
  "opts": [("filename | /path", "(positional) the file to extract (full path = direct, no depth limit)"),
           ("--path P", "address the file by path (symmetric with details; resolved directly, no depth limit)"),
           ("--id HomeOid:FileId", "address the file by its reference (e.g. 0x760:0xc) — no path needed "
                                   "(recycle-bin/$-name/duplicates); == the usn FileRef"),
           ("--oid O", "re-root a BARE-NAME search at object O (0x hex or decimal)"),
           ("--depth N", "max depth for a BARE-NAME search (default: full; a full path ignores this)"),
           ("--no-verify-integrity", "skip the per-cluster CRC32-C integrity check on integrity-stream files"),
           ("--refuse-holes", "strict: report hole-sourced ranges and write nothing (default writes them)")],
  "ex": [("extract /specials/gamma.bak > out.bak", "carve a file by absolute path (any depth)"),
         ("extract report.dat:hidden_6247 > s.bin", "extract one inline ADS"),
         ("extract deep.log --oid 0x73c", "scope a bare-name search to a subtree")],
 },
 "security": {
  "tag": "Security descriptors / ACLs per object",
  "desc": ["Lists each security descriptor (owner, group, control flags, DACL/SACL ACEs). --files maps",
           "every file to its SecurityId+owner; --audit recomputes each descriptor's stored self-hash (the",
           "hash ReFS keeps in the $Secure/security table) and flags any mismatch — i.e. a security descriptor",
           "whose bytes were altered on disk without the hash being updated (tampering)."],
  "opts": [("-v, --verbose", "include the raw SD hex dump (list / --sid mode)"),
           ("--files", "map every file/dir to its SecurityId and owning SID"),
           ("--file SUB", "like --files, filtered to names containing SUB"),
           ("--sid ID", "print only the descriptor for SecurityId ID (0x hex or decimal)"),
           ("--audit", "tamper check: recompute each descriptor's stored self-hash; flag any mismatch"),
           ("--json", "machine-readable output")],
  "ex": [("security", "list all security descriptors"),
         ("security --files", "map files to owners"),
         ("security --audit", "verify SD hashes (tamper check)"),
         ("security --sid 0x1db3cc93d -v", "one descriptor + raw hex")],
 },
 "reparse": {
  "tag": "Reparse points — symlinks/junctions/WSL + the reparse index",
  "desc": ["Audits reparse points: walks the tree for files with the REPARSE_POINT attribute and decodes",
           "each buffer (tag, target, WSL UID/GID/mode). --index dumps the reparse index object (0x540)."],
  "opts": [("-v, --verbose", "include the raw reparse-buffer hex / index key bytes"),
           ("--index", "switch to the reparse INDEX view (OID 0x540) keyed by tag"),
           ("--tag T", "filter to one reparse tag (0x hex or decimal)"),
           ("--file SUB", "default mode: filter to names containing SUB"),
           ("--json", "machine-readable output")],
  "ex": [("reparse", "list all reparse points + decoded targets"),
         ("reparse --index -v", "dump the reparse index with raw keys"),
         ("reparse --tag 0xa000000c --json", "only IO_REPARSE_TAG_SYMLINK, as JSON")],
 },
 "deleted": {
  "tag": "Deleted-file VIEW + recoverability verdict (writing = `export deleted`)",
  "desc": ["Read-only view of deleted entries with a recoverability verdict. TWO MODES:",
           "  • `deleted`         — RECOVERY (default): Trash table (0xD) + checkpoint diff + the LIVE-page",
           "                        B+-tree node-slack scan.  [FAST — seconds]  Reads only pages the tree walk",
           "                        already touched. Recovers the common in-tree deletions.",
           "  • `deleted --full`  — FULL recovery: ALSO scans EVERY cluster of the volume for orphan pages (the",
           "                        freed pages of deleted objects) and, on export, carves non-resident content.",
           "                        Finds far more — the older deletions whose directory entry is already gone",
           "                        from the tree.  [SLOW — it reads the whole volume once, at the disk's",
           "                        sequential read speed. On a 1-2 GB/s disk that is about a minute per",
           "                        60-100 GB: ~1 min for 64 GB, ~20-35 min for 2 TB, and VERY SLOW at",
           "                        multi-TB (~2.5-4.5 h for 16 TB). Progress is printed as it runs.]",
           "COST OF EACH OPTION (so you can choose knowingly):",
           "  FAST       `deleted` · --trash · --no-slack · --orphans · --search · --csv/--json/--jsonl · --rows",
           "  MODERATE   --carve (on export) — reads the data extents of each recovered non-resident file, so the",
           "             cost follows how much deleted data you are reconstructing, not the size of the volume",
           "  SLOW       --full · --scan-pages — each reads the WHOLE volume once, at the disk's sequential read",
           "             speed: on a 1-2 GB/s disk about a minute per 60-100 GB (~1 min at 64 GB, ~20-35 min at",
           "             2 TB), and VERY SLOW at multi-TB (~2.5-4.5 h at 16 TB)",
           "  OPT-OUT    --max-scan N  makes a slow scan fast again by stopping after N clusters — but then the run",
           "             covers only part of the disk and is labelled INCOMPLETE in the output and the recovery log.",
           "A slow run that you chose knowingly is fine; a scan that silently stopped part-way is not, so coverage",
           "is always printed and any partial run is flagged.",
           "Each entry carries a RECOVERABLE verdict: 'FULL FILE recoverable' (RESIDENT — content inline in the",
           "record) / 'extent_backed' (NON-RESIDENT — data is in on-disk extents whose MAP survives, so",
           "`export deleted --carve` reconstructs it best-effort) / 'metadata only' (name/size/timestamps only).",
           "Each row shows the directory it was deleted FROM. Prior versions of files that still exist →",
           "`snapshots`; Windows Recycle Bin → `recyclebin`.",
           "`export deleted DIR` writes: (1) deleted_files.csv + .json — the INDEX, one row per entry (name,",
           "recoverability, reliability, category, and the content file if any); (2) content/ — only the READABLE",
           "files: content/<name> for a RESIDENT file (byte-exact) and, under --full/--carve, content/<name>.carved",
           "for a NON-RESIDENT file (best-effort, may be stale); (3) recovery_log.txt — the forensic audit trail.",
           "The raw remnant bytes go to rows/ ONLY with --rows: each rows/<name>_c<cluster>o<off>.row is the raw",
           "recovered directory-entry value (name in the key; timestamps/attrs/size/extent-map at the $SI/index",
           "offsets — inspect one with the `details` command or the structure docs). A plain view writes nothing.",
           "'recoverable' means present & decodable, NOT un-overwritten."],
  "opts": [("--full", "SLOW. FULL recovery: also scan every cluster for orphan pages + carve non-resident "
                      "content (vs the quick default). Reads the whole volume once — about a minute per "
                      "60-100 GB"),
           ("--no-slack", "skip the slack scan entirely (Trash table + checkpoint diff only — fast, metadata)"),
           ("--trash", "only the Trash table, then return (fastest; view only — no --csv/--json/export)"),
           ("--scan-pages", "SLOW. Additionally run the orphaned-page NAME scan (a distinct method; whole "
                            "volume, same about-a-minute-per-60-100 GB budget)"),
           ("--orphans", "add a LOW-CONFIDENCE tier: Object-Table OIDs unlinked from the tree (identity-filtered; "
                         "opt-in). Low volume; genuine deleted dirs usually recover more fully via the slack scan"),
           ("--carve", "with `export deleted`: reconstruct NON-RESIDENT files best-effort into content/<name>.carved "
                       "(on by default under --full). Best-effort — the data clusters may have been reused since "
                       "deletion, so .carved may be stale (verify); the resident content/<name> is byte-exact"),
           ("--search SUB", "filter recovered entries by name substring"),
           ("--max-scan N", "stop the orphan-page scan after N clusters. Default: NO limit — the whole volume "
                            "is scanned, because a partial scan silently misses deleted files. Use this only to "
                            "trade completeness for speed; the run is then reported as INCOMPLETE"),
           ("--rows", "with `export deleted`: ALSO write the raw remnant bytes to rows/ (OFF by default; provenance "
                      "/ chain-of-custody — the exact recovered directory-entry bytes)"),
           ("--no-system", "drop OS/BitLocker (`FVE2.{…}`) system churn from the index + export (focus on user files)"),
           ("--rows-only", "with `export deleted`: write ONLY the raw remnants (rows/) + the index, skip content/"),
           ("--content-only", "with `export deleted`: content + index only (this is now the DEFAULT; kept for scripts)"),
           ("--csv/--json/--jsonl FILE", "write the deleted-entry index to a machine-readable file — columns "
                          "FileName, IsDirectory, RecoverySource, RecoveredFrom, Recoverability, Created, Modified, "
                          "RecoveredChild, Cluster, FileAttributes, Category, Reliability, ContentFile; composes "
                          "with any recovery flag (same columns as the exported deleted_files.csv)"),
           ("--log PATH", "write the forensic recovery-run log here — also forces a log on a plain view "
                          "(when exporting, the default is <export-dir>/recovery_log.txt)"),
           ("--extract DIR", "DEPRECATED — use `export deleted DIR` (index + content/, and rows/ with --rows)")],
  "ex": [("deleted", "RECOVERY (default): Trash + checkpoint + live-page slack, with recoverability verdicts"),
         ("deleted --full", "FULL: also scan orphan pages + carve — the complete pass"),
         ("deleted --trash", "fastest: Trash-only check"),
         ("export deleted OUT --full", "write deleted_files.csv/.json + content/ (resident exact + carved) — full scan"),
         ("export deleted OUT --full --no-system", "same, but hide the BitLocker FVE2 churn (user files only)"),
         ("export deleted OUT --rows", "also keep the raw remnant bytes in rows/ (provenance)"),
         ("deleted --search report", "only deleted entries named like 'report'")],
 },
 "recyclebin": {
  "tag": "Decode $RECYCLE.BIN $I metadata (original path, deletion time)",
  "desc": ["Walks $RECYCLE.BIN/<SID>/ and decodes each $I metadata file — the original full path, deletion",
           "time, and logical size of a recycled item — and reports whether its $R payload still survives.",
           "Filesystem-agnostic Windows format ($I header 1=Vista-8.1, 2=Win10/11)."],
  "opts": [("--csv/--json/--jsonl [FILE]", "machine output (one record per recycled item); to stdout or FILE")],
  "ex": [("recyclebin", "list every recycled item with its original path + deletion time"),
         ("recyclebin --json", "same, as JSON")],
 },
 "specials": {
  "tag": "Special-attribute files — one discoverable home for every special type",
  "desc": ["Lists files carrying a special attribute. No argument prints a COUNT SUMMARY of every type;",
           "`specials <type>` prints that type's list with type-specific columns; `specials all` prints every",
           "section. Types (alphabetical): ads, compressed, ea, encrypted, hardlink, integrity, reparse, snapshot, sparse, wsl.",
           "This is the discovery/list layer — for deep ops use reparse --index / snapshots --extract /",
           "dataruns / export ads. (Equivalent to `files --filter <type>`, which also still works.)"],
  "opts": [("<type>", "ads · compressed · ea · encrypted · hardlink · integrity · reparse · snapshot · sparse · wsl"),
           ("all", "print every type's list, sectioned"),
           ("--csv/--json/--jsonl [FILE]", "machine output (json: counts/per-type lists; csv/jsonl: flat "
                                           "type/path/home_oid/file_id/detail records) to stdout or FILE")],
  "ex": [("specials", "count summary of every special type"),
         ("specials ads", "every named data stream + its host file"),
         ("specials hardlink", "hard-link groups (all names of each multi-linked file)"),
         ("specials sparse", "sparse files with logical vs allocated size")],
 },
 "ads": {
  "tag": "Named data streams (ADS) across the volume",
  "desc": ["Lists every named data stream (Alternate Data Stream) on the volume and its host file — a top-level",
           "shortcut for `specials ads` (same code). Extract one with `export ads \"<file>:<stream>\"`."],
  "opts": [("--csv/--json/--jsonl [FILE]", "machine output (type/path/home_oid/file_id/detail) to stdout or FILE")],
  "ex": [("ads", "list every ADS + its host file"),
         ("ads --csv ads.csv", "export the ADS inventory to CSV"),
         ("export ads \"notes.txt:secret\"", "extract one stream's bytes")],
 },
 "export": {
  "tag": "Get data out — one home for every extraction path",
  "desc": ["Exports content or artifacts. SINGLE-value subverbs print to the screen (add `-o FILE` to save):",
           "`file <path>` (one file, = extract) · `ads <path:stream>` (one inline ADS) · `reparse` (the reparse",
           "inventory as text, or --json). BULK subverbs write to a directory — and if you omit it they auto-create a",
           "timestamped `forefst_export_<what>_<stamp>/`: `resident-all` (every resident file's inline $DATA) ·",
           "`snapshots` (all stream-snapshot versions; alias `prior-versions`) · `deleted` (.row + .recovered",
           "[+ --carve .carved]) · `recyclebin` ($R payloads) · `metadata` (the VBR/CHKP/SUPB/MLog/USN/B+-tree",
           "bundle). Bare `export -o DIR` = metadata."],
  "opts": [("file <path> [-o FILE] | --oid O", "carve ONE file's bytes (stdout, or -o FILE to save)"),
           ("ads <path:stream> [-o FILE]", "carve ONE inline alternate data stream (stdout, or -o FILE)"),
           ("reparse [--json] [-o FILE]", "the reparse-point inventory (targets/tags/kind) — text, or --json (stdout, or -o FILE)"),
           ("resident-all [dir]", "every resident file's inline content, tree preserved (auto-dir if omitted)"),
           ("snapshots [dir]", "each stream-snapshot version (alias: snapshot / prior-versions; auto-dir if omitted)"),
           ("deleted [dir] [--carve] [--rows-only|--content-only]",
            "deleted remnants: raw .row + .recovered (inline) [+ .carved extent-backed with --carve] + manifest"),
           ("recyclebin [dir]", "surviving $R payloads, named by their decoded original filename (auto-dir if omitted)"),
           ("metadata -o <dir>", "the hash-verified metadata bundle (--what vbr,chkp,supb,mlog,usn,btree · --btree-mode packed|per-object)")],
  "ex": [("export file /dir/report.docx -o out.docx", "one file, saved"),
         ("export ads \"notes.txt:hidden\"", "one ADS to the screen (add -o to save)"),
         ("export snapshots", "every snapshot version -> an auto-created timestamped folder"),
         ("export deleted ./rec/ --carve", "recover deleted rows + reconstruct non-resident files"),
         ("export recyclebin ./recovered/", "recover the recycle-bin payloads"),
         ("export metadata -o ./bundle/", "the metadata bundle (= the old `export`)")],
 },
 "snapshots": {
  "tag": "Volume snapshots / block-clone (CoW) streams",
  "desc": ["Inventories files carrying stream snapshots (CoW prior versions) and can recover/preview or",
           "extract each prior version's content via its extent chain."],
  "opts": [("-v, --verbose", "per-snapshot allocation/id/value details"),
           ("--show", "recover & preview each snapshot's prior CoW content"),
           ("--file SUB", "only files whose path contains SUB (a fuller path disambiguates same-named files)"),
           ("--snapshot SEL", "only ONE version: a 1-based [N] index, or part of a version name"),
           ("--depth N", "cap recursion depth (default: full)"),
           ("--extract DIR", "write each recovered version into DIR"),
           ("--json", "machine-readable inventory")],
  "ex": [("snapshots", "list files with snapshots"),
         ("snapshots --file lasttest.txt --show -v", "preview one file's prior versions"),
         ("snapshots --file lasttest.txt --snapshot first --show", "preview just the version named 'first'"),
         ("export snapshots ./v --file report.txt --snapshot 2", "extract only version [2] of report.txt"),
         ("snapshots --extract ./recovered --depth 12", "carve all recoverable versions")],
 },
 "integrity": {
  "tag": "Verify metadata-page checksums",
  "desc": ["Structural audit of metadata pages. By default a fast verdict; --checksums verifies the",
           "system root tables, --fullchecksums extends to every object B-tree (CRC64 or SHA-256)."],
  "opts": [("-v, --verbose", "per-page details (capped 200)"),
           ("--json [FILE]", "emit the full report as a structured JSON object (to stdout or FILE)"),
           ("--checksums", "verify the system root tables' checksums"),
           ("--fullchecksums", "verify every object B-tree (implies --checksums)"),
           ("--scan-range A-B", "raw mode: inspect each LCN in the range standalone"),
           ("--max-pages N", "cap the checksum crawl (default 300000)")],
  "ex": [("integrity", "fast structural verdict"),
         ("integrity --checksums", "verify system-root checksums"),
         ("integrity --fullchecksums -v", "full sweep + page details")],
 },
 "dataruns": {
  "tag": "File data extents / data-runs per object",
  "desc": ["Maps non-resident files to their on-disk extents (data-runs). Default lists extent-backed",
           "files; -v adds resident/no-extent files and every decoded run (fvcn/lcn/length)."],
  "opts": [("-v, --verbose", "include resident/no-extent files and every decoded run"),
           ("--csv/--json/--jsonl [FILE]", "machine output (one record per file; JSON keeps the structured "
                                           "run list); to stdout or FILE (prints a count)"),
           ("--oid O", "start at object O (0x hex or decimal; default 0x600)"),
           ("--depth N", "cap recursion depth (default: full)")],
  "ex": [("dataruns", "map extent-backed files under the root"),
         ("dataruns -v --depth 5", "full per-file run dump, deeper"),
         ("dataruns --oid 0x705 -v", "scope to one directory subtree")],
 },
}

def _render_cmd_help(cmd):
    h = CMD_HELP.get(cmd)
    if not h:
        print(f"{PROG}: no help for {cmd!r}. Run `{PROG} --help`.", file=sys.stderr); return
    forensic = cmd in FORENSIC_SUBCOMMANDS
    print(f"{PROG} v{VERSION} <image> {cmd} — {h['tag']}\n")
    print(f"  usage: {PROG} <image> {cmd} [options]" + ("" if forensic else "") + "\n")
    for line in h["desc"]:
        print(f"  {line}")
    print("\n  Options:")
    for flag, desc in h["opts"]:
        print(f"    {flag:26} {desc}" if flag else f"    {'':26} {desc}")
    print("\n  Examples:")
    for ex, note in h["ex"]:
        print(f"    {PROG} disk.raw {ex}")
        print(f"        {note}")
    print()

def _print_overview():
    print(f"{PROG} v{VERSION} — ReFS forensic analysis tool\n")
    print(f"usage: {PROG} <image> [subcommand] [options]")
    print(f"       {PROG} <image>                 # defaults to `summary`")
    print(f"       {PROG} <image> <cmd> --help    # detailed help for one subcommand")
    print(f"       {PROG} list                    # one-line index of all subcommands\n")
    print("Core subcommands:")
    for k, v in SUBCOMMANDS.items():
        print(f"  {k:12} {v}")
    print("\nSecondary subcommands:")
    for k in FORENSIC_SUBCOMMANDS:
        if k in EXPERIMENTAL_SUBCOMMANDS:
            continue
        print(f"  {k:12} {CMD_HELP[k]['tag']}")
    print("\nExperimental / informational  (suggestive output — corroborate before relying on it):")
    for k in EXPERIMENTAL_SUBCOMMANDS:
        if k in FORENSIC_SUBCOMMANDS:
            print(f"  {k:12} {CMD_HELP[k]['tag']}")
    print(f"\n{GLOBAL_HELP}\n")
    print("Examples (grouped by what you want to do):")
    _EXAMPLE_GROUPS = (
        ("List / inventory", (
            ("files --csv listing.csv",     "full inventory -> CSV"),
            ("find report --regex",         "find files by name (alias of `search`)"),
            ("details /dir/file.txt",       "everything about ONE file (or 0xOID)"),
        )),
        ("Special files", (
            ("specials",                    "count table of every special type"),
            ("specials ads",                "list all files with alternate data streams"),
            ("specials hardlink",           "list hard-linked files, grouped"),
        )),
        ("Get data out", (
            ("export ads \"file:stream\"",    "extract one alternate data stream"),
            ("export resident-all out/",    "dump every resident file's inline data"),
            ("export snapshots out/",       "extract all stream-snapshot versions"),
        )),
        ("Deleted / recovery", (
            ("deleted",                     "list deleted files + a recoverability verdict (slack by default)"),
            ("export deleted out/ --carve", "recover them: .row + .recovered + carved non-resident"),
            ("recyclebin",                  "report the Windows $RECYCLE.BIN"),
        )),
        ("Timeline / anomalies", (
            ("timeline --fast --limit 50",  "USN+MLog+$SI merged super-timeline"),
            ("timestomp",                   "flag backdated / anomalous timestamps"),
            ("summary",                     "volume summary (version, checkpoint, flags)"),
        )),
    )
    for title, rows in _EXAMPLE_GROUPS:
        print(f"  {title}:")
        for ex, note in rows:
            print(f"    {PROG} disk.raw {ex:30}  # {note}")
    print(f"\n{VERSION_NOTE}")

# Every option that consumes the FOLLOWING token as its value (across argparse + the forensic commands).
# Used so a help token that is actually a value (e.g. `extract --path --help`) is NOT mistaken for a
# help request.
_VALUED_OPTS = {"-o", "--output", "--oid", "--path", "--filter", "--depth", "--partition-start",
                "--cow-before", "--btree-mode", "--csv", "--extract", "--file", "--limit",
                "--margin-days", "--max-pages", "--max-scan", "--min", "--out", "--scan-range",
                "--search", "--sid", "--source", "--tag", "--what"}

def _help_requested(toks):
    """True if -h/--help appears as a real help request — i.e. NOT as the value of a valued option."""
    for i, t in enumerate(toks):
        if t in ("-h", "--help") and not (i > 0 and toks[i - 1] in _VALUED_OPTS):
            return True
    return False

def main():
    # Full-depth walks (4.D / audit 5.3): a modest recursion-limit raise. Real ReFS trees are shallow (corpus max
    # = 40 levels), so this is never hit legitimately; it is kept comfortably C-stack-SAFE (4000, ~100x the corpus
    # max) so a crafted/corrupt tree deeper than this raises a CATCHABLE RecursionError — which walk_directory_tree
    # turns into a clean error — rather than the 40000 setting's outcome on a small C stack: an uncatchable
    # SIGSEGV / rc=137 that converts a reportable error into an unreportable process death.
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 4000))
    # `--csv-safe` (opt-in spreadsheet formula-injection guard) is a GLOBAL modifier that must apply to every
    # CSV-emitting command (files/usn/timeline/timestomp/mlog/deleted), so detect+strip it here before any
    # dispatch or argparse. Default stays OFF = filenames written byte-faithfully.
    global _CSV_GUARD
    if "--csv-safe" in sys.argv:
        _CSV_GUARD = True
        sys.argv = [a for a in sys.argv if a != "--csv-safe"]
    # Global `--partition-start N` works in ANY position: relocate it to the END of argv so a flag placed
    # BEFORE the subcommand (e.g. `IMG --partition-start 0 integrity`) confuses neither the forensic dispatch
    # (which keys on argv[2]) nor argparse (which mishandles an optional between the image/command positionals).
    # No-op when it is already last; only the first occurrence is moved.
    for _pi in range(2, len(sys.argv) - 1):
        if sys.argv[_pi] == "--partition-start":
            sys.argv = sys.argv[:_pi] + sys.argv[_pi + 2:] + [sys.argv[_pi], sys.argv[_pi + 1]]
            break
    _ALL_CMDS = set(SUBCOMMANDS) | set(HIDDEN_SUBCOMMANDS) | set(FORENSIC_SUBCOMMANDS)
    # Resolve a command-token alias (e.g. `find` -> `search`) to canonical BEFORE any dispatch/help, so all
    # downstream (help, argparse, forensic routing) sees the real name. The alias applies to the subcommand
    # token, which is sys.argv[2] (sys.argv[1] is the image).
    # Case-insensitive SUBCOMMAND and OPTION NAMES (values are left exactly as typed — a path, a stream name
    # or a --filter category is case-sensitive data, not a keyword). Normalising here means every downstream
    # consumer — help, argparse, forensic routing — sees the canonical spelling.
    if len(sys.argv) >= 3:
        _lc = sys.argv[2].lower()
        if sys.argv[2] not in _ALL_CMDS and _lc in _ALL_CMDS:
            sys.argv[2] = _lc
        elif sys.argv[2] not in SUBCOMMAND_ALIASES and _lc in SUBCOMMAND_ALIASES:
            sys.argv[2] = _lc
    # Long option NAMES only. A token is skipped when it is the VALUE of a valued option, so a path or a
    # stream name that happens to start with "--" is never touched. Every option whose canonical spelling has
    # capitals (--ID / --OID / --FileRef) also has a lowercase form registered, so lowercasing always lands on
    # a real option.
    for _i in range(2, len(sys.argv)):
        _a = sys.argv[_i]
        if not _a.startswith("--") or _a == "--":
            continue
        if _i > 0 and sys.argv[_i - 1] in _VALUED_OPTS:
            continue                                    # this token is a value, not an option name
        _name, _sep, _val = _a.partition("=")
        if _name.lower() != _name:
            sys.argv[_i] = _name.lower() + _sep + _val if _sep else _name.lower()
    if len(sys.argv) >= 3 and sys.argv[2] in SUBCOMMAND_ALIASES:
        sys.argv[2] = SUBCOMMAND_ALIASES[sys.argv[2]]
    _argv = sys.argv
    # ── help handling (before any dispatch / argparse) ──
    if len(_argv) == 1 or (len(_argv) >= 2 and _argv[1] in ("-h", "--help", "help")):
        if len(_argv) >= 3 and _argv[2] in _ALL_CMDS:
            _render_cmd_help(_argv[2])
        else:
            _print_overview()
        return
    # `forefst <image> help [<cmd>]` → general overview, or targeted per-command help when a command
    # follows (`forefst disk.raw help mlog`, `… help details`). `help` here is the subcommand token
    # (sys.argv[2]); sys.argv[1] is the image. Mirrors the `forefst help <cmd>` (no-image) form above.
    if len(_argv) >= 3 and _argv[2] == "help":
        _hcmd = _argv[3] if len(_argv) >= 4 else None
        if _hcmd in SUBCOMMAND_ALIASES:
            _hcmd = SUBCOMMAND_ALIASES[_hcmd]
        if _hcmd and _hcmd in _ALL_CMDS:
            _render_cmd_help(_hcmd)
        elif _hcmd:
            print(f"[{PROG}] no such subcommand: '{_hcmd}' — showing the overview.\n")
            _print_overview()
        else:
            _print_overview()
        return
    # `forefst <image> [<cmd>] --help/-h` → per-command or overview help (but not when -h/--help is the
    # value of a valued option, e.g. `extract --path --help`)
    if len(_argv) >= 3 and _help_requested(_argv[2:]):
        _cmd = next((a for a in _argv[2:] if a in _ALL_CMDS), None)
        if _cmd:
            _render_cmd_help(_cmd)
        else:
            _print_overview()
        return

    # `forefst list` / `--list` / `-l`: list subcommands (no image needed). The bare word is accepted for the
    # same reason `help` is: a user who types one expects the other to work the same way.
    if len(sys.argv) >= 2 and sys.argv[1] in ("list", "--list", "-l"):
        print(f"{PROG} v{VERSION} — subcommands (usage: {PROG} <image> <subcommand> [options]):\n")
        print("core subcommands:")
        for _k, _v in SUBCOMMANDS.items():
            print(f"  {_k:13} {_v}")
        print("\nsecondary subcommands:")
        for _k, _v in FORENSIC_SUBCOMMANDS.items():
            if _k in EXPERIMENTAL_SUBCOMMANDS:
                continue
            print(f"  {_k:13} {_v}")
        print("\nexperimental / informational subcommands  (suggestive output — corroborate before relying on it):")
        for _k in EXPERIMENTAL_SUBCOMMANDS:
            if _k in FORENSIC_SUBCOMMANDS:
                print(f"  {_k:13} {FORENSIC_SUBCOMMANDS[_k]}")
        print(f"\n{VERSION_NOTE}")
        return

    # Delegated forensic subcommands: parse like refsanalysis (raw remaining args + own flags),
    # since they use options argparse doesn't model (--parse/--raw-scan/--no-si/--source/...).
    if len(sys.argv) >= 3 and sys.argv[2] in FORENSIC_HANDLERS:
        image = sys.argv[1]
        subcmd = sys.argv[2]
        remaining = sys.argv[3:]
        part_start = None
        filtered = []
        i = 0
        while i < len(remaining):
            if remaining[i] == "--partition-start":
                if i + 1 >= len(remaining):
                    # audit 2.9: --partition-start IS a known option missing its value — say so, don't let
                    # _parse_args report it as "unknown option". (Exit stays 1, matching the invalid-value
                    # path below; the usage-vs-runtime exit-code contract is a separate, deferred change.)
                    print(f"{PROG}: error: option --partition-start requires a value "
                          f"(a byte offset, e.g. 0 or 0x100000)", file=sys.stderr)
                    sys.exit(1)
                try:
                    part_start = int(remaining[i + 1], 0)
                except ValueError:
                    print(f"{PROG}: error: invalid --partition-start value: {remaining[i + 1]}", file=sys.stderr)
                    sys.exit(1)
                i += 2
            else:
                filtered.append(remaining[i]); i += 1
        if not os.path.exists(image):
            print(f"{PROG}: error: file not found: {image}", file=sys.stderr); sys.exit(1)
        if not os.path.isfile(image):
            print(f"{PROG}: error: not a regular file: {image}", file=sys.stderr); sys.exit(1)
        # G3: the delegated subcommands took a different route from the native ones and never printed the
        # opening banner, so the tool version was invisible on 14 of the 20 commands. stderr only (as on the
        # native path), so piped stdout / --csv output is unaffected.
        if not ({"-q", "--quiet"} & set(remaining)):          # match the native path, which honours -q
            print(f"[{PROG} v{VERSION}] Opening {os.path.basename(image)}...", file=sys.stderr)
        # audit 2.8: do NOT validate the image here. The handler parses its own flags FIRST (via _parse_args /
        # _check_unknown_flags), so a typo'd flag is reported before the image is read; its bootstrap() then
        # validates/aborts with the SAME clean ValueError the `files` path already surfaces (audit 2.3 — one
        # acceptance policy, one error message, for every command). Mirror the argparse path's catch.
        try:
            sys.exit(FORENSIC_HANDLERS[subcmd](image, filtered, part_start))
        except ValueError as e:
            print(f"{PROG}: error: {e}", file=sys.stderr); sys.exit(1)
        except OSError as e:
            print(f"{PROG}: error: cannot read image: {e}", file=sys.stderr); sys.exit(1)

    ap = _UsageExit1Parser(prog=PROG,
                           description="ReFS forensic file lister",
                           epilog=VERSION_NOTE)
    ap.add_argument("--version", action="version", version=f"forefst.py v{VERSION} — ReFS forensic file lister")
    ap.add_argument("image", help="Path to disk image")
    ap.add_argument("command", nargs="?", choices=list(SUBCOMMANDS) + list(HIDDEN_SUBCOMMANDS), default=None,
                    help="subcommand (default: summary); run `forefst --list` to see all")
    ap.add_argument("target", nargs="?", default=None,
                    help="search PATTERN, or details /path | 0xOID")
    ap.add_argument("-o", "--output", help="Output file (default: stdout); or use --csv/--json/--jsonl FILE")
    ap.add_argument("--body", nargs="?", const="-", metavar="FILE",
                    help="files: body-file (mactime) output; bare = stdout, or give a FILE")
    ap.add_argument("--csv-safe", action="store_true",
                    help="CSV output: prefix a cell starting with = + - @ with a quote to neutralise spreadsheet "
                         "formula injection. OFF by default so filenames are written byte-faithfully; enable this "
                         "only if you will open the CSV in Excel/LibreOffice (applies to all CSV-emitting commands)")
    # --csv/--json/--jsonl now accept an OPTIONAL FILE (bare = stdout, `--json FILE` = write file + count),
    # standardizing files/summary/search/details with the forensic commands. Put the search/details TARGET
    # BEFORE these flags (`search foo --json`), so the pattern isn't consumed as the format's FILE.
    ap.add_argument("--csv", nargs="?", const="-", default=None, metavar="FILE",
                    help="CSV output to stdout, or to FILE")
    ap.add_argument("--json", nargs="?", const="-", default=None, metavar="FILE",
                    help="JSON output (array) to stdout, or to FILE")
    ap.add_argument("--jsonl", nargs="?", const="-", default=None, metavar="FILE",
                    help="JSON Lines output to stdout, or to FILE")
    ap.add_argument("--hash-image", action="store_true",
                    help="summary: include SHA-256 hash of the full disk image")
    ap.add_argument("--path", default=None,
                    help="details: address the object by path (e.g. /dir/file.txt)")
    ap.add_argument("--id", "--ID", "--FileRef", "--fileref", "--oid", "--OID", dest="id", default=None,
                    help="details/export: address the object by identity — an OID (e.g. 0x703) or a FileRef "
                         "HomeOID:FileID (e.g. 0x703:0x2e). --FileRef/--OID are aliases of --id.")
    ap.add_argument("--regex", action="store_true",
                    help="search: treat PATTERN as a regular expression")
    ap.add_argument("--filter", default=None, metavar="CATEGORY",
                    help="files: subset by attribute category — " + "/".join(FILE_FILTERS))
    ap.add_argument("--depth", type=int, default=DEFAULT_DEPTH, help="Max directory recursion depth (default: full)")
    ap.add_argument("--partition-start", type=lambda x: int(x, 0), default=None,
                    help="Override partition start offset in bytes")
    ap.add_argument("--cow-before", metavar="IMAGE",
                    help="files: earlier disk image for forward CoW version recovery")
    ap.add_argument("--cow-partition-start", type=lambda x: int(x, 0), default=None,
                    help="files: partition offset for the --cow-before image (default: auto-detect its own "
                         "GPT). C16: use when the before-image has a DIFFERENT layout than the main image "
                         "(otherwise both auto-detect). NOTE: the CoW-recovery path is lightly tested.")
    ap.add_argument("-q", "--quiet", action="store_true", help="Suppress progress to stderr")
    args = ap.parse_args()
    if args.command is None:
        # Phase 3 (4.A): a bare `forefst <image>` gives the volume SUMMARY (orientation first); run
        # `forefst <image> files` for the full CSV listing.
        args.command = "summary"

    def log(msg):
        if not args.quiet:
            print(msg, file=sys.stderr)

    def die(msg):
        print(f"{PROG}: error: {msg}", file=sys.stderr)
        sys.exit(1)

    # Output format mutual exclusion (--csv/--json/--jsonl accept an optional FILE, so they are None-or-str)
    fmt_count = sum(1 for v in (args.body, args.csv, args.json, args.jsonl) if v is not None)
    if fmt_count > 1:
        die("--csv, --json, --jsonl and --body are mutually exclusive")

    # Input validation
    if not os.path.exists(args.image):
        die(f"file not found: {args.image}")
    if not os.path.isfile(args.image):
        die(f"not a regular file: {args.image}")
    if args.depth < 1:
        die(f"--depth must be >= 1 (got {args.depth})")
    if args.partition_start is not None and args.partition_start < 0:
        die(f"--partition-start must be >= 0 (got {args.partition_start})")
    if args.cow_before:
        if not os.path.isfile(args.cow_before):
            die(f"--cow-before: file not found: {args.cow_before}")
        if os.path.abspath(args.cow_before) == os.path.abspath(args.image):
            die("--cow-before image must be different from the main image")
        if args.command != "files":
            die("--cow-before is only valid with the 'files' subcommand")
    # -o/--output on a LISTING command means "write the current format here", so the same flag produces CSV,
    # JSON or a bodyfile depending on other flags — the format is invisible at the call site, which is why
    # each format now carries its own destination (`--csv FILE`, `--json FILE`, ...). Refusing -o outright
    # was the wrong correction: it broke every documented example and every script that used it, against a
    # release note promising the old spellings keep working. It is accepted as an alias for the selected
    # format's destination (CSV by default) -- `_resolve_out_fmt` already implements exactly that -- with a
    # deprecation note, and a warning when it is given ALONGSIDE an explicit destination, where it is ignored.
    if getattr(args, "output", None) and args.command in SUBCOMMANDS:
        _explicit = next((f"--{n} {v}" for n, v in (("csv", getattr(args, "csv", None)),
                                                    ("json", getattr(args, "json", None)),
                                                    ("jsonl", getattr(args, "jsonl", None)),
                                                    ("body", getattr(args, "body", None)))
                          if isinstance(v, str) and v not in ("", "-")), None)
        if _explicit:
            print(f"[{PROG}] WARNING: both `{_explicit}` and `-o {args.output}` given — the format flag's "
                  f"destination wins and -o is ignored.", file=sys.stderr)
        else:
            print(f"[{PROG}] note: -o/--output is deprecated for `{args.command}`; it still works and writes "
                  f"the selected format. Prefer naming the format's own destination: "
                  f"`{PROG} <image> {args.command} --csv {args.output}`.", file=sys.stderr)
    # Subcommand flag scoping (clean break: these belong to specific subcommands)
    if (args.id is not None or args.path) and args.command != "details":
        die("--oid/--path are only valid with the 'details' subcommand")
    if args.filter is not None:
        if args.command not in ("files", "search"):
            die("--filter is only valid with the 'files' or 'search' subcommand")
        if args.filter not in FILE_FILTERS:
            die(f"--filter: unknown category {args.filter!r}. Choices: {', '.join(sorted(FILE_FILTERS))}")

    # Help-on-empty (4.C): a bare `details` (no target/OID/path/id) shows its help instead of opening the image.
    if args.command == "details" and args.target is None and not args.path and not args.id:
        # audit 2.12: when a MACHINE format was explicitly requested, a missing target is a usage error, not
        # help. Help-on-stdout is invalid JSON in a pipe AND exits 0 (a silent pipeline failure); instead emit
        # the error to stderr and exit non-zero (the existing error convention — the usage-vs-runtime exit-code
        # split is the separately-deferred change). The friendly help stays for the interactive case.
        if any(getattr(args, _f, None) is not None for _f in ("json", "jsonl", "csv")):
            die("details: a target is required (a /path, --oid, or --id) when --json/--jsonl/--csv is requested")
        _render_cmd_help("details")
        return

    # Bootstrap
    log(f"[{PROG} v{VERSION}] Opening {os.path.basename(args.image)}...")   # A1: version on the first line
    try:
        f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns = bootstrap(args.image, args.partition_start)
    except ValueError as e:
        die(str(e))
    except OSError as e:
        die(f"cannot read image: {e}")
    version_str = f"{vmaj}.{vmin}"
    usn_active = False
    if 0x520 in obj_map:
        try:
            for kd, _vd in walk_bplus(f, ps, cs, tr, obj_map[0x520]):
                if len(kd) >= 4 and le16(kd, 0) == 0x30:
                    try:
                        nm = kd[4:].decode("utf-16-le").rstrip("\x00")
                        if nm == "Change Journal": usn_active = True; break
                    except Exception: pass
        except Exception: pass
    usn_tag = " | USN: active" if usn_active else ""
    log(f"[{PROG}] ReFS {version_str} | {len(obj_map)} objects | cluster_size={cs}{usn_tag}")
    if (vmaj, vmin) < (3, 14):
        log(f"[{PROG}] note: ReFS {version_str} (<3.14) — some enriched fields may be incomplete (see --list)")

    # summary / fastsummary subcommands (both extended-by-default)
    if args.command in ("summary", "fastsummary"):
        is_fast = (args.command == "fastsummary")
        is_plus = True
        log(f"[{PROG}] Running {'fast ' if is_fast else ''}summary...")
        # `plus_mode` is True for BOTH commands, so it cannot gate this: the page-reference verification
        # belongs to `summary` only. It reads ~385 metadata pages, which took `fastsummary` from 0.36 s to
        # 36.70 s on a real Windows volume -- a 100x regression on the command whose contract is speed.
        fast_data = cmd_fastsummary(f, ps, cs, tr, roots, obj_map, vmaj, vmin, chkp_lcns,
                                     args.image, plus_mode=is_plus, hash_image=args.hash_image, log_fn=log,
                                     verify_page_refs=False)
        if is_fast:
            if args.json is not None:
                _emit_json_obj(fast_data, _native_fmt_dest(args)[1], "fast summary")
            else:
                _print_fastsummary(fast_data, plus_mode=is_plus)
            f.close()
            return

        # Full summary: needs directory walk (enriched, so ADS/SecurityId/reparse counts are correct)
        log(f"[{PROG}] Walking directory tree for full summary...")
        log("Tip: `fastsummary` = quick volume metadata (no directory walk).")   # 1summary: moved to the top
        counts, results = fs_content_summary(f, ps, cs, tr, obj_map, plus=is_plus, depth=args.depth)
        walk_summary = {
            "directories": counts["directories"], "files": counts["files"],
            "resident_files": counts["resident_files"],
            "total_file_size": _human_size(counts["total_file_size_bytes"]),
            "total_file_size_bytes": counts["total_file_size_bytes"],
            "oldest_timestamp": filetime_to_iso(counts["oldest_ft"]) if counts["oldest_ft"] else "(none)",
            "newest_timestamp": filetime_to_iso(counts["newest_ft"]) if counts["newest_ft"] else "(none)",
        }
        walk_summary["non_resident_files"] = counts["non_resident_files"]
        if is_plus:
            walk_summary["encrypted_files"] = counts["encrypted_files"]
            walk_summary["integrity_files"] = counts["integrity_files"]
            walk_summary["compressed_files"] = counts["compressed_files"]
            walk_summary["hardlink_extra"] = counts["hardlink_extra"]
            walk_summary["hardlink_names"] = counts["hardlink_names"]
            walk_summary["hardlink_groups"] = counts["hardlink_groups"]
            walk_summary["snapshots"] = counts["snapshots"]
            walk_summary["snapshot_files"] = counts["snapshot_files"]
            walk_summary["ads_entries"] = counts["ads_entries"]
        # UsnJournalId: the volume-constant journal epoch carried by every file's $SI val+0x70
        # (reliable, unlike the $Max stream). Take the most common non-zero value.
        _jids = {}
        for r in results:
            _j = r.get("usn_journal_id", 0)
            if _j:
                _jids[_j] = _jids.get(_j, 0) + 1
        if _jids:
            fast_data["usn_journal_id"] = max(_jids, key=_jids.get)
        combined = {**fast_data, **walk_summary}
        combined["summary_mode"] = "summary-plus" if is_plus else "summary"
        if args.json is not None:
            _emit_json_obj(combined, _native_fmt_dest(args)[1], "summary")
        else:
            _print_summary(walk_summary, fast_data, plus_mode=is_plus)
        f.close()
        return

    # details subcommand — inspect ONE object by OID, path, or reference (--id HomeOid:FileId)
    if args.command == "details":
        det_oid, det_path = None, None
        # Two ways in: by PATH or by IDENTITY. `--id` (aliases --oid/--OID/--FileRef) takes either an OID or a
        # FileRef, so there is no longer a separate --oid flag to confuse with it.
        if args.id is not None and args.path:
            die("details: give --id (or --oid/--FileRef) OR --path, not both")
        if args.target is not None and (args.id is not None or args.path):
            die("details: give a target OR --id/--path, not both")
        if args.id is not None:
            _hoid, _fid = _parse_id_ref(args.id)
            if _fid == 0:
                det_oid = _hoid
            else:
                _ent = _resolve_id_entry(f, ps, cs, tr, obj_map, _hoid, _fid)
                if _ent is None:
                    print(f"no object for --id {args.id}", file=sys.stderr); f.close(); sys.exit(1)
                det_path = _ent["path"]
        elif args.path:
            det_path = args.path
        elif args.target is not None:
            t = args.target
            if t.startswith("/"):
                det_path = t
            elif t[:2].lower() == "0x":
                try:
                    det_oid = int(t, 16)
                except ValueError:
                    die(f"details: invalid OID {t!r}")
            else:
                die("details: target must start with '/' (path) or '0x' (OID), or use --path/--oid")
        else:
            die("details: provide a /path, a 0xOID, or --path/--oid")
        if det_oid is None:
            # path mode: a directory has its own OID (-> OID detail below); a FILE has none, so we
            # show its full record (F6) by walking to the matching entry (full enrichment, consistent
            # with `files`). Sub-directories keep the richer OID/$SI view.
            _poid, _pkd, _pvd = resolve_path(f, ps, cs, tr, obj_map, det_path)
            if _pkd is None:
                print(f"path not found: {det_path}", file=sys.stderr); f.close(); sys.exit(1)
            # A directory is ALWAYS non-resident (value <= 84 B) with the dir-bit at value+0x40.
            # A resident entry (>84 B) is always a FILE — its +0x40 is access_time, not file_attrs,
            # so the dir-bit must NOT be tested there (that mis-routed resident files as dirs).
            if (len(_pvd) <= NON_RESIDENT_MAX_VALUE and len(_pvd) >= 0x44
                    and (le32(_pvd, 0x40) & 0x10000000)):
                det_oid = le64(_pvd, 0x08)
            else:
                # FILE by path (F6): find the enriched entry in the walk, print/JSON its detail.
                norm = det_path.lstrip("/")
                log(f"[{PROG}] Resolving file {det_path}...")
                results = walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, args.depth, True, set())
                match = next((r for r in results if r.get("path") == norm), None)
                if match is None:
                    print(f"path not found: {det_path}", file=sys.stderr); f.close(); sys.exit(1)
                sd_map = build_security_map(f, ps, cs, tr, obj_map)
                oid2path = _build_oid2path(results)   # CreationDir (HomeOID → path), same as `files`
                # EA source: the resident value carries the embedded $EA sub-records directly; a
                # non-resident file's EAs are in its type-0x40 backing (fetched by home/parent + file_id).
                if match.get("is_resident"):
                    ea_src = _pvd
                else:
                    _fsz = match.get("file_size")
                    ea_src = (fetch_t40_backing(f, ps, cs, tr, obj_map, match.get("home_oid") or 0, match.get("file_id") or 0, _fsz)
                              or fetch_t40_backing(f, ps, cs, tr, obj_map, match.get("parent_oid") or 0, match.get("file_id") or 0, _fsz))
                if args.json:
                    rec = _build_record(match, sd_map, version_str, oid2path)
                    eas, packed = extract_eas_from_value(ea_src) if ea_src is not None else (None, None)
                    if eas is not None:
                        rec["packed_ea_size"] = packed
                        # oracle gate (see _print_file_detail): only emit the list/WSL when it reconciles.
                        if sum(5 + len(e["name"]) + len(e["value"]) for e in eas) == packed:
                            rec["extended_attributes"] = [{"name": e["name"], "length": len(e["value"]),
                                                           "value_hex": e["value"].hex()} for e in eas]
                            wsl = decode_wsl_eas(eas)
                            if wsl:
                                wj = dict(wsl)
                                if "mode" in wsl: wj["mode_decoded"] = decode_lx_mode(wsl["mode"])
                                rec["wsl"] = wj
                        else:
                            rec["extended_attributes"] = None
                    _ifl = internal_flags_str(match.get("internal_flags", 0))
                    if _ifl:
                        rec["internal_flags"] = _ifl
                    _emit_json_obj(rec, _native_fmt_dest(args)[1], "record")
                elif args.csv is not None or args.jsonl is not None:
                    # D7: one row in the `files` schema — same columns, so a details row can sit alongside a
                    # files export without reshaping.
                    _fmt = "csv" if args.csv is not None else "jsonl"
                    _dest = _native_fmt_dest(args)[1]
                    _row = _csv_fields(match, sd_map, version_str, oid2path)
                    _emit_records([_row], CSV_COLUMNS, _fmt, _dest or "-", "record")
                else:
                    _print_file_detail(match, sd_map, version_str, raw_value=ea_src, oid2path=oid2path)
                f.close()
                return
        log(f"[{PROG}] Looking up OID 0x{det_oid:x}...")
        # Resolve the directory's own path so its detail can lead with the same identity block a file gets.
        try:
            _oid_path = build_oid_path_map(f, ps, cs, tr, obj_map).get(det_oid)
        except Exception:
            _oid_path = None
        try:
            _oid_sd = build_security_map(f, ps, cs, tr, obj_map)   # so a directory resolves owner/group too
        except Exception:
            _oid_sd = None
        detail = cmd_oid_detail(f, ps, cs, tr, obj_map, vmaj, vmin, det_oid, log_fn=log)
        if detail is None:
            print(f"OID 0x{det_oid:x} not found in object table ({len(obj_map)} objects).", file=sys.stderr)
            print("Use `forefst <image> search <name>` to find files by name.", file=sys.stderr)
            f.close()
            sys.exit(1)
        if "error" in detail:
            print(f"Error reading OID 0x{det_oid:x}: {detail['error']}", file=sys.stderr)
            f.close()
            sys.exit(1)
        if args.json is not None:
            _emit_json_obj(detail, _native_fmt_dest(args)[1], "detail")
        elif args.csv is not None or args.jsonl is not None:
            # D7: a directory row in the `files` schema, so --csv/--jsonl mean the same thing for a directory
            # as for a file. Resolved from the same walk `files` uses, rather than reshaping the structural
            # detail, so every column is populated identically.
            _fmt = "csv" if args.csv is not None else "jsonl"
            _res = walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, args.depth, True, set())
            _m = next((r for r in _res if r.get("is_dir") and r.get("oid") == det_oid), None)
            if _m is None:
                print(f"OID 0x{det_oid:x} is not a directory in the tree — use --json for its structure.",
                      file=sys.stderr); f.close(); sys.exit(1)
            _row = _csv_fields(_m, _oid_sd or {}, version_str, _build_oid2path(_res))
            _emit_records([_row], CSV_COLUMNS, _fmt, _native_fmt_dest(args)[1] or "-", "record")
        else:
            _print_oid_detail(detail, path=_oid_path, sd_map=_oid_sd)
        f.close()
        return

    # search subcommand
    if args.command == "search":
        pattern = args.target
        if not pattern:
            die("search: provide a PATTERN (forefst <image> search PATTERN)")
        log(f"[{PROG}] Searching for \"{pattern}\"...")
        # Deleted/Trash objects are surfaced by the `deleted` command (use `deleted --search PATTERN`);
        # `search` covers the live tree only.
        matches = cmd_search(f, ps, cs, tr, obj_map, vmaj, vmin, pattern,
                             regex_mode=args.regex, filter_cat=args.filter)
        if isinstance(matches, dict) and "error" in matches:
            print(matches["error"], file=sys.stderr)
            f.close()
            sys.exit(1)
        _sfmt, _sdest = _native_fmt_dest(args)
        if args.json is not None or args.jsonl is not None or args.csv is not None:
            # Phase C: `id` leads — a directory's OID or a file's FileRef, the value a reader can pass to
            # `details --id`. `oid` is kept for compatibility but now holds a real OID or nothing; it used to
            # carry the placeholder strings "(resident)"/"(non-res)", which are not identifiers.
            _scols = ["id", "oid", "parent_oid", "type", "file_size", "is_resident", "modified", "path",
                      "is_deleted"]
            for _m in matches:
                if not str(_m.get("oid", "")).startswith("0x"):
                    _m["oid"] = ""
            _emit_records(matches, _scols, _sfmt, _sdest or "-", "matches")
        else:
            _print_search(matches, pattern)
        f.close()
        return

    # Build security descriptor map — always: SecurityId->Owner SID is part of the standard listing now
    # (the former --enrich-only resolution is unconditional; see walk_directory_tree enrichment).
    log(f"[{PROG}] Building security descriptor map...")
    sd_map = build_security_map(f, ps, cs, tr, obj_map)
    log(f"[{PROG}] {len(sd_map)} security descriptors loaded")

    # Deleted-file recovery lives solely in the `deleted` command; the files listing walks the LIVE tree
    # only (no Trash/orphan/checkpoint/slack scan). trash_set stays empty.
    trash_set = set()

    # Walk directory tree
    log(f"[{PROG}] Walking directory tree...")
    results = walk_directory_tree(f, ps, cs, tr, obj_map, 0x600, args.depth,
                                  True, trash_set)
    ndirs = sum(1 for r in results if r["is_dir"])
    nfiles = sum(1 for r in results if not r["is_dir"])
    nresident = sum(1 for r in results if not r["is_dir"] and r.get("is_resident"))
    nnonres = nfiles - nresident
    # D1: the file partition (resident + non-resident = files). The hard-link/special counts go on their own
    # line below so nothing looks like a partition it isn't.
    log(f"[{PROG}] {ndirs} dirs, {nfiles} files ({nresident} inline + {nnonres} extent-backed)")
    # Special-file categories — SAME predicates as `specials` (A3 consistency), so the counts always agree.
    _spc = {name: sum(1 for r in results if pred(r)) for name, _d, pred in SPECIALS_TYPES}
    _hlg = len({tuple(sorted(r.get("hard_link_names") or [f"oid:{r.get('oid')}"]))
                for r in results if r.get("hard_link_count", 1) > 1})
    log(f"[{PROG}] hard-linked: {_hlg} files sharing {_spc['hardlink']} names · ADS: {_spc['ads']}"
        f" · reparse: {_spc['reparse']} · WSL: {_spc['wsl']} · sparse: {_spc['sparse']}"
        f" · encrypted: {_spc['encrypted']} · compressed: {_spc['compressed']}"
        f" · integrity: {_spc['integrity']} · EA: {_spc['ea']} · snapshots: {_spc['snapshot']}")

    # Forward CoW version recovery (cross-image comparison)
    if args.cow_before:
        log(f"[{PROG}] Performing forward CoW version recovery...")
        # C16: the before-image's partition offset is its OWN (--cow-partition-start), not the main
        # image's args.partition_start (which was wrongly forced onto the before-image). Default None =>
        # auto-detect the before-image's GPT. NOTE: the CoW-recovery path is lightly tested.
        cow_entries = cow_recovery(f, ps, cs, tr, obj_map,
                                    args.cow_before, args.cow_partition_start, log)
        if cow_entries:
            # For modified files, use the current path from the main walk
            oid_to_path = {r["oid"]: r["path"] for r in results if r.get("oid")}
            oid_to_name = {r["oid"]: r["name"] for r in results if r.get("oid")}
            for ce in cow_entries:
                if ce["deletion_source"] == "cow_modified" and ce["oid"] in oid_to_path:
                    current_path = oid_to_path[ce["oid"]]
                    ce["path"] = f"$COW_PREVIOUS/{current_path}"
                    parent = os.path.dirname(current_path)
                    ce["parent_path"] = f"$COW_PREVIOUS/{parent}" if parent else "$COW_PREVIOUS"
                    # Recover name from current tree if B+ tree had no 0x30 entry
                    if ce["name"].startswith("OID_0x") and ce["oid"] in oid_to_name:
                        ce["name"] = oid_to_name[ce["oid"]]
            log(f"[{PROG}] {len(cow_entries)} previous-version entries recovered via CoW")
            results.extend(cow_entries)

    # F13: --filter — subset the listing by attribute category (after deleted/CoW so the filter
    # applies to the full set). Output stays the normal files format, just the matching rows.
    if args.filter:
        _pred = FILE_FILTERS[args.filter]
        results = [r for r in results if _pred(r)]
        log(f"[{PROG}] --filter {args.filter}: {len(results)} matching entries")

    # Output — --csv/--json/--jsonl [FILE] (bare=stdout), --body, or -o; resolved uniformly.
    fmt, dest = _native_fmt_dest(args)
    out, _close = _native_out(dest)
    try:
        if fmt == "body":
            emit_body(results, out)
        elif fmt == "json":
            emit_json(results, sd_map, version_str, out)
        elif fmt == "jsonl":
            emit_jsonl(results, sd_map, version_str, out)
        else:
            emit_csv(results, sd_map, version_str, out)
    finally:
        if _close:
            out.close()
        f.close()

    ndeleted = sum(1 for r in results if r.get("is_deleted"))
    if dest:
        print(f"Wrote {len(results)} entries to {dest}")
    log(f"[{PROG}] Done. {len(results)} entries ({ndeleted} deleted) -> {fmt.upper()} {dest or '(stdout)'}")

if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        # A downstream reader closed the pipe early (e.g. `| head`, or `| more` then `q`). Redirect stdout to
        # devnull so the interpreter's flush-on-exit does not raise a second BrokenPipeError + traceback.
        try:
            devnull = os.open(os.devnull, os.O_WRONLY)
            os.dup2(devnull, sys.stdout.fileno())
        except Exception:
            pass
        sys.exit(0)
    except KeyboardInterrupt:
        sys.exit(130)
